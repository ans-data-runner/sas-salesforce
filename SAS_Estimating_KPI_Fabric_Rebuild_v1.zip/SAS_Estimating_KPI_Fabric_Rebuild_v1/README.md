# SAS Estimating KPI Fabric Rebuild v1

This package is deliberately limited to the **Estimating Team** report.

It amends the approach in the supplied notebooks rather than rebuilding the whole KPI
programme. The final target remains:

`wh_sas_gold.salesforce.fact_kpi_result_v2`

There is no Gold `staging` schema, no Gold staging table, and no Lakehouse shortcut into a
Gold staging schema.

## Architecture

```text
bronze_lakehouse
  dbo.Estimating Request
  dbo.User
  dbo.Record Type
  dbo.Quote
  dbo.Quote Line
          |
          v
lh_sas_silver
  salesforce.fact_estimating
  salesforce.fact_estimating_quote
  salesforce.fact_estimating_quote_line
  kpi.dim_department
  kpi.dim_kpi
  kpi.fact_kpi_target
  kpi.fact_kpi_commentary
  kpi.fact_estimating_kpi
          |
          v
wh_sas_gold
  etl.usp_load_estimating_kpi_results
          |
          v
  salesforce.fact_kpi_result_v2
  salesforce.vw_estimating_kpi_report
```

## Correct KPI mappings

| Category | KPI | Salesforce source | Weekly calculation |
|---|---|---|---|
| Productivity | Quotes Issues | Estimating Request | Count distinct requests by `Date_Closed__c` customer week |
| Delivery | Quotes Issues on Time | Estimating Request | `SUM(on_time_flag) / COUNT(closed requests) * 100`, where closed date is on/before `Complete_By_Date__c` |
| Quality | Estimated Hours | Estimating Request | Average `Hours_Taken_to_Close__c` for positive/nonblank hours |
| Cost | Rate of Sales per square meter | Quote + Quote Line | Unweighted average `Quote Line.Sqm_Rate__c`, excluding `Item_SQM__c < 0.03` |

## Corrections to the supplied Estimating notebook

The existing notebook references fields such as `Estimate Request No.`, `Opened_Date`,
`Closed_Date`, `Estimated_Hours`, `Complete By Date`, `Date/Time Closed`, `Item_SQM`,
`Net_Total` and `Line_SQM`. Those are workbook/report labels rather than the API field names
shown in the Bronze schema.

It also:

- uses Spark `weekofyear` instead of the existing customer calendar;
- sums estimating hours instead of taking the workbook average of positive hours;
- calculates weighted `SUM(Net Total) / SUM(Line SQM)` instead of the workbook's unweighted
  average of line-level £/SQM;
- references undefined dataframes and an undefined existing KPI result;
- assumes a Gold staging route.

The replacement notebooks correct those points.

## Important £/SQM limitation

The workbook contains a separate Salesforce Quote Line export for each week but does not
include the report's date filter. The code therefore:

1. maps every quote line to both `Quote_Date__c` and `Closed_Date__c`;
2. selects the working date with `p_cost_reporting_date_column`;
3. defaults to `Quote_Date__c`;
4. includes a validation diagnostic comparing both candidates with workbook weeks 32-42.

If neither date reproduces the workbook, the missing dependency is the Salesforce report
definition or a retained weekly Quote Line snapshot. The notebook does not invent a filter.

## Notebook run order

1. Attach schema-enabled `lh_sas_silver` as the default Lakehouse.
2. Ensure `dbo.dim_date` is populated using the customer week calendar.
3. Run `00_create_estimating_silver_objects.ipynb`.
4. Run `10_build_fact_estimating.ipynb`.
5. Run `11_build_fact_estimating_quote_line.ipynb`.
6. Run `20_build_fact_estimating_kpi.ipynb`.
7. Run `90_validate_estimating_week42.ipynb`.
8. In `wh_sas_gold`, run the SQL scripts in numeric order.
9. Load 2025:

```sql
EXEC etl.usp_load_estimating_kpi_results @reporting_year = 2025;
```

10. Refresh the Power BI semantic model against
    `salesforce.fact_kpi_result_v2` or `salesforce.vw_estimating_kpi_report`.

## Production parameter changes

For a normal current run, set:

```python
p_as_of_date = None
p_load_batch_id = "<pipeline run id>"
```

When Bronze moves:

```python
p_bronze_lakehouse = "lh_sas_bronze"
```

The Bronze table resolver tries both the current non-schema naming and future `dbo` schema
naming.

## Output fields added for the report

The Gold extension script adds nullable fields for:

- owner;
- status;
- completed up to week;
- current week;
- submission;
- department;
- KPI code;
- measure;
- UOM;
- sign;
- commentary;
- week state;
- data status;
- source lineage;
- source row count;
- load batch ID.

The existing Proposal columns remain in place.
