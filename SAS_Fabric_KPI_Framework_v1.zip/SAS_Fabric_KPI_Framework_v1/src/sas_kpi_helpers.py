"""Shared helpers for the SAS Fabric KPI framework.
Copy this file to /lakehouse/default/Files/kpi_framework/src/ in lh_sas_silver.
"""
from functools import reduce
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import SparkSession


def quote_ident(name):
    return "`" + str(name).replace("`", "``") + "`"


def table_name(schema, table):
    return f"{quote_ident(schema)}.{quote_ident(table)}"


def source_candidates(lakehouse, schema, table):
    # Covers schema-enabled and legacy/default-schema Lakehouses.
    return [
        f"{quote_ident(lakehouse)}.{quote_ident(schema)}.{quote_ident(table)}",
        f"{quote_ident(lakehouse)}.{quote_ident(table)}",
        f"{quote_ident(schema)}.{quote_ident(table)}",
        quote_ident(table),
    ]


def read_first_existing(spark, candidates, required=True):
    errors=[]
    for candidate in candidates:
        try:
            df=spark.table(candidate)
            print(f"Using table: {candidate}")
            return df, candidate
        except Exception as exc:
            errors.append(f"{candidate}: {exc}")
    if required:
        raise RuntimeError("No candidate table could be read:\n" + "\n".join(errors))
    return None, None


def first_existing_col(df, *candidates, default_type="string"):
    lookup={c.lower():c for c in df.columns}
    for c in candidates:
        if c.lower() in lookup:
            return F.col(quote_ident(lookup[c.lower()]))
    return F.lit(None).cast(default_type)


def require_columns(df, columns, object_name):
    missing=[c for c in columns if c not in df.columns]
    if missing:
        raise ValueError(f"{object_name} is missing required columns: {missing}. Available: {df.columns}")


def stable_key(*columns):
    safe=[F.coalesce(c.cast("string"), F.lit("")) for c in columns]
    return F.abs(F.xxhash64(F.concat_ws("|", *safe)))


def with_customer_week(df, event_date_col, dim_date_table="dbo.dim_date", prefix=""):
    active_spark=SparkSession.getActiveSession()
    if active_spark is None:
        raise RuntimeError("No active SparkSession is available")
    d=(active_spark.table(dim_date_table)
       .select(
           F.col("calendar_date").alias(f"{prefix}calendar_date"),
           F.col("date_key").cast("int").alias(f"{prefix}date_key"),
           F.col("week_key").cast("int").alias(f"{prefix}week_key"),
           F.col("customer_year").cast("int").alias(f"{prefix}reporting_year"),
           F.col("customer_week_no").cast("int").alias(f"{prefix}reporting_week"),
           F.col("week_start_date").alias(f"{prefix}week_start_date"),
           F.col("week_end_date").alias(f"{prefix}week_ending_date"),
       ))
    return (df.withColumn("__event_date", F.to_date(event_date_col))
            .join(d, F.col("__event_date") == F.col(f"{prefix}calendar_date"), "left")
            .drop("__event_date", f"{prefix}calendar_date"))


def normalise_percentage(column):
    s=F.regexp_replace(F.trim(column.cast("string")), "%", "")
    n=s.cast("double")
    return (F.when(n.isNull(), F.lit(None).cast("double"))
            .when(n.between(0,1), n*100.0)
            .otherwise(n))


def merge_delta(spark, df, target_table, key_columns):
    if not key_columns:
        raise ValueError("key_columns must not be empty")
    try:
        exists=spark.catalog.tableExists(target_table)
    except Exception:
        exists=False
    if not exists:
        (df.write.format("delta").mode("overwrite").saveAsTable(target_table))
        print(f"Created {target_table}: {df.count()} rows")
        return
    condition=" AND ".join([f"t.{quote_ident(c)} <=> s.{quote_ident(c)}" for c in key_columns])
    (DeltaTable.forName(spark,target_table).alias("t")
     .merge(df.alias("s"),condition)
     .whenMatchedUpdateAll()
     .whenNotMatchedInsertAll()
     .execute())
    print(f"Merged {df.count()} source rows into {target_table}")


def observation_frame(df, kpi_code, department_code, site_code="ALL",
                      actual_col="actual_value", numerator_col=None, denominator_col=None,
                      source_system="", source_object="", data_status_col=None,
                      commentary_col=None, source_quality_flag="OK", load_batch_id=None):
    numerator = F.col(numerator_col) if numerator_col else F.lit(None).cast("decimal(28,8)")
    denominator = F.col(denominator_col) if denominator_col else F.lit(None).cast("decimal(28,8)")
    data_status = F.col(data_status_col) if data_status_col else F.when(F.col(actual_col).isNull(),F.lit("NO_DATA")).otherwise(F.lit("ACTUAL"))
    commentary = F.col(commentary_col) if commentary_col else F.lit(None).cast("string")
    batch=load_batch_id or "interactive"
    out=(df
        .withColumn("kpi_code",F.lit(kpi_code))
        .withColumn("department_code",F.lit(department_code))
        .withColumn("site_code",F.lit(site_code))
        .withColumn("actual_value",F.col(actual_col).cast("decimal(28,8)"))
        .withColumn("numerator_value",numerator.cast("decimal(28,8)"))
        .withColumn("denominator_value",denominator.cast("decimal(28,8)"))
        .withColumn("data_status",data_status.cast("string"))
        .withColumn("commentary",commentary.cast("string"))
        .withColumn("source_system",F.lit(source_system))
        .withColumn("source_object",F.lit(source_object))
        .withColumn("source_quality_flag",F.lit(source_quality_flag))
        .withColumn("load_batch_id",F.lit(batch))
        .withColumn("calculation_timestamp",F.current_timestamp())
        .withColumn("observation_key",stable_key(F.col("kpi_code"),F.col("site_code"),F.col("week_key")))
        .select("observation_key","kpi_code","department_code","site_code","week_key","week_ending_date","reporting_year","reporting_week",
                "actual_value","numerator_value","denominator_value","source_row_count","data_status","commentary","source_system","source_object",
                "source_quality_flag","load_batch_id","calculation_timestamp"))
    return out


def union_all(frames):
    if not frames:
        raise ValueError("No frames supplied")
    return reduce(lambda a,b:a.unionByName(b,allowMissingColumns=True),frames)
