/* 10_refresh_dimensions.sql */
CREATE OR ALTER PROCEDURE reporting.usp_refresh_kpi_dimensions
AS
BEGIN
    SET NOCOUNT ON;
    MERGE reporting.dim_department AS t
    USING staging.dim_department AS s ON t.department_code=s.department_code
    WHEN MATCHED THEN UPDATE SET department_key=s.department_key,department_name=s.department_name,owner_name=s.owner_name,submission_frequency=s.submission_frequency,reporting_lag_weeks=s.reporting_lag_weeks,is_active=s.is_active,updated_ts=s.updated_ts
    WHEN NOT MATCHED THEN INSERT (department_key,department_code,department_name,owner_name,submission_frequency,reporting_lag_weeks,is_active,created_ts,updated_ts)
      VALUES (s.department_key,s.department_code,s.department_name,s.owner_name,s.submission_frequency,s.reporting_lag_weeks,s.is_active,s.created_ts,s.updated_ts);

    MERGE reporting.dim_site AS t
    USING staging.dim_site AS s ON t.site_code=s.site_code
    WHEN MATCHED THEN UPDATE SET site_key=s.site_key,site_name=s.site_name,is_active=s.is_active,updated_ts=s.updated_ts
    WHEN NOT MATCHED THEN INSERT (site_key,site_code,site_name,is_active,created_ts,updated_ts)
      VALUES (s.site_key,s.site_code,s.site_name,s.is_active,s.created_ts,s.updated_ts);

    MERGE reporting.dim_kpi AS t
    USING staging.dim_kpi AS s ON t.kpi_code=s.kpi_code
    WHEN MATCHED THEN UPDATE SET kpi_key=s.kpi_key,department_code=s.department_code,category=s.category,kpi_name=s.kpi_name,measure=s.measure,uom=s.uom,breach_direction=s.breach_direction,target_method=s.target_method,reporting_lag_weeks=s.reporting_lag_weeks,amber_tolerance_pct=s.amber_tolerance_pct,display_order=s.display_order,is_headline=s.is_headline,source_system=s.source_system,source_object=s.source_object,calculation_description=s.calculation_description,is_active=s.is_active,updated_ts=s.updated_ts
    WHEN NOT MATCHED THEN INSERT (kpi_key,kpi_code,department_code,category,kpi_name,measure,uom,breach_direction,target_method,reporting_lag_weeks,amber_tolerance_pct,display_order,is_headline,source_system,source_object,calculation_description,is_active,created_ts,updated_ts)
      VALUES (s.kpi_key,s.kpi_code,s.department_code,s.category,s.kpi_name,s.measure,s.uom,s.breach_direction,s.target_method,s.reporting_lag_weeks,s.amber_tolerance_pct,s.display_order,s.is_headline,s.source_system,s.source_object,s.calculation_description,s.is_active,s.created_ts,s.updated_ts);
END;
GO
