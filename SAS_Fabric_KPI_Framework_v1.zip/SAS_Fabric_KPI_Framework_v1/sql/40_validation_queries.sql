/* 40_validation_queries.sql */
-- Duplicate business grain: must return no rows.
SELECT kpi_key,site_key,week_key,COUNT(*) AS row_count
FROM reporting.fact_kpi_result
GROUP BY kpi_key,site_key,week_key
HAVING COUNT(*)>1;

-- Missing key/metadata checks.
SELECT
 SUM(CASE WHEN department_key IS NULL THEN 1 ELSE 0 END) AS null_department_key,
 SUM(CASE WHEN site_key IS NULL THEN 1 ELSE 0 END) AS null_site_key,
 SUM(CASE WHEN kpi_key IS NULL THEN 1 ELSE 0 END) AS null_kpi_key,
 SUM(CASE WHEN week_key IS NULL THEN 1 ELSE 0 END) AS null_week_key
FROM reporting.fact_kpi_result;

-- Data quality/status overview.
SELECT department,kpi_name,source_quality_flag,data_status,COUNT(*) AS weeks
FROM reporting.fact_kpi_result
GROUP BY department,kpi_name,source_quality_flag,data_status
ORDER BY department,kpi_name,source_quality_flag,data_status;

-- Current report extract.
SELECT * FROM reporting.vw_kpi_report
WHERE reporting_year=YEAR(GETDATE())
ORDER BY department,display_order,week_ending_date;
