/* 20_refresh_fact_kpi_result.sql */
CREATE OR ALTER PROCEDURE reporting.usp_refresh_fact_kpi_result
AS
BEGIN
    SET NOCOUNT ON;
    MERGE reporting.fact_kpi_result AS t
    USING staging.fact_kpi_result_stage AS s
      ON t.kpi_result_key=s.kpi_result_key
    WHEN MATCHED THEN UPDATE SET
      date_key=s.date_key,week_key=s.week_key,week_ending_date=s.week_ending_date,week_start_date=s.week_start_date,
      reporting_year=s.reporting_year,reporting_week=s.reporting_week,department_key=s.department_key,site_key=s.site_key,kpi_key=s.kpi_key,
      status=s.status,complete_up_to_week=s.complete_up_to_week,current_week=s.current_week,submission_frequency=s.submission_frequency,
      department=s.department,category=s.category,kpi_name=s.kpi_name,measure=s.measure,uom=s.uom,sign=s.sign,commentary=s.commentary,
      target_value=s.target_value,actual_value=s.actual_value,variance_value=s.variance_value,performance_variance_value=s.performance_variance_value,
      rag_status=s.rag_status,data_status=s.data_status,numerator_value=s.numerator_value,denominator_value=s.denominator_value,
      source_row_count=s.source_row_count,source_system=s.source_system,source_object=s.source_object,source_quality_flag=s.source_quality_flag,
      calculation_timestamp=s.calculation_timestamp,load_batch_id=s.load_batch_id
    WHEN NOT MATCHED THEN INSERT (
      kpi_result_key,date_key,week_key,week_ending_date,week_start_date,reporting_year,reporting_week,department_key,site_key,kpi_key,
      status,complete_up_to_week,current_week,submission_frequency,department,category,kpi_name,measure,uom,sign,commentary,
      target_value,actual_value,variance_value,performance_variance_value,rag_status,data_status,numerator_value,denominator_value,
      source_row_count,source_system,source_object,source_quality_flag,calculation_timestamp,load_batch_id)
    VALUES (
      s.kpi_result_key,s.date_key,s.week_key,s.week_ending_date,s.week_start_date,s.reporting_year,s.reporting_week,s.department_key,s.site_key,s.kpi_key,
      s.status,s.complete_up_to_week,s.current_week,s.submission_frequency,s.department,s.category,s.kpi_name,s.measure,s.uom,s.sign,s.commentary,
      s.target_value,s.actual_value,s.variance_value,s.performance_variance_value,s.rag_status,s.data_status,s.numerator_value,s.denominator_value,
      s.source_row_count,s.source_system,s.source_object,s.source_quality_flag,s.calculation_timestamp,s.load_batch_id);
END;
GO

CREATE OR ALTER PROCEDURE reporting.usp_refresh_all_kpi
AS
BEGIN
  SET NOCOUNT ON;
  EXEC reporting.usp_refresh_kpi_dimensions;
  EXEC reporting.usp_refresh_fact_kpi_result;
END;
GO
