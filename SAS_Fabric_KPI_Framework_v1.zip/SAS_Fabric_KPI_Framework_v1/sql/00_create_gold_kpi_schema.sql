/* 00_create_gold_kpi_schema.sql
Run in wh_sas_gold. Create OneLake table shortcuts under schema [staging] first for:
  dim_department, dim_site, dim_kpi, fact_kpi_result_stage
from lh_sas_silver (kpi schema).
*/
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name='reporting')
    EXEC('CREATE SCHEMA reporting');
GO

IF OBJECT_ID('reporting.dim_department','U') IS NULL
BEGIN
CREATE TABLE reporting.dim_department (
    department_key BIGINT NOT NULL,
    department_code VARCHAR(50) NOT NULL,
    department_name VARCHAR(200) NOT NULL,
    owner_name VARCHAR(200) NULL,
    submission_frequency VARCHAR(30) NULL,
    reporting_lag_weeks INT NULL,
    is_active BIT NULL,
    created_ts DATETIME2(6) NULL,
    updated_ts DATETIME2(6) NULL
);
END;
GO
IF OBJECT_ID('reporting.dim_site','U') IS NULL
BEGIN
CREATE TABLE reporting.dim_site (
    site_key BIGINT NOT NULL,
    site_code VARCHAR(50) NOT NULL,
    site_name VARCHAR(200) NOT NULL,
    is_active BIT NULL,
    created_ts DATETIME2(6) NULL,
    updated_ts DATETIME2(6) NULL
);
END;
GO
IF OBJECT_ID('reporting.dim_kpi','U') IS NULL
BEGIN
CREATE TABLE reporting.dim_kpi (
    kpi_key BIGINT NOT NULL,
    kpi_code VARCHAR(100) NOT NULL,
    department_code VARCHAR(50) NOT NULL,
    category VARCHAR(50) NOT NULL,
    kpi_name VARCHAR(250) NOT NULL,
    measure VARCHAR(1000) NULL,
    uom VARCHAR(100) NULL,
    breach_direction VARCHAR(20) NULL,
    target_method VARCHAR(50) NULL,
    reporting_lag_weeks INT NULL,
    amber_tolerance_pct DECIMAL(9,6) NULL,
    display_order INT NULL,
    is_headline BIT NULL,
    source_system VARCHAR(100) NULL,
    source_object VARCHAR(300) NULL,
    calculation_description VARCHAR(2000) NULL,
    is_active BIT NULL,
    created_ts DATETIME2(6) NULL,
    updated_ts DATETIME2(6) NULL
);
END;
GO
IF OBJECT_ID('reporting.fact_kpi_result','U') IS NULL
BEGIN
CREATE TABLE reporting.fact_kpi_result (
    kpi_result_key BIGINT NOT NULL,
    date_key INT NULL,
    week_key INT NOT NULL,
    week_ending_date DATE NOT NULL,
    week_start_date DATE NULL,
    reporting_year INT NOT NULL,
    reporting_week INT NOT NULL,
    department_key BIGINT NOT NULL,
    site_key BIGINT NOT NULL,
    kpi_key BIGINT NOT NULL,
    status VARCHAR(30) NULL,
    complete_up_to_week INT NULL,
    current_week INT NULL,
    submission_frequency VARCHAR(30) NULL,
    department VARCHAR(200) NULL,
    category VARCHAR(50) NULL,
    kpi_name VARCHAR(250) NULL,
    measure VARCHAR(1000) NULL,
    uom VARCHAR(100) NULL,
    sign VARCHAR(30) NULL,
    commentary VARCHAR(4000) NULL,
    target_value DECIMAL(28,8) NULL,
    actual_value DECIMAL(28,8) NULL,
    variance_value DECIMAL(28,8) NULL,
    performance_variance_value DECIMAL(28,8) NULL,
    rag_status VARCHAR(30) NULL,
    data_status VARCHAR(30) NULL,
    numerator_value DECIMAL(28,8) NULL,
    denominator_value DECIMAL(28,8) NULL,
    source_row_count BIGINT NULL,
    source_system VARCHAR(100) NULL,
    source_object VARCHAR(500) NULL,
    source_quality_flag VARCHAR(100) NULL,
    calculation_timestamp DATETIME2(6) NULL,
    load_batch_id VARCHAR(100) NULL
);
END;
GO
