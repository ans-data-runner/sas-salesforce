# SAS Fabric KPI Framework v1

This package refactors the current Design/Salesforce-specific KPI fact into a reusable, source-neutral framework for **Design, Estimating, SOP and EHS**, with a path for future Syteline KPIs.

## Architecture

`bronze_lakehouse` (later `lh_sas_bronze`) → source adapters in `lh_sas_silver` → `kpi.fact_kpi_observation` → `kpi.fact_kpi_result_stage` → OneLake shortcuts in `wh_sas_gold.staging` → Warehouse stored procedures → `reporting.fact_kpi_result` / `reporting.vw_kpi_report` → Power BI.

The key design choice is to keep **calculation logic in Silver**, where Spark can handle mixed source shapes, and use **Warehouse SQL for controlled merges and the Power BI serving model**.

## Run order

1. Upload this folder to `lh_sas_silver/Files/kpi_framework`.
2. Attach all PySpark notebooks to `lh_sas_silver`.
3. Run `00_create_silver_kpi_framework.ipynb`.
4. Confirm Record Type names and load monthly exchange rates.
5. Run notebooks 10, 11, 12 and 13.
6. Run `20_build_gold_shaped_kpi_stage.ipynb`.
7. In `wh_sas_gold`, create schema shortcuts named `staging.dim_department`, `staging.dim_site`, `staging.dim_kpi`, `staging.fact_kpi_result_stage` from the Silver `kpi` schema.
8. Run SQL files 00, 10, 20 and 30 in order, then `EXEC reporting.usp_refresh_all_kpi;`.
9. Point the Power BI template to `reporting.vw_kpi_report`.
10. Run notebook 90 and SQL 40 for validation.

## Parameterisation

Every notebook has the same parameter cell:

- `p_bronze_lakehouse = "bronze_lakehouse"` — change once to `lh_sas_bronze` after migration.
- `p_bronze_schema = "dbo"`
- `p_silver_lakehouse = "lh_sas_silver"`
- `p_dim_date_table = "dbo.dim_date"`
- `p_run_date`, `p_load_batch_id`

The EHS notebook also parameterises the energy year/file paths and SafetyCulture template filter.

## Required report fields

The Gold fact/view contains: status, complete-up-to week, current week, submission frequency, department, category, KPI/measure, UOM, sign, commentary, week, target, actual, variance, RAG, data status, numerator/denominator, source lineage and calculation timestamp.

## Important source decisions

- Customer weeks always come from `dbo.dim_date`; notebooks do **not** use Spark `weekofyear`.
- Non-GBP proposal values require an exchange rate. They are not silently treated as GBP.
- Targets are weekly/effective-dated because the supplied files contain target changes and conflicts.
- `OVER` amber logic uses `target / 0.95`, matching the spreadsheet formula.
- SOP cleansing/sign-off is grouped by order-created week, matching the workbook. Historic values may restate while orders are open.
- Estimating £/m² uses the exact line-average rule only when `kpi.fact_estimate_sqm_line_input` is populated. Header fallback is labelled.
- EHS Lost Working Days needs the PBIX `EHSIncidentRegister` source ingested or weekly manual input.

## Reference files

- `kpi_catalog_seed.csv`: governed metric definitions.
- `kpi_target_history_seed.csv`: target snapshots extracted from the supplied 2025/2026 workbooks.
- `kpi_excel_actual_history.csv`: workbook actual/RAG snapshots for regression testing.
- `kpi_source_mapping.csv`: automation status, fields and unresolved issues.
