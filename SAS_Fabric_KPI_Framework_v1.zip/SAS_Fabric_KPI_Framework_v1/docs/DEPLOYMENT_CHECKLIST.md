# Deployment checklist

## Silver

- Confirm `lh_sas_silver` is schema-enabled.
- Upload the complete `kpi_framework` folder under Lakehouse Files.
- Mark the first code cell in each notebook as **Parameters**.
- Run setup, then source notebooks, then result stage.
- Load monthly FX rows into `kpi.ref_exchange_rate_monthly`; GBP is seeded automatically.
- Load weekly manual values into `kpi.fact_kpi_manual_input` only for controlled exceptions/FTE/lost days.

## Gold Warehouse

- Run SQL files in numeric order.
- Create the four `staging` shortcuts before executing refresh procedures.
- Execute `reporting.usp_refresh_all_kpi` after the Silver result-stage notebook.
- Use `reporting.vw_kpi_report` as the Power BI source.
- Keep the compatibility view temporarily, then migrate the semantic model away from the `salesforce` schema.

## Pipeline order and retry

1. Bronze ingestion
2. Customer calendar/date dimension
3. KPI setup/reference load (only when definitions change)
4. Design, Estimating, SOP, EHS source notebooks (parallel after Bronze)
5. Gold-shaped stage
6. Warehouse stored procedure
7. Validation
8. Power BI semantic model refresh

Use a single active run for the Warehouse merge and add pipeline retry for transient conflicts.
