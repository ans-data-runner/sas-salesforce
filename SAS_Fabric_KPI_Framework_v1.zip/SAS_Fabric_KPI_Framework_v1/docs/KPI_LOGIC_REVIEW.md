# KPI logic review and implementation decisions

## Why the current `salesforce.fact_kpi_result_v2` should change

The current table is useful but is tied to a single source namespace and only carries a small set of descriptors. The new fact is deliberately source-neutral and preserves numerator, denominator, source-row count, data status, target provenance and source-quality flags. This makes future Syteline additions incremental rather than another bespoke report table.

## Workbook logic preserved

- RAG categories: Green meets target; Amber is within 5% worse; Red is worse; TBC/Blank/No Data/Missed/OD are preserved as data statuses.
- Under-breach/higher-is-better uses target and 95% of target.
- Over-breach/lower-is-better uses target and target divided by 0.95.
- Department submission lag: EHS one week in arrears; Design, Estimating and SOP current week.
- Estimating quality is **average hours to close**, correcting the supplied draft notebook that summed hours.
- Design opportunity value is a per-proposal average after GBP conversion.
- EHS energy is recalculated from kWh and conversion factors rather than trusting a precomputed CSV column.

## Conflicts intentionally not hidden

The supplied files contain evolving definitions and targets. Examples include EHS visual inspection count targets and energy targets, and Estimating £/m² being TBC in one workbook but 75 in the combined workbook. `fact_kpi_target` therefore stores target history/source and a confirmation flag rather than overwriting one value in `dim_kpi`.

## Source gaps requiring customer confirmation

1. Exact Salesforce Record Type labels for Design and Estimating.
2. The monthly FX source and rate convention used by the Design workbook.
3. Exact relationship between `Estimate` and `EstimateOrderLine` for the £/m² metric.
4. Whether Export SOP complaints are included with UK/USA SOP.
5. Weekly SOP FTE man-days source.
6. Ingestion route for the PBIX `EHSIncidentRegister` table.
7. Whether the 2025 EHS m² intensity KPI remains active in 2026.
