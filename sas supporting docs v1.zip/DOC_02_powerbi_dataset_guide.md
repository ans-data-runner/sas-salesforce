# Power BI Dataset & Lineage Guide
**Doc ref:** SAS-KPI-DOC-02 · **Version:** 1.0 · **Date:** 29-07-2026
**Audience:** Power BI developers building the departmental Top 4 KPI reports and detail pages.

---

## 1. What to connect to

Connect to `wh_sas_gold` (SQL endpoint, or DirectLake on the warehouse). Everything the Top 4 template needs is served by **two views**; the underlying dims/fact are also exposed if you prefer a star model in the semantic layer.

| Object | Grain | Use it for |
|---|---|---|
| `kpi.vw_kpi_report` | KPI × week | The matrix body: every attribute and value the template shows |
| `kpi.vw_kpi_report_header` | Department | The header block: Status / Submission / Current week / Completed up to week |
| `kpi.dim_department`, `kpi.dim_kpi`, `kpi.dim_week`, `kpi.fact_kpi_result` | star | Optional: model as a star instead of the flat view |
| silver `slv_ehs_inspection` | audit | "Visual checks – last 7 days" detail page |
| silver `slv_ehs_accident` | accident | "Lost working days" detail page |

Do **not** report from `stg.*` (transient, cleared by the load proc) or from the legacy `[salesforce].[fact_kpi_result_v2]` (kept only for parallel-run comparison).

## 2. Column dictionary — `kpi.vw_kpi_report`

**Slicers / rows**

| Column | Maps to template | Notes |
|---|---|---|
| `department_code / department_name / manager` | Report page + Owner | One report page (or report) per department |
| `category` | Category | Productivity · Delivery · Quality · Cost |
| `kpi_code` | — | Customer lookup driver (`EHS-KPI P1`); stable key for bookmarks/drill-through |
| `kpi` / `measure` | KPI / Measure | Name and long description |
| `uom`, `sign`, `frequency` | UOM / Sign | `frequency` 'W' or 'M' — filter monthly KPIs off weekly matrices |
| `kpi_commentary` | Commentary | Per-KPI commentary block (effective-dated) |
| `sort_order` | — | Sort KPIs within a department by this, never alphabetically |
| `decimal_places` | — | Formatting hint per KPI |

**Columns (time)**

| Column | Notes |
|---|---|
| `week_label` | Header row of the matrix ('42', cross-year '48 FY25') — **sort by `week_end_date`** |
| `week_no`, `calendar_year`, `week_end_date` | Customer calendar; Friday week-end ("Date (Fri)" row) |
| `is_current_week`, `is_future_week` | Drive the last-N-weeks filter and grey future columns |

**Values**

| Column | Notes |
|---|---|
| `target_value` | Template Target row (effective-dated: e.g. inspections 100 → 110 from wk2 2026) |
| `actual_value` | Template Actual row |
| `display_value` | **Use this as the shown value**: already switches between `actual_value` and `pct_of_target` per the KPI's `display_mode` — no DAX needed |
| `pct_of_target` | Direction-aware ratio, ≥ 1 always favourable (Under: actual/target; Over: target/actual) |
| `variance_value`, `variance_pct` | Signed actual − target and its % |
| `rag_status` | Template Variance row: 'G' 'A' 'R' 'TBC' or NULL — see §3 |
| `weekly_commentary` | Week-specific note (e.g. accident summary text) |

## 3. RAG conditional formatting

Match the customer legend exactly:

| `rag_status` | Meaning | Fill |
|---|---|---|
| `G` | Better than target | Green |
| `A` | <5% worse than target | Amber |
| `R` | Worse than target | Red |
| `TBC` | **Missing submission** — week was due but no data arrived (already accounts for the department's arrears, e.g. EHS 1 week) | Pink |
| NULL | No submission expected (future week / before KPI go-live / target not yet set) | Blank / grey |

All RAG is computed in the warehouse load procedure — never re-derive it in DAX, or the report and the Excel legend will drift.

## 4. Header block — `kpi.vw_kpi_report_header`

| Column | Template field | Derivation |
|---|---|---|
| `status` | Status | Constant 'Current' |
| `submission` | Submission | From `dim_department` ('Weekly') |
| `arrears_note` | e.g. "1 week in arrears" | From `dim_department.arrears_weeks` |
| `current_week_no / current_week_label` | Current Week | `dim_week.is_current_week` |
| `completed_up_to_week / completed_week_label` | Completed up to week | Latest week with any `actual_value` for the department |

## 5. Lineage (source → report)

```mermaid
flowchart LR
    subgraph BRONZE [bronze_lakehouse → lh_sas_bronze]
        B1[Salesforce extracts<br/>Proposal Request, Estimating Request,<br/>Order Tracking, Quote ...]
        B2[SafetyCultureTest<br/>audit exports]
        B3[Files: EHS energy CSVs<br/>Bridgend / Maybole]
        B4[Files: accident tracker]
        B5[ref_calendar_customer /<br/>dim_date_reference]
    end
    subgraph SILVER [lh_sas_silver]
        S0[dim_date]
        S1[fact_proposal /_delivery<br/>fact_quality_weekly<br/>fact_estimation<br/>fact_sop_kpi_flags]
        S2[slv_ehs_inspection<br/>slv_ehs_inspection_weekly]
        S3[slv_ehs_energy_weekly]
        S4[slv_ehs_accident<br/>slv_ehs_accident_weekly]
        S5[ref_emission_factor]
    end
    subgraph GOLD [wh_sas_gold]
        G0[stg.dim_week] --> G1[kpi.dim_week]
        G2[stg.kpi_result] --> G3[kpi.fact_kpi_result]
        G4[kpi.dim_department<br/>kpi.dim_kpi<br/>kpi.kpi_target<br/>kpi.kpi_commentary]
        G5[kpi.vw_kpi_report]
        G6[kpi.vw_kpi_report_header]
    end
    subgraph PBI [Power BI]
        P1[Top 4 KPI report<br/>matrix + header]
        P2[Visual checks page]
        P3[Lost working days page]
    end
    B5 --> S0 --> G0
    B1 --> S1
    B2 --> S2
    B3 --> S3
    B4 --> S4
    S5 --> S3
    S0 -.week mapping.-> S2 & S3 & S4 & S1
    S1 --> G2
    S2 --> G2
    S3 --> G2
    S4 --> G2
    G1 --> G3
    G4 --> G3
    G3 --> G5 --> P1
    G1 --> G5
    G4 --> G5
    G6 --> P1
    S2 --> P2
    S4 --> P3
```

Per-KPI source lineage is also carried **in the data**: `vw_kpi_report.source_system` (Salesforce / SafetyCulture / ManualCSV / Syteline) and the fact's `source_ref` (the silver table each value came from).

## 6. Which dataset supplies which report element

| Report element | Dataset | Field(s) |
|---|---|---|
| Department header (Owner, Status, Submission, weeks) | `vw_kpi_report_header` | all |
| Matrix rows (Category, KPI, Measure, UOM, Sign, Commentary) | `vw_kpi_report` | dim attributes, `kpi_commentary`, `sort_order` |
| Matrix week columns | `vw_kpi_report` | `week_label` sorted by `week_end_date` |
| Target / Actual / Variance rows | `vw_kpi_report` | `target_value`, `display_value`, `rag_status` |
| Accident Summary block | `vw_kpi_report` (EHS-KPI P1 `weekly_commentary`) or silver `slv_ehs_accident` | |
| Visual checks table & template chart | silver `slv_ehs_inspection` | audit-grain columns incl. `template_name`, `conducted_on` |
| Lost working days table & counters | silver `slv_ehs_accident` | accident-grain columns incl. `lost_days` |

## 7. Refresh & semantic model notes

- The weekly pipeline lands data Monday morning; schedule dataset refresh after `sp_load_fact_kpi_result` (or rely on DirectLake).
- Relationships if star-modelling: `fact_kpi_result[kpi_key] → dim_kpi[kpi_key]`, `fact_kpi_result[week_key] → dim_week[week_key]`, `dim_kpi[department_key] → dim_department[department_key]`. All single-direction, one-to-many.
- `week_key` is the yyyyMMdd integer of the Friday — the same convention as existing gold facts, so cross-fact date joins keep working.
- One template serves every department: page-filter on `department_code`. New departments appear automatically once activated in `kpi.dim_department` / `dim_kpi` and fed by a notebook.
