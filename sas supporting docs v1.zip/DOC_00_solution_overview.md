# SAS KPI Reporting Platform — Solution Overview
**Doc ref:** SAS-KPI-DOC-00 · **Version:** 1.0 · **Date:** 29-07-2026 · **Author:** ANS (Paul, Data Solutions Architect)
**Status:** Living document — updated as further departmental dashboards are onboarded.

---

## 1. Purpose

SAS International report departmental "Top 4" KPIs weekly across 17 departments, historically compiled by hand in Excel (master workbook *Top 4 KPI Reporting*). This solution replaces the manual compilation with a governed Microsoft Fabric pipeline: source data lands in the bronze lakehouse, is standardised in the silver lakehouse, and is served to Power BI from a single generic KPI model in the gold warehouse.

The design principle throughout: **KPIs are rows, not tables.** Adding a department or a KPI never changes the schema, the stored procedures, or the Power BI template — it is reference-data inserts plus one notebook that produces weekly actuals.

## 2. Scope

| Phase | Departments | Source | Status |
|---|---|---|---|
| 1 (current) | EHS, Estimating, SOP, Design & R&D | Salesforce, SafetyCulture, manual energy/accident files | In build |
| 2 (planned) | Remaining 13 departments (Product Design, Product Eng MB/BE, Bridgend/Maybole Manuf, Logistics, Engineering, Quality Maybole, Procurement, IT, Marketing, Finance, HR) | Predominantly Syteline | Pre-seeded inactive in `kpi.dim_kpi` |

All ~70 company KPI definitions from the master workbook are already loaded into the model (inactive where out of scope), so phase 2 onboarding is incremental.

## 3. Architecture at a glance

```
bronze_lakehouse (-> lh_sas_bronze)     lh_sas_silver                  wh_sas_gold                        Power BI
─────────────────────────────────      ────────────────────────       ─────────────────────────────      ───────────────
Salesforce extracts                    dim_date (customer calendar)   stg.dim_week / stg.kpi_result      Top 4 KPI report
SafetyCulture audits          ──►      slv_ehs_* weekly tables  ──►   kpi.dim_department / dim_kpi  ──►  (per department,
ref_calendar_customer                  fact_proposal / estimation     kpi.dim_week / kpi_target          one template)
Energy CSVs / accident tracker         fact_sop_kpi_flags ...         kpi.fact_kpi_result                Detail pages
                                                                      kpi.vw_kpi_report(+_header)        (inspections,
                                                                                                          accidents)
```

Environment names: `bronze_lakehouse` (migrating to `lh_sas_bronze`), `lh_sas_silver`, `wh_sas_gold`. All notebooks resolve these from one config notebook (`nb_000_env_config`), so the bronze rename is a one-line change.

## 4. Business rules encoded in the model

These match the customer's own template legend and master workbook exactly:

- **RAG:** G = better than target · A = less than 5% worse than target (tolerance configurable per KPI) · R = worse than target · **TBC = missing submission** (week was due but no data arrived) · **Blank = no submission expected** (future week, or before the KPI went live).
- **Signs:** *Under Breach* (higher is better), *Over Breach* (lower is better), *Above Zero* (target is zero; any breach is R with no amber band).
- **Display modes:** each KPI shows either its *Act Result* or *% of target* — the direction-aware ratio where ≥ 1 is always favourable.
- **Calendar:** the customer's own calendar (Sat–Fri weeks, week 1 ends the first Friday of January), loaded from `ref_calendar_customer` — never computed.
- **Arrears:** per-department (EHS reports one week in arrears); the missing-submission logic honours it.
- **Emission factors** (EHS cost KPIs): gas 0.20264, electricity 0.20705 kg CO₂e per kWh, versioned in `ref_emission_factor`. Weekly intensity = total CO₂e ÷ site Transfer Price. Validated against the source workbook with zero mismatches.

## 5. Document set

| Ref | Document | Audience |
|---|---|---|
| DOC-00 | Solution Overview (this document) | Customer / all |
| DOC-01 | Notebook Developer Guide | Data engineers |
| DOC-02 | Power BI Dataset & Lineage Guide | Power BI developers |
| DOC-03 | ERD (Mermaid) — bronze / silver / gold | All technical |
| DOC-04 | KPI Onboarding Runbook | Data engineers / delivery |

## 6. Decision log

| # | Date | Decision | Rationale |
|---|---|---|---|
| 1 | 29-07-26 | Single generic `kpi` schema replaces `[salesforce].[fact_kpi_result_v2]` | One model serves 17 departments; onboarding = reference rows + one notebook |
| 2 | 29-07-26 | KPI codes adopt the customer's master-workbook lookup drivers (`EHS-KPI P1`) | Traceability to the artefact the business already owns |
| 3 | 29-07-26 | `week_key` = yyyyMMdd of the Friday week-end | Preserves the existing silver/gold convention; no fact translation |
| 4 | 29-07-26 | Calendar loaded from `ref_calendar_customer`, not computed | Customer calendar is authoritative; avoids fiscal-anchor drift |
| 5 | 29-07-26 | Zero-target KPIs use sign *Above Zero* (no amber) | Matches master workbook behaviour; templates' "Over Breach" wording retained in commentary |
| 6 | 29-07-26 | v2 history migrated via script 06; old table retained for parallel run | De-risked cutover |

## 7. Open items

| # | Item | Owner | Status |
|---|---|---|---|
| 1 | Confirm SafetyCulture bronze table (`SafetyCultureTest`) column coverage | ANS | Open |
| 2 | Confirm accident tracker bronze drop path | ANS / SAS | Open |
| 3 | Confirm `fact_estimation` / `fact_sop_kpi_flags` column names in nb_110 | ANS | Open |
| 4 | SOP C1 FTE headcount source | SAS | Open |
| 5 | Maybole cost KPI target (2.75 per wk42 master vs none in 2026 sheet) | SAS (Neil Laing) | Open |
| 6 | Extend missing-submission back-fill to monthly KPIs before Engineering/Finance/HR onboard | ANS | Backlog |
| 7 | Bronze migration `bronze_lakehouse` → `lh_sas_bronze` | ANS | Planned |
