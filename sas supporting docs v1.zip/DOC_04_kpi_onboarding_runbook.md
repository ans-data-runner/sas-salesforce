# KPI Onboarding Runbook
**Doc ref:** SAS-KPI-DOC-04 · **Version:** 1.0 · **Date:** 29-07-2026
**Audience:** Data engineers / delivery, for each new departmental dashboard (incl. the Syteline phase).

---

The whole point of the generic model: onboarding a KPI or a department is **reference data + one notebook**. Nothing else changes — no gold DDL, no proc changes, no Power BI rework.

## Step 1 — Define (or activate) the reference rows

Most departments are already seeded from the master workbook. Check first:

```sql
SELECT * FROM kpi.dim_department WHERE department_name = '<dept>';
SELECT * FROM kpi.dim_kpi        WHERE kpi_code LIKE '<dept>-KPI%';
```

**If seeded (typical):** set `is_active = 1` on the department and its KPIs, and correct any attribute that has moved since wk42 (target, sign, display_mode, `valid_from` = the Friday of the first reported week).

**If new:** insert following the pattern in `05_seed_kpi_reference.sql`. Rules:
- `kpi_code` = the customer's lookup driver from the master workbook (`<Dept>-KPI P1/D1/Q1/C1`).
- `sign`: 'Under Breach' (higher better) / 'Over Breach' (lower better) / 'Above Zero' (target 0, no amber).
- `display_mode`: 'Act Result' or '% of target' — copy the master workbook's *Shown* column.
- `target_type`: 'Fixed' (+ `default_target`) / 'Weekly' (+ rows in `kpi.kpi_target`, effective-dated by `week_key`) / 'TBC' (no RAG until a target lands).
- `valid_from` matters: it is what separates *Blank* (before go-live) from *TBC* (missing submission) in the report.

## Step 2 — Land the source in bronze (if not already there)

Files under `Files/<domain>/…`, tables via the existing ingestion patterns. Note the path/table name — it is a notebook parameter, never hard-coded.

## Step 3 — Build the weekly silver table

New notebook `nb_0xx_silver_<domain>` following the existing pattern:
1. `%run nb_000_env_config`
2. Parameters cell: bronze source path/table + any filters.
3. Standardise: snake_case columns, typed casts, dedupe on the natural key, `load_datetime`.
4. Persist the detail grain if a report page needs it (`slv_<domain>`).
5. Aggregate to week via join to `get_dim_date()` (**never** `weekofyear()` — the customer calendar is authoritative), one row per `week_end_date` with named actual columns.
6. `save_silver(df, "slv_<domain>_weekly")`.

Every-week KPIs with a zero target (complaints, lost days): left-join onto all elapsed calendar weeks so quiet weeks stage as 0, not as missing.

## Step 4 — Stage the actuals to gold

Add to an existing staging notebook (nb_100/nb_110) or create `nb_1xx_gold_stage_<dept>_kpis`:

```python
stage += [kpi_rows(weekly_df, "<Dept>-KPI P1", "<actual_col>",
                   "<SourceSystem>", "slv_<domain>_weekly")]
...
write_gold_staging(staged, "stg.kpi_result")
```

Leave `target_value` NULL — the proc resolves targets. Never write to `kpi.*` from Spark; never compute RAG in a notebook.

## Step 5 — Wire into the pipeline

Add the silver notebook to the parallel group and the staging notebook before the final `EXEC kpi.sp_load_fact_kpi_result;` activity in `pl_kpi_weekly`.

## Step 6 — Validate

```sql
-- rows landed and RAG behaves
SELECT * FROM kpi.vw_kpi_report
WHERE  department_code = '<dept>' ORDER BY sort_order, week_end_date;

-- reconciliation vs the department's Excel: spot-check 3+ weeks per KPI
-- (actual, target, RAG, and pct_of_target where display_mode = '% of target')

-- missing-submission logic: expect TBC only for due weeks after valid_from
SELECT rag_status, COUNT(*) FROM kpi.vw_kpi_report
WHERE  department_code = '<dept>' GROUP BY rag_status;
```

Acceptance: values match the departmental workbook for the sampled weeks; TBC/Blank pattern matches the legend; the Power BI template shows the department with **zero report changes** beyond the department filter.

## Step 7 — Document

Update DOC-00 (§2 scope table, decision log, open items) and add any source-specific notes to DOC-01 §4. Version-bump the doc headers.

## Monthly KPIs (Engineering, Finance, HR)

Modelled (`frequency = 'M'`, `month_no` on `dim_week`) but two extensions are needed before first monthly onboarding: stage monthly actuals against the last Friday of the customer month, and extend the TBC back-fill in `sp_load_fact_kpi_result` (currently weekly-only) to month grain. Tracked as open item 6 in DOC-00.
