# Notebook Developer Guide
**Doc ref:** SAS-KPI-DOC-01 · **Version:** 1.0 · **Date:** 29-07-2026
**Audience:** Data engineers maintaining or extending the Fabric notebooks.

---

## 1. Environment and conventions

| Item | Value |
|---|---|
| Bronze lakehouse | `bronze_lakehouse` → will become `lh_sas_bronze` |
| Silver lakehouse | `lh_sas_silver` (tables in `dbo`) |
| Gold warehouse | `wh_sas_gold` (schemas `kpi`, `stg`) |
| Week convention | Sat–Fri, `week_key` = yyyyMMdd of the Friday, from the customer calendar |
| Warehouse writes | Spark → warehouse via `synapsesql`, **staging tables only** (`stg.*`) |
| Set-based logic | Always in warehouse stored procedures, never in Spark |

Every notebook begins with `%run nb_000_env_config`. That notebook exposes:

- `BRONZE_LAKEHOUSE / SILVER_LAKEHOUSE / GOLD_WAREHOUSE` — parameters cell, overridable per pipeline notebook-activity. **The bronze rename is done here and nowhere else.**
- `bronze_file(rel)` / `bronze_table(name)` / `silver_table(name)` — OneLake ABFS paths, so no lakehouse needs to be attached as default.
- `read_silver(name)` / `save_silver(df, name, mode)` — standard Delta read/write (overwrite + `overwriteSchema`).
- `write_gold_staging(df, "stg.kpi_result")` — append via the Fabric Spark↔Warehouse connector.
- `get_dim_date()` — the silver customer calendar.
- `seed_emission_factors()` — one-off creation of `ref_emission_factor` (gas 0.20264 / elec 0.20705).

Why paths rather than `spark.table("lakehouse.table")`: path access works identically whichever lakehouse is attached, survives the bronze rename, and avoids the backtick-quoting the legacy notebooks needed for `` `bronze_lakehouse`.`Proposal Request` ``.

## 2. Notebook inventory and run order

| Order | Notebook | Reads | Writes | Purpose |
|---|---|---|---|---|
| 1 | `nb_005_gold_stage_dim_week` | silver `dim_date` | gold `stg.dim_week` | Push customer calendar weeks to gold |
| — | *(warehouse)* `EXEC kpi.sp_load_dim_week` | `stg.dim_week` | `kpi.dim_week` | Rebuild week dim; sets current/future flags |
| 2 | `nb_010_silver_ehs_energy` | bronze energy CSVs, `ref_emission_factor`, `dim_date` | `slv_ehs_energy_weekly` | CO₂e + intensity per site-week |
| 2 | `nb_020_silver_ehs_inspections` | bronze `SafetyCultureTest`, `dim_date` | `slv_ehs_inspection`, `slv_ehs_inspection_weekly` | Audit grain + weekly count / avg pass % |
| 2 | `nb_030_silver_ehs_accidents` | bronze accident tracker, `dim_date` | `slv_ehs_accident`, `slv_ehs_accident_weekly` | Accident grain + weekly lost days |
| 3 | `nb_100_gold_stage_ehs_kpis` | the three `slv_ehs_*_weekly` tables | gold `stg.kpi_result` | Reshape EHS actuals to the generic staging shape |
| 3 | `nb_110_gold_stage_salesforce_kpis` | `fact_proposal(_delivery)`, `fact_quality_weekly`, `fact_estimation`, `fact_sop_kpi_flags` | gold `stg.kpi_result` | Design / Estimating / SOP actuals |
| — | *(warehouse)* `EXEC kpi.sp_load_fact_kpi_result` | `stg.kpi_result` | `kpi.fact_kpi_result` | Key resolution, target lookup, variance, RAG, TBC back-fill |

Notebooks in the same order group can run in parallel. The two `EXEC` steps are pipeline *Stored procedure / Script* activities against `wh_sas_gold` — Spark never merges into final gold tables.

Pipeline `pl_kpi_weekly`: nb_005 → sp_load_dim_week → [nb_010 ∥ nb_020 ∥ nb_030] → nb_100 → nb_110 → sp_load_fact_kpi_result. Schedule weekly, Monday morning. Re-running any part is safe: silver writes are overwrite; the fact proc is delete-and-insert on the affected (kpi, week) grain and clears the staging rows it consumed.

## 3. The staging contract (the only shape notebooks produce)

Every KPI notebook ultimately emits rows to `stg.kpi_result`:

| Column | Notes |
|---|---|
| `kpi_code` | Customer lookup driver, e.g. `EHS-KPI C1`. Must exist in `kpi.dim_kpi` — the proc throws on unknown codes rather than dropping rows |
| `week_end_date` | Friday. Must exist in `kpi.dim_week` |
| `target_value` | Almost always NULL — targets resolve in the proc (`kpi.kpi_target` effective-dated, else `dim_kpi.default_target`). Stage a value only to override |
| `actual_value` | The weekly result |
| `commentary` | Optional weekly note |
| `source_system` / `source_ref` | Lineage: e.g. `SafetyCulture` / `slv_ehs_inspection_weekly` |

The helper `kpi_rows(df, code, actual_col, …)` in nb_100/nb_110 builds this shape from any weekly dataframe.

## 4. Notebook-specific notes

**nb_010 energy.** Real CSV quirks are handled: UTF-8 BOM, a blank row under the header, site-prefixed headers, a trailing space in `Conversion factor Electricity ` and an asterisk in the Maybole gas column — column matching is fuzzy (`find()`), so header drift raises a clear error instead of mis-mapping. Factors come from the file's own conversion-factor columns with `ref_emission_factor` as fallback. Intensity is NULL when TP is zero/absent (site idle weeks) so those weeks surface as TBC/blank, not divide-by-zero noise. `CALENDAR_YEAR` parameter states which customer year the file's `Week No` belongs to. Logic validated against the source workbook: 0 mismatches on 48 populated site-weeks.

**nb_020 inspections.** Dedupes on `audit_id`; optional `TEMPLATE_FILTER` list restricts to specific SafetyCulture templates. Weekly grain via join to `dim_date` (never `weekofyear()` — the customer calendar is authoritative).

**nb_030 accidents.** Accident dates parsed dd/MM/yyyy first. `lost_days` nulls coalesce to 0 at accident grain.

**nb_100 EHS staging.** Lost Working Days is a target-zero, every-week KPI: accident weeks are left-joined onto *all* elapsed calendar weeks so accident-free weeks stage as 0 (G) rather than being absent (which would back-fill as TBC).

**nb_110 Salesforce staging.** Design logic is ported from the legacy `nb_gold_fact_kpi_result_table_populate` (column names verified). Estimating and SOP blocks carry `--- CONFIRM ---` constants for column names against `fact_estimation` / `fact_sop_kpi_flags` — confirm before first run. SOP C1 stages only once `FTE_HEADCOUNT` has a source.

## 5. Extending — adding a KPI

Follow DOC-04 (runbook). In notebook terms: build/extend a weekly silver table, add one `kpi_rows(...)` call, done. Never add columns to `stg.kpi_result`, never write to `kpi.*` tables from Spark, never compute RAG in a notebook — the proc owns it so every KPI behaves identically.

## 6. Legacy notebooks

`nb_silver_dim_kpi_table_populate`, `nb_silver_fact_kpi_result_staging_table_populate`, `nb_gold_fact_kpi_result*` and the shortcut-based staging route are superseded by this build. Silver source-fact notebooks (`nb_silver_fact_proposal*`, `fact_estimation`, `fact_sop_kpi_flags`, `dim_date` etc.) remain in service; recommended follow-up is moving their bronze references onto `nb_000_env_config` before the `lh_sas_bronze` migration.
