# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "6950bf8e-2162-41a8-af31-7263ad5c1551",
# META       "default_lakehouse_name": "bronze_lakehouse",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "6950bf8e-2162-41a8-af31-7263ad5c1551"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "a9d36928-04b7-4824-8410-8b9cdb5a5569",
# META       "known_warehouses": [
# META         {
# META           "id": "a9d36928-04b7-4824-8410-8b9cdb5a5569",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

df = spark.read.option("header", True).csv(
    "Files/reference/calendar_customer.csv"
)

display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.write.mode("overwrite").saveAsTable("ref_calendar_customer")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
