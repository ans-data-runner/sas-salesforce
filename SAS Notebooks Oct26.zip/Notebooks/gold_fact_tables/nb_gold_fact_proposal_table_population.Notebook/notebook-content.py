# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "08b5c04c-9292-b499-4015-b57cdd6ec612",
# META       "known_warehouses": [
# META         {
# META           "id": "08b5c04c-9292-b499-4015-b57cdd6ec612",
# META           "type": "Datawarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import col, lit

def pick_table(*candidates):
    for t in candidates:
        try:
            if spark.catalog.tableExists(t):
                return t
        except Exception:
            pass
    raise Exception(f"None of these tables exist: {candidates}")

SILVER_FACT_PROPOSAL = pick_table("fact_proposal", "fact_proposal")
print("Using Silver source:", SILVER_FACT_PROPOSAL)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_gold_fact_proposal = (
    spark.table(SILVER_FACT_PROPOSAL)
    .filter(col("closed_date").isNotNull())
    .select(
        col("proposal_request_no"),
        col("project_name"),
        col("record_type"),
        col("sales_division"),
        col("geography"),
        col("opened_date"),
        col("closed_date"),
        col("closed_year"),
        col("closed_week"),
        col("closed_month"),
        col("estimated_value_native"),
        col("currency_code"),
        col("exchange_rate_to_gbp"),
        col("estimated_value_gbp"),
        lit(1).cast("int").alias("is_closed")   # warehouse column is BIT; int 1 writes cleanly
    )
)

print("Rows to load:", df_gold_fact_proposal.count())
df_gold_fact_proposal.show(5, truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

(
    df_gold_fact_proposal.write
    .mode("append")
    .saveAsTable("wh_sas_gold.salesforce.fact_proposal")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

gold_cnt = spark.sql("SELECT COUNT(*) AS c FROM wh_sas_gold.salesforce.fact_proposal").collect()[0]["c"]
print("Rows now in wh_sas_gold.salesforce.fact_proposal:", gold_cnt)

spark.sql("""
SELECT *
FROM wh_sas_gold.salesforce.fact_proposal
ORDER BY closed_year DESC, closed_week DESC
LIMIT 20
""").show(truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.table("wh_sas_gold.salesforce.fact_proposal").printSchema()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, lit

SOURCE = "fact_proposal"  # lakehouse table (no schema)
TARGET = "wh_sas_gold.salesforce.fact_proposal"  # warehouse table

df_gold_fact_proposal = (
    spark.table(SOURCE)
    .filter(col("closed_date").isNotNull())
    .select(
        col("proposal_request_no").cast("string").alias("proposal_request_no"),
        col("project_name").cast("string").alias("project_name"),
        col("record_type").cast("string").alias("record_type"),
        col("sales_division").cast("string").alias("sales_division"),
        col("geography").cast("string").alias("geography"),
        col("opened_date").cast("date").alias("opened_date"),
        col("closed_date").cast("date").alias("closed_date"),
        col("closed_year").cast("int").alias("closed_year"),
        col("closed_week").cast("int").alias("closed_week"),
        col("closed_month").cast("int").alias("closed_month"),
        col("estimated_value_native").cast("decimal(18,2)").alias("estimated_value_native"),
        col("currency_code").cast("string").alias("currency_code"),
        col("exchange_rate_to_gbp").cast("decimal(18,8)").alias("exchange_rate_to_gbp"),
        col("estimated_value_gbp").cast("decimal(18,2)").alias("estimated_value_gbp"),
        lit(True).cast("boolean").alias("is_closed")   
    )
)

print("Rows prepared for Gold:", df_gold_fact_proposal.count())
df_gold_fact_proposal.show(5, truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, lit

# 3-part name required: Warehouse.Schema.Table
WAREHOUSE_TABLE = "wh_sas_gold.salesforce.fact_proposal"

# Lakehouse source table (use full lakehouse name if needed e.g. "lh_sas_silver.fact_proposal")
SOURCE = "fact_proposal"

# 1) Prepare dataframe in Spark (from Lakehouse)
df_gold_fact_proposal = (
    spark.table(SOURCE)
    .filter(col("closed_date").isNotNull())
    .select(
        col("proposal_request_no").cast("string").alias("proposal_request_no"),
        col("project_name").cast("string").alias("project_name"),
        col("record_type").cast("string").alias("record_type"),
        col("sales_division").cast("string").alias("sales_division"),
        col("geography").cast("string").alias("geography"),
        col("opened_date").cast("date").alias("opened_date"),
        col("closed_date").cast("date").alias("closed_date"),
        col("closed_year").cast("int").alias("closed_year"),
        col("closed_week").cast("int").alias("closed_week"),
        col("closed_month").cast("int").alias("closed_month"),
        col("estimated_value_native").cast("decimal(18,2)").alias("estimated_value_native"),
        col("currency_code").cast("string").alias("currency_code"),
        col("exchange_rate_to_gbp").cast("decimal(18,8)").alias("exchange_rate_to_gbp"),
        col("estimated_value_gbp").cast("decimal(18,2)").alias("estimated_value_gbp"),
        lit(True).cast("boolean").alias("is_closed")
    )
)

print("Rows prepared:", df_gold_fact_proposal.count())

# 2) Clear the Warehouse table (T-SQL via Warehouse endpoint)
# This works for you already, so keep it.
spark.sql(f"DELETE FROM {WAREHOUSE_TABLE}")
print("Target cleared:", WAREHOUSE_TABLE)

# 3) Write to Warehouse using Fabric DW Spark connector
# NOTE: Use synapsesql() method (NOT format("synapse"))
(
    df_gold_fact_proposal
    .write
    .mode("append")  # use append after DELETE
    .synapsesql(WAREHOUSE_TABLE)
)

print("Gold fact_proposal loaded successfully into Warehouse:", WAREHOUSE_TABLE)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
