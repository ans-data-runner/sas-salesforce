# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "08b5c04c-9292-b499-4015-b57cdd6ec612",
# META       "known_warehouses": [
# META         {
# META           "id": "08b5c04c-9292-b499-4015-b57cdd6ec612",
# META           "type": "Datawarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import (
    col, lit, count, avg, sum as _sum, current_timestamp, when
)
from pyspark.sql import functions as F

def pick_table(*candidates):
    for t in candidates:
        try:
            if spark.catalog.tableExists(t):
                return t
        except Exception:
            pass
    raise Exception(f"None of these tables exist: {candidates}")

# Resolve sources (prefer silver.*)
T_FACT_PROPOSAL  = pick_table("silver.fact_proposal", "fact_proposal")
T_FACT_DELIVERY  = pick_table("silver.fact_proposal_delivery", "fact_proposal_delivery")
T_FACT_QUALITY   = pick_table("silver.fact_quality_weekly", "fact_quality_weekly")
T_DIM_KPI        = pick_table("silver.dim_kpi", "dim_kpi")

print("Using:")
print(" fact_proposal      =", T_FACT_PROPOSAL)
print(" fact_proposal_del  =", T_FACT_DELIVERY)
print(" fact_quality_weekly=", T_FACT_QUALITY)
print(" dim_kpi            =", T_DIM_KPI)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

fact_proposal = spark.read.table(T_FACT_PROPOSAL)
fact_delivery = spark.read.table(T_FACT_DELIVERY)
fact_quality  = spark.read.table(T_FACT_QUALITY)
dim_kpi       = spark.read.table(T_DIM_KPI)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, count, avg, sum as _sum, lit

ORG_UNIT = "Design & R&D"

# Pick a join key that exists on BOTH tables (fact_proposal does NOT have proposal_sk in the schema)
join_candidates = ["proposal_sk", "proposal_id", "proposal_request_no"]
join_key = next((k for k in join_candidates if k in fact_proposal.columns and k in fact_delivery.columns), None)

print("Chosen join key for OTIF:", join_key)
if join_key is None:
    raise Exception(
        f"No common join key found between fact_proposal and fact_delivery.\n"
        f"fact_proposal columns: {fact_proposal.columns}\n"
        f"fact_delivery columns: {fact_delivery.columns}"
    )

# 1) Productivity: Volume Completed (count of closed proposals per week)
kpi_volume = (
    fact_proposal
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(count("*").alias("kpi_value"))
    .withColumn("kpi_name", lit("Volume Completed"))
    .withColumn("organisational_unit", lit(ORG_UNIT))
)

# 2) Delivery: OTIF (avg of on_time_flag per week)
# Dedup delivery in case it has more than one row per proposal key
delivery_dedup = fact_delivery.dropDuplicates([join_key])

kpi_otif = (
    fact_proposal
    .join(delivery_dedup, join_key, "inner")
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(avg(col("on_time_flag").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("OTIF %"))
    .withColumn("organisational_unit", lit(ORG_UNIT))
)

# 3) Quality: Design Rejections (weekly sum)
kpi_rejects = (
    fact_quality
    .groupBy("year", "week_number")
    .agg(_sum(col("rejected_designs_count").cast("double")).alias("kpi_value"))
    .withColumnRenamed("year", "closed_year")
    .withColumnRenamed("week_number", "closed_week")
    .withColumn("kpi_name", lit("Design Rejections"))
    .withColumn("organisational_unit", lit(ORG_UNIT))
)

# 4) Cost: Opportunity Value per Proposal (weekly avg)
kpi_value = (
    fact_proposal
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(avg(col("estimated_value_gbp").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("Opportunity Value per Proposal"))
    .withColumn("organisational_unit", lit(ORG_UNIT))
)

print("OK - KPI dataframes created:",
      "volume=", kpi_volume.count(),
      "otif=", kpi_otif.count(),
      "rejects=", kpi_rejects.count(),
      "value=", kpi_value.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("Volume:", kpi_volume.count())
print("OTIF:", kpi_otif.count())
print("Design Rejections:", kpi_rejects.count())
print("Opportunity Value:", kpi_value.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

kpi_volume.orderBy(col("closed_year").desc(), col("closed_week").desc()).show(5)
kpi_otif.orderBy(col("closed_year").desc(), col("closed_week").desc()).show(5)
kpi_rejects.orderBy(col("closed_year").desc(), col("closed_week").desc()).show(5)
kpi_value.orderBy(col("closed_year").desc(), col("closed_week").desc()).show(5)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col

kpi_result_silver = (
    kpi_volume
    .select("closed_year", "closed_week", "kpi_name", "kpi_value", "organisational_unit")
    .unionByName(
        kpi_otif.select("closed_year", "closed_week", "kpi_name", "kpi_value", "organisational_unit")
    )
    .unionByName(
        kpi_rejects.select("closed_year", "closed_week", "kpi_name", "kpi_value", "organisational_unit")
    )
    .unionByName(
        kpi_value.select("closed_year", "closed_week", "kpi_name", "kpi_value", "organisational_unit")
    )
)

# ===============================
# Enrichment: add KPI metadata (safe, non-destructive)
# Creates NEW table: silver.kpi_result_silver_enriched
# ===============================
from pyspark.sql.functions import trim, upper

# Prepare dim_kpi with metadata
dim_kpi_keyed = (
    dim_kpi
    .select(
        col("kpi_id"),
        col("category").alias("kpi_category"),
        col("target_value").cast("decimal(18,4)").alias("target_value"),
        col("breach_direction"),
        upper(trim(col("kpi_name"))).alias("kpi_name_key")
    )
)

# Add join key to KPI results
kpi_result_silver_keyed = (
    kpi_result_silver
    .withColumn("kpi_name_key", upper(trim(col("kpi_name"))))
)

# Enrich KPI results
kpi_result_silver_enriched = (
    kpi_result_silver_keyed
    .join(dim_kpi_keyed, on="kpi_name_key", how="left")
    .drop("kpi_name_key")
)

# Validation: unmatched KPI names
unmatched = (
    kpi_result_silver_enriched
    .filter(col("kpi_id").isNull())
    .select("kpi_name")
    .distinct()
)

print("Unmatched KPI names:", unmatched.count())
unmatched.show(truncate=False)

# Persist enriched table (original remains untouched)
kpi_result_silver_enriched.write.mode("overwrite").saveAsTable("kpi_result_silver_enriched")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, lit, current_timestamp

kpi_result_gold = (
    kpi_result_silver
    .withColumn("calendar_year", col("closed_year"))
    .withColumn("week_number", col("closed_week"))
    .withColumn("kpi_category", lit("KPI"))  # or join from dim_kpi later
    .withColumn("target_value", lit(None).cast("decimal(18,4)"))
    .withColumn("breach_direction", lit(None).cast("string"))
    .withColumn("rag_status", lit(None).cast("string"))
    .withColumn("calculation_timestamp", current_timestamp())
    .withColumn("kpi_value", col("kpi_value").cast("decimal(18,4)"))
    .select(
        col("calendar_year"),
        col("week_number"),
        col("kpi_name"),
        col("kpi_category"),
        col("organisational_unit"),
        col("kpi_value"),
        col("target_value"),
        col("breach_direction"),
        col("rag_status"),
        col("calculation_timestamp")
    )
)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("Total KPI rows:", kpi_result_gold.count())

kpi_result_gold.orderBy(
    col("closed_year").desc(),
    col("closed_week").desc()
).show(10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("Total KPI rows:", kpi_result_silver.count())
kpi_result_silver.orderBy(
    col("closed_year").desc(),
    col("closed_week").desc()
).show(10)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import when, col, lit, current_timestamp

kpi_result_gold_2025 = (
    kpi_result_silver_enriched
    .withColumn("calendar_year", col("closed_year"))
    .withColumn("week_number", col("closed_week"))
    .withColumn("calculation_timestamp", current_timestamp())
    .withColumn("kpi_value", col("kpi_value").cast("decimal(18,4)"))
    .withColumn(
        "breach_status",
        when(
            col("target_value").isNull(), lit(None)
        ).when(
            col("breach_direction") == "UNDER",
            when(col("kpi_value") < col("target_value"), lit("UNDER")).otherwise(lit("OVER"))
        ).when(
            col("breach_direction") == "OVER",
            when(col("kpi_value") > col("target_value"), lit("OVER")).otherwise(lit("UNDER"))
        ).otherwise(lit(None))
    )
    .filter(col("calendar_year") == 2025)  # <-- Only 2025 rows
    .select(
        col("kpi_id"),
        col("calendar_year"),
        col("week_number"),
        col("kpi_name"),
        col("kpi_category"),
        col("organisational_unit"),
        col("kpi_value"),
        col("target_value"),
        col("breach_direction"),
        col("breach_status"),
        col("calculation_timestamp")
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

kpi_result_gold_2025.show(20, truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import when, col, lit, current_timestamp

kpi_result_gold_2025 = (
    kpi_result_silver_enriched
    .withColumn("calendar_year", col("closed_year"))
    .withColumn("week_number", col("closed_week"))
    .withColumn("calculation_timestamp", current_timestamp())
    .withColumn("kpi_value", col("kpi_value").cast("decimal(18,4)"))
    .withColumn(
        "rag_status",
        when(col("kpi_value").isNull() & col("target_value").isNull(), lit("Blank"))
        .when(col("kpi_value").isNull(), lit("TBC"))
        .when(col("target_value").isNull(), lit("Blank"))
        .when(col("kpi_value") >= col("target_value"), lit("G"))
        .when(col("kpi_value") >= col("target_value") * 0.95, lit("A"))
        .otherwise(lit("R"))
    )
    .filter(col("calendar_year") == 2025)
    .select(
        col("kpi_id"),
        col("calendar_year"),
        col("week_number"),
        col("kpi_name"),
        col("kpi_category"),
        col("organisational_unit"),
        col("kpi_value"),
        col("target_value"),
        col("breach_direction"),
        col("rag_status"),
        col("calculation_timestamp")
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

kpi_result_gold_2025.toPandas().to_csv("/lakehouse/default/Files/gold_2025_validation_with_RAG.csv", index=False)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************


# MARKDOWN ********************

