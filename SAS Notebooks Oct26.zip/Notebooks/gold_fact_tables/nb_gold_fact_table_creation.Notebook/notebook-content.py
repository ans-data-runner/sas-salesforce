# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

spark.sql("""
CREATE TABLE IF NOT EXISTS dim_date (
    date_key            INT,
    calendar_date       DATE,
    day_of_week         INT,
    day_name            STRING,
    is_weekday          BOOLEAN,
    customer_week_no    INT,
    customer_year       INT,
    customer_period     INT,
    week_start_date     DATE,
    week_end_date       DATE,
    is_current_week     BOOLEAN,
    is_current_year     BOOLEAN
)
USING DELTA;
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
