# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# # Get SQL metadata
# This notebook contains a reusable function called `get_sql_metadata` which ingests as table from Fabric SQL to a DataFrame. The function expects a server name, and initial catalog (database name) and a table. The server and catalog can be retrieved from the connection string in the Fabric SQL item interface.
# 
# ## Usage
# ### Register Function
# The function can be registered to the current session by invoking the notebook using the `%run` magic command from the parent notebook.
# 
# Cell 1:
# ```text
# %run nb_get_sql_metadata_py
# ```
# > Note - the `%run` command must be in a separate cell with no other Python code
# 
# Cell 2:
# ```python
# df = get_sql_metadata(server, database, table)
# ```
# 
# ### Parameters
# Consider storing the parameters in a Fabric variable library, to establish consistency across environments. The example below uses a variable library called `vl_connections`.
# 
# ```python
# # Get library using notebookutils
# vl_connections = notebookutils.variableLibrary.getLibrary("vl_connections")
# 
# # Get variables from library
# METADATA_DB_SERVER = vl_connections.getVariable("METADATA_DB_SERVER")
# METADATA_DB_CATALOG = vl_connections.getVariable("METADATA_DB_CATALOG")
# METADATA_DB_TABLE = vl_connections.getVariable("METADATA_DB_TABLE")
# 
# # Invoke function
# metadata_df = get_sql_metadata(server=METADATA_DB_SERVER,
#                                database=METADATA_DB_CATALOG,
#                                table=METADATA_DB_TABLE)
# ```


# CELL ********************

import notebookutils
from pyspark.sql import DataFrame

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_sql_metadata(server: str, database: str, table: str) -> DataFrame:
    """Read a Fabric SQL table and return it as a Spark DataFrame.

    Gets an access token for the current user using notebookutils, uses it to authenticate to 
    the specified Fabric SQL database, then reads the specified table into a Spark DataFrame.

    Server should be provided without the domain suffix (e.g. 'myserver' not 'myserver.database.fabric.microsoft.com').

    Args:
        server (str): The Fabric SQL server identifier (without domain suffix).
        database (str): The name of the database.
        table (str): The fully-qualified table name (e.g. 'SalesLT.Address').

    Returns:
        DataFrame: A Spark DataFrame containing the table contents.
    """
    if not server or not database or not table:
        raise ValueError("server, database, and table are all required")

    # Append the Fabric SQL domain suffix if not already present
    if not server.endswith(".database.fabric.microsoft.com"):
        server_fqdn = f"{server}.database.fabric.microsoft.com"
    else:
        server_fqdn = server

    server_host = f"{server_fqdn}:1433"

    url = f"jdbc:sqlserver://{server_host};databaseName={database};encrypt=true;trustServerCertificate=false"

    access_token = notebookutils.credentials.getToken("pbi")

    # Handle different possible structures of the access token response
    if isinstance(access_token, dict):
        access_token = access_token.get("access_token") or access_token.get("accessToken") or access_token.get("token")

    jdbc_options = {
        "url": url,
        "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
        "accessToken": str(access_token),
        "dbtable": table
    }

    return spark.read.format("jdbc").options(**jdbc_options).load()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

vl_connections = notebookutils.variableLibrary.getLibrary("vl_connections")

METADATA_DB_SERVER = vl_connections.getVariable("METADATA_DB_SERVER")
METADATA_DB_CATALOG = vl_connections.getVariable("METADATA_DB_CATALOG")
METADATA_DB_TABLE = vl_connections.getVariable("METADATA_DB_TABLE")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

metadata_df = get_sql_metadata(server=METADATA_DB_SERVER, database=METADATA_DB_CATALOG, table="ELT.IngestDefinition")

# Consider persisting the DataFrame to avoid collecting it back to the driver multiple times during iteration
metadata_df.persist()

for row in metadata_df.collect():
    # Access column values using dot-notation
    # definition_id = row.IngestDefinitionID
    # print(f"{definition_id=}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
