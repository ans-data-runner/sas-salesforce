# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "a081350c-382e-41c4-b79b-a18dba47b324",
# META       "default_lakehouse_name": "lh_sas_bronze",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "a081350c-382e-41c4-b79b-a18dba47b324"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

L1Transforms = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(L1Transforms)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ---- Handle legacy Parquet/Hive dates & timestamps (Spark 2.x files) ----
for k, v in [
    ("spark.sql.parquet.datetimeRebaseModeInRead",  "LEGACY"),
    ("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED"),  # or "LEGACY" if you must interop with Spark 2.x readers
    ("spark.sql.parquet.int96RebaseModeInRead",     "LEGACY"),
    ("spark.sql.parquet.int96RebaseModeInWrite",    "CORRECTED"),
    # Some runtimes still look at the legacy.* keys; set them too for safety:
    ("spark.sql.legacy.parquet.datetimeRebaseModeInRead",  "LEGACY"),
    ("spark.sql.legacy.parquet.datetimeRebaseModeInWrite", "CORRECTED")
]:
    spark.conf.set(k, v)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run /nb_common_transforms

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
import json
from datetime import datetime, timezone
from pyspark.sql.types import StructType


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


import json
from typing import Any
from pyspark.sql.types import (
    StructType, StructField,
    IntegerType, StringType, BooleanType
)

# --- Safe JSON parsing (handles already-parsed, strings, bytes, double-encoded) ---
def parse_json_safe(s: Any):
    """
    Returns a Python object from JSON input with robust handling:
    - If s is already a dict/list, returns it.
    - If s is bytes, decodes as UTF-8.
    - Tries json.loads(s); if that fails, tries a second json.loads on the result (double-encoded).
    - If all parsing fails, returns s unchanged (will be coerced later).
    """
    if isinstance(s, (dict, list)):
        return s

    if isinstance(s, (bytes, bytearray)):
        try:
            s = s.decode("utf-8")
        except Exception:
            s = str(s)

    try:
        return json.loads(s)
    except Exception:
        pass

    try:
        return json.loads(json.loads(s))
    except Exception:
        return s

# --- Explicit schema matching your sample payload ---
spec_schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("source_lakehouse_name", StringType(), True),
    StructField("source_schema_name",    StringType(), True),
    StructField("source_table_name",     StringType(), True),
    StructField("transform_json",        StringType(), True),
    StructField("target_lakehouse_name", StringType(), True),
    StructField("target_schema_name",    StringType(), True),
    StructField("target_table_name",     StringType(), True),
    StructField("is_active",             BooleanType(), True),
    StructField("created_utc",           StringType(), True),   # cast to timestamp later if desired
    StructField("modified_utc",          StringType(), True),   # cast to timestamp later if desired
])

# --- Normalize any non-string scalars and nested objects ---
def to_scalar_for_schema(key: str, v: Any):
    """
    Ensures each field fits the schema:
    - Strings remain strings.
    - Booleans remain booleans for 'is_active'.
    - Integers remain integers for 'id' (if possible).
    - dict/list -> JSON string for transform_json or any unexpected nesting.
    - None stays None.
    """
    if v is None:
        return None

    if key == "id":
        try:
            return int(v)
        except Exception:
            return None  # or raise

    if key == "is_active":
        # Preserve boolean when possible
        if isinstance(v, bool):
            return v
        if isinstance(v, (int, str)):
            s = str(v).strip().lower()
            if s in ("1", "true", "t", "yes", "y"):
                return True
            if s in ("0", "false", "f", "no", "n"):
                return False
        return None

    # transform_json should remain a string; if it is dict/list, serialize
    if key == "transform_json":
        if isinstance(v, (dict, list)):
            return json.dumps(v, ensure_ascii=False)
        return str(v)

    # For other fields: if nested -> JSON string; else str
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False)
    return str(v)

# =========================
# Main logic
# =========================
raw_param = L1Transforms  # provided by your environment
obj = parse_json_safe(raw_param)

# Normalize into list[dict]
if isinstance(obj, dict):
    rows = [obj]
elif isinstance(obj, list):
    normalized = []
    for item in obj:
        if isinstance(item, dict):
            normalized.append(item)
        else:
            normalized.append({"value": item})
    rows = normalized
else:
    rows = [{"value": obj}]

# Build rows aligned to the explicit schema (order of fields fixed by spec_schema)
schema_cols = [f.name for f in spec_schema.fields]

normalized_rows = []
for r in rows:
    if not isinstance(r, dict):
        r = {"value": r}
    normalized_rows.append({k: to_scalar_for_schema(k, r.get(k)) for k in schema_cols})

# Create the DataFrame (explicit schema avoids NullType inference issues)
spec_df = spark.createDataFrame(normalized_rows, schema=spec_schema)

print(f"Rows received: {len(rows)}")
spec_df.printSchema()
display(spec_df)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


import json
from datetime import datetime, timezone

from pyspark.sql import SparkSession

spark: SparkSession  # Fabric provides this


DEFAULT_TZ = "Europe/London"
DEFAULT_CHECKSUM_COL = "row_checksum"


def _subset_to_list(subset):
    """
    Accepts: None, string "col1,col2", or list ["col1","col2"].
    Returns: list or None
    """
    if subset is None:
        return None
    if isinstance(subset, list):
        return [str(c).strip() for c in subset if str(c).strip() != ""]
    s = str(subset).strip()
    if s == "":
        return None
    return [c.strip() for c in s.split(",") if c.strip() != ""]


def now_utc_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def _replace_tokens_in_dict(d):
    """
    Replaces known tokens in a flat dict; extend as needed.
    """
    for k, v in list(d.items()):
        if isinstance(v, str) and v == "{{now_utc}}":
            d[k] = now_utc_iso()
    return d


def _sorted_steps(spec: dict):
    # Sort by applyOrder; default to 0 if missing
    return sorted(spec.get("steps", []), key=lambda s: int(s.get("applyOrder", 0)))


def process_spec_row(spec_row) -> dict:
    """
    Execute transform for a single control row.
    Returns a dict of metrics & status for summary reporting.
    """

    # ---- Extract control fields (expect lowercase snake_case column names)
    source_lakehouse_name = spec_row["source_lakehouse_name"]
    source_schema_name    = spec_row["source_schema_name"]
    source_table_name     = spec_row["source_table_name"]

    target_lakehouse_name = spec_row["target_lakehouse_name"]
    target_schema_name    = spec_row["target_schema_name"]
    target_table_name     = spec_row["target_table_name"]

    # Transform JSON (required)
    spec_json = spec_row["transform_json"] or "{}"
    spec = json.loads(spec_json)

    # Defaults (could also be extended to come from spec_row or transform_json)
    default_tz = DEFAULT_TZ
    default_checksum_col = DEFAULT_CHECKSUM_COL

    # ---- Read source
    # In Spark, the fully qualified table name is typically <database>.<table>
    # If you truly separate SQL schema inside the same lakehouse, keep the three-part:
    src_fqn = f"{source_lakehouse_name}.{source_schema_name}.{source_table_name}"

    metrics = {
        "source_lakehouse_name": source_lakehouse_name,
        "source_schema_name":    source_schema_name,
        "source_table_name":     source_table_name,
        "target_lakehouse_name": target_lakehouse_name,
        "target_schema_name":    target_schema_name,
        "target_table_name":     target_table_name,
        "src_fqn":               src_fqn,
        "status":                "STARTED",
        "error":                 None,
        "input_rows":            None,
        "output_rows":           None,
        "started_utc":           now_utc_iso(),
        "ended_utc":             None,
    }

    try:
        src_df = spark.read.table(src_fqn)
    except Exception as e:
        metrics["status"] = "FAILED_READ"
        metrics["error"] = f"Failed to read source {src_fqn}: {e}"
        metrics["ended_utc"] = now_utc_iso()
        print(f"[ERROR] {metrics['error']}")
        return metrics

    input_rows = src_df.count()
    metrics["input_rows"] = input_rows

    # ---- Init transforms
    ct = CommonTransforms(src_df)

    # ---- Execute steps
    steps = _sorted_steps(spec)
    for step in steps:
        ttype  = str(step.get("type", "")).upper().strip()
        subset = _subset_to_list(step.get("subset"))  # normalize subset to list/None
        params = step.get("params", {}) or {}

        # Token substitutions in params and nested colDict if present
        params = _replace_tokens_in_dict(params)
        if "colDict" in params and isinstance(params["colDict"], dict):
            params["colDict"] = _replace_tokens_in_dict(params["colDict"])

        # Dispatch based on transform type
        if ttype == "TRIM":
            # Current class trims all string columns (subset ignored).
            ct.inputDf = ct.trim()

        elif ttype == "DEDUPLICATE":
            # subset=None => drop exact duplicates across all columns
            ct.inputDf = ct.deDuplicate(subset=subset)

        elif ttype == "REPLACE_NULL":
            ct.inputDf = ct.replaceNull(value=params.get("value"), subset=subset)

        elif ttype == "UTC_TO_LOCAL":
            tz = params.get("timezone", default_tz)
            ct.inputDf = ct.utc_to_local(localTimeZone=tz, subset=subset)

        elif ttype == "LOCAL_TO_UTC":
            tz = params.get("timezone", default_tz)
            ct.inputDf = ct.local_to_utc(localTimeZone=tz, subset=subset)

        elif ttype == "CHANGE_TIMEZONE":
            ct.inputDf = ct.changeTimezone(
                fromTimezone=params.get("from", "UTC"),
                toTimezone=params.get("to", default_tz),
                subset=subset,
            )

        elif ttype == "DROP_COLUMNS":
            if not subset:
                raise ValueError("DROP_COLUMNS requires 'subset' with one or more columns.")
            ct.inputDf = ct.dropSysColumns(subset)

        elif ttype == "ADD_CHECKSUM":
            col_name = params.get("colName", default_checksum_col)
            ct.inputDf = ct.addChecksumCol(col_name)

        elif ttype == "JULIAN_TO_CALENDAR":
            if not subset:
                raise ValueError("JULIAN_TO_CALENDAR requires 'subset' with one or more columns.")
            ct.inputDf = ct.julian_to_calendar(subset)

        elif ttype == "CALENDAR_TO_JULIAN":
            if not subset:
                raise ValueError("CALENDAR_TO_JULIAN requires 'subset' with one or more columns.")
            ct.inputDf = ct.calendar_to_julian(subset)

        elif ttype == "ADD_LIT_COLS":
            col_dict = params.get("colDict", {})
            if not isinstance(col_dict, dict) or len(col_dict) == 0:
                raise ValueError("ADD_LIT_COLS requires params.colDict with at least one key/value.")
            ct.inputDf = ct.addLitCols(col_dict)

        else:
            raise ValueError(f"Unsupported transform type: {ttype}")

    # ---- Write target
    df_out = ct.inputDf
    output_rows = df_out.count()
    metrics["output_rows"] = output_rows

    # Ensure target schema exists in the correct lakehouse
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {target_lakehouse_name}.{target_schema_name}")

    target_fqn = f"{target_lakehouse_name}.{target_schema_name}.{target_table_name}"

    (
        df_out.write
        .mode("overwrite")   # change to "append" or implement Delta MERGE if needed
        .format("delta")
        .saveAsTable(target_fqn)
    )

    metrics["status"] = "SUCCESS"
    metrics["ended_utc"] = now_utc_iso()
    print(f"[OK] {src_fqn} -> {target_fqn} | input_rows={input_rows}, output_rows={output_rows}")
    return metrics


results = []
for row in spec_df.toLocalIterator():  # memory-friendly iteration
    try:
        res = process_spec_row(row)
    except Exception as ex:
        # Catch any unforeseen errors per row to allow the loop to continue
        res = {
            "source_lakehouse_name": row["source_lakehouse_name"],
            "source_schema_name":    row["source_schema_name"],
            "source_table_name":     row["source_table_name"],
            "target_lakehouse_name": row["target_lakehouse_name"],
            "target_schema_name":    row["target_schema_name"],
            "target_table_name":     row["target_table_name"],
            "status":                "FAILED_UNHANDLED",
            "error":                 str(ex),
            "input_rows":            None,
            "output_rows":           None,
            "started_utc":           now_utc_iso(),
            "ended_utc":             now_utc_iso(),
        }
        print(
            f"[ERROR] Unhandled for "
            f"{row['source_lakehouse_name']}."
            f"{row['source_schema_name']}."
            f"{row['source_table_name']}: {ex}"
        )
    results.append(res)

# Optional: turn results into a Spark DF for audit/logging
# summary_df = spark.createDataFrame(results)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

spec_row = spec_df.first()
lakehouse_name = spec_row["LakehouseName"]
source_schema = spec_row["SchemaName"]
source_table  = spec_row["TableName"]

spec = json.loads(spec_row["TransformJson"])

target_lakehouse_name = spec_row["TargetLakehouseName"]
target_schema = spec_row["TargetSchemaName"]
target_table  = spec_row["TargetTableName"]


default_tz              = "Europe/London"
default_checksum_col    = "row_checksum"



# ---------------------------
# 
# ---------------------------
src_table = f"{lakehouse_name}.{source_schema}.{source_table}"
df = spark.read.table(src_table)
input_rows = df.count()

# ---------------------------
# Use your CommonTransforms class
# ---------------------------
ct = CommonTransforms(df)

# ---------------------------
# Helpers
# ---------------------------
def _subset_to_list(subset):
    """
    Accepts: None, string "col1,col2", or list ["col1","col2"].
    Returns: list or None
    """
    if subset is None:
        return None
    # If it's already a list
    if isinstance(subset, list):
        return [str(c).strip() for c in subset if str(c).strip() != ""]
    # If it's a single string (CSV)
    s = str(subset).strip()
    if s == "":
        return None
    return [c.strip() for c in s.split(",") if c.strip() != ""]

def now_utc_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")

def _replace_tokens_in_dict(d):
    """
    Replaces known tokens in a flat dict; extend as needed.
    """
    for k, v in list(d.items()):
        if isinstance(v, str) and v == "{{now_utc}}":
            d[k] = now_utc_iso()
    return d

# ---------------------------
# Execute steps in applyOrder
# ---------------------------
steps = sorted(spec.get("steps", []), key=lambda s: int(s.get("applyOrder", 0)))

for step in steps:
    ttype   = str(step.get("type", "")).upper().strip()
    subset  = _subset_to_list(step.get("subset"))  # normalize subset
    params  = step.get("params", {}) or {}

    # Token substitutions in params and nested colDict if present
    params = _replace_tokens_in_dict(params)
    if "colDict" in params and isinstance(params["colDict"], dict):
        params["colDict"] = _replace_tokens_in_dict(params["colDict"])

    if ttype == "TRIM":
        # Current class trims all string columns (subset ignored).
        # If you want subset-only trim behavior, add a trim_subset method in CommonTransforms.
        ct.inputDf = ct.trim()

    elif ttype == "DEDUPLICATE":
        # Uses dropDuplicates; subset=None will dedupe across all columns (exact duplicates).
        ct.inputDf = ct.deDuplicate(subset=subset)

    elif ttype == "REPLACE_NULL":
        # Supports date/timestamp/numeric/string default handling per your class.
        ct.inputDf = ct.replaceNull(value=params.get("value"), subset=subset)

    elif ttype == "UTC_TO_LOCAL":
        tz = params.get("timezone", default_tz)
        ct.inputDf = ct.utc_to_local(localTimeZone=tz, subset=subset)

    elif ttype == "LOCAL_TO_UTC":
        tz = params.get("timezone", default_tz)
        ct.inputDf = ct.local_to_utc(localTimeZone=tz, subset=subset)

    elif ttype == "CHANGE_TIMEZONE":
        ct.inputDf = ct.changeTimezone(fromTimezone=params.get("from","UTC"),
                                       toTimezone=params.get("to", default_tz),
                                       subset=subset)

    elif ttype == "DROP_COLUMNS":
        if not subset:
            raise ValueError("DROP_COLUMNS requires 'subset' with one or more columns.")
        ct.inputDf = ct.dropSysColumns(subset)

    elif ttype == "ADD_CHECKSUM":
        col_name = params.get("colName", default_checksum_col)
        ct.inputDf = ct.addChecksumCol(col_name)

    elif ttype == "JULIAN_TO_CALENDAR":
        if not subset:
            raise ValueError("JULIAN_TO_CALENDAR requires 'subset' with one or more columns.")
        ct.inputDf = ct.julian_to_calendar(subset)

    elif ttype == "CALENDAR_TO_JULIAN":
        if not subset:
            raise ValueError("CALENDAR_TO_JULIAN requires 'subset' with one or more columns.")
        ct.inputDf = ct.calendar_to_julian(subset)

    elif ttype == "ADD_LIT_COLS":
        col_dict = params.get("colDict", {})
        if not isinstance(col_dict, dict) or len(col_dict) == 0:
            raise ValueError("ADD_LIT_COLS requires params.colDict with at least one key/value.")
        ct.inputDf = ct.addLitCols(col_dict)

    else:
        raise ValueError(f"Unsupported transform type: {ttype}")

# ---------------------------
# Write to target Delta (L1)
# ---------------------------
df_out = ct.inputDf
output_rows = df_out.count()

target_table = f"{target_lakehouse_name}.{target_schema}.{target_table}"
(df_out
 .write
 .mode("overwrite")      # change to "append" or MERGE upsert as needed
 .format("delta")
 .saveAsTable(target_table)
)




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

# Add in output here similar to results so we can log it back to ControlDB
notebookutils.notebook.exit("Process Completed")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
