# SAS Fabric KPI Framework v2

This package refactors the current Design/Salesforce-specific KPI fact into a reusable, source-neutral framework for **Design, Estimating, SOP and EHS**, with a path for future Syteline KPIs.

## Architecture

`bronze_lakehouse` (later `lh_sas_bronze`) → source adapters and calculations in `lh_sas_silver` → `kpi.fact_kpi_observation` → `kpi.fact_kpi_result_curated` → Warehouse stored procedures reading Silver directly → `wh_sas_gold.reporting.fact_kpi_result` / `reporting.vw_kpi_report` → Power BI.

**There is no persistent staging schema and there are no OneLake shortcuts in the Gold Warehouse.** The Silver Lakehouse is the transformation and load-ready staging layer. Gold contains only reporting dimensions, the reporting fact, views and ETL stored procedures.

The key design choice is to keep **source joins, workbook calculation logic, target selection, RAG and weekly shaping in Silver**, where Spark can handle mixed source shapes. The Warehouse procedures remain deliberately thin: validate the Silver contract, merge dimensions, merge the fact and serve Power BI.

## Workspace object names

The package is configured for:

- Bronze Lakehouse: `bronze_lakehouse` — later change the notebook parameter to `lh_sas_bronze`.
- Silver Lakehouse and SQL analytics endpoint: `lh_sas_silver`.
- Gold Warehouse: `wh_sas_gold`.
- Silver KPI schema: `kpi`.
- Gold schemas: `reporting` and `etl`.

The SQL scripts use the three-part source names `[lh_sas_silver].[kpi].[table_name]`. If the SQL analytics endpoint has a different name, replace `lh_sas_silver` in the SQL files before deployment.

This direct three-part-name design assumes `lh_sas_silver` and `wh_sas_gold` are in the same Fabric workspace. If they are not, move them into the same workspace or introduce an appropriate cross-workspace OneLake shortcut before using these procedures.

## Run order

1. Upload this folder to `lh_sas_silver/Files/kpi_framework`.
2. Attach all PySpark notebooks to `lh_sas_silver`.
3. Mark each notebook's first code cell as its Fabric **Parameters** cell.
4. Run `00_create_silver_kpi_framework.ipynb`.
5. Confirm Salesforce Record Type names and load monthly exchange rates.
6. Run notebooks `10_build_design_kpis`, `11_build_estimating_kpis`, `12_build_sop_kpis` and `13_build_ehs_kpis`.
7. Run `20_build_silver_kpi_result_curated.ipynb`.
8. In `wh_sas_gold`, run SQL files `00`, `05`, `10`, `20` and `30` in numeric order.
9. Execute `EXEC etl.usp_refresh_kpi_reporting;`.
10. Point the Power BI template to `reporting.vw_kpi_report`.
11. Run notebook `90_validate_kpi_framework.ipynb` and SQL file `40_validation_queries.sql`.

No Gold staging shortcuts are required.

## Normal pipeline order

1. Bronze ingestion.
2. Customer calendar/date dimension refresh.
3. KPI reference/setup load when definitions or targets change.
4. Design, Estimating, SOP and EHS source notebooks; these can run in parallel after Bronze.
5. Silver `kpi.fact_kpi_result_curated` build.
6. Gold `etl.usp_refresh_kpi_reporting` execution.
7. Validation.
8. Power BI semantic-model refresh.

Use a single active Warehouse load and pipeline retry for transient conflicts.

## Parameterisation

Every notebook has the same core parameter cell:

- `p_bronze_lakehouse = "bronze_lakehouse"` — change to `lh_sas_bronze` after migration.
- `p_bronze_schema = "dbo"`.
- `p_silver_lakehouse = "lh_sas_silver"`.
- `p_silver_kpi_schema = "kpi"`.
- `p_dim_date_table = "dbo.dim_date"`.
- `p_run_date` and `p_load_batch_id`.

The EHS notebook also parameterises the energy year/file paths and SafetyCulture template filter.

## Silver-to-Gold contract

`lh_sas_silver.kpi.fact_kpi_result_curated` is the only load-ready KPI result used by Gold. Its grain is:

`one row per KPI + site + customer reporting week`.

The curated contract also carries `kpi_code`, `department_code` and `site_code` so that validation and future loads are not dependent only on hashed keys.

It contains the requested report fields and supporting audit columns: status, complete-up-to week, current week, submission frequency, department, category, KPI/measure, UOM, sign, commentary, week, target, actual, variance, RAG, data status, numerator/denominator, source lineage, source-quality flag, calculation timestamp and load batch ID.

The Gold procedures do not reproduce the workbook calculations. They only:

1. check for duplicate Silver business keys;
2. merge Silver dimensions into Gold dimensions;
3. verify that all fact keys resolve to Gold dimensions;
4. merge the curated Silver result into `reporting.fact_kpi_result`.

The Warehouse refresh always merges the complete current Silver result. `load_batch_id` remains on each row for lineage and troubleshooting; it is not used as a snapshot filter.

## Important source decisions

- Customer weeks always come from `dbo.dim_date`; notebooks do **not** use Spark `weekofyear`.
- Non-GBP proposal values require an exchange rate. They are not silently treated as GBP.
- Targets are weekly/effective-dated because the supplied files contain target changes and conflicts.
- `OVER` amber logic uses `target / 0.95`, matching the spreadsheet formula.
- SOP cleansing/sign-off is grouped by order-created week, matching the workbook. Historic values may restate while orders are open.
- Estimating £/m² uses the exact line-average rule only when `kpi.fact_estimate_sqm_line_input` is populated. Header fallback is labelled.
- EHS Lost Working Days needs the PBIX `EHSIncidentRegister` source ingested or weekly manual input.

## Reference files

- `kpi_catalog_seed.csv`: governed metric definitions.
- `kpi_target_history_seed.csv`: target snapshots extracted from the supplied 2025/2026 workbooks.
- `kpi_excel_actual_history.csv`: workbook actual/RAG snapshots for regression testing.
- `kpi_source_mapping.csv`: automation status, fields and unresolved issues.
- `docs/ARCHITECTURE_DECISION.md`: the Silver-as-staging decision and its implementation impact.
