# Deployment checklist

## Silver Lakehouse

- Confirm `lh_sas_silver` is schema-enabled.
- Upload the complete `kpi_framework` folder under Lakehouse Files.
- Attach all notebooks to `lh_sas_silver`.
- Mark the first code cell in each notebook as **Parameters**.
- Run setup, then the source notebooks, then `20_build_silver_kpi_result_curated.ipynb`.
- Load monthly FX rows into `kpi.ref_exchange_rate_monthly`; GBP is seeded automatically.
- Load weekly manual values into `kpi.fact_kpi_manual_input` only for controlled exceptions, FTE values and lost working days until those sources are automated.
- Confirm `kpi.fact_kpi_result_curated` has one row per KPI/site/week.
- Confirm the Lakehouse SQL analytics endpoint exposes the `kpi` schema and the curated tables.

## Gold Warehouse

- Do **not** create a `staging` schema.
- Do **not** create OneLake shortcuts for KPI dimensions or facts.
- Confirm the Gold Warehouse can query `[lh_sas_silver].[kpi].[dim_department]` and the other Silver tables by running `05_validate_silver_access.sql`.
- Run SQL files in numeric order.
- Execute `etl.usp_refresh_kpi_reporting` after the Silver curated-result notebook.
- Use `reporting.vw_kpi_report` as the Power BI source.
- Keep the compatibility view temporarily, then migrate the semantic model away from the `salesforce` schema.

## Pipeline order and retry

1. Bronze ingestion.
2. Customer calendar/date dimension.
3. KPI setup/reference load when definitions change.
4. Design, Estimating, SOP and EHS source notebooks in parallel after Bronze.
5. Silver curated KPI result.
6. Warehouse stored procedure.
7. Validation.
8. Power BI semantic-model refresh.

Use a single active Warehouse merge and add pipeline retry for transient conflicts.

## Release checks

- No references to `staging.*` remain in SQL or notebooks.
- No references to `fact_kpi_result_stage` remain.
- `etl.usp_refresh_kpi_reporting` completes successfully.
- Silver business keys loaded into Gold reconcile with the current Silver curated result.
- SQL duplicate-grain validation returns no rows.
- Power BI visuals return the expected status, complete-up-to week, current week, department, category, measure, UOM, sign, commentary, target, actual, variance and RAG fields.
