# Architecture decision: use Silver as the KPI staging layer

## Decision

Use `lh_sas_silver` as the persistent transformation and staging layer. Do not create a persistent `staging` schema or KPI table shortcuts in `wh_sas_gold`.

## Resulting flow

`Bronze → Silver source facts → Silver KPI observations → Silver KPI curated result → Gold ETL procedures → Gold reporting dimensions/fact → Power BI`.

## Responsibilities

### Silver notebooks

- source-system joins and cleansing;
- customer-week allocation;
- spreadsheet formula recreation;
- weekly aggregation;
- effective-dated or rolling target selection;
- variance and RAG calculation;
- source-quality flags and controlled manual overrides;
- creation of `kpi.fact_kpi_result_curated`.

### Gold Warehouse procedures

- direct read from the Silver SQL analytics endpoint;
- duplicate and dimension-key validation;
- dimension merges;
- fact merge;
- reporting views and backward-compatible view.

## Code changes made in v2

- Renamed `20_build_gold_shaped_kpi_stage.ipynb` to `20_build_silver_kpi_result_curated.ipynb`.
- Renamed `kpi.fact_kpi_result_stage` to `kpi.fact_kpi_result_curated`.
- Removed all Gold `staging.*` and shortcut instructions.
- Moved load procedures from the `reporting` schema to the `etl` schema.
- Updated the Warehouse procedures to read `[lh_sas_silver].[kpi].*` directly.
- Added a Silver-access preflight SQL script.
- Updated validation, documentation and the manifest.
