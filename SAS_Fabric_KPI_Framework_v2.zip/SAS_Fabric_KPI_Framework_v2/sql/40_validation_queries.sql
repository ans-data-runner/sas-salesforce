/* 40_validation_queries.sql */

/* Silver duplicate business grain: must return no rows. */
SELECT kpi_key, site_key, week_key, COUNT_BIG(*) AS row_count
FROM [lh_sas_silver].[kpi].[fact_kpi_result_curated]
GROUP BY kpi_key, site_key, week_key
HAVING COUNT_BIG(*) > 1;

/* Gold duplicate business grain: must return no rows. */
SELECT kpi_key, site_key, week_key, COUNT_BIG(*) AS row_count
FROM reporting.fact_kpi_result
GROUP BY kpi_key, site_key, week_key
HAVING COUNT_BIG(*) > 1;

/* Missing Gold key/metadata checks. */
SELECT
    SUM(CASE WHEN department_key IS NULL THEN 1 ELSE 0 END) AS null_department_key,
    SUM(CASE WHEN site_key IS NULL THEN 1 ELSE 0 END) AS null_site_key,
    SUM(CASE WHEN kpi_key IS NULL THEN 1 ELSE 0 END) AS null_kpi_key,
    SUM(CASE WHEN week_key IS NULL THEN 1 ELSE 0 END) AS null_week_key
FROM reporting.fact_kpi_result;

/* Current Silver business keys missing from Gold: must return no rows after refresh. */
SELECT
    source.kpi_result_key,
    source.kpi_code,
    source.site_code,
    source.week_ending_date
FROM [lh_sas_silver].[kpi].[fact_kpi_result_curated] AS source
LEFT JOIN reporting.fact_kpi_result AS target
  ON target.kpi_result_key = source.kpi_result_key
WHERE target.kpi_result_key IS NULL;

/* Data quality/status overview. */
SELECT department, kpi_name, source_quality_flag, data_status, COUNT_BIG(*) AS weeks
FROM reporting.fact_kpi_result
GROUP BY department, kpi_name, source_quality_flag, data_status
ORDER BY department, kpi_name, source_quality_flag, data_status;

/* Current report extract. */
SELECT *
FROM reporting.vw_kpi_report
WHERE reporting_year = YEAR(GETDATE())
ORDER BY department, display_order, week_ending_date;
