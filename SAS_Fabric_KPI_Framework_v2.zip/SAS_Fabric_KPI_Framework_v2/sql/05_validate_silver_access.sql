/* 05_validate_silver_access.sql
Run in wh_sas_gold before creating/executing the load procedures.

The source database name below must match the SQL analytics endpoint for the
Silver Lakehouse. Replace lh_sas_silver in all SQL files if your endpoint name
differs. This direct query also assumes the Silver Lakehouse and Gold Warehouse
are in the same Fabric workspace. If a newly created/changed Delta table is not yet
visible, allow the SQL analytics endpoint metadata to synchronise and rerun.
*/
SELECT TOP (5) * FROM [lh_sas_silver].[kpi].[dim_department];
SELECT TOP (5) * FROM [lh_sas_silver].[kpi].[dim_site];
SELECT TOP (5) * FROM [lh_sas_silver].[kpi].[dim_kpi];
SELECT TOP (5) * FROM [lh_sas_silver].[kpi].[fact_kpi_result_curated];

SELECT
    (SELECT COUNT_BIG(*) FROM [lh_sas_silver].[kpi].[dim_department]) AS silver_departments,
    (SELECT COUNT_BIG(*) FROM [lh_sas_silver].[kpi].[dim_site]) AS silver_sites,
    (SELECT COUNT_BIG(*) FROM [lh_sas_silver].[kpi].[dim_kpi]) AS silver_kpis,
    (SELECT COUNT_BIG(*) FROM [lh_sas_silver].[kpi].[fact_kpi_result_curated]) AS silver_kpi_results;
