/* 20_refresh_fact_kpi_result.sql
Direct Silver-to-Gold fact load. No staging schema or shortcuts are used.
Source SQL analytics endpoint: lh_sas_silver.

The curated Silver table represents the current load-ready state. The procedure
therefore merges the complete table each run. load_batch_id is retained as row
lineage, not used as a snapshot filter.
*/
CREATE OR ALTER PROCEDURE etl.usp_load_kpi_results
AS
BEGIN
    SET NOCOUNT ON;

    /* The Silver contract must be unique at KPI/site/week grain. */
    IF EXISTS (
        SELECT 1
        FROM [lh_sas_silver].[kpi].[fact_kpi_result_curated]
        GROUP BY kpi_key, site_key, week_key
        HAVING COUNT_BIG(*) > 1
    )
    BEGIN
        THROW 50001, 'Duplicate KPI/site/week rows found in Silver fact_kpi_result_curated.', 1;
    END;

    /* Dimensions are loaded first; stop rather than loading unresolved fact keys. */
    IF EXISTS (
        SELECT 1
        FROM [lh_sas_silver].[kpi].[fact_kpi_result_curated] AS source
        LEFT JOIN reporting.dim_department AS department
          ON department.department_key = source.department_key
        LEFT JOIN reporting.dim_site AS site
          ON site.site_key = source.site_key
        LEFT JOIN reporting.dim_kpi AS kpi
          ON kpi.kpi_key = source.kpi_key
        WHERE department.department_key IS NULL
           OR site.site_key IS NULL
           OR kpi.kpi_key IS NULL
    )
    BEGIN
        THROW 50002, 'One or more Silver KPI results do not resolve to Gold dimensions.', 1;
    END;

    MERGE reporting.fact_kpi_result AS target
    USING [lh_sas_silver].[kpi].[fact_kpi_result_curated] AS source
       ON target.kpi_result_key = source.kpi_result_key
    WHEN MATCHED THEN
        UPDATE SET
            target.date_key = source.date_key,
            target.week_key = source.week_key,
            target.week_ending_date = source.week_ending_date,
            target.week_start_date = source.week_start_date,
            target.reporting_year = source.reporting_year,
            target.reporting_week = source.reporting_week,
            target.department_key = source.department_key,
            target.site_key = source.site_key,
            target.kpi_key = source.kpi_key,
            target.status = source.status,
            target.complete_up_to_week = source.complete_up_to_week,
            target.current_week = source.current_week,
            target.submission_frequency = source.submission_frequency,
            target.department = source.department,
            target.category = source.category,
            target.kpi_name = source.kpi_name,
            target.measure = source.measure,
            target.uom = source.uom,
            target.sign = source.sign,
            target.commentary = source.commentary,
            target.target_value = source.target_value,
            target.actual_value = source.actual_value,
            target.variance_value = source.variance_value,
            target.performance_variance_value = source.performance_variance_value,
            target.rag_status = source.rag_status,
            target.data_status = source.data_status,
            target.numerator_value = source.numerator_value,
            target.denominator_value = source.denominator_value,
            target.source_row_count = source.source_row_count,
            target.source_system = source.source_system,
            target.source_object = source.source_object,
            target.source_quality_flag = source.source_quality_flag,
            target.calculation_timestamp = source.calculation_timestamp,
            target.load_batch_id = source.load_batch_id
    WHEN NOT MATCHED THEN
        INSERT (
            kpi_result_key, date_key, week_key, week_ending_date, week_start_date,
            reporting_year, reporting_week, department_key, site_key, kpi_key,
            status, complete_up_to_week, current_week, submission_frequency,
            department, category, kpi_name, measure, uom, sign, commentary,
            target_value, actual_value, variance_value, performance_variance_value,
            rag_status, data_status, numerator_value, denominator_value,
            source_row_count, source_system, source_object, source_quality_flag,
            calculation_timestamp, load_batch_id
        )
        VALUES (
            source.kpi_result_key, source.date_key, source.week_key,
            source.week_ending_date, source.week_start_date, source.reporting_year,
            source.reporting_week, source.department_key, source.site_key,
            source.kpi_key, source.status, source.complete_up_to_week,
            source.current_week, source.submission_frequency, source.department,
            source.category, source.kpi_name, source.measure, source.uom, source.sign,
            source.commentary, source.target_value, source.actual_value,
            source.variance_value, source.performance_variance_value,
            source.rag_status, source.data_status, source.numerator_value,
            source.denominator_value, source.source_row_count, source.source_system,
            source.source_object, source.source_quality_flag,
            source.calculation_timestamp, source.load_batch_id
        );
END;
GO

CREATE OR ALTER PROCEDURE etl.usp_refresh_kpi_reporting
AS
BEGIN
    SET NOCOUNT ON;

    EXEC etl.usp_load_kpi_dimensions;
    EXEC etl.usp_load_kpi_results;
END;
GO
