/* 10_refresh_dimensions.sql
Direct Silver-to-Gold dimension load. No staging schema or shortcuts are used.
Source SQL analytics endpoint: lh_sas_silver.
*/
CREATE OR ALTER PROCEDURE etl.usp_load_kpi_dimensions
AS
BEGIN
    SET NOCOUNT ON;

    MERGE reporting.dim_department AS target
    USING [lh_sas_silver].[kpi].[dim_department] AS source
       ON target.department_code = source.department_code
    WHEN MATCHED THEN
        UPDATE SET
            target.department_key = source.department_key,
            target.department_name = source.department_name,
            target.owner_name = source.owner_name,
            target.submission_frequency = source.submission_frequency,
            target.reporting_lag_weeks = source.reporting_lag_weeks,
            target.is_active = source.is_active,
            target.updated_ts = source.updated_ts
    WHEN NOT MATCHED THEN
        INSERT (
            department_key, department_code, department_name, owner_name,
            submission_frequency, reporting_lag_weeks, is_active, created_ts, updated_ts
        )
        VALUES (
            source.department_key, source.department_code, source.department_name, source.owner_name,
            source.submission_frequency, source.reporting_lag_weeks, source.is_active,
            source.created_ts, source.updated_ts
        );

    MERGE reporting.dim_site AS target
    USING [lh_sas_silver].[kpi].[dim_site] AS source
       ON target.site_code = source.site_code
    WHEN MATCHED THEN
        UPDATE SET
            target.site_key = source.site_key,
            target.site_name = source.site_name,
            target.is_active = source.is_active,
            target.updated_ts = source.updated_ts
    WHEN NOT MATCHED THEN
        INSERT (site_key, site_code, site_name, is_active, created_ts, updated_ts)
        VALUES (
            source.site_key, source.site_code, source.site_name,
            source.is_active, source.created_ts, source.updated_ts
        );

    MERGE reporting.dim_kpi AS target
    USING [lh_sas_silver].[kpi].[dim_kpi] AS source
       ON target.kpi_code = source.kpi_code
    WHEN MATCHED THEN
        UPDATE SET
            target.kpi_key = source.kpi_key,
            target.department_code = source.department_code,
            target.category = source.category,
            target.kpi_name = source.kpi_name,
            target.measure = source.measure,
            target.uom = source.uom,
            target.breach_direction = source.breach_direction,
            target.target_method = source.target_method,
            target.reporting_lag_weeks = source.reporting_lag_weeks,
            target.amber_tolerance_pct = source.amber_tolerance_pct,
            target.display_order = source.display_order,
            target.is_headline = source.is_headline,
            target.source_system = source.source_system,
            target.source_object = source.source_object,
            target.calculation_description = source.calculation_description,
            target.is_active = source.is_active,
            target.updated_ts = source.updated_ts
    WHEN NOT MATCHED THEN
        INSERT (
            kpi_key, kpi_code, department_code, category, kpi_name, measure, uom,
            breach_direction, target_method, reporting_lag_weeks, amber_tolerance_pct,
            display_order, is_headline, source_system, source_object,
            calculation_description, is_active, created_ts, updated_ts
        )
        VALUES (
            source.kpi_key, source.kpi_code, source.department_code, source.category,
            source.kpi_name, source.measure, source.uom, source.breach_direction,
            source.target_method, source.reporting_lag_weeks, source.amber_tolerance_pct,
            source.display_order, source.is_headline, source.source_system,
            source.source_object, source.calculation_description, source.is_active,
            source.created_ts, source.updated_ts
        );
END;
GO
