/* 30_reporting_views.sql
Gold serving views. No staging objects are required.
*/
CREATE OR ALTER VIEW reporting.vw_kpi_report
AS
SELECT
 f.kpi_result_key, f.week_key, f.week_ending_date, f.week_start_date, f.reporting_year, f.reporting_week,
 f.status, f.complete_up_to_week, f.current_week, f.submission_frequency,
 d.department_code, f.department, k.display_order, k.is_headline,
 s.site_code, s.site_name,
 f.category, f.kpi_name, f.measure, f.uom, f.sign, f.commentary,
 f.target_value, f.actual_value, f.variance_value, f.performance_variance_value,
 f.rag_status, f.data_status, f.numerator_value, f.denominator_value, f.source_row_count,
 f.source_system, f.source_object, f.source_quality_flag, f.calculation_timestamp, f.load_batch_id
FROM reporting.fact_kpi_result f
JOIN reporting.dim_department d ON d.department_key=f.department_key
JOIN reporting.dim_site s ON s.site_key=f.site_key
JOIN reporting.dim_kpi k ON k.kpi_key=f.kpi_key;
GO

-- Backward-compatibility for the existing Power BI model while it is migrated.
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name='salesforce')
    EXEC('CREATE SCHEMA salesforce');
GO
CREATE OR ALTER VIEW salesforce.fact_kpi_result_v2
AS
SELECT
 date_key,week_ending_date,week_start_date,week_ending_date AS week_end_date,
 reporting_year AS calendar_year,reporting_week AS week_number,kpi_key AS kpi_id,
 kpi_name,category AS kpi_category,department AS organisational_unit,
 actual_value,target_value,variance_value,
 CASE WHEN sign='Under Breach' THEN 'UNDER' WHEN sign='Over Breach' THEN 'OVER' END AS breach_direction,
 rag_status,calculation_timestamp
FROM reporting.fact_kpi_result;
GO
