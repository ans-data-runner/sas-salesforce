# Changelog

## v2 — Silver-as-staging architecture

- Removed the Gold staging schema and all OneLake shortcut requirements.
- Added direct Silver-to-Gold Warehouse loads using three-part SQL names.
- Renamed the final Silver notebook and result table from `stage` to `curated`.
- Added `etl.usp_load_kpi_dimensions`, `etl.usp_load_kpi_results` and `etl.usp_refresh_kpi_reporting`.
- Added duplicate-grain and dimension-key validation before the Gold fact merge.
- Added `05_validate_silver_access.sql`.
- Updated the README, deployment checklist, logic review and notebook validation.
- Added KPI/department/site business codes to the curated Silver result for validation.
- Gold now merges the complete current curated result each run; load_batch_id is retained for lineage only.
