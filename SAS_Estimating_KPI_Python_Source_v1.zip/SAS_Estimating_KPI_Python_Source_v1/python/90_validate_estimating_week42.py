"""
Converted from: 90_validate_estimating_week42.ipynb

This file is intended for use as a Microsoft Fabric PySpark notebook source.
Sections are separated with '# %%' cell markers so the file can also be opened
as a cell-based Python script in compatible editors.
"""

# %% [markdown]
# # 90 - Validate Estimating KPI output against Week 42 workbook history
#
# This validates weeks 32-42 for the three Estimating Request KPIs.
#
# The £/SQM result is reported separately because the workbook does not expose the Salesforce
# report date filter used to place quote lines into each week.

# %%  # tags: parameters
p_kpi_table = "kpi.fact_estimating_kpi"
p_quote_line_table = "salesforce.fact_estimating_quote_line"
p_reporting_year = 2025
p_fail_on_cost_mismatch = False
p_absolute_tolerance = 0.01

# %%
from pyspark.sql import functions as F

expected_rows = [(2025, 32, 'EST_QUOTES_ISSUED', 127.0, 126.0, 'G'), (2025, 32, 'EST_QUOTES_ON_TIME', 75.59055118110236, 85.0, 'R'), (2025, 32, 'EST_AVG_HOURS', 41.056338028169016, 28.0, 'R'), (2025, 32, 'EST_RATE_PER_SQM', 69.10333333333332, 75.0, 'R'), (2025, 33, 'EST_QUOTES_ISSUED', 95.0, 126.0, 'R'), (2025, 33, 'EST_QUOTES_ON_TIME', 69.47368421052632, 85.0, 'R'), (2025, 33, 'EST_AVG_HOURS', 36.3728813559322, 28.0, 'R'), (2025, 33, 'EST_RATE_PER_SQM', 77.475625, 75.0, 'G'), (2025, 34, 'EST_QUOTES_ISSUED', 121.0, 126.0, 'A'), (2025, 34, 'EST_QUOTES_ON_TIME', 79.33884297520662, 85.0, 'R'), (2025, 34, 'EST_AVG_HOURS', 40.145161290322584, 28.0, 'R'), (2025, 34, 'EST_RATE_PER_SQM', 63.224062499999974, 75.0, 'R'), (2025, 35, 'EST_QUOTES_ISSUED', 83.0, 126.0, 'R'), (2025, 35, 'EST_QUOTES_ON_TIME', 85.54216867469879, 85.0, 'G'), (2025, 35, 'EST_AVG_HOURS', 37.67857142857143, 28.0, 'R'), (2025, 35, 'EST_RATE_PER_SQM', 150.0293023255814, 75.0, 'G'), (2025, 36, 'EST_QUOTES_ISSUED', 107.0, 126.0, 'R'), (2025, 36, 'EST_QUOTES_ON_TIME', 86.91588785046729, 85.0, 'G'), (2025, 36, 'EST_AVG_HOURS', 41.22222222222222, 28.0, 'R'), (2025, 36, 'EST_RATE_PER_SQM', 70.96, 75.0, 'R'), (2025, 37, 'EST_QUOTES_ISSUED', 141.0, 126.0, 'G'), (2025, 37, 'EST_QUOTES_ON_TIME', 65.24822695035462, 85.0, 'R'), (2025, 37, 'EST_AVG_HOURS', 53.688311688311686, 28.0, 'R'), (2025, 37, 'EST_RATE_PER_SQM', 79.84490196078433, 75.0, 'G'), (2025, 38, 'EST_QUOTES_ISSUED', 115.0, 126.0, 'R'), (2025, 38, 'EST_QUOTES_ON_TIME', 68.69565217391305, 85.0, 'R'), (2025, 38, 'EST_AVG_HOURS', 53.333333333333336, 28.0, 'R'), (2025, 38, 'EST_RATE_PER_SQM', 79.96475609756097, 75.0, 'G'), (2025, 39, 'EST_QUOTES_ISSUED', 108.0, 126.0, 'R'), (2025, 39, 'EST_QUOTES_ON_TIME', 77.77777777777779, 85.0, 'R'), (2025, 39, 'EST_AVG_HOURS', 28.865671641791046, 28.0, 'A'), (2025, 39, 'EST_RATE_PER_SQM', 107.59413793103447, 75.0, 'G'), (2025, 40, 'EST_QUOTES_ISSUED', 92.0, 126.0, 'R'), (2025, 40, 'EST_QUOTES_ON_TIME', 82.6086956521739, 85.0, 'A'), (2025, 40, 'EST_AVG_HOURS', 34.37837837837838, 28.0, 'R'), (2025, 40, 'EST_RATE_PER_SQM', 80.21103448275862, 75.0, 'G'), (2025, 41, 'EST_QUOTES_ISSUED', 124.0, 126.0, 'A'), (2025, 41, 'EST_QUOTES_ON_TIME', 75.0, 85.0, 'R'), (2025, 41, 'EST_AVG_HOURS', 47.98148148148148, 28.0, 'R'), (2025, 41, 'EST_RATE_PER_SQM', 79.48862068965519, 75.0, 'G'), (2025, 42, 'EST_QUOTES_ISSUED', 123.0, 126.0, 'A'), (2025, 42, 'EST_QUOTES_ON_TIME', 82.11382113821138, 85.0, 'A'), (2025, 42, 'EST_AVG_HOURS', 26.193548387096776, 28.0, 'G'), (2025, 42, 'EST_RATE_PER_SQM', 80.65988372093024, 75.0, 'G')]

expected = spark.createDataFrame(
    expected_rows,
    "calendar_year int, week_number int, kpi_code string, "
    "expected_actual_value double, expected_target_value double, "
    "expected_rag_status string"
)

actual = (
    spark.table(p_kpi_table)
    .filter(
        (F.col("calendar_year") == F.lit(int(p_reporting_year))) &
        F.col("week_number").between(32, 42)
    )
    .select(
        "calendar_year", "week_number", "kpi_code",
        F.col("actual_value").cast("double").alias("actual_value"),
        F.col("target_value").cast("double").alias("target_value"),
        "rag_status"
    )
)

comparison = (
    expected.alias("e")
    .join(actual.alias("a"), ["calendar_year", "week_number", "kpi_code"], "left")
    .withColumn(
        "actual_difference",
        F.abs(F.col("a.actual_value") - F.col("e.expected_actual_value"))
    )
    .withColumn(
        "target_difference",
        F.abs(F.col("a.target_value") - F.col("e.expected_target_value"))
    )
    .withColumn(
        "value_pass",
        F.col("actual_difference") <= F.lit(float(p_absolute_tolerance))
    )
    .withColumn(
        "target_pass",
        F.col("target_difference") <= F.lit(float(p_absolute_tolerance))
    )
    .withColumn(
        "rag_pass",
        F.col("a.rag_status") == F.col("e.expected_rag_status")
    )
)

display(comparison.orderBy("week_number", "kpi_code"))

# %%
# The first three KPIs have a directly supported Salesforce date basis: request Date_Closed__c.
request_failures = comparison.filter(
    (F.col("kpi_code") != "EST_RATE_PER_SQM") &
    (
        ~F.coalesce(F.col("value_pass"), F.lit(False)) |
        ~F.coalesce(F.col("target_pass"), F.lit(False)) |
        ~F.coalesce(F.col("rag_pass"), F.lit(False))
    )
)

request_failure_count = request_failures.count()
if request_failure_count:
    display(request_failures)
    raise RuntimeError(
        f"{request_failure_count} request-based KPI comparisons failed. "
        "Review the source filters and customer calendar mapping."
    )

print("Request-based KPI validation passed for weeks 32-42.")

# %%
# Diagnose the unconfirmed £/SQM weekly date basis.
lines = spark.table(p_quote_line_table).filter("is_sqm_kpi_eligible = true")
expected_cost = expected.filter(F.col("kpi_code") == "EST_RATE_PER_SQM")

quote_date = (
    lines
    .filter(F.col("quote_date_customer_year") == int(p_reporting_year))
    .groupBy(
        F.col("quote_date_customer_year").alias("calendar_year"),
        F.col("quote_date_customer_week_no").alias("week_number")
    )
    .agg(F.avg("sqm_rate").alias("candidate_actual_value"))
    .withColumn("candidate_date_basis", F.lit("Quote_Date__c"))
)

closed_date = (
    lines
    .filter(F.col("closed_date_customer_year") == int(p_reporting_year))
    .groupBy(
        F.col("closed_date_customer_year").alias("calendar_year"),
        F.col("closed_date_customer_week_no").alias("week_number")
    )
    .agg(F.avg("sqm_rate").alias("candidate_actual_value"))
    .withColumn("candidate_date_basis", F.lit("Closed_Date__c"))
)

cost_diagnostic = (
    quote_date.unionByName(closed_date)
    .join(expected_cost, ["calendar_year", "week_number"], "inner")
    .withColumn(
        "absolute_difference",
        F.abs(F.col("candidate_actual_value") - F.col("expected_actual_value"))
    )
    .orderBy("week_number", "candidate_date_basis")
)

display(cost_diagnostic)

selected_cost_failures = comparison.filter(
    (F.col("kpi_code") == "EST_RATE_PER_SQM") &
    (
        ~F.coalesce(F.col("value_pass"), F.lit(False)) |
        ~F.coalesce(F.col("target_pass"), F.lit(False)) |
        ~F.coalesce(F.col("rag_pass"), F.lit(False))
    )
)

if selected_cost_failures.count():
    print(
        "The selected £/SQM date basis does not fully reproduce the workbook. "
        "Confirm the Salesforce report filter/date or arrange weekly Quote Line snapshots."
    )
    display(selected_cost_failures)
    if p_fail_on_cost_mismatch:
        raise RuntimeError("£/SQM workbook validation failed.")
else:
    print("Selected £/SQM date basis reproduces weeks 32-42 within tolerance.")
