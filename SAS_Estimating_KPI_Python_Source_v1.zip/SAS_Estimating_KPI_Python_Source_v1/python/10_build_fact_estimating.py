"""
Converted from: 10_build_fact_estimating.ipynb

This file is intended for use as a Microsoft Fabric PySpark notebook source.
Sections are separated with '# %%' cell markers so the file can also be opened
as a cell-based Python script in compatible editors.
"""

# %% [markdown]
# # 10 - Build `salesforce.fact_estimating`
#
# Grain: one row per Salesforce Estimating Request.
#
# This replaces the existing estimation notebook fields that do not exist in Bronze and uses
# the customer calendar in `dbo.dim_date` rather than Spark `weekofyear`.

# %%  # tags: parameters
# Fabric pipeline parameters
p_bronze_lakehouse = "bronze_lakehouse"
p_silver_salesforce_schema = "salesforce"
p_date_table = "dbo.dim_date"
p_target_table = "salesforce.fact_estimating"

# %%
from pyspark.sql import functions as F
from pyspark.sql.window import Window

def read_bronze_table(table_name: str):
    candidates = [
        f"`{p_bronze_lakehouse}`.`{table_name}`",
        f"`{p_bronze_lakehouse}`.`dbo`.`{table_name}`",
        f"{p_bronze_lakehouse}.`{table_name}`",
        f"{p_bronze_lakehouse}.dbo.`{table_name}`",
    ]
    errors = []
    for candidate in candidates:
        try:
            df = spark.table(candidate)
            print("Using Bronze table:", candidate)
            return df
        except Exception as exc:
            errors.append(f"{candidate}: {exc}")
    raise RuntimeError(
        f"Could not read Bronze table '{table_name}'. Tried:\n" + "\n".join(errors)
    )

def require_columns(df, required: list[str], object_name: str) -> None:
    missing = [name for name in required if name not in df.columns]
    if missing:
        raise RuntimeError(
            f"{object_name} is missing required columns: {missing}. "
            f"Available columns: {df.columns}"
        )

def latest_salesforce_rows(df):
    ordering = [
        F.col(name).desc_nulls_last()
        for name in ["SystemModstamp", "LastModifiedDate", "CreatedDate"]
        if name in df.columns
    ]
    if not ordering:
        return df.dropDuplicates(["Id"])
    return (
        df.withColumn("_rn", F.row_number().over(Window.partitionBy("Id").orderBy(*ordering)))
          .filter(F.col("_rn") == 1)
          .drop("_rn")
    )

# %%
request_raw = read_bronze_table("Estimating Request")
user_raw = read_bronze_table("User")
record_type_raw = read_bronze_table("Record Type")

require_columns(
    request_raw,
    [
        "Id", "Name", "OwnerId", "IsDeleted", "CreatedDate",
        "Complete_By_Date__c", "Date_Closed__c",
        "Hours_Taken_to_Close__c", "Sales_Division__c",
        "Project_Region__c", "Project_Name__c", "Status__c",
        "RecordTypeId", "SystemModstamp"
    ],
    "dbo.Estimating Request"
)
require_columns(user_raw, ["Id", "Name"], "dbo.User")
require_columns(record_type_raw, ["Id", "Name", "SobjectType"], "dbo.Record Type")

request = latest_salesforce_rows(request_raw)
users = latest_salesforce_rows(user_raw)
record_types = latest_salesforce_rows(record_type_raw)

dates = (
    spark.table(p_date_table)
    .select(
        "date_key", "calendar_date", "customer_year", "customer_week_no",
        "week_start_date", "week_end_date", "week_key"
    )
    .dropDuplicates(["calendar_date"])
)

# %%
req = request.alias("r")
usr = users.select(
    F.col("Id").alias("user_id"),
    F.coalesce(F.col("Full_Name__c"), F.col("Name")).alias("source_owner_name")
).alias("u")
rt = record_types.select(
    F.col("Id").alias("record_type_id"),
    F.col("Name").alias("record_type_name"),
    F.col("SobjectType").alias("record_type_object")
).alias("rt")

closed_date = F.to_date(F.col("r.Date_Closed__c"))
complete_by_date = F.to_date(F.col("r.Complete_By_Date__c"))

fact_estimating = (
    req
    .filter(~F.coalesce(F.col("r.IsDeleted"), F.lit(False)))
    .join(usr, F.col("r.OwnerId") == F.col("u.user_id"), "left")
    .join(rt, F.col("r.RecordTypeId") == F.col("rt.record_type_id"), "left")
    .withColumn("estimating_request_id", F.col("r.Id"))
    .withColumn("estimating_request_no", F.coalesce(F.col("r.Name"), F.col("r.Id")))
    .withColumn("project_name", F.coalesce(F.col("r.Project_Name__c"), F.col("r.Project_Name2__c")))
    .withColumn("complete_by_date", complete_by_date)
    .withColumn("closed_timestamp", F.col("r.Date_Closed__c").cast("timestamp"))
    .withColumn("closed_date", closed_date)
    .withColumn("hours_taken_to_close", F.col("r.Hours_Taken_to_Close__c").cast("double"))
    .withColumn("sales_division", F.col("r.Sales_Division__c").cast("string"))
    .withColumn("project_region", F.col("r.Project_Region__c").cast("string"))
    .withColumn("request_status", F.col("r.Status__c").cast("string"))
    .withColumn("currency_code", F.col("r.CurrencyIsoCode").cast("string"))
    .withColumn("is_closed", closed_date.isNotNull())
    .withColumn(
        "on_time_flag",
        F.when(closed_date.isNull(), F.lit(None).cast("int"))
         .when(complete_by_date.isNull(), F.lit(0))
         .when(closed_date <= complete_by_date, F.lit(1))
         .otherwise(F.lit(0))
    )
    .withColumn("source_created_ts", F.col("r.CreatedDate").cast("timestamp"))
    .withColumn("source_modified_ts", F.col("r.SystemModstamp").cast("timestamp"))
    .join(dates.alias("d"), closed_date == F.col("d.calendar_date"), "left")
    .select(
        "estimating_request_id",
        "estimating_request_no",
        "project_name",
        F.col("r.OwnerId").alias("source_owner_id"),
        "source_owner_name",
        "record_type_name",
        "complete_by_date",
        "closed_timestamp",
        "closed_date",
        "hours_taken_to_close",
        "sales_division",
        "project_region",
        "request_status",
        "currency_code",
        "is_closed",
        "on_time_flag",
        F.col("d.date_key").alias("closed_date_key"),
        F.col("d.customer_year").alias("closed_customer_year"),
        F.col("d.customer_week_no").alias("closed_customer_week_no"),
        F.col("d.week_start_date").alias("closed_week_start_date"),
        F.col("d.week_end_date").alias("closed_week_end_date"),
        F.col("d.week_key").alias("closed_week_key"),
        "source_created_ts",
        "source_modified_ts",
        F.current_timestamp().alias("created_ts"),
        F.current_timestamp().alias("updated_ts"),
    )
)

duplicate_ids = (
    fact_estimating.groupBy("estimating_request_id").count().filter("count > 1").count()
)
if duplicate_ids:
    raise RuntimeError(f"Duplicate Estimating Request IDs found after transformation: {duplicate_ids}")

(
    fact_estimating.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(p_target_table)
)

print("Rows written:", fact_estimating.count())
display(
    fact_estimating
    .filter(F.col("closed_date").isNotNull())
    .orderBy(F.col("closed_date").desc())
    .limit(20)
)

# %%
# Compact validation
result = spark.table(p_target_table)

result.groupBy("closed_customer_year", "closed_customer_week_no").agg(
    F.countDistinct("estimating_request_id").alias("closed_requests"),
    F.round(F.avg(F.col("on_time_flag").cast("double")) * 100.0, 4).alias("on_time_pct"),
    F.round(
        F.avg(
            F.when(F.col("hours_taken_to_close") > 0, F.col("hours_taken_to_close"))
        ),
        4
    ).alias("avg_positive_hours")
).orderBy(
    F.col("closed_customer_year").desc(),
    F.col("closed_customer_week_no").desc()
).show(20, truncate=False)
