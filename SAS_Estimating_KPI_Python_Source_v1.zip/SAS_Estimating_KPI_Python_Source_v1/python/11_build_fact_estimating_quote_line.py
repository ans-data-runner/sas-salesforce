"""
Converted from: 11_build_fact_estimating_quote_line.ipynb

This file is intended for use as a Microsoft Fabric PySpark notebook source.
Sections are separated with '# %%' cell markers so the file can also be opened
as a cell-based Python script in compatible editors.
"""

# %% [markdown]
# # 11 - Build Estimating Quote and Quote Line facts
#
# Grain:
# - `salesforce.fact_estimating_quote`: one row per Salesforce Quote.
# - `salesforce.fact_estimating_quote_line`: one row per Salesforce Quote Line.
#
# The workbook calculates the cost KPI as the unweighted average of line-level `Sqm_Rate__c`
# after excluding rows where `Item_SQM__c < 0.03`.
#
# The workbook exports do not expose the Salesforce report's week-date filter. The notebook
# therefore keeps both Quote Date and Closed Date week mappings and makes the selected basis
# configurable.

# %%  # tags: parameters
# Fabric pipeline parameters
p_bronze_lakehouse = "bronze_lakehouse"
p_date_table = "dbo.dim_date"
p_quote_target_table = "salesforce.fact_estimating_quote"
p_quote_line_target_table = "salesforce.fact_estimating_quote_line"

# Supported values: "Quote_Date__c", "Closed_Date__c", "Closed_Date_Time__c".
# Quote_Date__c is the default working assumption and must be confirmed against the live
# Salesforce report filter.
p_cost_reporting_date_column = "Quote_Date__c"

# The supplied workbook only proves the Item SQM >= 0.03 rule.
# These optional filters are deliberately disabled until the Salesforce report definition
# confirms them.
p_require_primary_quote = False
p_allowed_quote_statuses = []  # e.g. ["Approved", "Presented"]

# %%
from pyspark.sql import functions as F
from pyspark.sql.window import Window

def read_bronze_table(table_name: str):
    candidates = [
        f"`{p_bronze_lakehouse}`.`{table_name}`",
        f"`{p_bronze_lakehouse}`.`dbo`.`{table_name}`",
        f"{p_bronze_lakehouse}.`{table_name}`",
        f"{p_bronze_lakehouse}.dbo.`{table_name}`",
    ]
    errors = []
    for candidate in candidates:
        try:
            df = spark.table(candidate)
            print("Using Bronze table:", candidate)
            return df
        except Exception as exc:
            errors.append(f"{candidate}: {exc}")
    raise RuntimeError(
        f"Could not read Bronze table '{table_name}'. Tried:\n" + "\n".join(errors)
    )

def require_columns(df, required: list[str], object_name: str) -> None:
    missing = [name for name in required if name not in df.columns]
    if missing:
        raise RuntimeError(
            f"{object_name} is missing required columns: {missing}. "
            f"Available columns: {df.columns}"
        )

def latest_salesforce_rows(df):
    ordering = [
        F.col(name).desc_nulls_last()
        for name in ["SystemModstamp", "LastModifiedDate", "CreatedDate"]
        if name in df.columns
    ]
    if not ordering:
        return df.dropDuplicates(["Id"])
    return (
        df.withColumn("_rn", F.row_number().over(Window.partitionBy("Id").orderBy(*ordering)))
          .filter(F.col("_rn") == 1)
          .drop("_rn")
    )

# %%
quote_raw = read_bronze_table("Quote")
quote_line_raw = read_bronze_table("Quote Line")
request_raw = read_bronze_table("Estimating Request")

require_columns(
    quote_raw,
    [
        "Id", "Name", "IsDeleted", "Estimating_Request__c",
        "Estimating_Request_No__c", "Quote_Date__c", "Closed_Date__c",
        "SBQQ__Status__c", "SBQQ__Primary__c", "SBQQ__NetAmount__c",
        "Quote_SQM__c", "SQM_Rate__c", "Sales_Division__c", "Region__c",
        "SystemModstamp"
    ],
    "dbo.Quote"
)
require_columns(
    quote_line_raw,
    [
        "Id", "Name", "IsDeleted", "SBQQ__Quote__c",
        "SBQQ__Quantity__c", "SBQQ__NetTotal__c",
        "SBQQ__Description__c", "Item_SQM__c",
        "Line_SQM__c", "Sqm_Rate__c", "Price_Excluded__c",
        "SystemModstamp"
    ],
    "dbo.Quote Line"
)
require_columns(
    request_raw,
    ["Id", "Name", "Project_Name__c", "Project_Name2__c"],
    "dbo.Estimating Request"
)

quote = latest_salesforce_rows(quote_raw)
quote_line = latest_salesforce_rows(quote_line_raw)
request = latest_salesforce_rows(request_raw)

dates = (
    spark.table(p_date_table)
    .select(
        "date_key", "calendar_date", "customer_year", "customer_week_no",
        "week_start_date", "week_end_date", "week_key"
    )
    .dropDuplicates(["calendar_date"])
)

# %%
supported_dates = {"Quote_Date__c", "Closed_Date__c", "Closed_Date_Time__c"}
if p_cost_reporting_date_column not in supported_dates:
    raise ValueError(
        f"p_cost_reporting_date_column must be one of {sorted(supported_dates)}; "
        f"received {p_cost_reporting_date_column!r}"
    )

q = quote.alias("q")
r = request.select(
    F.col("Id").alias("request_id"),
    F.col("Name").alias("request_no"),
    F.coalesce(F.col("Project_Name__c"), F.col("Project_Name2__c")).alias("request_project_name")
).alias("r")

# Prefer the Salesforce relationship ID. Use request number only as a controlled fallback.
request_join_condition = (
    (F.col("q.Estimating_Request__c") == F.col("r.request_id")) |
    (
        F.col("q.Estimating_Request__c").isNull() &
        (F.col("q.Estimating_Request_No__c") == F.col("r.request_no"))
    )
)

quote_date = F.to_date(F.col("q.Quote_Date__c"))
closed_date = F.to_date(F.col("q.Closed_Date__c"))
closed_datetime_date = F.to_date(F.col("q.Closed_Date_Time__c")) if "Closed_Date_Time__c" in quote.columns else closed_date

selected_date = {
    "Quote_Date__c": quote_date,
    "Closed_Date__c": closed_date,
    "Closed_Date_Time__c": closed_datetime_date,
}[p_cost_reporting_date_column]

base_quote = (
    q.filter(~F.coalesce(F.col("q.IsDeleted"), F.lit(False)))
     .join(r, request_join_condition, "left")
)

if p_require_primary_quote:
    base_quote = base_quote.filter(F.col("q.SBQQ__Primary__c") == F.lit(True))

if p_allowed_quote_statuses:
    base_quote = base_quote.filter(F.col("q.SBQQ__Status__c").isin(p_allowed_quote_statuses))

fact_quote = (
    base_quote
    .join(dates.alias("qd"), quote_date == F.col("qd.calendar_date"), "left")
    .join(dates.alias("cd"), closed_date == F.col("cd.calendar_date"), "left")
    .join(dates.alias("sd"), selected_date == F.col("sd.calendar_date"), "left")
    .select(
        F.col("q.Id").alias("quote_id"),
        F.col("q.Name").alias("quote_name"),
        F.coalesce(F.col("r.request_id"), F.col("q.Estimating_Request__c")).alias("estimating_request_id"),
        F.coalesce(F.col("r.request_no"), F.col("q.Estimating_Request_No__c")).alias("estimating_request_no"),
        F.col("r.request_project_name").alias("project_name"),
        F.col("q.CurrencyIsoCode").alias("currency_code"),
        F.col("q.SBQQ__Status__c").alias("quote_status"),
        F.col("q.SBQQ__Primary__c").alias("is_primary_quote"),
        F.col("q.SBQQ__NetAmount__c").cast("double").alias("quote_net_amount"),
        F.col("q.Quote_SQM__c").cast("double").alias("quote_sqm"),
        F.col("q.SQM_Rate__c").cast("double").alias("quote_sqm_rate"),
        F.col("q.Sales_Division__c").alias("sales_division"),
        F.col("q.Region__c").alias("sales_region"),
        quote_date.alias("quote_date"),
        closed_date.alias("closed_date"),
        selected_date.alias("cost_kpi_reporting_date"),
        F.col("qd.customer_year").alias("quote_date_customer_year"),
        F.col("qd.customer_week_no").alias("quote_date_customer_week_no"),
        F.col("qd.week_key").alias("quote_date_week_key"),
        F.col("cd.customer_year").alias("closed_date_customer_year"),
        F.col("cd.customer_week_no").alias("closed_date_customer_week_no"),
        F.col("cd.week_key").alias("closed_date_week_key"),
        F.col("sd.date_key").alias("cost_kpi_date_key"),
        F.col("sd.customer_year").alias("cost_kpi_customer_year"),
        F.col("sd.customer_week_no").alias("cost_kpi_customer_week_no"),
        F.col("sd.week_start_date").alias("cost_kpi_week_start_date"),
        F.col("sd.week_end_date").alias("cost_kpi_week_end_date"),
        F.col("sd.week_key").alias("cost_kpi_week_key"),
        F.lit(p_cost_reporting_date_column).alias("cost_reporting_date_basis"),
        F.col("q.CreatedDate").cast("timestamp").alias("source_created_ts"),
        F.col("q.SystemModstamp").cast("timestamp").alias("source_modified_ts"),
        F.current_timestamp().alias("created_ts"),
        F.current_timestamp().alias("updated_ts"),
    )
)

(
    fact_quote.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(p_quote_target_table)
)

print("Quote rows written:", fact_quote.count())

# %%
ql = quote_line.alias("ql")
fq = fact_quote.alias("fq")

fact_quote_line = (
    ql
    .filter(~F.coalesce(F.col("ql.IsDeleted"), F.lit(False)))
    .join(fq, F.col("ql.SBQQ__Quote__c") == F.col("fq.quote_id"), "inner")
    .select(
        F.col("ql.Id").alias("quote_line_id"),
        F.col("ql.Name").alias("quote_line_name"),
        F.col("fq.quote_id"),
        F.col("fq.quote_name"),
        F.col("fq.estimating_request_id"),
        F.col("fq.estimating_request_no"),
        F.col("fq.project_name"),
        F.col("fq.quote_status"),
        F.col("fq.is_primary_quote"),
        F.col("fq.sales_division"),
        F.col("fq.sales_region"),
        F.col("ql.CurrencyIsoCode").alias("currency_code"),
        F.col("ql.SBQQ__Quantity__c").cast("double").alias("quantity"),
        F.col("ql.SBQQ__NetTotal__c").cast("double").alias("net_total"),
        F.col("ql.SBQQ__Description__c").alias("line_description"),
        F.col("ql.Item_SQM__c").cast("double").alias("item_sqm"),
        F.col("ql.Line_SQM__c").cast("double").alias("line_sqm"),
        F.col("ql.Sqm_Rate__c").cast("double").alias("sqm_rate"),
        F.col("ql.Price_Excluded__c").cast("boolean").alias("price_excluded"),
        F.when(
            (F.col("ql.Item_SQM__c").cast("double") >= F.lit(0.03)) &
            F.col("ql.Sqm_Rate__c").cast("double").isNotNull(),
            F.lit(True)
        ).otherwise(F.lit(False)).alias("is_sqm_kpi_eligible"),
        F.col("fq.quote_date"),
        F.col("fq.closed_date"),
        F.col("fq.cost_kpi_reporting_date"),
        F.col("fq.quote_date_customer_year"),
        F.col("fq.quote_date_customer_week_no"),
        F.col("fq.quote_date_week_key"),
        F.col("fq.closed_date_customer_year"),
        F.col("fq.closed_date_customer_week_no"),
        F.col("fq.closed_date_week_key"),
        F.col("fq.cost_kpi_date_key"),
        F.col("fq.cost_kpi_customer_year"),
        F.col("fq.cost_kpi_customer_week_no"),
        F.col("fq.cost_kpi_week_start_date"),
        F.col("fq.cost_kpi_week_end_date"),
        F.col("fq.cost_kpi_week_key"),
        F.col("fq.cost_reporting_date_basis"),
        F.col("ql.CreatedDate").cast("timestamp").alias("source_created_ts"),
        F.col("ql.SystemModstamp").cast("timestamp").alias("source_modified_ts"),
        F.current_timestamp().alias("created_ts"),
        F.current_timestamp().alias("updated_ts"),
    )
)

duplicate_lines = fact_quote_line.groupBy("quote_line_id").count().filter("count > 1").count()
if duplicate_lines:
    raise RuntimeError(f"Duplicate Quote Line IDs found after transformation: {duplicate_lines}")

(
    fact_quote_line.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(p_quote_line_target_table)
)

print("Quote Line rows written:", fact_quote_line.count())
display(
    fact_quote_line
    .filter(F.col("is_sqm_kpi_eligible"))
    .orderBy(F.col("cost_kpi_reporting_date").desc())
    .limit(20)
)

# %%
# Compact comparison of the two plausible week-date mappings.
line_fact = spark.table(p_quote_line_target_table).filter("is_sqm_kpi_eligible = true")

quote_date_summary = (
    line_fact.groupBy("quote_date_customer_year", "quote_date_customer_week_no")
    .agg(
        F.avg("sqm_rate").alias("average_sqm_rate"),
        F.count("*").alias("eligible_line_count")
    )
    .withColumn("date_basis", F.lit("Quote_Date__c"))
    .withColumnRenamed("quote_date_customer_year", "customer_year")
    .withColumnRenamed("quote_date_customer_week_no", "customer_week_no")
)

closed_date_summary = (
    line_fact.groupBy("closed_date_customer_year", "closed_date_customer_week_no")
    .agg(
        F.avg("sqm_rate").alias("average_sqm_rate"),
        F.count("*").alias("eligible_line_count")
    )
    .withColumn("date_basis", F.lit("Closed_Date__c"))
    .withColumnRenamed("closed_date_customer_year", "customer_year")
    .withColumnRenamed("closed_date_customer_week_no", "customer_week_no")
)

display(
    quote_date_summary.unionByName(closed_date_summary)
    .filter(F.col("customer_year").isNotNull())
    .orderBy(
        F.col("customer_year").desc(),
        F.col("customer_week_no").desc(),
        "date_basis"
    )
)
