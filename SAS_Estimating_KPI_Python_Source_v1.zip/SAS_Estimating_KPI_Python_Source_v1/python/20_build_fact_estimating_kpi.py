"""
Converted from: 20_build_fact_estimating_kpi.ipynb

This file is intended for use as a Microsoft Fabric PySpark notebook source.
Sections are separated with '# %%' cell markers so the file can also be opened
as a cell-based Python script in compatible editors.
"""

# %% [markdown]
# # 20 - Build `kpi.fact_estimating_kpi`
#
# Grain: one row per Estimating KPI per customer week.
#
# The table is the direct Silver-to-Gold load contract. Gold does not need a staging schema.

# %%  # tags: parameters
# Fabric pipeline parameters
p_date_table = "dbo.dim_date"
p_request_fact = "salesforce.fact_estimating"
p_quote_line_fact = "salesforce.fact_estimating_quote_line"
p_kpi_dimension = "kpi.dim_kpi"
p_department_dimension = "kpi.dim_department"
p_target_table = "kpi.fact_kpi_target"
p_commentary_table = "kpi.fact_kpi_commentary"
p_output_table = "kpi.fact_estimating_kpi"

p_department_code = "ESTIMATING"
p_reporting_year = 2025
p_as_of_date = "2025-10-17"  # Set to None in the production pipeline to use current date.
p_load_batch_id = "interactive"

# %%
from datetime import date
from pyspark.sql import functions as F

required_tables = [
    p_date_table, p_request_fact, p_quote_line_fact,
    p_kpi_dimension, p_department_dimension, p_target_table,
    p_commentary_table
]
missing_tables = [t for t in required_tables if not spark.catalog.tableExists(t)]
if missing_tables:
    raise RuntimeError(f"Run the prerequisite notebooks first. Missing tables: {missing_tables}")

as_of_date = date.fromisoformat(p_as_of_date) if p_as_of_date else date.today()

dim_date = spark.table(p_date_table)
request_fact = spark.table(p_request_fact)
quote_line_fact = spark.table(p_quote_line_fact)
dim_kpi = spark.table(p_kpi_dimension)
dim_department = spark.table(p_department_dimension)
targets = spark.table(p_target_table)
commentary = spark.table(p_commentary_table)

# %%
# One date row per customer week, anchored to the Friday week ending date.
weeks = (
    dim_date
    .filter(F.col("customer_year") == F.lit(int(p_reporting_year)))
    .filter(F.col("calendar_date") == F.col("week_end_date"))
    .select(
        "date_key",
        F.col("week_end_date").alias("week_ending_date"),
        "week_start_date",
        "week_end_date",
        F.col("customer_year").alias("calendar_year"),
        F.col("customer_week_no").alias("week_number"),
        "week_key",
    )
    .dropDuplicates(["week_key"])
)

if weeks.count() == 0:
    raise RuntimeError(f"No customer weeks found in {p_date_table} for {p_reporting_year}")

current_week_row = (
    dim_date
    .filter(F.col("calendar_date") == F.to_date(F.lit(as_of_date.isoformat())))
    .select("customer_year", "customer_week_no", "week_key")
    .limit(1)
    .collect()
)

if current_week_row and current_week_row[0]["customer_year"] == int(p_reporting_year):
    current_week = int(current_week_row[0]["customer_week_no"])
    current_week_key = int(current_week_row[0]["week_key"])
elif int(p_reporting_year) < as_of_date.year:
    latest = weeks.orderBy(F.col("week_key").desc()).limit(1).collect()[0]
    current_week = int(latest["week_number"])
    current_week_key = int(latest["week_key"])
else:
    current_week = 0
    current_week_key = 0

print(
    "Reporting year:", p_reporting_year,
    "As-of date:", as_of_date,
    "Current customer week:", current_week,
    "Current week key:", current_week_key
)

# %%
# Request-based KPI actuals
request_weekly = (
    request_fact
    .filter(
        F.col("is_closed") &
        (F.col("closed_customer_year") == F.lit(int(p_reporting_year)))
    )
    .groupBy("closed_week_key")
    .agg(
        F.countDistinct("estimating_request_id").cast("double").alias("quotes_issued"),
        (
            F.sum(F.col("on_time_flag").cast("double")) /
            F.countDistinct("estimating_request_id") * F.lit(100.0)
        ).alias("quotes_on_time_pct"),
        F.avg(
            F.when(
                F.col("hours_taken_to_close") > F.lit(0.0),
                F.col("hours_taken_to_close")
            )
        ).alias("average_positive_hours"),
        F.countDistinct("estimating_request_id").alias("request_source_count"),
        F.countDistinct(
            F.when(
                F.col("hours_taken_to_close") > F.lit(0.0),
                F.col("estimating_request_id")
            )
        ).alias("hours_source_count"),
    )
    .withColumnRenamed("closed_week_key", "week_key")
)

request_kpis = (
    request_weekly
    .select(
        "week_key",
        F.lit("EST_QUOTES_ISSUED").alias("kpi_code"),
        F.col("quotes_issued").alias("actual_value"),
        F.col("request_source_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.dbo.Estimating Request").alias("source_object"),
        F.lit(None).cast("string").alias("source_quality_flag")
    )
    .unionByName(
        request_weekly.select(
            "week_key",
            F.lit("EST_QUOTES_ON_TIME").alias("kpi_code"),
            F.col("quotes_on_time_pct").alias("actual_value"),
            F.col("request_source_count").cast("long").alias("source_row_count"),
            F.lit("bronze_lakehouse.dbo.Estimating Request").alias("source_object"),
            F.when(
                F.col("request_source_count") == 0,
                F.lit("NO_CLOSED_REQUESTS")
            ).otherwise(F.lit(None).cast("string")).alias("source_quality_flag")
        )
    )
    .unionByName(
        request_weekly.select(
            "week_key",
            F.lit("EST_AVG_HOURS").alias("kpi_code"),
            F.col("average_positive_hours").alias("actual_value"),
            F.col("hours_source_count").cast("long").alias("source_row_count"),
            F.lit("bronze_lakehouse.dbo.Estimating Request").alias("source_object"),
            F.when(
                F.col("hours_source_count") == 0,
                F.lit("NO_POSITIVE_HOURS")
            ).otherwise(F.lit(None).cast("string")).alias("source_quality_flag")
        )
    )
)

# %%
# Workbook rule: arithmetic average of eligible line-level Sqm_Rate__c values.
cost_kpis = (
    quote_line_fact
    .filter(
        F.col("is_sqm_kpi_eligible") &
        (F.col("cost_kpi_customer_year") == F.lit(int(p_reporting_year)))
    )
    .groupBy("cost_kpi_week_key")
    .agg(
        F.avg("sqm_rate").alias("actual_value"),
        F.count("*").cast("long").alias("source_row_count"),
        F.countDistinct("quote_id").alias("source_quote_count"),
        F.first("cost_reporting_date_basis", ignorenulls=True).alias("date_basis")
    )
    .withColumnRenamed("cost_kpi_week_key", "week_key")
    .withColumn("kpi_code", F.lit("EST_RATE_PER_SQM"))
    .withColumn("source_object", F.lit("bronze_lakehouse.dbo.Quote + dbo.Quote Line"))
    .withColumn(
        "source_quality_flag",
        F.concat(
            F.lit("DATE_BASIS="),
            F.coalesce(F.col("date_basis"), F.lit("UNKNOWN")),
            F.lit("; QUOTES="),
            F.col("source_quote_count").cast("string")
        )
    )
    .select(
        "week_key", "kpi_code", "actual_value", "source_row_count",
        "source_object", "source_quality_flag"
    )
)

actuals = request_kpis.unionByName(cost_kpis)

# %%
department = (
    dim_department
    .filter(
        (F.col("department_code") == F.lit(p_department_code)) &
        F.col("is_active")
    )
    .select(
        "department_code", "department_name", "department_owner",
        "submission_frequency"
    )
    .limit(1)
)

if department.count() != 1:
    raise RuntimeError("Exactly one active Estimating department row is required.")

kpis = (
    dim_kpi
    .filter(
        (F.col("department_code") == F.lit(p_department_code)) &
        F.col("is_active")
    )
)

# Full weekly scaffold preserves future weeks in the report.
scaffold = weeks.crossJoin(kpis).crossJoin(department)

target_join_condition = (
    (F.col("s.kpi_id") == F.col("t.kpi_id")) &
    (F.col("s.week_key") >= F.col("t.effective_from_week_key")) &
    (
        F.col("t.effective_to_week_key").isNull() |
        (F.col("s.week_key") <= F.col("t.effective_to_week_key"))
    )
)

weekly_commentary = commentary.select(
    F.col("kpi_id").alias("commentary_kpi_id"),
    F.col("week_key").alias("commentary_week_key"),
    F.col("commentary").alias("weekly_commentary")
)

result_base = (
    scaffold.alias("s")
    .join(actuals.alias("a"), ["week_key", "kpi_code"], "left")
    .join(targets.alias("t"), target_join_condition, "left")
    .join(
        weekly_commentary.alias("c"),
        (F.col("s.kpi_id") == F.col("c.commentary_kpi_id")) &
        (F.col("s.week_key") == F.col("c.commentary_week_key")),
        "left"
    )
    .select(
        F.col("s.date_key"),
        F.col("s.week_ending_date"),
        F.col("s.week_start_date"),
        F.col("s.week_end_date"),
        F.col("s.calendar_year"),
        F.col("s.week_number"),
        F.col("s.week_key"),
        F.col("s.kpi_id"),
        F.col("s.kpi_code"),
        F.col("s.kpi_name"),
        F.col("s.kpi_category"),
        F.col("s.department_name").alias("organisational_unit"),
        F.col("s.department_name").alias("department"),
        F.col("s.department_owner"),
        F.col("s.submission_frequency"),
        F.col("s.measure_name"),
        F.col("s.uom"),
        F.col("s.breach_direction"),
        F.col("s.sign_label"),
        F.coalesce(F.col("c.weekly_commentary"), F.col("s.default_commentary")).alias("commentary"),
        F.col("s.active_from_week_key"),
        F.col("a.actual_value").cast("double").alias("actual_value"),
        F.col("t.target_value").cast("double").alias("target_value"),
        F.col("a.source_row_count").cast("long").alias("source_row_count"),
        F.col("a.source_object"),
        F.col("a.source_quality_flag"),
    )
)

# %%
with_status = (
    result_base
    .withColumn(
        "week_state",
        F.when(F.col("week_key") > F.lit(current_week_key), F.lit("Future"))
         .otherwise(F.lit("Calc"))
    )
    .withColumn(
        "data_status",
        F.when(F.col("week_key") > F.lit(current_week_key), F.lit("Future"))
         .when(F.col("week_key") < F.col("active_from_week_key"), F.lit("TBC"))
         .when(F.col("target_value").isNull(), F.lit("TBC"))
         .when(F.col("actual_value").isNull(), F.lit("No Data"))
         .otherwise(F.lit("Actual"))
    )
    .withColumn(
        "variance_value",
        (F.col("actual_value") - F.col("target_value")).cast("double")
    )
    .withColumn(
        "performance_variance_value",
        F.when(
            F.col("breach_direction") == F.lit("OVER"),
            F.col("target_value") - F.col("actual_value")
        ).otherwise(
            F.col("actual_value") - F.col("target_value")
        ).cast("double")
    )
    .withColumn(
        "rag_status",
        F.when(F.col("data_status") == "Future", F.lit(None).cast("string"))
         .when(F.col("data_status") == "TBC", F.lit("TBC"))
         .when(F.col("data_status") == "No Data", F.lit("No Data"))
         .when(
             F.col("breach_direction") == "UNDER",
             F.when(F.col("actual_value") >= F.col("target_value"), F.lit("G"))
              .when(F.col("actual_value") >= F.col("target_value") * F.lit(0.95), F.lit("A"))
              .otherwise(F.lit("R"))
         )
         .when(
             F.col("breach_direction") == "OVER",
             F.when(F.col("actual_value") <= F.col("target_value"), F.lit("G"))
              .when(
                  (F.col("target_value") > F.lit(0.0)) &
                  (F.col("actual_value") <= F.col("target_value") / F.lit(0.95)),
                  F.lit("A")
              )
              .otherwise(F.lit("R"))
         )
         .otherwise(F.lit(None).cast("string"))
    )
)

completeness = (
    with_status
    .filter(F.col("week_key") <= F.lit(current_week_key))
    .groupBy("week_key", "week_number")
    .agg(
        F.sum(
            F.when(F.col("week_key") >= F.col("active_from_week_key"), 1).otherwise(0)
        ).alias("active_kpi_count"),
        F.sum(
            F.when(
                (F.col("week_key") >= F.col("active_from_week_key")) &
                F.col("actual_value").isNotNull(),
                1
            ).otherwise(0)
        ).alias("actual_kpi_count")
    )
    .filter(
        (F.col("active_kpi_count") > 0) &
        (F.col("active_kpi_count") == F.col("actual_kpi_count"))
    )
    .agg(F.max("week_number").alias("completed_up_to_week"))
    .collect()[0]["completed_up_to_week"]
)

completed_up_to_week = int(completeness) if completeness is not None else 0
department_status = "Current" if completed_up_to_week >= current_week else "Overdue"

final_result = (
    with_status
    .withColumn("department_status", F.lit(department_status))
    .withColumn("completed_up_to_week", F.lit(completed_up_to_week).cast("int"))
    .withColumn("current_week", F.lit(current_week).cast("int"))
    .withColumn("source_system", F.lit("Salesforce"))
    .withColumn("load_batch_id", F.lit(p_load_batch_id))
    .withColumn("calculation_timestamp", F.current_timestamp())
    .select(
        "date_key", "week_ending_date", "week_start_date", "week_end_date",
        "calendar_year", "week_number", "week_key",
        "kpi_id", "kpi_code", "kpi_name", "kpi_category",
        "organisational_unit", "department", "department_owner",
        "department_status", "completed_up_to_week", "current_week",
        "submission_frequency", "measure_name", "uom",
        "breach_direction", "sign_label", "commentary",
        F.col("actual_value").cast("decimal(18,4)").alias("actual_value"),
        F.col("target_value").cast("decimal(18,4)").alias("target_value"),
        F.col("variance_value").cast("decimal(19,4)").alias("variance_value"),
        F.col("performance_variance_value").cast("decimal(19,4)").alias("performance_variance_value"),
        "rag_status", "week_state", "data_status",
        "source_system", "source_object", "source_row_count",
        "source_quality_flag", "load_batch_id", "calculation_timestamp"
    )
)

duplicate_grain = (
    final_result
    .groupBy("calendar_year", "week_number", "kpi_id", "organisational_unit")
    .count()
    .filter("count > 1")
    .count()
)
if duplicate_grain:
    raise RuntimeError(f"Duplicate KPI grain detected: {duplicate_grain}")

(
    final_result.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(p_output_table)
)

print(
    "Rows written:", final_result.count(),
    "Completed up to week:", completed_up_to_week,
    "Current week:", current_week,
    "Department status:", department_status
)
display(final_result.filter(F.col("week_number").between(32, 42)).orderBy("week_number", "kpi_id"))
