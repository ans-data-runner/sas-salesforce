"""
Converted from: 00_create_estimating_silver_objects.ipynb

This file is intended for use as a Microsoft Fabric PySpark notebook source.
Sections are separated with '# %%' cell markers so the file can also be opened
as a cell-based Python script in compatible editors.
"""

# %% [markdown]
# # 00 - Create Estimating Silver KPI objects
#
# Attach the schema-enabled Lakehouse `lh_sas_silver` as the default Lakehouse before running.
#
# This notebook creates only Silver objects. It does not create a Gold staging schema or shortcuts.

# %%  # tags: parameters
# Fabric pipeline parameters
p_silver_salesforce_schema = "salesforce"
p_silver_kpi_schema = "kpi"
p_date_table = "dbo.dim_date"

p_department_code = "ESTIMATING"
p_department_name = "Estimating"
p_department_owner = "Julian Sparrow"
p_submission_frequency = "Weekly"

# Workbook targets
p_target_quotes_issued = 126.0
p_target_quotes_on_time = 85.0
p_target_estimated_hours = 28.0
p_target_rate_per_sqm = 75.0

# Cost KPI starts at customer week 22 in the supplied workbook.
p_cost_target_start_year = 2025
p_cost_target_start_week = 22

# %%
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, IntegerType,
    DoubleType, BooleanType, DateType, TimestampType
)

def require_table(table_name: str) -> None:
    if not spark.catalog.tableExists(table_name):
        raise RuntimeError(
            f"Required table '{table_name}' does not exist. "
            "Run the Silver date-dimension notebook first."
        )

require_table(p_date_table)

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {p_silver_salesforce_schema}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {p_silver_kpi_schema}")

print("Current database:", spark.sql("SELECT current_database()").collect()[0][0])
print("Silver schemas ensured:", p_silver_salesforce_schema, p_silver_kpi_schema)

# %%
# Department metadata
spark.sql(f'''
CREATE TABLE IF NOT EXISTS {p_silver_kpi_schema}.dim_department (
    department_code          STRING,
    department_name          STRING,
    department_owner         STRING,
    submission_frequency     STRING,
    is_active                BOOLEAN,
    created_ts               TIMESTAMP,
    updated_ts               TIMESTAMP
)
USING DELTA
''')

# KPI catalogue. Stable IDs are intentionally explicit so the Gold key does not change.
spark.sql(f'''
CREATE TABLE IF NOT EXISTS {p_silver_kpi_schema}.dim_kpi (
    kpi_id                   BIGINT,
    kpi_code                 STRING,
    department_code          STRING,
    kpi_category             STRING,
    kpi_name                 STRING,
    measure_name             STRING,
    uom                      STRING,
    breach_direction         STRING,
    sign_label               STRING,
    default_commentary       STRING,
    active_from_week_key     INT,
    is_active                BOOLEAN,
    created_ts               TIMESTAMP,
    updated_ts               TIMESTAMP
)
USING DELTA
''')

spark.sql(f'''
CREATE TABLE IF NOT EXISTS {p_silver_kpi_schema}.fact_kpi_target (
    kpi_id                   BIGINT,
    effective_from_week_key  INT,
    effective_to_week_key    INT,
    target_value             DOUBLE,
    target_status            STRING,
    source_comment           STRING,
    created_ts               TIMESTAMP,
    updated_ts               TIMESTAMP
)
USING DELTA
''')

# Optional weekly commentary overrides. Leave empty until business commentary is supplied.
spark.sql(f'''
CREATE TABLE IF NOT EXISTS {p_silver_kpi_schema}.fact_kpi_commentary (
    kpi_id                   BIGINT,
    week_key                 INT,
    commentary               STRING,
    commentary_owner         STRING,
    created_ts               TIMESTAMP,
    updated_ts               TIMESTAMP
)
USING DELTA
''')

# %%
dim_date = spark.table(p_date_table)

year_start = (
    dim_date
    .filter(F.col("customer_year") == F.lit(p_cost_target_start_year))
    .agg(F.min("week_key").alias("week_key"))
    .collect()[0]["week_key"]
)

cost_start = (
    dim_date
    .filter(
        (F.col("customer_year") == F.lit(p_cost_target_start_year)) &
        (F.col("customer_week_no") == F.lit(p_cost_target_start_week))
    )
    .agg(F.min("week_key").alias("week_key"))
    .collect()[0]["week_key"]
)

if year_start is None or cost_start is None:
    raise RuntimeError(
        "dbo.dim_date does not contain the required 2025 customer weeks. "
        "Rebuild/populate the date dimension before continuing."
    )

department_rows = [(
    p_department_code,
    p_department_name,
    p_department_owner,
    p_submission_frequency,
    True
)]

department_df = (
    spark.createDataFrame(
        department_rows,
        "department_code string, department_name string, department_owner string, "
        "submission_frequency string, is_active boolean"
    )
    .withColumn("created_ts", F.current_timestamp())
    .withColumn("updated_ts", F.current_timestamp())
)
department_df.createOrReplaceTempView("src_estimating_department")

spark.sql(f'''
MERGE INTO {p_silver_kpi_schema}.dim_department AS tgt
USING src_estimating_department AS src
  ON tgt.department_code = src.department_code
WHEN MATCHED THEN UPDATE SET
  tgt.department_name = src.department_name,
  tgt.department_owner = src.department_owner,
  tgt.submission_frequency = src.submission_frequency,
  tgt.is_active = src.is_active,
  tgt.updated_ts = current_timestamp()
WHEN NOT MATCHED THEN INSERT *
''')

kpi_rows = [
    (
        2101, "EST_QUOTES_ISSUED", p_department_code, "Productivity",
        "Quotes Issues", "Count of quotes issued", "Count",
        "UNDER", "Under Breach",
        "Target is based on the average of Q1 2025 actuals.",
        int(year_start), True
    ),
    (
        2102, "EST_QUOTES_ON_TIME", p_department_code, "Delivery",
        "Quotes Issues on Time", "Percentage of quotes issued on time", "Percentage",
        "UNDER", "Under Breach",
        "Target is based on the average of Q1 2025 actuals.",
        int(year_start), True
    ),
    (
        2103, "EST_AVG_HOURS", p_department_code, "Quality",
        "Estimated Hours", "Average hours used on estimations", "Hours",
        "OVER", "Over Breach",
        "Target is based on the average of Q1 2025 actuals.",
        int(year_start), True
    ),
    (
        2104, "EST_RATE_PER_SQM", p_department_code, "Cost",
        "Rate of Sales per square meter",
        "Average sales value per square metre; quote lines with Item SQM below 0.03 are excluded.",
        "GBP", "UNDER", "Under Breach",
        "Target is set at 75 and may be re-evaluated.",
        int(cost_start), True
    ),
]

kpi_df = (
    spark.createDataFrame(
        kpi_rows,
        "kpi_id long, kpi_code string, department_code string, kpi_category string, "
        "kpi_name string, measure_name string, uom string, breach_direction string, "
        "sign_label string, default_commentary string, active_from_week_key int, "
        "is_active boolean"
    )
    .withColumn("created_ts", F.current_timestamp())
    .withColumn("updated_ts", F.current_timestamp())
)
kpi_df.createOrReplaceTempView("src_estimating_kpi")

spark.sql(f'''
MERGE INTO {p_silver_kpi_schema}.dim_kpi AS tgt
USING src_estimating_kpi AS src
  ON tgt.kpi_id = src.kpi_id
WHEN MATCHED THEN UPDATE SET
  tgt.kpi_code = src.kpi_code,
  tgt.department_code = src.department_code,
  tgt.kpi_category = src.kpi_category,
  tgt.kpi_name = src.kpi_name,
  tgt.measure_name = src.measure_name,
  tgt.uom = src.uom,
  tgt.breach_direction = src.breach_direction,
  tgt.sign_label = src.sign_label,
  tgt.default_commentary = src.default_commentary,
  tgt.active_from_week_key = src.active_from_week_key,
  tgt.is_active = src.is_active,
  tgt.updated_ts = current_timestamp()
WHEN NOT MATCHED THEN INSERT *
''')

# %%
target_rows = [
    (2101, int(year_start), None, float(p_target_quotes_issued), "ACTIVE",
     "Average of Q1 2025 actuals."),
    (2102, int(year_start), None, float(p_target_quotes_on_time), "ACTIVE",
     "Average of Q1 2025 actuals."),
    (2103, int(year_start), None, float(p_target_estimated_hours), "ACTIVE",
     "Average of Q1 2025 actuals."),
    (2104, int(cost_start), None, float(p_target_rate_per_sqm), "ACTIVE",
     "Target supplied in Estimating Team KPI workbook; active from customer week 22."),
]

target_df = (
    spark.createDataFrame(
        target_rows,
        "kpi_id long, effective_from_week_key int, effective_to_week_key int, "
        "target_value double, target_status string, source_comment string"
    )
    .withColumn("created_ts", F.current_timestamp())
    .withColumn("updated_ts", F.current_timestamp())
)
target_df.createOrReplaceTempView("src_estimating_target")

spark.sql(f'''
MERGE INTO {p_silver_kpi_schema}.fact_kpi_target AS tgt
USING src_estimating_target AS src
  ON tgt.kpi_id = src.kpi_id
 AND tgt.effective_from_week_key = src.effective_from_week_key
WHEN MATCHED THEN UPDATE SET
  tgt.effective_to_week_key = src.effective_to_week_key,
  tgt.target_value = src.target_value,
  tgt.target_status = src.target_status,
  tgt.source_comment = src.source_comment,
  tgt.updated_ts = current_timestamp()
WHEN NOT MATCHED THEN INSERT *
''')

display(
    spark.table(f"{p_silver_kpi_schema}.dim_kpi")
    .filter(F.col("department_code") == p_department_code)
    .orderBy("kpi_id")
)
