-- 20_create_estimating_reporting_view.sql

CREATE OR ALTER VIEW salesforce.vw_estimating_kpi_report
AS
SELECT
    department_owner AS owner_name,
    department_status AS status,
    completed_up_to_week,
    current_week,
    submission_frequency AS submission,
    department,
    kpi_category AS category,
    kpi_name AS kpi,
    measure_name AS measure,
    uom,
    sign_label AS sign,
    commentary,
    week_number AS week,
    week_ending_date AS [date_fri],
    target_value AS target,
    actual_value AS actual,
    variance_value AS numeric_variance,
    performance_variance_value,
    rag_status AS variance,
    week_state,
    data_status,
    calendar_year,
    kpi_id,
    kpi_code,
    source_system,
    source_object,
    source_row_count,
    source_quality_flag,
    calculation_timestamp
FROM salesforce.fact_kpi_result_v2
WHERE organisational_unit = 'Estimating';
