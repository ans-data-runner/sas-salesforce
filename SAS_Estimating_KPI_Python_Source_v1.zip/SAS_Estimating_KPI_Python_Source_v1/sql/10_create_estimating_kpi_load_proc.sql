-- 10_create_estimating_kpi_load_proc.sql
-- Run in wh_sas_gold after the Silver notebooks and 00_extend_fact_kpi_result_v2.sql.
-- No Gold staging table or shortcut is used.

CREATE OR ALTER PROCEDURE etl.usp_load_estimating_kpi_results
    @reporting_year INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT
            calendar_year,
            week_number,
            kpi_id,
            organisational_unit,
            COUNT(*) AS row_count
        FROM [lh_sas_silver].[kpi].[fact_estimating_kpi]
        WHERE @reporting_year IS NULL OR calendar_year = @reporting_year
        GROUP BY
            calendar_year,
            week_number,
            kpi_id,
            organisational_unit
        HAVING COUNT(*) > 1
    )
    BEGIN
        THROW 50001, 'Duplicate Estimating KPI rows found in Silver.', 1;
    END;

    BEGIN TRY
        BEGIN TRANSACTION;

        DELETE FROM salesforce.fact_kpi_result_v2
        WHERE organisational_unit = 'Estimating'
          AND (@reporting_year IS NULL OR calendar_year = @reporting_year);

        INSERT INTO salesforce.fact_kpi_result_v2
        (
            date_key,
            week_ending_date,
            week_start_date,
            week_end_date,
            calendar_year,
            week_number,
            week_key,
            kpi_id,
            kpi_code,
            kpi_name,
            kpi_category,
            organisational_unit,
            department,
            department_owner,
            department_status,
            completed_up_to_week,
            current_week,
            submission_frequency,
            measure_name,
            uom,
            breach_direction,
            sign_label,
            commentary,
            actual_value,
            target_value,
            variance_value,
            performance_variance_value,
            rag_status,
            week_state,
            data_status,
            source_system,
            source_object,
            source_row_count,
            source_quality_flag,
            load_batch_id,
            calculation_timestamp
        )
        SELECT
            date_key,
            week_ending_date,
            week_start_date,
            week_end_date,
            calendar_year,
            week_number,
            week_key,
            kpi_id,
            kpi_code,
            kpi_name,
            kpi_category,
            organisational_unit,
            department,
            department_owner,
            department_status,
            completed_up_to_week,
            current_week,
            submission_frequency,
            measure_name,
            uom,
            breach_direction,
            sign_label,
            commentary,
            actual_value,
            target_value,
            variance_value,
            performance_variance_value,
            rag_status,
            week_state,
            data_status,
            source_system,
            source_object,
            source_row_count,
            source_quality_flag,
            load_batch_id,
            calculation_timestamp
        FROM [lh_sas_silver].[kpi].[fact_estimating_kpi]
        WHERE @reporting_year IS NULL OR calendar_year = @reporting_year;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
