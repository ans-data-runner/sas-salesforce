-- 00_extend_fact_kpi_result_v2.sql
-- Run in Warehouse: wh_sas_gold
-- Adds only nullable columns so the existing Proposal load remains compatible.

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'salesforce')
    EXEC('CREATE SCHEMA salesforce');

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'etl')
    EXEC('CREATE SCHEMA etl');

IF OBJECT_ID('salesforce.fact_kpi_result_v2', 'U') IS NULL
BEGIN
    CREATE TABLE salesforce.fact_kpi_result_v2
    (
        date_key                       INT NULL,
        week_ending_date               DATE NULL,
        week_start_date                DATE NULL,
        week_end_date                  DATE NULL,
        calendar_year                  INT NULL,
        week_number                    INT NULL,
        kpi_id                         BIGINT NULL,
        kpi_name                       VARCHAR(8000) NULL,
        kpi_category                   VARCHAR(8000) NULL,
        organisational_unit            VARCHAR(8000) NULL,
        actual_value                   DECIMAL(18,4) NULL,
        target_value                   DECIMAL(18,4) NULL,
        variance_value                 DECIMAL(19,4) NULL,
        breach_direction               VARCHAR(8000) NULL,
        rag_status                     VARCHAR(8000) NULL,
        calculation_timestamp          DATETIME2(6) NULL
    );
END;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'week_key'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD week_key INT NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'kpi_code'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD kpi_code VARCHAR(100) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'department'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD department VARCHAR(200) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'department_owner'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD department_owner VARCHAR(200) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'department_status'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD department_status VARCHAR(50) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'completed_up_to_week'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD completed_up_to_week INT NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'current_week'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD current_week INT NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'submission_frequency'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD submission_frequency VARCHAR(50) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'measure_name'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD measure_name VARCHAR(1000) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'uom'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD uom VARCHAR(100) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'sign_label'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD sign_label VARCHAR(100) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'commentary'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD commentary VARCHAR(8000) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'performance_variance_value'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD performance_variance_value DECIMAL(19,4) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'week_state'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD week_state VARCHAR(50) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'data_status'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD data_status VARCHAR(50) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'source_system'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD source_system VARCHAR(100) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'source_object'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD source_object VARCHAR(1000) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'source_row_count'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD source_row_count BIGINT NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'source_quality_flag'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD source_quality_flag VARCHAR(1000) NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('salesforce.fact_kpi_result_v2') AND name = 'load_batch_id'
)
    ALTER TABLE salesforce.fact_kpi_result_v2 ADD load_batch_id VARCHAR(200) NULL;
