-- 90_validate_estimating_gold.sql

-- Expected grain: one row per Estimating KPI per customer week.
SELECT
    calendar_year,
    week_number,
    kpi_id,
    kpi_name,
    COUNT(*) AS row_count
FROM salesforce.fact_kpi_result_v2
WHERE organisational_unit = 'Estimating'
GROUP BY calendar_year, week_number, kpi_id, kpi_name
HAVING COUNT(*) > 1;

-- Week 42 values should be approximately:
-- Quotes Issues = 123 / A
-- Quotes Issues on Time = 82.1138 / A
-- Estimated Hours = 26.1935 / G
-- Rate of Sales per square meter = 80.6599 / G
-- The cost value depends on confirming the Salesforce Quote report week-date filter.
SELECT
    calendar_year,
    week_number,
    kpi_code,
    kpi_name,
    target_value,
    actual_value,
    variance_value,
    rag_status,
    source_row_count,
    source_quality_flag
FROM salesforce.fact_kpi_result_v2
WHERE organisational_unit = 'Estimating'
  AND calendar_year = 2025
  AND week_number BETWEEN 32 AND 42
ORDER BY week_number, kpi_id;

SELECT TOP (100)
    *
FROM salesforce.vw_estimating_kpi_report
ORDER BY calendar_year DESC, week DESC, kpi_id;
