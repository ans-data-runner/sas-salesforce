# SAS Estimating KPI Python Source v1

This package contains plain `.py` versions of the five Microsoft Fabric PySpark notebooks.

## Python files

1. `00_create_estimating_silver_objects.py`
2. `10_build_fact_estimating.py`
3. `11_build_fact_estimating_quote_line.py`
4. `20_build_fact_estimating_kpi.py`
5. `90_validate_estimating_week42.py`

The scripts preserve the original notebook cell order and use `# %%` markers between cells.
Notebook markdown has been retained as Python comments.

## Recommended use in Microsoft Fabric

Create a new PySpark notebook and either:

- paste each script section into matching notebook cells; or
- import/open the `.py` file where your Fabric workflow supports Python source files.

Run them in the numbered order shown above.

The supporting SQL, documentation and validation CSV from the original package are included
unchanged.
