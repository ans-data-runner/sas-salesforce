# Existing notebook replacement notes

## Replace

`nb_silver_fact_estimation_table_populate.ipynb`

with:

- `10_build_fact_estimating.ipynb`
- `11_build_fact_estimating_quote_line.ipynb`
- `20_build_fact_estimating_kpi.ipynb`

## Do not use for Estimating

`nb_silver_fact_kpi_result_staging_table_populate.ipynb`

That notebook is Design/Proposal specific and assumes a Gold staging shortcut.

## Keep

Your existing customer-calendar notebooks and `dbo.dim_date`, subject to confirming that the
date dimension is complete for all reporting years.

Your existing Proposal fact and Proposal KPI logic can remain while the Gold KPI table is
extended with nullable metadata columns.
