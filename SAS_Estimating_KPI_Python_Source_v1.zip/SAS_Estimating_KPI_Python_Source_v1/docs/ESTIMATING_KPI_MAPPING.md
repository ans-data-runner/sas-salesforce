# Estimating KPI calculation mapping

## 1. Productivity - Quotes Issues

**Workbook logic**

The workbook pivot counts `Estimating Request: Estimate Request No.` by customer week.

**Salesforce logic**

- Table: `dbo.Estimating Request`
- Business key: `Id`
- Display number: `Name`
- Reporting date: `Date_Closed__c`
- Filter: `IsDeleted = false` and `Date_Closed__c is not null`
- Calculation: `COUNT(DISTINCT Id)`

Target: **126**

Breach direction: **UNDER** - higher is better.

## 2. Delivery - Quotes Issues on Time

**Workbook logic**

The workbook divides the weekly sum of `On Time / Late` by the number of closed requests and
multiplies by 100.

**Salesforce logic**

- Due date: `Complete_By_Date__c`
- Completion date: `Date_Closed__c`
- On-time flag: 1 when completion date is on or before due date; otherwise 0
- Reporting week: completion-date customer week
- Calculation: `SUM(on_time_flag) / COUNT(DISTINCT closed request) * 100`

Target: **85**

Breach direction: **UNDER** - higher is better.

## 3. Quality - Estimated Hours

**Workbook logic**

The raw workbook classifies zero/blank hours as blank, filters those rows out in the pivot, and
calculates weekly sum of hours divided by count of requests.

**Salesforce logic**

- Field: `Hours_Taken_to_Close__c`
- Reporting date: `Date_Closed__c`
- Filter: hours > 0
- Calculation: `AVG(Hours_Taken_to_Close__c)`

Target: **28**

Breach direction: **OVER** - lower is better.

## 4. Cost - Rate of Sales per square meter

**Workbook logic**

Each weekly worksheet exports Quote Lines and uses the existing line-level £/SQM value. It
excludes lines where Item SQM is below 0.03 and takes the arithmetic average of the remaining
line values.

**Salesforce logic**

- Quote Line to Quote: `Quote Line.SBQQ__Quote__c = Quote.Id`
- Quote to Estimating Request:
  `Quote.Estimating_Request__c = Estimating Request.Id`
- Rate: `Quote Line.Sqm_Rate__c`
- Eligibility: `Quote Line.Item_SQM__c >= 0.03`
- Calculation: `AVG(Sqm_Rate__c)`

Target: **75**, active from customer week 22.

Breach direction: **UNDER** - higher is better.

**Unconfirmed source rule**

The workbook export does not identify the date used by the Salesforce report. The notebook
keeps Quote Date and Closed Date mappings and defaults to `Quote_Date__c`.
