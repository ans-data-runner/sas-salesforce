# Deployment checklist

## Silver

- [ ] `lh_sas_silver` is schema enabled.
- [ ] `lh_sas_silver` is attached as the default Lakehouse.
- [ ] `dbo.dim_date` contains the customer calendar and Friday week ending dates.
- [ ] Run notebook 00.
- [ ] Run notebook 10.
- [ ] Confirm Week 42 request metrics: 123, 82.1138%, 26.1935 hours.
- [ ] Run notebook 11.
- [ ] Review Quote Date versus Closed Date £/SQM diagnostic.
- [ ] Set `p_cost_reporting_date_column` to the confirmed Salesforce report date.
- [ ] Run notebook 20.
- [ ] Confirm `kpi.fact_estimating_kpi` has four rows per active/future customer week.
- [ ] Run notebook 90.

## Gold Warehouse

- [ ] Run `00_extend_fact_kpi_result_v2.sql`.
- [ ] Run `10_create_estimating_kpi_load_proc.sql`.
- [ ] Run `20_create_estimating_reporting_view.sql`.
- [ ] Execute the load procedure for 2025.
- [ ] Run `90_validate_estimating_gold.sql`.
- [ ] Confirm the existing Proposal rows remain unchanged.
- [ ] Point/refresh the Power BI template.

## Production

- [ ] Set `p_as_of_date = None`.
- [ ] Pass the Fabric pipeline run ID into `p_load_batch_id`.
- [ ] Schedule notebooks before the Gold stored procedure.
- [ ] Add a retry/wait step if the Lakehouse SQL endpoint has not yet exposed a newly written
      Delta table.
- [ ] Change `p_bronze_lakehouse` only when the Bronze Lakehouse is renamed.
