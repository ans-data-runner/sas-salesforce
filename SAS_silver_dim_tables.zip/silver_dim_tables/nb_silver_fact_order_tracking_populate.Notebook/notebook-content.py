# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import (
    col, year, weekofyear, month,
    current_timestamp, abs, xxhash64, coalesce
)

# Source = Salesforce Order Tracking
src = spark.table("bronze_lakehouse.`Order Tracking`")

# Business Key
bk = coalesce(
    col("Name"),
    col("Id")
).alias("order_tracking_no")

df = (
    src
    .withColumn("order_tracking_no", bk)
    .withColumn("order_id", abs(xxhash64(col("order_tracking_no"))))
    
    # Core fields (aligned to Excel mapping)
    .withColumn("project_name", col("Project_Description__c"))
    .withColumn("infor_order_reference", col("Infor_Order_Reference__c"))
    .withColumn("created_date", col("Created_Date__c").cast("date"))
    
    # KPI duration fields
    .withColumn("days_in_cleansing", col("Days_In_Cleansing__c").cast("double"))
    .withColumn("days_in_signoff", col("Days_In_Customer_Sign_Off__c").cast("double"))
    .withColumn("days_in_engineering", col("Days_In_Engineering__c").cast("double"))
    .withColumn("days_in_scheduling", col("Days_in_Scheduling__c").cast("double"))

    # Date breakdown (MUST match rest of your model)
    .withColumn("created_year", year(col("created_date")))
    .withColumn("created_week", weekofyear(col("created_date")))
    .withColumn("created_month", month(col("created_date")))
)

df.write.mode("overwrite").saveAsTable("fact_order_tracking")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
