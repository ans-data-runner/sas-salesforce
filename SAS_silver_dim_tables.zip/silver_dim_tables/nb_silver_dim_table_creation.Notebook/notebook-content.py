# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

spark.sql("""
CREATE TABLE IF NOT EXISTS dim_date (
    date_key            INT,
    calendar_date       DATE,
    day_of_week         INT,
    day_name            STRING,
    is_weekday          BOOLEAN,
    customer_week_no    INT,
    customer_year       INT,
    customer_period     INT,
    week_start_date     DATE,
    week_end_date       DATE,
    is_current_week     BOOLEAN,
    is_current_year     BOOLEAN
)
USING DELTA;
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE dim_kpi (
    kpi_id                BIGINT,
    category              STRING,
    kpi_name              STRING,
    description           STRING,
    uom                   STRING,
    breach_direction      STRING,     -- 'UNDER' or 'OVER'
    target_value          DECIMAL(18,4),
    rag_threshold_low     DECIMAL(18,4),
    rag_threshold_high    DECIMAL(18,4),
    is_active             BOOLEAN,
    created_utc        TIMESTAMP,
    updated_utc        TIMESTAMP
)
USING DELTA;
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE kpi_target_rule (
    rule_id            BIGINT,
    kpi_category       STRING,
    applies_when_kpi   STRING,      -- e.g. 'Productivity'
    operator           STRING,      -- '<=', '>=', etc.
    comparison_value   DECIMAL(18,4),
    target_value       DECIMAL(18,4),
    is_active          BOOLEAN,
    created_utc        TIMESTAMP,
    updated_utc        TIMESTAMP
)
    USING DELTA;
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE IF NOT EXISTS dim_exchange_rate (
    from_currency_code   STRING,
    to_currency_code     STRING,
    rate_from_to         DECIMAL(18,8),
    rate_to_from         DECIMAL(18,8),
    period_label         STRING,
    period_start_date    DATE,
    period_end_date      DATE,
    source_file          STRING,
    load_timestamp       TIMESTAMP
)
USING DELTA;
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE IF NOT EXISTS fact_proposal (
    proposal_id            BIGINT,            -- deterministic hash
    proposal_request_no    STRING,
    project_name           STRING,
    record_type            STRING,
    sales_division         STRING,
    geography              STRING,
    opened_date            DATE,
    closed_date            DATE,
    closed_year            INT,
    closed_week            INT,
    closed_month           INT,
    currency_code          STRING,
    estimated_value_native DECIMAL(18,2),
    exchange_rate_to_gbp   DECIMAL(18,8),
    estimated_value_gbp    DECIMAL(18,2),
    is_closed              BOOLEAN,
    rejected_drawings_count INT,
    created_utc            TIMESTAMP,
    updated_utc            TIMESTAMP
)
USING DELTA;
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE IF NOT EXISTS fact_proposal_delivery (
    proposal_id         BIGINT,
    proposal_request_no STRING,
    due_date             DATE,
    completed_date       DATE,
    on_time_flag         INT,      -- 1 = on time, 0 = late / not completed
    is_on_time           BOOLEAN,
    created_utc          TIMESTAMP
)
USING DELTA;
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE IF NOT EXISTS fact_quality_weekly (
    year                    INT,
    week_number             INT,
    rejected_designs_count  INT,
    source                  STRING,
    created_utc             TIMESTAMP
)
USING DELTA;
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


spark.sql("""
CREATE TABLE IF NOT EXISTS dim_date (
    date_key                INT,
    calendar_date           DATE,
    day_of_week             INT,
    day_name                STRING,
    is_weekday              BOOLEAN,
    customer_week_no        INT,
    customer_year           INT,
    customer_period         INT,
    calendar_quarter        INT,
    calendar_quarter_name   STRING,
    week_start_date         DATE,
    week_end_date           DATE,
    week_key                INT,
     -- canonical weekly join key (week ending date)
    created_ts              TIMESTAMP,
    updated_ts              TIMESTAMP
)
USING delta;
""")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE IF NOT EXISTS dbo.dim_record_type (
    record_type_key       BIGINT,
    record_type_id        STRING,
    record_type_name      STRING,
    developer_name        STRING,
    sobject_type          STRING,
    is_active             BOOLEAN,
    description           STRING,
    created_ts            TIMESTAMP,
    updated_ts            TIMESTAMP
)
USING delta
""")
print("Ensured table: dbo.dim_record_type")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
