# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "6950bf8e-2162-41a8-af31-7263ad5c1551"
# META         },
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ---- Parameters ----
SOURCE_LH   = "bronze_lakehouse"
SOURCE_TBL  = "dim_date_reference"

TARGET_LH   = "lh_sas_silver"
TARGET_SCHEMA = "dbo"
TARGET_TBL  = "dim_date"

SOURCE_FULL = f"{SOURCE_LH}.{SOURCE_TBL}"
TARGET_FULL = f"{TARGET_SCHEMA}.{TARGET_TBL}"  # e.g. lh_sas_silver.dbo.dim_date

print("SOURCE:", SOURCE_FULL)
print("TARGET:", TARGET_FULL)
print("TARGET lakehouse (set as notebook default):", TARGET_LH)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_src_raw = spark.table(SOURCE_FULL)
df_src_raw.printSchema()
print("Source row count:", df_src_raw.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_src = (
    df_src_raw
    .select(
        F.col("date_key").cast("int").alias("date_key"),
        F.to_date(F.col("calendar_date")).alias("calendar_date"),
        F.col("day_of_week").cast("int").alias("day_of_week"),
        F.col("day_name").cast("string").alias("day_name"),
        F.col("is_weekday").cast("boolean").alias("is_weekday"),
        F.col("customer_week_no").cast("int").alias("customer_week_no"),
        F.col("customer_year").cast("int").alias("customer_year"),
        F.col("customer_period").cast("int").alias("customer_period"),
        F.col("calendar_quarter").cast("int").alias("calendar_quarter"),
        F.col("calendar_quarter_name").cast("string").alias("calendar_quarter_name"),
        F.to_date(F.col("week_start_date")).alias("week_start_date"),
        F.to_date(F.col("week_end_date")).alias("week_end_date"),
    )
    # week_key is derived from week_end_date (YYYYMMDD int) to support weekly KPI joins
    .withColumn(
        "week_key",
        F.when(F.col("week_end_date").isNotNull(),
               F.date_format(F.col("week_end_date"), "yyyyMMdd").cast("int"))
         .otherwise(F.lit(None).cast("int"))
    )
    .withColumn("created_ts", F.current_timestamp())
    .withColumn("updated_ts", F.current_timestamp())
    .dropDuplicates(["date_key"])
)

print("Transformed row count (deduped on date_key):", df_src.count())
df_src.createOrReplaceTempView("src_dim_date")
display(df_src.orderBy("calendar_date").limit(10))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



spark.sql(f"""
MERGE INTO {TARGET_FULL} AS tgt
USING src_dim_date AS src
ON tgt.date_key = src.date_key

WHEN MATCHED THEN UPDATE SET
  tgt.calendar_date = src.calendar_date,
  tgt.day_of_week = src.day_of_week,
  tgt.day_name = src.day_name,
  tgt.is_weekday = src.is_weekday,
  tgt.customer_week_no = src.customer_week_no,
  tgt.customer_year = src.customer_year,
  tgt.customer_period = src.customer_period,
  tgt.calendar_quarter = src.calendar_quarter,
  tgt.calendar_quarter_name = src.calendar_quarter_name,
  tgt.week_start_date = src.week_start_date,
  tgt.week_end_date = src.week_end_date,
  tgt.week_key = src.week_key,
  tgt.updated_ts = current_timestamp()

WHEN NOT MATCHED THEN INSERT (
  date_key, calendar_date, day_of_week, day_name, is_weekday,
  customer_week_no, customer_year, customer_period,
  calendar_quarter, calendar_quarter_name,
  week_start_date, week_end_date, week_key,
  created_ts, updated_ts
)
VALUES (
  src.date_key, src.calendar_date, src.day_of_week, src.day_name, src.is_weekday,
  src.customer_week_no, src.customer_year, src.customer_period,
  src.calendar_quarter, src.calendar_quarter_name,
  src.week_start_date, src.week_end_date, src.week_key,
  src.created_ts, src.updated_ts
)
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("current_database():", spark.sql("SELECT current_database()").collect()[0][0])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# row count + uniqueness
df = spark.table("dbo.dim_date")
print("rows:", df.count())
print("dupe date_key:", df.groupBy("date_key").count().where("count > 1").count())

# check weekly join key coverage
print("null week_end_date:", df.where("week_end_date is null").count())
print("null week_key:", df.where("week_key is null").count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
