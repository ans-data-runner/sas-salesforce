# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "f16f8a32-ffdb-4553-9f10-e2b8c82e4450",
# META       "known_warehouses": [
# META         {
# META           "id": "f16f8a32-ffdb-4553-9f10-e2b8c82e4450",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Bronze source tables
p_bronze_lakehouse = "bronze_lakehouse"

p_ehs_bridgend_candidates = [
    "bronze_lakehouse.ehs_bridgend",
    "bronze_lakehouse.dbo.ehs_bridgend",
    "ehs_bridgend",
    "dbo.ehs_bridgend"
]

p_ehs_maybole_candidates = [
    "bronze_lakehouse.ehs_maybole",
    "bronze_lakehouse.dbo.ehs_maybole",
    "ehs_maybole",
    "dbo.ehs_maybole"
]

p_safety_culture_candidates = [
    "bronze_lakehouse.SafetyCultureTest",
    "bronze_lakehouse.`SafetyCultureTest`",
    "bronze_lakehouse.dbo.SafetyCultureTest",
    "SafetyCultureTest",
    "dbo.SafetyCultureTest"
]

# Silver tables
p_dim_date_candidates = [
    "dbo.dim_date",
    "dim_date",
    "lh_sas_silver.dbo.dim_date",
    "lh_sas_silver.dim_date"
]

p_existing_kpi_table = "dbo.kpi_result_silver_enriched_v2"

p_fact_ehs_energy_table = "dbo.fact_ehs_energy_weekly"
p_fact_ehs_visual_table = "dbo.fact_ehs_visual_inspections"
p_ehs_kpi_output_table = "dbo.kpi_result_ehs_silver_enriched"

# EHS reporting settings
p_department = "Environment, Health and Safety"
p_organisational_unit = "Environment, Health and Safety"
p_source_system = "EHS / SafetyCulture"

# EHS energy data only has Week_No, so set the reporting year here
p_reporting_year = 2026

# KPI IDs
KPI_ID_EHS_LOST_WORKING_DAYS = 5001
KPI_ID_EHS_VISUAL_INSPECTION_COUNT = 5002
KPI_ID_EHS_VISUAL_INSPECTION_SCORE = 5003
KPI_ID_EHS_BRIDGEND_ENERGY_INTENSITY = 5004
KPI_ID_EHS_MAYBOLE_ENERGY_INTENSITY = 5005

# KPI targets
TARGET_LOST_WORKING_DAYS = 0.0
TARGET_VISUAL_INSPECTION_COUNT = 110.0
TARGET_VISUAL_INSPECTION_SCORE = 90.0
TARGET_BRIDGEND_ENERGY_INTENSITY = 0.10
TARGET_MAYBOLE_ENERGY_INTENSITY = 0.10


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def read_first_available_table(candidates):
    errors = []

    for candidate in candidates:
        try:
            df = spark.table(candidate)
            print(f"Using table: {candidate}")
            return df
        except Exception as exc:
            errors.append(f"{candidate}: {str(exc)}")

    raise RuntimeError(
        "Could not read any candidate table. Tried:\n" +
        "\n".join(errors)
    )


def colx(name):
    return F.col(f"`{name}`")


def first_existing_col(df, candidates, alias_name, cast_type=None):
    available = set(df.columns)

    for candidate in candidates:
        if candidate in available:
            expr = colx(candidate)
            if cast_type:
                expr = expr.cast(cast_type)
            return expr.alias(alias_name)

    return F.lit(None).cast(cast_type or "string").alias(alias_name)


def require_any_column(df, candidates, object_name, logical_name):
    available = set(df.columns)

    for candidate in candidates:
        if candidate in available:
            return candidate

    raise RuntimeError(
        f"{object_name} is missing a column for {logical_name}.\n"
        f"Tried: {candidates}\n"
        f"Available columns: {df.columns}"
    )


def parse_date_expr(expr):
    """
    Handles common date string formats and real date/timestamp columns.
    """
    return F.coalesce(
        F.to_date(expr),
        F.to_date(F.to_timestamp(expr)),
        F.to_date(expr.cast("timestamp"))
    )


def parse_percentage_expr(expr):
    """
    Converts SafetyCulture score percentages such as:
      '91'
      '91%'
      '0.91'
    into a percentage value like 91.0.
    """
    cleaned = F.regexp_replace(expr.cast("string"), "%", "").cast("double")

    return (
        F.when(cleaned.isNull(), F.lit(None).cast("double"))
         .when(cleaned <= F.lit(1.0), cleaned * F.lit(100.0))
         .otherwise(cleaned)
    )


def rag_status(actual_col, target_col, breach_col, data_status_col):
    return (
        F.when(data_status_col == "TBC", F.lit("TBC"))
        .when(data_status_col == "No Data", F.lit("No Data"))
        .when(target_col.isNull(), F.lit("TBC"))
        .when(actual_col.isNull(), F.lit("No Data"))

        # UNDER means higher is better
        .when(
            (breach_col == "UNDER") &
            (actual_col >= target_col),
            F.lit("G")
        )
        .when(
            (breach_col == "UNDER") &
            (actual_col >= target_col * F.lit(0.95)),
            F.lit("A")
        )

        # OVER means lower is better
        .when(
            (breach_col == "OVER") &
            (actual_col <= target_col),
            F.lit("G")
        )
        .when(
            (breach_col == "OVER") &
            (actual_col <= target_col * F.lit(1.05)),
            F.lit("A")
        )

        .otherwise(F.lit("R"))
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ehs_bridgend_raw = read_first_available_table(p_ehs_bridgend_candidates)
ehs_maybole_raw = read_first_available_table(p_ehs_maybole_candidates)
safety_raw = read_first_available_table(p_safety_culture_candidates)

dim_date = (
    read_first_available_table(p_dim_date_candidates)
    .select(
        "date_key",
        "calendar_date",
        "customer_year",
        "customer_week_no",
        "week_start_date",
        "week_end_date",
        "week_key"
    )
    .dropDuplicates(["calendar_date"])
)

print("Bridgend columns:")
print(ehs_bridgend_raw.columns)

print("Maybole columns:")
print(ehs_maybole_raw.columns)

print("SafetyCulture columns:")
print(safety_raw.columns)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

bridgend_energy = (
    ehs_bridgend_raw
    .select(
        colx("Week_No").cast("int").alias("week_number"),
        F.lit(p_reporting_year).cast("int").alias("calendar_year"),
        F.lit("Bridgend").alias("site"),

        first_existing_col(
            ehs_bridgend_raw,
            ["TP_Actual_Bridgend"],
            "tp_actual",
            "double"
        ),

        first_existing_col(
            ehs_bridgend_raw,
            ["Bridgend_Gas_kWh"],
            "gas_kwh",
            "double"
        ),

        first_existing_col(
            ehs_bridgend_raw,
            ["Conversion_factor_Gas"],
            "conversion_factor_gas",
            "double"
        ),

        first_existing_col(
            ehs_bridgend_raw,
            ["CO₂e_Gas", "CO2e_Gas"],
            "co2e_gas",
            "double"
        ),

        first_existing_col(
            ehs_bridgend_raw,
            ["Bridgend_Electricity_kWh"],
            "electricity_kwh",
            "double"
        ),

        first_existing_col(
            ehs_bridgend_raw,
            ["Conversion_factor_Electricity"],
            "conversion_factor_electricity",
            "double"
        ),

        first_existing_col(
            ehs_bridgend_raw,
            ["CO₂e_Electricity", "CO2e_Electricity"],
            "co2e_electricity",
            "double"
        ),

        first_existing_col(
            ehs_bridgend_raw,
            ["CO₂e_Total", "CO2e_Total"],
            "co2e_total",
            "double"
        ),

        first_existing_col(
            ehs_bridgend_raw,
            ["Intensity_Total"],
            "intensity_total",
            "double"
        )
    )
)

maybole_energy = (
    ehs_maybole_raw
    .select(
        colx("Week_No").cast("int").alias("week_number"),
        F.lit(p_reporting_year).cast("int").alias("calendar_year"),
        F.lit("Maybole").alias("site"),

        first_existing_col(
            ehs_maybole_raw,
            ["TP_Actual_Maybole"],
            "tp_actual",
            "double"
        ),

        first_existing_col(
            ehs_maybole_raw,
            ["Maybole_Gas_kWh_", "Maybole_Gas_kWh*", "Maybole_Gas_kWh"],
            "gas_kwh",
            "double"
        ),

        first_existing_col(
            ehs_maybole_raw,
            ["Conversion_factor_Gas"],
            "conversion_factor_gas",
            "double"
        ),

        first_existing_col(
            ehs_maybole_raw,
            ["CO₂e_Gas", "CO2e_Gas"],
            "co2e_gas",
            "double"
        ),

        first_existing_col(
            ehs_maybole_raw,
            ["Maybole_Electricity_kWh"],
            "electricity_kwh",
            "double"
        ),

        first_existing_col(
            ehs_maybole_raw,
            ["Conversion_factor_Electricity"],
            "conversion_factor_electricity",
            "double"
        ),

        first_existing_col(
            ehs_maybole_raw,
            ["CO₂e_Electricity", "CO2e_Electricity"],
            "co2e_electricity",
            "double"
        ),

        first_existing_col(
            ehs_maybole_raw,
            ["CO₂e_Total", "CO2e_Total"],
            "co2e_total",
            "double"
        ),

        first_existing_col(
            ehs_maybole_raw,
            ["Intensity_Total"],
            "intensity_total",
            "double"
        )
    )
)

fact_ehs_energy_weekly = (
    bridgend_energy
    .unionByName(maybole_energy)
    .join(
        dim_date
        .groupBy(
            F.col("customer_year").cast("int").alias("calendar_year"),
            F.col("customer_week_no").cast("int").alias("week_number")
        )
        .agg(
            F.min("week_start_date").alias("week_start_date"),
            F.max("week_end_date").alias("week_end_date"),
            F.max("week_key").alias("week_key")
        ),
        ["calendar_year", "week_number"],
        "left"
    )
    .withColumn("created_ts", F.current_timestamp())
    .withColumn("updated_ts", F.current_timestamp())
)

fact_ehs_energy_weekly.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(p_fact_ehs_energy_table)

print("Rows written:", spark.table(p_fact_ehs_energy_table).count())

display(
    spark.table(p_fact_ehs_energy_table)
    .orderBy("site", "calendar_year", "week_number")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

audit_id_col = require_any_column(
    safety_raw,
    ["data.id", "audit_id", "id"],
    "SafetyCultureTest",
    "audit id"
)

completed_col = require_any_column(
    safety_raw,
    ["data.date_completed", "date_completed", "completed_at"],
    "SafetyCultureTest",
    "date completed"
)

conducted_col = None
for candidate in ["data.conducted_on", "conducted_on"]:
    if candidate in safety_raw.columns:
        conducted_col = candidate
        break

score_percentage_col = require_any_column(
    safety_raw,
    ["data.score_percentage", "score_percentage", "Percentage"],
    "SafetyCultureTest",
    "score percentage"
)

fact_ehs_visual_inspections_base = (
    safety_raw
    .select(
        colx(audit_id_col).alias("audit_id"),

        first_existing_col(
            safety_raw,
            ["data.name", "name"],
            "inspection_name",
            "string"
        ),

        first_existing_col(
            safety_raw,
            ["data.template_name", "template_name"],
            "template_name",
            "string"
        ),

        first_existing_col(
            safety_raw,
            ["data.owner_name", "owner_name"],
            "owner_name",
            "string"
        ),

        first_existing_col(
            safety_raw,
            ["data.prepared_by", "prepared_by"],
            "prepared_by",
            "string"
        ),

        first_existing_col(
            safety_raw,
            ["data.site_id", "site_id"],
            "site_id",
            "string"
        ),

        first_existing_col(
            safety_raw,
            ["data.location", "location"],
            "location",
            "string"
        ),

        first_existing_col(
            safety_raw,
            ["data.client_site", "client_site"],
            "client_site",
            "string"
        ),

        parse_date_expr(colx(completed_col)).alias("date_completed"),

        (
            parse_date_expr(colx(conducted_col)).alias("conducted_on")
            if conducted_col
            else F.lit(None).cast("date").alias("conducted_on")
        ),

        parse_percentage_expr(colx(score_percentage_col)).alias("score_percentage"),

        first_existing_col(
            safety_raw,
            ["data.score", "score"],
            "score",
            "double"
        ),

        first_existing_col(
            safety_raw,
            ["data.max_score", "max_score"],
            "max_score",
            "double"
        ),

        first_existing_col(
            safety_raw,
            ["data.duration", "duration"],
            "duration",
            "string"
        )
    )
    .filter(F.col("date_completed").isNotNull())
    .dropDuplicates(["audit_id"])
)

fact_ehs_visual_inspections = (
    fact_ehs_visual_inspections_base
    .join(
        dim_date.alias("d"),
        F.col("date_completed") == F.col("d.calendar_date"),
        "left"
    )
    .select(
        "audit_id",
        "inspection_name",
        "template_name",
        "owner_name",
        "prepared_by",
        "site_id",
        "location",
        "client_site",
        "conducted_on",
        "date_completed",
        "score_percentage",
        "score",
        "max_score",
        "duration",
        F.col("d.date_key").alias("completed_date_key"),
        F.col("d.customer_year").alias("completed_customer_year"),
        F.col("d.customer_week_no").alias("completed_customer_week_no"),
        F.col("d.week_key").alias("completed_week_key"),
        F.col("d.week_start_date").alias("completed_week_start_date"),
        F.col("d.week_end_date").alias("completed_week_end_date"),
        F.current_timestamp().alias("created_ts"),
        F.current_timestamp().alias("updated_ts")
    )
)

fact_ehs_visual_inspections.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(p_fact_ehs_visual_table)

print("Rows written:", spark.table(p_fact_ehs_visual_table).count())

display(
    spark.table(p_fact_ehs_visual_table)
    .orderBy(F.col("date_completed").desc())
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


#### DON'T RUN AS WE HAVENT ADDED THE ACCIDENT TRACKER DATA YET

incident_date_col = require_any_column(
    incident_raw,
    ["Date", "date"],
    "EHSIncidentRegister",
    "incident date"
)

lost_days_col = require_any_column(
    incident_raw,
    ["Lost days", "Lost_Days", "lost_days"],
    "EHSIncidentRegister",
    "lost days"
)

fact_ehs_incidents_base = (
    incident_raw
    .select(
        first_existing_col(
            incident_raw,
            ["Investigation number", "Investigation_Number", "investigation_number"],
            "investigation_number",
            "string"
        ),

        parse_date_expr(colx(incident_date_col)).alias("incident_date"),

        first_existing_col(
            incident_raw,
            ["Site", "site"],
            "site",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Location", "location"],
            "location",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Brief description", "Brief_description", "brief_description"],
            "brief_description",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Accident level", "Accident_Level", "accident_level"],
            "accident_level",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Injury type", "Injury_type", "injury_type"],
            "injury_type",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Body part", "Body_part", "body_part"],
            "body_part",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Task undertaken", "Task_undertaken", "task_undertaken"],
            "task_undertaken",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Systems cause", "Systems_cause", "systems_cause"],
            "systems_cause",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Tools cause", "Tools_cause", "tools_cause"],
            "tools_cause",
            "string"
        ),

        first_existing_col(
            incident_raw,
            ["Environment cause", "Environment_cause", "environment_cause"],
            "environment_cause",
            "string"
        ),

        colx(lost_days_col).cast("double").alias("lost_days")
    )
    .filter(F.col("incident_date").isNotNull())
)

fact_ehs_incidents = (
    fact_ehs_incidents_base
    .join(
        dim_date.alias("d"),
        F.col("incident_date") == F.col("d.calendar_date"),
        "left"
    )
    .select(
        "investigation_number",
        "incident_date",
        "site",
        "location",
        "brief_description",
        "accident_level",
        "injury_type",
        "body_part",
        "task_undertaken",
        "systems_cause",
        "tools_cause",
        "environment_cause",
        "lost_days",
        F.col("d.date_key").alias("incident_date_key"),
        F.col("d.customer_year").alias("incident_customer_year"),
        F.col("d.customer_week_no").alias("incident_customer_week_no"),
        F.col("d.week_key").alias("incident_week_key"),
        F.col("d.week_start_date").alias("incident_week_start_date"),
        F.col("d.week_end_date").alias("incident_week_end_date"),
        F.current_timestamp().alias("created_ts"),
        F.current_timestamp().alias("updated_ts")
    )
)

fact_ehs_incidents.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(p_fact_ehs_incidents_table)

print("Rows written:", spark.table(p_fact_ehs_incidents_table).count())

display(
    spark.table(p_fact_ehs_incidents_table)
    .orderBy(F.col("incident_date").desc())
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

fact_energy = spark.table(p_fact_ehs_energy_table)
fact_visual = spark.table(p_fact_ehs_visual_table)

visual_weekly = (
    fact_visual
    .groupBy(
        F.col("completed_customer_year").alias("closed_year"),
        F.col("completed_customer_week_no").alias("closed_week"),
        F.col("completed_week_key").alias("week_key")
    )
    .agg(
        F.countDistinct("audit_id").cast("double").alias("visual_inspection_count"),
        F.avg("score_percentage").cast("double").alias("visual_inspection_score"),
        F.countDistinct("audit_id").cast("long").alias("source_row_count")
    )
    .filter(
        F.col("closed_year").isNotNull()
        &
        F.col("closed_week").isNotNull()
    )
)

energy_weekly = (
    fact_energy
    .groupBy(
        F.col("calendar_year").alias("closed_year"),
        F.col("week_number").alias("closed_week"),
        F.col("week_key"),
        F.col("site")
    )
    .agg(
        F.avg("intensity_total").cast("double").alias("energy_intensity"),
        F.sum("co2e_total").cast("double").alias("co2e_total"),
        F.sum("tp_actual").cast("double").alias("tp_actual"),
        F.count("*").cast("long").alias("source_row_count")
    )
    .filter(
        F.col("closed_year").isNotNull()
        &
        F.col("closed_week").isNotNull()
    )
)

# Build available EHS week scope
ehs_week_scope = (
    visual_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key"
    )
    .unionByName(
        energy_weekly
        .select(
            "closed_year",
            "closed_week",
            "week_key"
        ),
        allowMissingColumns=True
    )
    .dropDuplicates(
        [
            "closed_year",
            "closed_week",
            "week_key"
        ]
    )
)

# Placeholder Lost Working Days KPI
lost_days_weekly = (
    ehs_week_scope
    .withColumn(
        "lost_working_days",
        F.lit(0.0).cast("double")
    )
    .withColumn(
        "source_row_count",
        F.lit(0).cast("long")
    )
)

display(
    lost_days_weekly
    .orderBy(
        "closed_year",
        "closed_week"
    )
)

display(
    visual_weekly
    .orderBy(
        "closed_year",
        "closed_week"
    )
)

display(
    energy_weekly
    .orderBy(
        "site",
        "closed_year",
        "closed_week"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

lost_days_kpi = (
    lost_days_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_EHS_LOST_WORKING_DAYS).cast("long").alias("kpi_id"),
        F.lit("EHS_LOST_WORKING_DAYS").alias("kpi_code"),
        F.lit("Lost Working Days").alias("kpi_name"),
        F.lit("Productivity").alias("kpi_category"),

        F.col("lost_working_days").cast("double").alias("kpi_value"),
        F.lit(TARGET_LOST_WORKING_DAYS).cast("double").alias("target_value"),

        F.lit("OVER").alias("breach_direction"),
        F.lit("Over Breach").alias("sign"),
        F.lit("Over Breach").alias("sign_label"),

        F.lit("Days").alias("uom"),

        F.lit(
            "Working days lost through accidents or injury attributed to the workplace. Data from Accident Tracker."
        ).alias("measure"),

        F.lit(
            "Working days lost through accidents or injury attributed to the workplace. Data from Accident Tracker."
        ).alias("measure_name"),

        F.lit(
            "Accident Tracker source is not currently available in the Bronze Lakehouse. Defaulted to 0 until the Accident Tracker data source is onboarded."
        ).alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("Accident Tracker - source pending").alias("source_object")
    )
)

visual_count_kpi = (
    visual_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_EHS_VISUAL_INSPECTION_COUNT).cast("long").alias("kpi_id"),
        F.lit("EHS_VISUAL_INSPECTIONS_COUNT").alias("kpi_code"),
        F.lit("Visual Inspections Count").alias("kpi_name"),
        F.lit("Delivery").alias("kpi_category"),

        F.col("visual_inspection_count").cast("double").alias("kpi_value"),
        F.lit(TARGET_VISUAL_INSPECTION_COUNT).cast("double").alias("target_value"),

        F.lit("UNDER").alias("breach_direction"),
        F.lit("Under Breach").alias("sign"),
        F.lit("Under Breach").alias("sign_label"),

        F.lit("Count").alias("uom"),

        F.lit(
            "Completion rate of visual inspections based on SafetyCulture completed records."
        ).alias("measure"),

        F.lit(
            "Completion rate of visual inspections based on SafetyCulture completed records."
        ).alias("measure_name"),

        F.lit(
            "Derived from SafetyCulture completed inspections."
        ).alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.SafetyCultureTest").alias("source_object")
    )
)

visual_score_kpi = (
    visual_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_EHS_VISUAL_INSPECTION_SCORE).cast("long").alias("kpi_id"),
        F.lit("EHS_VISUAL_INSPECTIONS_SCORE").alias("kpi_code"),
        F.lit("Visual Inspections Pass Rates").alias("kpi_name"),
        F.lit("Quality").alias("kpi_category"),

        F.col("visual_inspection_score").cast("double").alias("kpi_value"),
        F.lit(TARGET_VISUAL_INSPECTION_SCORE).cast("double").alias("target_value"),

        F.lit("UNDER").alias("breach_direction"),
        F.lit("Under Breach").alias("sign"),
        F.lit("Under Breach").alias("sign_label"),

        F.lit("Percentage").alias("uom"),

        F.lit(
            "Average score of visual inspections based on SafetyCulture completed records."
        ).alias("measure"),

        F.lit(
            "Average score of visual inspections based on SafetyCulture completed records."
        ).alias("measure_name"),

        F.lit(
            "Derived from SafetyCulture score percentage."
        ).alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.SafetyCultureTest").alias("source_object")
    )
)

bridgend_energy_kpi = (
    energy_weekly
    .filter(F.col("site") == "Bridgend")
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_EHS_BRIDGEND_ENERGY_INTENSITY).cast("long").alias("kpi_id"),
        F.lit("EHS_BRIDGEND_ENERGY_INTENSITY").alias("kpi_code"),
        F.lit("Ratio of gas and electricity emissions to TP (Bridgend)").alias("kpi_name"),
        F.lit("Cost").alias("kpi_category"),

        F.col("energy_intensity").cast("double").alias("kpi_value"),
        F.lit(TARGET_BRIDGEND_ENERGY_INTENSITY).cast("double").alias("target_value"),

        F.lit("OVER").alias("breach_direction"),
        F.lit("Over Breach").alias("sign"),
        F.lit("Over Breach").alias("sign_label"),

        F.lit("Ratio").alias("uom"),

        F.lit(
            "Compares CO2e produced from Bridgend gas and electricity use with TP produced at site. Lower is better."
        ).alias("measure"),

        F.lit(
            "Compares CO2e produced from Bridgend gas and electricity use with TP produced at site. Lower is better."
        ).alias("measure_name"),

        F.lit(
            "Derived from EHS Bridgend weekly energy table using Intensity Total."
        ).alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.ehs_bridgend").alias("source_object")
    )
)

maybole_energy_kpi = (
    energy_weekly
    .filter(F.col("site") == "Maybole")
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_EHS_MAYBOLE_ENERGY_INTENSITY).cast("long").alias("kpi_id"),
        F.lit("EHS_MAYBOLE_ENERGY_INTENSITY").alias("kpi_code"),
        F.lit("Ratio of gas and electricity emissions to TP (Maybole)").alias("kpi_name"),
        F.lit("Cost").alias("kpi_category"),

        F.col("energy_intensity").cast("double").alias("kpi_value"),
        F.lit(TARGET_MAYBOLE_ENERGY_INTENSITY).cast("double").alias("target_value"),

        F.lit("OVER").alias("breach_direction"),
        F.lit("Over Breach").alias("sign"),
        F.lit("Over Breach").alias("sign_label"),

        F.lit("Ratio").alias("uom"),

        F.lit(
            "Compares CO2e produced from Maybole gas and electricity use with TP produced at site. Lower is better."
        ).alias("measure"),

        F.lit(
            "Compares CO2e produced from Maybole gas and electricity use with TP produced at site. Lower is better."
        ).alias("measure_name"),

        F.lit(
            "Derived from EHS Maybole weekly energy table using Intensity Total."
        ).alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.ehs_maybole").alias("source_object")
    )
)

ehs_kpi_base = (
    lost_days_kpi
    .unionByName(visual_count_kpi)
    .unionByName(visual_score_kpi)
    .unionByName(bridgend_energy_kpi)
    .unionByName(maybole_energy_kpi)
)

display(
    ehs_kpi_base
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_id"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ehs_kpi_enriched = (
    ehs_kpi_base
    .withColumn(
        "organisational_unit",
        F.lit(p_organisational_unit)
    )
    .withColumn(
        "department",
        F.lit(p_department)
    )

    .withColumn(
        "variance_value",
        (
            F.col("kpi_value")
            - F.col("target_value")
        ).cast("double")
    )

    .withColumn(
        "performance_variance_value",
        F.when(
            F.col("breach_direction") == "OVER",
            F.col("target_value") - F.col("kpi_value")
        )
        .otherwise(
            F.col("kpi_value") - F.col("target_value")
        )
        .cast("double")
    )

    .withColumn(
        "data_status",
        F.when(
            F.col("kpi_value").isNull(),
            F.lit("No Data")
        )
        .when(
            F.col("target_value").isNull(),
            F.lit("Actual - Target TBC")
        )
        .otherwise(
            F.lit("Actual")
        )
    )

    .withColumn(
        "rag_status",
        rag_status(
            F.col("kpi_value"),
            F.col("target_value"),
            F.col("breach_direction"),
            F.col("data_status")
        )
    )

    .withColumn(
        "source_system",
        F.lit(p_source_system)
    )

    .withColumn(
        "calculation_timestamp",
        F.current_timestamp()
    )

    .select(
        "closed_year",
        "closed_week",
        "week_key",

        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",

        "organisational_unit",
        "department",

        "measure",
        "measure_name",

        "uom",

        "sign",
        "sign_label",

        "commentary",

        F.col("kpi_value").cast("double").alias("kpi_value"),

        F.col("target_value").cast("double").alias("target_value"),

        "variance_value",
        "performance_variance_value",

        "breach_direction",

        "rag_status",
        "data_status",

        "source_system",
        "source_object",

        F.col("source_row_count")
         .cast("long")
         .alias("source_row_count"),

        "calculation_timestamp"
    )
)

ehs_kpi_enriched.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        p_ehs_kpi_output_table
    )

print(
    "EHS KPI rows:",
    spark.table(
        p_ehs_kpi_output_table
    ).count()
)

display(
    spark.table(
        p_ehs_kpi_output_table
    )
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_id"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

existing_kpi = spark.table(p_existing_kpi_table)

ehs_codes = [
    "EHS_LOST_WORKING_DAYS",
    "EHS_VISUAL_INSPECTIONS_COUNT",
    "EHS_VISUAL_INSPECTIONS_SCORE",
    "EHS_BRIDGEND_ENERGY_INTENSITY",
    "EHS_MAYBOLE_ENERGY_INTENSITY"
]

existing_without_ehs = (
    existing_kpi
    .filter(
        ~F.col("kpi_code").isin(ehs_codes)
    )
)

combined_kpi = (
    existing_without_ehs
    .unionByName(
        ehs_kpi_enriched,
        allowMissingColumns=True
    )
)

combined_kpi.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(p_existing_kpi_table)

print("Existing rows before:", existing_kpi.count())
print("EHS rows added:", ehs_kpi_enriched.count())
print("Final V2 rows:", spark.table(p_existing_kpi_table).count())

display(
    spark.table(p_existing_kpi_table)
    .filter(F.col("kpi_code").isin(ehs_codes))
    .orderBy("closed_year", "closed_week", "kpi_id")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

kpi = spark.table("dbo.kpi_result_silver_enriched_v2")
dim_date = spark.table("dbo.dim_date")

dim_week = (
    dim_date
    .filter(F.col("day_name") == "Friday")
    .select(
        F.col("date_key").cast("int").alias("date_key"),
        F.col("calendar_date").alias("week_ending_date"),
        F.col("week_start_date"),
        F.col("week_end_date"),
        F.col("customer_year").cast("int").alias("calendar_year"),
        F.col("customer_week_no").cast("int").alias("week_number")
    )
    .dropDuplicates(["calendar_year", "week_number"])
)

fact_kpi_result_staging_v2 = (
    kpi
    .join(
        dim_week,
        (
            kpi.closed_year.cast("int") == dim_week.calendar_year
        )
        &
        (
            kpi.closed_week.cast("int") == dim_week.week_number
        ),
        "left"
    )
    .select(
        "date_key",
        "week_ending_date",
        "week_start_date",
        "week_end_date",
        "calendar_year",
        "week_number",

        "closed_year",
        "closed_week",
        "week_key",

        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",

        "organisational_unit",
        "department",

        "measure",
        "measure_name",

        "uom",

        "sign",
        "sign_label",

        "commentary",

        F.col("kpi_value").alias("actual_value"),

        "target_value",
        "variance_value",
        "performance_variance_value",

        "breach_direction",

        "rag_status",
        "data_status",

        "source_system",
        "source_object",
        "source_row_count",

        "calculation_timestamp"
    )
)

fact_kpi_result_staging_v2.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("dbo.fact_kpi_result_staging_v2")

print(
    "Rows written to fact_kpi_result_staging_v2:",
    spark.table("dbo.fact_kpi_result_staging_v2").count()
)

display(
    spark.table("dbo.fact_kpi_result_staging_v2")
    .filter(F.col("organisational_unit") == p_organisational_unit)
    .orderBy("calendar_year", "week_number", "kpi_id")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

test_v2 = spark.table(
    "dbo.kpi_result_silver_enriched_v2_test"
)

current_v2 = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

print("Test V2 rows:", test_v2.count())
print("Current V2 rows:", current_v2.count())

print("Test V2 organisational units")
display(
    test_v2
    .groupBy("organisational_unit")
    .agg(F.count("*").alias("rows"))
    .orderBy("organisational_unit")
)

print("Current V2 organisational units")
display(
    current_v2
    .groupBy("organisational_unit")
    .agg(F.count("*").alias("rows"))
    .orderBy("organisational_unit")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

test_v2 = spark.table(
    "dbo.kpi_result_silver_enriched_v2_test"
)

dim_kpi = spark.table(
    "dbo.dim_kpi"
)

# Work out the category column used in dim_kpi
dim_category_col = (
    "category"
    if "category" in dim_kpi.columns
    else "kpi_category"
)

dim_kpi_keyed = (
    dim_kpi
    .select(
        F.upper(F.trim(F.col("kpi_name"))).alias("kpi_name_key"),
        F.col("kpi_id").cast("long").alias("dim_kpi_id"),
        F.col(dim_category_col).cast("string").alias("dim_kpi_category"),
        F.col("target_value").cast("double").alias("dim_target_value"),
        F.col("breach_direction").cast("string").alias("dim_breach_direction")
    )
    .dropDuplicates(["kpi_name_key"])
)

design_base = (
    test_v2
    .filter(
        F.col("organisational_unit") == "Design & R&D"
    )
    .withColumn(
        "kpi_name_key",
        F.upper(F.trim(F.col("kpi_name")))
    )
)

design_refreshed = (
    design_base
    .join(
        dim_kpi_keyed,
        "kpi_name_key",
        "left"
    )
    .drop("kpi_name_key")

    # Refresh dim_kpi-driven fields where available
    .withColumn(
        "kpi_id",
        F.coalesce(
            F.col("dim_kpi_id"),
            F.col("kpi_id").cast("long")
        )
    )
    .withColumn(
        "kpi_category",
        F.coalesce(
            F.col("dim_kpi_category"),
            F.col("kpi_category")
        )
    )
    .withColumn(
        "target_value",
        F.coalesce(
            F.col("dim_target_value"),
            F.col("target_value").cast("double")
        )
    )
    .withColumn(
        "breach_direction",
        F.coalesce(
            F.col("dim_breach_direction"),
            F.col("breach_direction")
        )
    )
    .drop(
        "dim_kpi_id",
        "dim_kpi_category",
        "dim_target_value",
        "dim_breach_direction"
    )

    # Department
    .withColumn(
        "department",
        F.lit("Design & R&D")
    )

    # KPI code
    .withColumn(
        "kpi_code",
        F.coalesce(
            F.col("kpi_code"),
            F.upper(
                F.regexp_replace(
                    F.concat_ws(
                        "_",
                        F.lit("DESIGN_RND"),
                        F.col("kpi_name")
                    ),
                    "[^A-Za-z0-9]+",
                    "_"
                )
            )
        )
    )

    # Measure labels
    .withColumn(
        "measure",
        F.when(
            F.col("kpi_name") == "Volume Completed",
            F.lit("Number of Approx. Design requests closed weekly")
        )
        .when(
            F.col("kpi_name") == "OTIF %",
            F.lit("% of Designs closed that were completed by the internal Date")
        )
        .when(
            F.col("kpi_name") == "Design Rejections",
            F.lit("Number of rejected designs (internal to Design team)")
        )
        .when(
            F.col("kpi_name") == "Opportunity Value per Proposal",
            F.lit("Expected Opportunity value / No of proposals collated")
        )
        .otherwise(F.col("measure"))
    )
    .withColumn(
        "measure_name",
        F.col("measure")
    )

    # UOM
    .withColumn(
        "uom",
        F.when(
            F.col("kpi_name") == "Volume Completed",
            F.lit("Count")
        )
        .when(
            F.col("kpi_name") == "OTIF %",
            F.lit("Percentage")
        )
        .when(
            F.col("kpi_name") == "Design Rejections",
            F.lit("Count")
        )
        .when(
            F.col("kpi_name") == "Opportunity Value per Proposal",
            F.lit("£")
        )
        .otherwise(F.col("uom"))
    )

    # Sign labels
    .withColumn(
        "sign",
        F.when(
            F.col("kpi_name") == "Design Rejections",
            F.lit("Over Breach")
        )
        .otherwise(F.lit("Under Breach"))
    )
    .withColumn(
        "sign_label",
        F.col("sign")
    )

    # Commentary
    .withColumn(
        "commentary",
        F.when(
            F.col("kpi_name").isin("Volume Completed", "OTIF %"),
            F.lit("Salesforce")
        )
        .when(
            F.col("kpi_name") == "Design Rejections",
            F.lit("Not in a system")
        )
        .when(
            F.col("kpi_name") == "Opportunity Value per Proposal",
            F.lit("Never reported on before")
        )
        .otherwise(F.col("commentary"))
    )

    # Variance values
    .withColumn(
        "variance_value",
        (
            F.col("kpi_value").cast("double")
            - F.col("target_value").cast("double")
        ).cast("double")
    )
    .withColumn(
        "performance_variance_value",
        F.when(
            F.col("breach_direction") == "OVER",
            F.col("target_value").cast("double")
            - F.col("kpi_value").cast("double")
        )
        .otherwise(
            F.col("kpi_value").cast("double")
            - F.col("target_value").cast("double")
        )
        .cast("double")
    )

    # Data status
    .withColumn(
        "data_status",
        F.when(
            F.col("kpi_value").isNull(),
            F.lit("No Data")
        )
        .when(
            F.col("target_value").isNull(),
            F.lit("Actual - Target TBC")
        )
        .otherwise(
            F.lit("Actual")
        )
    )

    # RAG status
    .withColumn(
        "rag_status",
        F.when(
            F.col("kpi_value").isNull()
            &
            F.col("target_value").isNull(),
            F.lit("Blank")
        )
        .when(
            F.col("kpi_value").isNull(),
            F.lit("TBC")
        )
        .when(
            F.col("target_value").isNull(),
            F.lit("Blank")
        )

        # UNDER means higher is better
        .when(
            (F.col("breach_direction") == "UNDER")
            &
            (
                F.col("kpi_value").cast("double")
                >=
                F.col("target_value").cast("double")
            ),
            F.lit("G")
        )
        .when(
            (F.col("breach_direction") == "UNDER")
            &
            (
                F.col("kpi_value").cast("double")
                >=
                F.col("target_value").cast("double") * F.lit(0.95)
            ),
            F.lit("A")
        )

        # OVER means lower is better
        .when(
            (F.col("breach_direction") == "OVER")
            &
            (
                F.col("kpi_value").cast("double")
                <=
                F.col("target_value").cast("double")
            ),
            F.lit("G")
        )
        .when(
            (F.col("breach_direction") == "OVER")
            &
            (
                F.col("kpi_value").cast("double")
                <=
                F.col("target_value").cast("double") * F.lit(1.05)
            ),
            F.lit("A")
        )
        .otherwise(F.lit("R"))
    )

    # Source/audit defaults
    .withColumn(
        "source_system",
        F.coalesce(
            F.col("source_system"),
            F.lit("Salesforce")
        )
    )
    .withColumn(
        "source_object",
        F.coalesce(
            F.col("source_object"),
            F.lit("dbo.kpi_result_silver_enriched_v2_test")
        )
    )
    .withColumn(
        "source_row_count",
        F.col("source_row_count").cast("long")
    )
    .withColumn(
        "calculation_timestamp",
        F.coalesce(
            F.col("calculation_timestamp"),
            F.current_timestamp()
        )
    )
)

display(
    design_refreshed
    .select(
        "closed_year",
        "closed_week",
        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",
        "organisational_unit",
        "department",
        "measure",
        "measure_name",
        "uom",
        "sign",
        "sign_label",
        "commentary",
        "kpi_value",
        "target_value",
        "breach_direction",
        "rag_status",
        "data_status"
    )
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_id"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

design_refreshed.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_design_rnd_refreshed_test"
    )

print(
    "Design & R&D refreshed rows:",
    spark.table(
        "dbo.kpi_result_design_rnd_refreshed_test"
    ).count()
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

current_v2 = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

design_refreshed = spark.table(
    "dbo.kpi_result_design_rnd_refreshed_test"
)

current_without_design = (
    current_v2
    .filter(
        F.col("organisational_unit") != "Design & R&D"
    )
)

repaired_v2 = (
    current_without_design
    .unionByName(
        design_refreshed,
        allowMissingColumns=True
    )
)

print("Current V2 rows without Design & R&D:", current_without_design.count())
print("Design & R&D rows to reload       :", design_refreshed.count())
print("Repaired V2 rows                  :", repaired_v2.count())

display(
    repaired_v2
    .groupBy("organisational_unit")
    .agg(F.count("*").alias("rows"))
    .orderBy("organisational_unit")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

repaired_v2.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2"
    )

print(
    "Live V2 rows:",
    spark.table(
        "dbo.kpi_result_silver_enriched_v2"
    ).count()
)

display(
    spark.table(
        "dbo.kpi_result_silver_enriched_v2"
    )
    .groupBy("organisational_unit")
    .agg(F.count("*").alias("rows"))
    .orderBy("organisational_unit")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

kpi = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

dim_date = spark.table(
    "dbo.dim_date"
)

dim_week = (
    dim_date
    .filter(
        F.col("day_name") == "Friday"
    )
    .select(
        F.col("date_key").cast("int").alias("date_key"),
        F.col("calendar_date").alias("week_ending_date"),
        F.col("week_start_date").alias("week_start_date"),
        F.col("week_end_date").alias("week_end_date"),
        F.col("customer_year").cast("int").alias("calendar_year"),
        F.col("customer_week_no").cast("int").alias("week_number")
    )
    .dropDuplicates(
        [
            "calendar_year",
            "week_number"
        ]
    )
)

fact_kpi_result_staging_v2 = (
    kpi
    .join(
        dim_week,
        (
            kpi.closed_year.cast("int")
            ==
            dim_week.calendar_year
        )
        &
        (
            kpi.closed_week.cast("int")
            ==
            dim_week.week_number
        ),
        "left"
    )
    .select(
        "date_key",
        "week_ending_date",
        "week_start_date",
        "week_end_date",
        "calendar_year",
        "week_number",

        "closed_year",
        "closed_week",
        "week_key",

        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",

        "organisational_unit",
        "department",

        "measure",
        "measure_name",

        "uom",

        "sign",
        "sign_label",

        "commentary",

        F.col("kpi_value").cast("double").alias("actual_value"),

        F.col("target_value").cast("double").alias("target_value"),
        F.col("variance_value").cast("double").alias("variance_value"),
        F.col("performance_variance_value").cast("double").alias("performance_variance_value"),

        "breach_direction",

        "rag_status",
        "data_status",

        "source_system",
        "source_object",
        F.col("source_row_count").cast("long").alias("source_row_count"),

        "calculation_timestamp"
    )
)

fact_kpi_result_staging_v2.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.fact_kpi_result_staging_v2"
    )

print(
    "Rows written to staging V2:",
    spark.table(
        "dbo.fact_kpi_result_staging_v2"
    ).count()
)

display(
    spark.table(
        "dbo.fact_kpi_result_staging_v2"
    )
    .groupBy(
        "organisational_unit",
        "department",
        "kpi_category"
    )
    .agg(F.count("*").alias("rows"))
    .orderBy(
        "organisational_unit",
        "department",
        "kpi_category"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.table("dbo.kpi_result_silver_enriched_v2").write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("dbo.kpi_result_silver_enriched_v2_stable_backup")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

display(
    spark.table("dbo.kpi_result_silver_enriched_v2")
    .filter(
        F.col("kpi_code").like("EHS_VISUAL%")
    )
    .select(
        "closed_year",
        "closed_week",
        "kpi_code",
        "kpi_name",
        "kpi_category",
        "kpi_value",
        "target_value"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

display(
    spark.table("dbo.kpi_result_ehs_silver_enriched")
    .filter(
        F.col("kpi_code").like("EHS_VISUAL%")
    )
    .select(
        "closed_year",
        "closed_week",
        "kpi_code",
        "kpi_name",
        "kpi_category",
        "department",
        "measure",
        "uom",
        "kpi_value",
        "target_value",
        "rag_status"
    )
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_code"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

print(
    spark.table(
        "dbo.fact_ehs_visual_inspections"
    ).count()
)

display(
    spark.table(
        "dbo.fact_ehs_visual_inspections"
    )
    .select(
        "audit_id",
        "date_completed",
        "score_percentage",
        "template_name"
    )
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

fact_visual = spark.table(
    "dbo.fact_ehs_visual_inspections"
)

visual_weekly = (
    fact_visual
    .filter(
        F.col("date_completed").isNotNull()
    )
    .withColumn(
        "closed_year",
        F.year(F.col("date_completed")).cast("int")
    )
    .withColumn(
        "closed_week",
        F.weekofyear(F.col("date_completed")).cast("int")
    )
    .withColumn(
        "week_key",
        F.concat_ws(
            "-",
            F.year(F.col("date_completed")).cast("string"),
            F.lpad(
                F.weekofyear(F.col("date_completed")).cast("string"),
                2,
                "0"
            )
        )
    )
    .groupBy(
        "closed_year",
        "closed_week",
        "week_key"
    )
    .agg(
        F.countDistinct("audit_id")
            .cast("double")
            .alias("visual_inspection_count"),

        F.avg("score_percentage")
            .cast("double")
            .alias("visual_inspection_score"),

        F.countDistinct("audit_id")
            .cast("long")
            .alias("source_row_count")
    )
)

print(
    "Visual weekly rows:",
    visual_weekly.count()
)

display(
    visual_weekly
    .orderBy(
        "closed_year",
        "closed_week"
    )
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

p_department = "Environment, Health and Safety"
p_organisational_unit = "Environment, Health and Safety"
p_source_system = "SafetyCulture"

KPI_ID_EHS_VISUAL_INSPECTION_COUNT = 5002
KPI_ID_EHS_VISUAL_INSPECTION_SCORE = 5003

TARGET_VISUAL_INSPECTION_COUNT = 110.0
TARGET_VISUAL_INSPECTION_SCORE = 90.0

visual_count_kpi = (
    visual_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_EHS_VISUAL_INSPECTION_COUNT)
            .cast("long")
            .alias("kpi_id"),

        F.lit("EHS_VISUAL_INSPECTIONS_COUNT")
            .alias("kpi_code"),

        F.lit("Visual Inspections Count")
            .alias("kpi_name"),

        F.lit("Delivery")
            .alias("kpi_category"),

        F.col("visual_inspection_count")
            .cast("double")
            .alias("kpi_value"),

        F.lit(TARGET_VISUAL_INSPECTION_COUNT)
            .cast("double")
            .alias("target_value"),

        F.lit("UNDER")
            .alias("breach_direction"),

        F.lit("Under Breach")
            .alias("sign"),

        F.lit("Under Breach")
            .alias("sign_label"),

        F.lit("Count")
            .alias("uom"),

        F.lit(
            "Completion rate of visual inspections based on SafetyCulture completed records."
        ).alias("measure"),

        F.lit(
            "Completion rate of visual inspections based on SafetyCulture completed records."
        ).alias("measure_name"),

        F.lit(
            "Derived from SafetyCulture completed inspections."
        ).alias("commentary"),

        F.col("source_row_count")
            .cast("long")
            .alias("source_row_count"),

        F.lit("bronze_lakehouse.SafetyCultureTest")
            .alias("source_object")
    )
)

visual_score_kpi = (
    visual_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_EHS_VISUAL_INSPECTION_SCORE)
            .cast("long")
            .alias("kpi_id"),

        F.lit("EHS_VISUAL_INSPECTIONS_SCORE")
            .alias("kpi_code"),

        F.lit("Visual Inspections Pass Rates")
            .alias("kpi_name"),

        F.lit("Quality")
            .alias("kpi_category"),

        F.col("visual_inspection_score")
            .cast("double")
            .alias("kpi_value"),

        F.lit(TARGET_VISUAL_INSPECTION_SCORE)
            .cast("double")
            .alias("target_value"),

        F.lit("UNDER")
            .alias("breach_direction"),

        F.lit("Under Breach")
            .alias("sign"),

        F.lit("Under Breach")
            .alias("sign_label"),

        F.lit("Percentage")
            .alias("uom"),

        F.lit(
            "Average score of visual inspections based on SafetyCulture completed records."
        ).alias("measure"),

        F.lit(
            "Average score of visual inspections based on SafetyCulture completed records."
        ).alias("measure_name"),

        F.lit(
            "Derived from SafetyCulture score percentage."
        ).alias("commentary"),

        F.col("source_row_count")
            .cast("long")
            .alias("source_row_count"),

        F.lit("bronze_lakehouse.SafetyCultureTest")
            .alias("source_object")
    )
)

visual_kpi_base = (
    visual_count_kpi
    .unionByName(
        visual_score_kpi
    )
)

display(
    visual_kpi_base
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_id"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

p_department = "Environment, Health and Safety"
p_organisational_unit = "Environment, Health and Safety"
p_source_system = "SafetyCulture"

visual_kpi_enriched = (
    visual_kpi_base
    .withColumn(
        "organisational_unit",
        F.lit(p_organisational_unit)
    )
    .withColumn(
        "department",
        F.lit(p_department)
    )

    .withColumn(
        "variance_value",
        (
            F.col("kpi_value")
            - F.col("target_value")
        ).cast("double")
    )

    .withColumn(
        "performance_variance_value",
        (
            F.col("kpi_value")
            - F.col("target_value")
        ).cast("double")
    )

    .withColumn(
        "data_status",
        F.when(
            F.col("kpi_value").isNull(),
            F.lit("No Data")
        )
        .when(
            F.col("target_value").isNull(),
            F.lit("Actual - Target TBC")
        )
        .otherwise(
            F.lit("Actual")
        )
    )

    .withColumn(
        "rag_status",
        F.when(
            F.col("kpi_value").isNull(),
            F.lit("No Data")
        )
        .when(
            F.col("target_value").isNull(),
            F.lit("TBC")
        )
        .when(
            F.col("kpi_value") >= F.col("target_value"),
            F.lit("G")
        )
        .when(
            F.col("kpi_value") >= (F.col("target_value") * F.lit(0.95)),
            F.lit("A")
        )
        .otherwise(
            F.lit("R")
        )
    )

    .withColumn(
        "source_system",
        F.lit(p_source_system)
    )

    .withColumn(
        "calculation_timestamp",
        F.current_timestamp()
    )

    .select(
        "closed_year",
        "closed_week",
        "week_key",

        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",

        "organisational_unit",
        "department",

        "measure",
        "measure_name",

        "uom",

        "sign",
        "sign_label",

        "commentary",

        F.col("kpi_value").cast("double").alias("kpi_value"),
        F.col("target_value").cast("double").alias("target_value"),

        "variance_value",
        "performance_variance_value",

        "breach_direction",

        "rag_status",
        "data_status",

        "source_system",
        "source_object",

        F.col("source_row_count")
            .cast("long")
            .alias("source_row_count"),

        "calculation_timestamp"
    )
)

print(
    "Visual KPI enriched rows:",
    visual_kpi_enriched.count()
)

display(
    visual_kpi_enriched
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_id"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("visual_weekly exists:", 'visual_weekly' in locals())
print("visual_kpi_base exists:", 'visual_kpi_base' in locals())
print("visual_kpi_enriched exists:", 'visual_kpi_enriched' in locals())


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("visual_kpi_enriched exists:", 'visual_kpi_enriched' in locals())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

existing_v2 = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

visual_codes = [
    "EHS_VISUAL_INSPECTIONS_COUNT",
    "EHS_VISUAL_INSPECTIONS_SCORE"
]

existing_without_visual = (
    existing_v2
    .filter(
        ~F.col("kpi_code").isin(visual_codes)
    )
)

v2_with_visual = (
    existing_without_visual
    .unionByName(
        visual_kpi_enriched,
        allowMissingColumns=True
    )
)

print("Existing V2 rows:", existing_v2.count())
print("Rows without visual:", existing_without_visual.count())
print("Visual rows to add:", visual_kpi_enriched.count())
print("New V2 rows:", v2_with_visual.count())

display(
    v2_with_visual
    .filter(
        F.col("kpi_code").isin(visual_codes)
    )
    .select(
        "closed_year",
        "closed_week",
        "kpi_code",
        "kpi_name",
        "kpi_category",
        "department",
        "measure",
        "uom",
        "kpi_value",
        "target_value",
        "rag_status"
    )
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_code"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

v2_with_visual.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2"
    )

print(
    "Final V2 rows:",
    spark.table(
        "dbo.kpi_result_silver_enriched_v2"
    ).count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(
    spark.table("dbo.fact_ehs_visual_inspections")
    .select(
        "date_completed",
        "completed_customer_year",
        "completed_customer_week_no",
        "completed_week_key",
        "template_name"
    )
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
