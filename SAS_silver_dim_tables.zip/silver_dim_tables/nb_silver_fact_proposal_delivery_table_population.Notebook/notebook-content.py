# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         },
# META         {
# META           "id": "6950bf8e-2162-41a8-af31-7263ad5c1551"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import (
    col, when, current_timestamp, abs, xxhash64, coalesce, lit
)

src = spark.table("`bronze_lakehouse`.`Proposal Request`")

# Business key – SAME logic as fact_proposal
bk = coalesce(col("Proposal_Number__c"), col("Name"), col("Id")).alias("proposal_request_no")

# Dates – only use columns we know exist
due_date_col = (
    col("Complete_By_Date__c").cast("date")
    if "Complete_By_Date__c" in src.columns
    else lit(None)
)

completed_date_col = (
    col("Closed_Date__c").cast("date")
    if "Closed_Date__c" in src.columns
    else lit(None)
)

df_delivery = (
    src
    .withColumn("proposal_request_no", bk)
    .withColumn("proposal_id", abs(xxhash64(col("proposal_request_no"))))
    .withColumn("due_date", due_date_col)
    .withColumn("completed_date", completed_date_col)

    # OTIF logic:
    # - only on-time if BOTH dates exist AND completed <= due
    .withColumn(
        "on_time_flag",
        when(
            col("completed_date").isNotNull() &
            col("due_date").isNotNull() &
            (col("completed_date") <= col("due_date")),
            lit(1)
        ).otherwise(lit(0))
    )
    .withColumn("is_on_time", col("on_time_flag") == 1)

    .select(
        "proposal_id",
        "proposal_request_no",
        "due_date",
        "completed_date",
        "on_time_flag",
        "is_on_time"
    )
    .withColumn("created_utc", current_timestamp())
)

df_delivery.write.mode("overwrite").saveAsTable("fact_proposal_delivery")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Row counts should broadly match
print("Row count comparison")

spark.sql("""
SELECT 'fact_proposal' AS table_name, COUNT(*) AS row_count
FROM fact_proposal
UNION ALL
SELECT 'fact_proposal_delivery' AS table_name, COUNT(*) AS row_count
FROM fact_proposal_delivery
""").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# OTIF sanity check
print("OTIF distribution")

spark.sql("""
SELECT
  is_on_time,
  COUNT(*) AS cnt
FROM fact_proposal_delivery
GROUP BY is_on_time
ORDER BY is_on_time
""").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Spot‑check late vs on‑time records
print("Recent proposals with due & completed dates")

spark.sql("""
SELECT
  proposal_request_no,
  due_date,
  completed_date,
  on_time_flag,
  is_on_time
FROM fact_proposal_delivery
WHERE due_date IS NOT NULL
ORDER BY completed_date DESC
LIMIT 20
""").show(truncate=False)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
