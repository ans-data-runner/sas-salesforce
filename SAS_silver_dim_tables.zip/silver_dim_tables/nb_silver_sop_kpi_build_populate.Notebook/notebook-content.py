# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "f16f8a32-ffdb-4553-9f10-e2b8c82e4450",
# META       "known_warehouses": [
# META         {
# META           "id": "f16f8a32-ffdb-4553-9f10-e2b8c82e4450",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Lakehouse / table names
p_bronze_lakehouse = "bronze_lakehouse"

p_customer_service_source = f"{p_bronze_lakehouse}.`Customer Service`"
p_order_tracking_source = f"{p_bronze_lakehouse}.`Order Tracking`"

p_dim_date_candidates = [
    "dim_date",
    "dbo.dim_date",
    "lh_sas_silver.dim_date",
    "lh_sas_silver.dbo.dim_date"
]

p_existing_kpi_table = "kpi_result_silver_enriched_v2"

p_fact_complaints_table = "fact_sop_complaints"
p_fact_lines_released_table = "fact_sop_lines_released"
p_sop_kpi_output_table = "kpi_result_sop_silver_enriched"

p_department = "SOP"
p_organisational_unit = "SOP"
p_source_system = "Salesforce"

# KPI IDs
KPI_ID_COMPLAINTS_RAISED = 3101
KPI_ID_LINES_RELEASED = 3102
KPI_ID_RELEASED_ORDER_VALUE = 3103
KPI_ID_VALUE_PER_FTE = 3104

# Targets are TBC unless the business supplies weekly targets.
TARGET_COMPLAINTS_RAISED = None
TARGET_LINES_RELEASED = None
TARGET_RELEASED_ORDER_VALUE = None
TARGET_VALUE_PER_FTE = None


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def read_first_available_table(candidates):
    errors = []

    for candidate in candidates:
        try:
            df = spark.table(candidate)
            print(f"Using table: {candidate}")
            return df
        except Exception as exc:
            errors.append(f"{candidate}: {str(exc)}")

    raise RuntimeError(
        "Could not read any candidate table. Tried:\n" +
        "\n".join(errors)
    )


def require_any_column(df, candidates, object_name, logical_name):
    available = set(df.columns)

    for c in candidates:
        if c in available:
            return c

    raise RuntimeError(
        f"{object_name} is missing a column for {logical_name}.\n"
        f"Tried: {candidates}\n"
        f"Available columns: {df.columns}"
    )


def first_existing_column_expr(df, candidates, alias_name, cast_type=None):
    available = set(df.columns)

    for c in candidates:
        if c in available:
            expr = F.col(c)
            if cast_type:
                expr = expr.cast(cast_type)
            return expr.alias(alias_name)

    return F.lit(None).cast(cast_type or "string").alias(alias_name)


def latest_salesforce_rows(df):
    if "Id" not in df.columns:
        return df

    ordering = [
        F.col(name).desc_nulls_last()
        for name in ["SystemModstamp", "LastModifiedDate", "CreatedDate"]
        if name in df.columns
    ]

    if not ordering:
        return df.dropDuplicates(["Id"])

    return (
        df
        .withColumn(
            "_rn",
            F.row_number().over(
                Window.partitionBy("Id").orderBy(*ordering)
            )
        )
        .filter(F.col("_rn") == 1)
        .drop("_rn")
    )


def make_week_joined(df, date_col_name, prefix):
    return (
        df
        .join(
            dim_date.alias("d"),
            F.col(date_col_name) == F.col("d.calendar_date"),
            "left"
        )
        .withColumnRenamed("customer_year", f"{prefix}_year")
        .withColumnRenamed("customer_week_no", f"{prefix}_week")
        .withColumnRenamed("week_key", f"{prefix}_week_key")
        .drop("date_key", "calendar_date", "week_start_date", "week_end_date")
    )


def rag_status(actual_col, target_col, breach_col, data_status_col):
    return (
        F.when(data_status_col == "TBC", F.lit("TBC"))
        .when(data_status_col == "No Data", F.lit("No Data"))
        .when(target_col.isNull(), F.lit("TBC"))
        .when(actual_col.isNull(), F.lit("No Data"))
        .when(
            breach_col == "UNDER",
            F.when(actual_col >= target_col, F.lit("G"))
             .when(actual_col >= target_col * F.lit(0.95), F.lit("A"))
             .otherwise(F.lit("R"))
        )
        .when(
            breach_col == "OVER",
            F.when(actual_col <= target_col, F.lit("G"))
             .when(
                 (target_col > F.lit(0.0)) &
                 (actual_col <= target_col / F.lit(0.95)),
                 F.lit("A")
             )
             .otherwise(F.lit("R"))
        )
        .otherwise(F.lit("TBC"))
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

customer_service_raw = spark.table(p_customer_service_source)
order_tracking_raw = spark.table(p_order_tracking_source)

dim_date = (
    read_first_available_table(p_dim_date_candidates)
    .select(
        "date_key",
        "calendar_date",
        "customer_year",
        "customer_week_no",
        "week_start_date",
        "week_end_date",
        "week_key"
    )
    .dropDuplicates(["calendar_date"])
)

print("Customer Service columns:")
print(customer_service_raw.columns)

print("Order Tracking columns:")
print(order_tracking_raw.columns)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

customer_service = latest_salesforce_rows(customer_service_raw)

complaint_id_col = require_any_column(
    customer_service,
    ["Id"],
    "Customer Service",
    "complaint id"
)

complaint_number_col = require_any_column(
    customer_service,
    [
        "CaseNumber",
        "Customer_Service_Number__c",
        "Customer_Service_No__c",
        "Name",
        "Id"
    ],
    "Customer Service",
    "complaint number"
)

complaint_open_date_col = require_any_column(
    customer_service,
    [
        "Open_Date__c",
        "Date_Time_Opened__c",
        "Date_Opened__c",
        "Opened_Date__c",
        "CreatedDate"
    ],
    "Customer Service",
    "complaint opened date"
)

fact_complaints_base = (
    customer_service
    .filter(~F.coalesce(F.col("IsDeleted"), F.lit(False)) if "IsDeleted" in customer_service.columns else F.lit(True))
    .select(
        F.col(complaint_id_col).alias("complaint_id"),
        F.col(complaint_number_col).alias("complaint_number"),

        first_existing_column_expr(
            customer_service,
            ["Fault_Category__c", "Fault_Category", "FaultCategory"],
            "fault_category",
            "string"
        ),

        first_existing_column_expr(
            customer_service,
            ["Department__c", "Department", "Department2__c"],
            "source_department",
            "string"
        ),

        first_existing_column_expr(
            customer_service,
            ["Sales_Division__c", "Sales_Division", "SalesDivision"],
            "sales_division",
            "string"
        ),

        first_existing_column_expr(
            customer_service,
            ["Project_Name__c", "Project_Name", "ProjectName"],
            "project_name",
            "string"
        ),

        F.to_date(F.col(complaint_open_date_col)).alias("opened_date"),

        first_existing_column_expr(
            customer_service,
            ["CreatedDate"],
            "source_created_ts",
            "timestamp"
        ),

        first_existing_column_expr(
            customer_service,
            ["SystemModstamp", "LastModifiedDate"],
            "source_modified_ts",
            "timestamp"
        )
    )
    .filter(F.col("opened_date").isNotNull())
    .dropDuplicates(["complaint_id"])
)

fact_complaints = (
    fact_complaints_base
    .join(
        dim_date.alias("d"),
        F.col("opened_date") == F.col("d.calendar_date"),
        "left"
    )
    .select(
        "complaint_id",
        "complaint_number",
        "fault_category",
        "source_department",
        "sales_division",
        "project_name",
        "opened_date",
        F.col("d.date_key").alias("opened_date_key"),
        F.col("d.customer_year").alias("opened_customer_year"),
        F.col("d.customer_week_no").alias("opened_customer_week_no"),
        F.col("d.week_key").alias("opened_week_key"),
        F.col("d.week_start_date").alias("opened_week_start_date"),
        F.col("d.week_end_date").alias("opened_week_end_date"),
        "source_created_ts",
        "source_modified_ts",
        F.current_timestamp().alias("created_ts"),
        F.current_timestamp().alias("updated_ts")
    )
)

fact_complaints.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(p_fact_complaints_table)

print("Rows written to fact_sop_complaints:", fact_complaints.count())

display(
    fact_complaints
    .orderBy(F.col("opened_date").desc())
    .limit(50)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

order_tracking = latest_salesforce_rows(order_tracking_raw)

required_order_cols = [
    "Id",
    "Order_lines_dated_on_factory_book__c"
]

missing_order_cols = [c for c in required_order_cols if c not in order_tracking.columns]

if missing_order_cols:
    raise RuntimeError(
        f"Order Tracking is missing required columns for Lines Released: {missing_order_cols}"
    )

fact_lines_released_base = (
    order_tracking
    .filter(~F.coalesce(F.col("IsDeleted"), F.lit(False)) if "IsDeleted" in order_tracking.columns else F.lit(True))
    .select(
        F.col("Id").alias("order_tracking_id"),

        F.coalesce(
            F.col("Order_Number__c") if "Order_Number__c" in order_tracking.columns else F.lit(None),
            F.col("Name") if "Name" in order_tracking.columns else F.lit(None),
            F.col("Id")
        ).alias("order_tracking_no"),

        first_existing_column_expr(
            order_tracking,
            ["Project_Description__c", "Project_Name__c", "Project_Name"],
            "project_name",
            "string"
        ),

        first_existing_column_expr(
            order_tracking,
            ["Infor_Order_Reference__c", "Infor_Order_Reference_f__c", "Project_Infor_Reference__c"],
            "infor_order_reference",
            "string"
        ),

        F.to_date(F.col("Order_lines_dated_on_factory_book__c")).alias("lines_released_date"),

        first_existing_column_expr(
            order_tracking,
            ["Final_Dispatch_Date__c"],
            "final_dispatch_date",
            "date"
        ),

        first_existing_column_expr(
            order_tracking,
            ["Date_shipped_out_of_factory__c"],
            "date_shipped_out_of_factory",
            "date"
        ),

        first_existing_column_expr(
            order_tracking,
            ["Production_End_Date__c"],
            "production_end_date",
            "date"
        ),

        first_existing_column_expr(
            order_tracking,
            ["Order_Value__c", "Value__c", "PO_Value__c"],
            "order_value",
            "double"
        ),

        first_existing_column_expr(
            order_tracking,
            ["Sales_Division__c"],
            "sales_division",
            "string"
        ),

        first_existing_column_expr(
            order_tracking,
            ["Status__c"],
            "order_status",
            "string"
        ),

        first_existing_column_expr(
            order_tracking,
            ["Stage__c"],
            "order_stage",
            "string"
        ),

        first_existing_column_expr(
            order_tracking,
            ["CreatedDate"],
            "source_created_ts",
            "timestamp"
        ),

        first_existing_column_expr(
            order_tracking,
            ["SystemModstamp", "LastModifiedDate"],
            "source_modified_ts",
            "timestamp"
        )
    )
    .filter(F.col("lines_released_date").isNotNull())
    .dropDuplicates(["order_tracking_id"])
)

fact_lines_released = (
    fact_lines_released_base
    .join(
        dim_date.alias("d"),
        F.col("lines_released_date") == F.col("d.calendar_date"),
        "left"
    )
    .select(
        "order_tracking_id",
        "order_tracking_no",
        "project_name",
        "infor_order_reference",
        "lines_released_date",
        F.col("d.date_key").alias("lines_released_date_key"),
        F.col("d.customer_year").alias("lines_released_customer_year"),
        F.col("d.customer_week_no").alias("lines_released_customer_week_no"),
        F.col("d.week_key").alias("lines_released_week_key"),
        F.col("d.week_start_date").alias("lines_released_week_start_date"),
        F.col("d.week_end_date").alias("lines_released_week_end_date"),
        "final_dispatch_date",
        "date_shipped_out_of_factory",
        "production_end_date",
        "order_value",
        "sales_division",
        "order_status",
        "order_stage",
        "source_created_ts",
        "source_modified_ts",
        F.current_timestamp().alias("created_ts"),
        F.current_timestamp().alias("updated_ts")
    )
)

fact_lines_released.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(p_fact_lines_released_table)

print("Rows written to fact_sop_lines_released:", fact_lines_released.count())

display(
    fact_lines_released
    .orderBy(F.col("lines_released_date").desc())
    .limit(50)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

fact_complaints_src = spark.table(p_fact_complaints_table)
fact_lines_released_src = spark.table(p_fact_lines_released_table)

complaints_weekly = (
    fact_complaints_src
    .groupBy(
        F.col("opened_customer_year").alias("closed_year"),
        F.col("opened_customer_week_no").alias("closed_week"),
        F.col("opened_week_key").alias("week_key")
    )
    .agg(
        F.countDistinct("complaint_id").cast("double").alias("complaints_raised"),
        F.countDistinct("complaint_id").cast("long").alias("source_row_count")
    )
    .filter(F.col("closed_year").isNotNull() & F.col("closed_week").isNotNull())
)

lines_released_weekly = (
    fact_lines_released_src
    .groupBy(
        F.col("lines_released_customer_year").alias("closed_year"),
        F.col("lines_released_customer_week_no").alias("closed_week"),
        F.col("lines_released_week_key").alias("week_key")
    )
    .agg(
        F.countDistinct("order_tracking_id").cast("double").alias("lines_released"),
        F.sum("order_value").cast("double").alias("released_order_value"),
        F.countDistinct("order_tracking_id").cast("long").alias("source_row_count")
    )
    .filter(F.col("closed_year").isNotNull() & F.col("closed_week").isNotNull())
)

display(complaints_weekly.orderBy("closed_year", "closed_week"))
display(lines_released_weekly.orderBy("closed_year", "closed_week"))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

complaints_kpi = (
    complaints_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_COMPLAINTS_RAISED).cast("long").alias("kpi_id"),
        F.lit("SOP_COMPLAINTS_RAISED").alias("kpi_code"),
        F.lit("Complaints Raised").alias("kpi_name"),
        F.lit("Quality").alias("kpi_category"),

        F.col("complaints_raised").cast("double").alias("kpi_value"),
        F.lit(TARGET_COMPLAINTS_RAISED).cast("double").alias("target_value"),

        F.lit("OVER").alias("breach_direction"),
        F.lit("Over Breach").alias("sign"),
        F.lit("Over Breach").alias("sign_label"),

        F.lit("Count").alias("uom"),
        F.lit("Count of customer complaints raised").alias("measure"),
        F.lit("Count of customer complaints raised").alias("measure_name"),

        F.lit("Derived from Salesforce Customer Service records using opened date. Target currently TBC.").alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.`Customer Service`").alias("source_object")
    )
)

lines_released_kpi = (
    lines_released_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_LINES_RELEASED).cast("long").alias("kpi_id"),
        F.lit("SOP_LINES_RELEASED").alias("kpi_code"),
        F.lit("Lines Released").alias("kpi_name"),
        F.lit("Productivity").alias("kpi_category"),

        F.col("lines_released").cast("double").alias("kpi_value"),
        F.lit(TARGET_LINES_RELEASED).cast("double").alias("target_value"),

        F.lit("UNDER").alias("breach_direction"),
        F.lit("Under Breach").alias("sign"),
        F.lit("Under Breach").alias("sign_label"),

        F.lit("Count").alias("uom"),
        F.lit("Number of order lines released").alias("measure"),
        F.lit("Number of order lines released").alias("measure_name"),

        F.lit("Derived from Order Tracking using Order_lines_dated_on_factory_book__c as the release date proxy. Target currently TBC.").alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.`Order Tracking`").alias("source_object")
    )
)

released_value_kpi = (
    lines_released_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_RELEASED_ORDER_VALUE).cast("long").alias("kpi_id"),
        F.lit("SOP_RELEASED_ORDER_VALUE").alias("kpi_code"),
        F.lit("Released Order Value").alias("kpi_name"),
        F.lit("Productivity").alias("kpi_category"),

        F.col("released_order_value").cast("double").alias("kpi_value"),
        F.lit(TARGET_RELEASED_ORDER_VALUE).cast("double").alias("target_value"),

        F.lit("UNDER").alias("breach_direction"),
        F.lit("Under Breach").alias("sign"),
        F.lit("Under Breach").alias("sign_label"),

        F.lit("£").alias("uom"),
        F.lit("Value of orders released").alias("measure"),
        F.lit("Value of orders released").alias("measure_name"),

        F.lit("Derived from Order Tracking order value using Order_lines_dated_on_factory_book__c as the release date proxy. Target currently TBC.").alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.`Order Tracking`").alias("source_object")
    )
)

value_per_fte_placeholder = (
    lines_released_weekly
    .select(
        "closed_year",
        "closed_week",
        "week_key",

        F.lit(KPI_ID_VALUE_PER_FTE).cast("long").alias("kpi_id"),
        F.lit("SOP_VALUE_PER_FTE").alias("kpi_code"),
        F.lit("Value per FTE").alias("kpi_name"),
        F.lit("Productivity").alias("kpi_category"),

        F.lit(None).cast("double").alias("kpi_value"),
        F.lit(TARGET_VALUE_PER_FTE).cast("double").alias("target_value"),

        F.lit("UNDER").alias("breach_direction"),
        F.lit("Under Breach").alias("sign"),
        F.lit("Under Breach").alias("sign_label"),

        F.lit("£/FTE").alias("uom"),
        F.lit("Released order value divided by FTE").alias("measure"),
        F.lit("Released order value divided by FTE").alias("measure_name"),

        F.lit("FTE denominator is not currently available in the Salesforce bronze layer. KPI retained as TBC until FTE source is provided.").alias("commentary"),

        F.col("source_row_count").cast("long").alias("source_row_count"),
        F.lit("bronze_lakehouse.`Order Tracking`; FTE source TBC").alias("source_object")
    )
)

sop_kpi_base = (
    complaints_kpi
    .unionByName(lines_released_kpi)
    .unionByName(released_value_kpi)
    .unionByName(value_per_fte_placeholder)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

sop_kpi_enriched = (
    sop_kpi_base
    .withColumn("organisational_unit", F.lit(p_organisational_unit))
    .withColumn("department", F.lit(p_department))
    .withColumn(
        "variance_value",
        (F.col("kpi_value") - F.col("target_value")).cast("double")
    )
    .withColumn(
        "performance_variance_value",
        F.when(
            F.col("breach_direction") == F.lit("OVER"),
            F.col("target_value") - F.col("kpi_value")
        ).otherwise(
            F.col("kpi_value") - F.col("target_value")
        ).cast("double")
    )
    .withColumn(
        "data_status",
        F.when(F.col("kpi_code") == "SOP_VALUE_PER_FTE", F.lit("TBC"))
         .when(F.col("kpi_value").isNull(), F.lit("No Data"))
         .when(F.col("target_value").isNull(), F.lit("Actual - Target TBC"))
         .otherwise(F.lit("Actual"))
    )
    .withColumn(
        "rag_status",
        rag_status(
            F.col("kpi_value"),
            F.col("target_value"),
            F.col("breach_direction"),
            F.col("data_status")
        )
    )
    .withColumn("source_system", F.lit(p_source_system))
    .withColumn("calculation_timestamp", F.current_timestamp())
    .select(
        "closed_year",
        "closed_week",
        "kpi_name",
        F.col("kpi_value").cast("double").alias("kpi_value"),
        "organisational_unit",
        F.col("kpi_id").cast("long").alias("kpi_id"),
        "kpi_category",
        F.col("target_value").cast("double").alias("target_value"),
        "breach_direction",
        "week_key",
        "kpi_code",
        "department",
        "measure",
        "measure_name",
        "uom",
        "sign",
        "sign_label",
        "commentary",
        "variance_value",
        "performance_variance_value",
        "rag_status",
        "data_status",
        "source_system",
        "source_object",
        F.col("source_row_count").cast("long").alias("source_row_count"),
        "calculation_timestamp"
    )
)

sop_kpi_enriched.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(p_sop_kpi_output_table)

display(
    sop_kpi_enriched
    .orderBy("closed_year", "closed_week", "kpi_id")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

existing_kpi = spark.table(p_existing_kpi_table)

sop_kpi_codes_to_replace = [
    "SOP_COMPLAINTS_RAISED",
    "SOP_LINES_RELEASED",
    "SOP_RELEASED_ORDER_VALUE",
    "SOP_VALUE_PER_FTE"
]

existing_without_sop_additional = (
    existing_kpi
    .filter(
        ~F.col("kpi_code").isin(sop_kpi_codes_to_replace)
    )
)

combined_kpi = (
    existing_without_sop_additional
    .unionByName(
        sop_kpi_enriched,
        allowMissingColumns=True
    )
)

combined_kpi.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(p_existing_kpi_table)

print("Existing rows before merge:", existing_kpi.count())
print("SOP KPI rows added:", sop_kpi_enriched.count())
print("Combined rows written:", combined_kpi.count())

display(
    spark.table(p_existing_kpi_table)
    .filter(F.col("kpi_code").isin(sop_kpi_codes_to_replace))
    .orderBy("closed_year", "closed_week", "kpi_id")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(
    spark.table(p_existing_kpi_table)
    .filter(
        F.col("department") == "SOP"
    )
    .groupBy(
        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",
        "measure",
        "uom",
        "data_status",
        "rag_status"
    )
    .agg(
        F.count("*").alias("rows"),
        F.min("closed_week").alias("min_week"),
        F.max("closed_week").alias("max_week"),
        F.sum("kpi_value").alias("sum_kpi_value")
    )
    .orderBy("kpi_id")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

###merge kpi tables from enriched into v2

spark.table(
    "dbo.kpi_result_silver_enriched_v2"
).write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2_backup"
    )

print(
    "Backup rows:",
    spark.table(
        "dbo.kpi_result_silver_enriched_v2_backup"
    ).count()
)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

legacy = spark.table("dbo.kpi_result_silver_enriched")
v2 = spark.table("dbo.kpi_result_silver_enriched_v2")

print("Legacy rows :", legacy.count())
print("V2 rows     :", v2.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

legacy = spark.table("dbo.kpi_result_silver_enriched")
v2 = spark.table("dbo.kpi_result_silver_enriched_v2")

legacy_aligned = legacy

# Add missing V2 columns
for c in v2.columns:

    if c not in legacy_aligned.columns:

        if c == "department":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.col("organisational_unit")
            )

        elif c in ["measure", "measure_name"]:
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.col("kpi_name")
            )

        elif c in ["sign", "sign_label"]:
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.when(
                    F.col("breach_direction") == "OVER",
                    F.lit("Over Breach")
                )
                .otherwise(
                    F.lit("Under Breach")
                )
            )

        elif c == "commentary":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.lit(
                    "Migrated from dbo.kpi_result_silver_enriched"
                )
            )

        elif c == "week_key":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.concat_ws(
                    "-",
                    F.col("closed_year"),
                    F.col("closed_week")
                )
            )

        elif c == "kpi_code":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.upper(
                    F.regexp_replace(
                        F.col("kpi_name"),
                        "[^A-Za-z0-9]",
                        "_"
                    )
                )
            )

        elif c == "variance_value":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                (
                    F.col("kpi_value")
                    - F.col("target_value")
                ).cast("double")
            )

        elif c == "performance_variance_value":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                (
                    F.col("kpi_value")
                    - F.col("target_value")
                ).cast("double")
            )

        elif c == "data_status":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.lit("Migrated")
            )

        elif c == "source_system":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.lit("Legacy KPI Silver")
            )

        elif c == "source_object":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.lit("dbo.kpi_result_silver_enriched")
            )

        elif c == "source_row_count":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.lit(None).cast("long")
            )

        elif c == "calculation_timestamp":
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.current_timestamp()
            )

        else:
            legacy_aligned = legacy_aligned.withColumn(
                c,
                F.lit(None)
            )

# Match V2 column order
legacy_aligned = legacy_aligned.select(v2.columns)

merged = (
    v2
    .unionByName(
        legacy_aligned,
        allowMissingColumns=True
    )
)

print("Merged rows :", merged.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

merged.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2_test"
    )

print(
    "Test rows:",
    spark.table(
        "dbo.kpi_result_silver_enriched_v2_test"
    ).count()
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Replace V2 with the validated merged result

spark.sql("""
DROP TABLE IF EXISTS dbo.kpi_result_silver_enriched_v2
""")

spark.table(
    "dbo.kpi_result_silver_enriched_v2_test"
).write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2"
    )

print(
    "Final V2 row count:",
    spark.table(
        "dbo.kpi_result_silver_enriched_v2"
    ).count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(
    spark.table(
        "dbo.kpi_result_silver_enriched_v2"
    )
    .groupBy("organisational_unit")
    .count()
    .orderBy("organisational_unit")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(
    spark.table(
        "dbo.kpi_result_silver_enriched_v2"
    )
    .select(
        "closed_year",
        "closed_week",
        "kpi_name",
        "organisational_unit",
        "department"
    )
    .orderBy(
        "closed_year",
        "closed_week"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

###build new staging table with additional dates

from pyspark.sql import functions as F

kpi = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

dim_date = spark.table(
    "dbo.dim_date"
)

print("KPI rows:", kpi.count())
print("Date rows:", dim_date.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dim_week = (
    dim_date
    .filter(
        F.col("day_name") == "Friday"
    )
    .select(
        F.col("date_key").cast("int"),
        F.col("calendar_date").alias(
            "week_ending_date"
        ),
        F.col("week_start_date"),
        F.col("week_end_date"),
        F.col("customer_year").cast("int").alias(
            "calendar_year"
        ),
        F.col("customer_week_no").cast("int").alias(
            "week_number"
        )
    )
    .dropDuplicates(
        [
            "calendar_year",
            "week_number"
        ]
    )
)

display(
    dim_week.orderBy(
        "calendar_year",
        "week_number"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

fact_kpi_result_staging_v2 = (
    kpi
    .join(
        dim_week,
        (
            kpi.closed_year.cast("int")
            ==
            dim_week.calendar_year
        )
        &
        (
            kpi.closed_week.cast("int")
            ==
            dim_week.week_number
        ),
        "left"
    )
    .select(
        "date_key",
        "week_ending_date",
        "week_start_date",
        "week_end_date",
        "calendar_year",
        "week_number",

        "closed_year",
        "closed_week",
        "week_key",

        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",

        "organisational_unit",
        "department",

        "measure",
        "measure_name",

        "uom",

        "sign",
        "sign_label",

        "commentary",

        F.col("kpi_value").alias(
            "actual_value"
        ),

        "target_value",

        "variance_value",

        "performance_variance_value",

        "breach_direction",

        "rag_status",
        "data_status",

        "source_system",
        "source_object",
        "source_row_count",

        "calculation_timestamp"
    )
)

print(
    "Staging rows:",
    fact_kpi_result_staging_v2.count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(
    fact_kpi_result_staging_v2
    .select(
        "date_key",
        "week_ending_date",
        "week_start_date",
        "week_end_date",
        "calendar_year",
        "week_number",

        "kpi_id",
        "kpi_name",

        "organisational_unit",
        "department",

        "actual_value",
        "target_value"
    )
    .orderBy(
        "calendar_year",
        "week_number",
        "kpi_id"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

####rebuild dbo.fact_kpi_result_staging_v2
fact_kpi_result_staging_v2.write \
    .format("delta") \
    .mode("overwrite") \
    .option(
        "overwriteSchema",
        "true"
    ) \
    .saveAsTable(
        "dbo.fact_kpi_result_staging_v2"
    )

print(
    "Rows written:",
    spark.table(
        "dbo.fact_kpi_result_staging_v2"
    ).count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(
    spark.table(
        "dbo.fact_kpi_result_staging_v2"
    )
    .groupBy(
        "organisational_unit",
        "department",
        "kpi_category"
    )
    .agg(
        F.count("*").alias("rows")
    )
    .orderBy(
        "organisational_unit",
        "department",
        "kpi_category"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

kpi = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

kpi_fixed = (
    kpi
    .withColumn(
        "rag_status",
        F.when(
            F.col("rag_status").isNotNull(),
            F.col("rag_status")
        )

        # Both blank
        .when(
            F.col("kpi_value").isNull() &
            F.col("target_value").isNull(),
            F.lit("Blank")
        )

        # Actual missing
        .when(
            F.col("kpi_value").isNull(),
            F.lit("TBC")
        )

        # Target missing
        .when(
            F.col("target_value").isNull(),
            F.lit("Blank")
        )

        # UNDER = higher better
        .when(
            (F.col("breach_direction") == "UNDER") &
            (F.col("kpi_value") >= F.col("target_value")),
            F.lit("G")
        )

        .when(
            (F.col("breach_direction") == "UNDER") &
            (
                F.col("kpi_value")
                >=
                (F.col("target_value") * F.lit(0.95))
            ),
            F.lit("A")
        )

        # OVER = lower better
        .when(
            (F.col("breach_direction") == "OVER") &
            (F.col("kpi_value") <= F.col("target_value")),
            F.lit("G")
        )

        .when(
            (F.col("breach_direction") == "OVER") &
            (
                F.col("kpi_value")
                <=
                (F.col("target_value") * F.lit(1.05))
            ),
            F.lit("A")
        )

        .otherwise(F.lit("R"))
    )
)

kpi_fixed.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema","true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2"
    )

print(
    "Rows:",
    kpi_fixed.count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

v2 = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

design_fixed = (
    v2
    .withColumn(
        "department",
        F.when(
            F.col("organisational_unit") == "Design & R&D",
            F.lit("Design & R&D")
        ).otherwise(F.col("department"))
    )

    .withColumn(
        "measure",
        F.when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Volume Completed"),
            F.lit(
                "Number of Approx. Design requests closed weekly"
            )
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "OTIF %"),
            F.lit(
                "% of Designs closed that were completed by the internal Date"
            )
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Design Rejections"),
            F.lit(
                "Number of rejected designs (internal to Design team)"
            )
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Opportunity Value per Proposal"),
            F.lit(
                "Expected Opportunity value / No of proposals collated"
            )
        )
        .otherwise(F.col("measure"))
    )
)

design_fixed = (
    design_fixed

    .withColumn(
        "measure_name",
        F.when(
            F.col("organisational_unit") == "Design & R&D",
            F.col("measure")
        ).otherwise(F.col("measure_name"))
    )

    .withColumn(
        "uom",
        F.when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Volume Completed"),
            F.lit("Count")
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "OTIF %"),
            F.lit("Percentage")
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Design Rejections"),
            F.lit("Count")
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Opportunity Value per Proposal"),
            F.lit("£")
        )
        .otherwise(F.col("uom"))
    )

    .withColumn(
        "sign",
        F.when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Design Rejections"),
            F.lit("Over Breach")
        )
        .when(
            F.col("organisational_unit") == "Design & R&D",
            F.lit("Under Breach")
        )
        .otherwise(F.col("sign"))
    )

    .withColumn(
        "sign_label",
        F.when(
            F.col("organisational_unit") == "Design & R&D",
            F.col("sign")
        )
        .otherwise(F.col("sign_label"))
    )

    .withColumn(
        "commentary",
        F.when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Volume Completed"),
            F.lit("Salesforce")
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "OTIF %"),
            F.lit("Salesforce")
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Design Rejections"),
            F.lit("Not in a system")
        )
        .when(
            (F.col("organisational_unit") == "Design & R&D")
            &
            (F.col("kpi_name") == "Opportunity Value per Proposal"),
            F.lit("Never reported on before")
        )
        .otherwise(F.col("commentary"))
    )
)

design_fixed.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema","true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2"
    )

print(
    "Rows:",
    design_fixed.count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

v2 = spark.table("dbo.kpi_result_silver_enriched_v2")

display(
    v2
    .filter(F.col("organisational_unit") == "HR Monthly")
    .groupBy(
        "closed_year",
        "closed_week",
        "kpi_code",
        "kpi_name",
        "kpi_category",
        "organisational_unit"
    )
    .agg(
        F.count("*").alias("row_count"),
        F.count("department").alias("rows_with_department"),
        F.count("measure").alias("rows_with_measure"),
        F.count("uom").alias("rows_with_uom")
    )
    .filter(F.col("row_count") > 1)
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_code"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.table(
    "dbo.kpi_result_silver_enriched_v2"
).write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2_backup_before_dedupe"
    )

print(
    "Backup rows:",
    spark.table(
        "dbo.kpi_result_silver_enriched_v2_backup_before_dedupe"
    ).count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.window import Window

v2 = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

dedupe_key = [
    "closed_year",
    "closed_week",
    "kpi_code",
    "kpi_name",
    "kpi_category",
    "organisational_unit"
]

v2_ranked = (
    v2
    .withColumn(
        "_metadata_score",
        F.when(F.col("department").isNotNull(), F.lit(1)).otherwise(F.lit(0)) +
        F.when(F.col("measure").isNotNull(), F.lit(1)).otherwise(F.lit(0)) +
        F.when(F.col("measure_name").isNotNull(), F.lit(1)).otherwise(F.lit(0)) +
        F.when(F.col("uom").isNotNull(), F.lit(1)).otherwise(F.lit(0)) +
        F.when(F.col("sign").isNotNull(), F.lit(1)).otherwise(F.lit(0)) +
        F.when(F.col("sign_label").isNotNull(), F.lit(1)).otherwise(F.lit(0)) +
        F.when(F.col("commentary").isNotNull(), F.lit(1)).otherwise(F.lit(0)) +
        F.when(F.col("rag_status").isNotNull(), F.lit(1)).otherwise(F.lit(0)) +
        F.when(F.col("data_status").isNotNull(), F.lit(1)).otherwise(F.lit(0))
    )
    .withColumn(
        "_rn",
        F.row_number().over(
            Window
            .partitionBy(*dedupe_key)
            .orderBy(
                F.col("_metadata_score").desc(),
                F.col("calculation_timestamp").desc_nulls_last()
            )
        )
    )
)

v2_deduped = (
    v2_ranked
    .filter(F.col("_rn") == 1)
    .drop("_metadata_score", "_rn")
)

print("Rows before dedupe:", v2.count())
print("Rows after dedupe :", v2_deduped.count())
print("Rows removed      :", v2.count() - v2_deduped.count())

display(
    v2_deduped
    .groupBy(
        "organisational_unit",
        "department",
        "kpi_category",
        "kpi_code",
        "kpi_name"
    )
    .agg(
        F.count("*").alias("rows")
    )
    .orderBy(
        "organisational_unit",
        "department",
        "kpi_category",
        "kpi_code"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

v2_deduped.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2_deduped_test"
    )

print(
    "Deduped test rows:",
    spark.table(
        "dbo.kpi_result_silver_enriched_v2_deduped_test"
    ).count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(
    spark.table(
        "dbo.kpi_result_silver_enriched_v2_deduped_test"
    )
    .filter(
        F.col("organisational_unit") == "HR Monthly"
    )
    .select(
        "closed_year",
        "closed_week",
        "kpi_code",
        "kpi_name",
        "organisational_unit",
        "department",
        "measure",
        "uom",
        "commentary"
    )
    .orderBy(
        "closed_year",
        "closed_week",
        "kpi_code"
    )
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
DROP TABLE IF EXISTS dbo.kpi_result_silver_enriched_v2
""")

spark.table(
    "dbo.kpi_result_silver_enriched_v2_deduped_test"
).write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.kpi_result_silver_enriched_v2"
    )

print(
    "Final V2 rows:",
    spark.table(
        "dbo.kpi_result_silver_enriched_v2"
    ).count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

kpi = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

dim_date = spark.table(
    "dbo.dim_date"
)

dim_week = (
    dim_date
    .filter(
        F.col("day_name") == "Friday"
    )
    .select(
        F.col("date_key").cast("int").alias("date_key"),
        F.col("calendar_date").alias("week_ending_date"),
        F.col("week_start_date").alias("week_start_date"),
        F.col("week_end_date").alias("week_end_date"),
        F.col("customer_year").cast("int").alias("calendar_year"),
        F.col("customer_week_no").cast("int").alias("week_number")
    )
    .dropDuplicates(
        [
            "calendar_year",
            "week_number"
        ]
    )
)

fact_kpi_result_staging_v2 = (
    kpi
    .join(
        dim_week,
        (
            kpi.closed_year.cast("int") == dim_week.calendar_year
        )
        &
        (
            kpi.closed_week.cast("int") == dim_week.week_number
        ),
        "left"
    )
    .select(
        "date_key",
        "week_ending_date",
        "week_start_date",
        "week_end_date",
        "calendar_year",
        "week_number",

        "closed_year",
        "closed_week",
        "week_key",

        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",

        "organisational_unit",
        "department",

        "measure",
        "measure_name",

        "uom",

        "sign",
        "sign_label",

        "commentary",

        F.col("kpi_value").alias("actual_value"),

        "target_value",
        "variance_value",
        "performance_variance_value",

        "breach_direction",

        "rag_status",
        "data_status",

        "source_system",
        "source_object",
        "source_row_count",

        "calculation_timestamp"
    )
)

fact_kpi_result_staging_v2.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.fact_kpi_result_staging_v2"
    )

print(
    "Rows written to staging v2:",
    spark.table(
        "dbo.fact_kpi_result_staging_v2"
    ).count()
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

# Source KPI table
kpi = spark.table(
    "dbo.kpi_result_silver_enriched_v2"
)

# Date dimension
dim_date = spark.table(
    "dbo.dim_date"
)

# One row per customer week, using Friday as week ending date
dim_week = (
    dim_date
    .filter(
        F.col("day_name") == "Friday"
    )
    .select(
        F.col("date_key").cast("int").alias("date_key"),
        F.col("calendar_date").alias("week_ending_date"),
        F.col("week_start_date").alias("week_start_date"),
        F.col("week_end_date").alias("week_end_date"),
        F.col("customer_year").cast("int").alias("calendar_year"),
        F.col("customer_week_no").cast("int").alias("week_number")
    )
    .dropDuplicates(
        [
            "calendar_year",
            "week_number"
        ]
    )
)

# Rebuild reporting staging table from enriched V2
fact_kpi_result_staging_v2 = (
    kpi
    .join(
        dim_week,
        (
            kpi.closed_year.cast("int")
            ==
            dim_week.calendar_year
        )
        &
        (
            kpi.closed_week.cast("int")
            ==
            dim_week.week_number
        ),
        "left"
    )
    .select(
        "date_key",
        "week_ending_date",
        "week_start_date",
        "week_end_date",
        "calendar_year",
        "week_number",

        "closed_year",
        "closed_week",
        "week_key",

        "kpi_id",
        "kpi_code",
        "kpi_name",
        "kpi_category",

        "organisational_unit",
        "department",

        "measure",
        "measure_name",

        "uom",

        "sign",
        "sign_label",

        "commentary",

        F.col("kpi_value").cast("double").alias("actual_value"),

        F.col("target_value").cast("double").alias("target_value"),
        F.col("variance_value").cast("double").alias("variance_value"),
        F.col("performance_variance_value").cast("double").alias("performance_variance_value"),

        "breach_direction",

        "rag_status",
        "data_status",

        "source_system",
        "source_object",
        F.col("source_row_count").cast("long").alias("source_row_count"),

        "calculation_timestamp"
    )
)

# Persist staging V2 for the Gold pipeline copy
fact_kpi_result_staging_v2.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(
        "dbo.fact_kpi_result_staging_v2"
    )

print(
    "Rows written to dbo.fact_kpi_result_staging_v2:",
    spark.table(
        "dbo.fact_kpi_result_staging_v2"
    ).count()
)

display(
    spark.table(
        "dbo.fact_kpi_result_staging_v2"
    )
    .groupBy(
        "organisational_unit",
        "department",
        "kpi_category"
    )
    .agg(
        F.count("*").alias("rows")
    )
    .orderBy(
        "organisational_unit",
        "department",
        "kpi_category"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

display(
    spark.table(
        "dbo.kpi_result_silver_enriched_v2"
    )
    .groupBy(
        "organisational_unit"
    )
    .agg(
        F.count("*").alias("rows")
    )
    .orderBy(
        "organisational_unit"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
