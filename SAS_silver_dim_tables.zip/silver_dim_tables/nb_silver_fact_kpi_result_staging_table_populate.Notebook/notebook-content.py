# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

#!/usr/bin/env python
# nb_gold_fact_kpi_result_staging_populate.py
# Purpose:
#   Build KPI results in Silver Lakehouse as a single "Gold-shaped" staging fact table.
#   This table is then shortcut into wh_sas_gold.staging, and Warehouse SQL builds final salesforce.fact_kpi_result.

from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, count, avg, sum as _sum, current_timestamp, when, upper, trim

# --------------------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------------------
def pick_table(*candidates):
    """
    Return first existing table from the list of candidates.
    Supports both 'silver.xxx' naming and plain 'xxx' naming patterns.
    """
    for t in candidates:
        try:
            if spark.catalog.tableExists(t):
                return t
        except Exception:
            pass
    raise Exception(f"None of these tables exist: {candidates}")

# --------------------------------------------------------------------------------------
# Resolve source tables (Silver Lakehouse)
# --------------------------------------------------------------------------------------
T_FACT_PROPOSAL = pick_table("silver.fact_proposal", "dbo.fact_proposal", "fact_proposal")
T_FACT_DELIVERY = pick_table("silver.fact_proposal_delivery", "dbo.fact_proposal_delivery", "fact_proposal_delivery")
T_FACT_QUALITY  = pick_table("silver.fact_quality_weekly", "dbo.fact_quality_weekly", "fact_quality_weekly")
T_DIM_KPI       = pick_table("silver.dim_kpi", "dbo.dim_kpi", "dim_kpi")
T_DIM_DATE      = pick_table("silver.dim_date", "dbo.dim_date", "dim_date")

print("Using tables:")
print(" fact_proposal        =", T_FACT_PROPOSAL)
print(" fact_proposal_delivery=", T_FACT_DELIVERY)
print(" fact_quality_weekly  =", T_FACT_QUALITY)
print(" dim_kpi              =", T_DIM_KPI)
print(" dim_date             =", T_DIM_DATE)

fact_proposal = spark.table(T_FACT_PROPOSAL)
fact_delivery = spark.table(T_FACT_DELIVERY)
fact_quality  = spark.table(T_FACT_QUALITY)
dim_kpi       = spark.table(T_DIM_KPI)
dim_date      = spark.table(T_DIM_DATE)

# --------------------------------------------------------------------------------------
# Constants / parameters
# --------------------------------------------------------------------------------------
ORG_UNIT = "Design & R&D"  # aligns with your current KPI set; can be replaced with a derived field later.

# --------------------------------------------------------------------------------------
# Determine join key for OTIF (must exist on BOTH proposal & delivery)
# --------------------------------------------------------------------------------------
join_candidates = ["proposal_sk", "proposal_id", "proposal_request_no"]
join_key = next((k for k in join_candidates if k in fact_proposal.columns and k in fact_delivery.columns), None)

print("Chosen join key for OTIF:", join_key)
if join_key is None:
    raise Exception(
        "No common join key found between fact_proposal and fact_proposal_delivery.\n"
        f"fact_proposal columns: {fact_proposal.columns}\n"
        f"fact_proposal_delivery columns: {fact_delivery.columns}"
    )

# Deduplicate delivery table to avoid multiplying rows on join
delivery_dedup = fact_delivery.dropDuplicates([join_key])

# --------------------------------------------------------------------------------------
# KPI Calculations (Silver KPI result shape: year/week/kpi_name/kpi_value/org_unit)
# --------------------------------------------------------------------------------------

# 1) Productivity: Volume Completed (count closed proposals per week)
kpi_volume = (
    fact_proposal
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(count(lit(1)).alias("kpi_value"))
    .withColumn("kpi_name", lit("Volume Completed"))
    .withColumn("organisational_unit", lit(ORG_UNIT))
)

# 2) Delivery: OTIF % (avg on_time_flag per week)
kpi_otif = (
    fact_proposal
    .join(delivery_dedup, join_key, "inner")
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(avg(col("on_time_flag").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("OTIF %"))
    .withColumn("organisational_unit", lit(ORG_UNIT))
)

# 3) Quality: Design Rejections (weekly sum from manual/quality fact)
kpi_rejects = (
    fact_quality
    .groupBy("year", "week_number")
    .agg(_sum(col("rejected_designs_count").cast("double")).alias("kpi_value"))
    .withColumnRenamed("year", "closed_year")
    .withColumnRenamed("week_number", "closed_week")
    .withColumn("kpi_name", lit("Design Rejections"))
    .withColumn("organisational_unit", lit(ORG_UNIT))
)

# 4) Cost: Opportunity Value per Proposal (weekly avg)
kpi_value = (
    fact_proposal
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(avg(col("estimated_value_gbp").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("Opportunity Value per Proposal"))
    .withColumn("organisational_unit", lit(ORG_UNIT))
)

# Union into one KPI result dataset (Silver KPI result)
kpi_result_silver = (
    kpi_volume.select("closed_year", "closed_week", "kpi_name", "kpi_value", "organisational_unit")
    .unionByName(kpi_otif.select("closed_year", "closed_week", "kpi_name", "kpi_value", "organisational_unit"))
    .unionByName(kpi_rejects.select("closed_year", "closed_week", "kpi_name", "kpi_value", "organisational_unit"))
    .unionByName(kpi_value.select("closed_year", "closed_week", "kpi_name", "kpi_value", "organisational_unit"))
)

# --------------------------------------------------------------------------------------
# Enrich KPI results with dim_kpi metadata (kpi_id, category, target_value, breach_direction)
# Join on a normalised KPI name key (as per your original approach)
# --------------------------------------------------------------------------------------
dim_kpi_keyed = (
    dim_kpi
    .select(
        col("kpi_id"),
        col("category").alias("kpi_category"),
        col("target_value").cast("decimal(18,4)").alias("target_value"),
        col("breach_direction"),
        upper(trim(col("kpi_name"))).alias("kpi_name_key")
    )
)

kpi_result_silver_keyed = (
    kpi_result_silver
    .withColumn("kpi_name_key", upper(trim(col("kpi_name"))))
)

kpi_result_enriched = (
    kpi_result_silver_keyed
    .join(dim_kpi_keyed, on="kpi_name_key", how="left")
    .drop("kpi_name_key")
)

# Optional: show any KPI names not found in dim_kpi
unmatched = (
    kpi_result_enriched
    .filter(col("kpi_id").isNull())
    .select("kpi_name")
    .distinct()
)
print("Unmatched KPI names (should be 0):", unmatched.count())
if unmatched.count() > 0:
    unmatched.show(truncate=False)

# --------------------------------------------------------------------------------------
# Join to dim_date for a complete time grain
# IMPORTANT: dim_date is daily grain; to avoid 7 rows per week, choose Friday (Excel week ending).
# --------------------------------------------------------------------------------------
kpi_with_date = (
    kpi_result_enriched
    .withColumn("calendar_year", col("closed_year").cast("int"))
    .withColumn("week_number", col("closed_week").cast("int"))
    .join(
        dim_date.select(
            col("date_key").cast("int").alias("date_key"),
            col("calendar_date").alias("week_ending_date"),
            col("week_start_date"),
            col("week_end_date"),
            col("customer_year").cast("int").alias("customer_year"),
            col("customer_week_no").cast("int").alias("customer_week_no"),
            col("day_name")
        ),
        (col("calendar_year") == col("customer_year")) &
        (col("week_number") == col("customer_week_no")) &
        (col("day_name") == lit("Friday")),
        "left"
    )
)

# --------------------------------------------------------------------------------------
# Final Gold-shaped staging fact: measures + RAG + audit timestamp
# RAG rules:
#   UNDER => higher is better: G if >= target, A if >= 95% of target
#   OVER  => lower is better : G if <= target, A if <= 105% of target
# Plus your Blank/TBC handling
# --------------------------------------------------------------------------------------
fact_kpi_result_staging = (
    kpi_with_date
    .withColumn("actual_value", col("kpi_value").cast("decimal(18,4)"))
    .withColumn("target_value", col("target_value").cast("decimal(18,4)"))
    .withColumn(
        "variance_value",
        when(col("actual_value").isNull() | col("target_value").isNull(), lit(None).cast("decimal(18,4)"))
        .otherwise(col("actual_value") - col("target_value"))
    )
    .withColumn("calculation_timestamp", current_timestamp())
    .withColumn(
        "rag_status",
        when(col("actual_value").isNull() & col("target_value").isNull(), lit("Blank"))
        .when(col("actual_value").isNull(), lit("TBC"))
        .when(col("target_value").isNull(), lit("Blank"))

        # UNDER (higher is better)
        .when((col("breach_direction") == lit("UNDER")) & (col("actual_value") >= col("target_value")), lit("G"))
        .when((col("breach_direction") == lit("UNDER")) & (col("actual_value") >= col("target_value") * lit(0.95)), lit("A"))
        .when((col("breach_direction") == lit("UNDER")), lit("R"))

        # OVER (lower is better)
        .when((col("breach_direction") == lit("OVER")) & (col("actual_value") <= col("target_value")), lit("G"))
        .when((col("breach_direction") == lit("OVER")) & (col("actual_value") <= col("target_value") * lit(1.05)), lit("A"))
        .when((col("breach_direction") == lit("OVER")), lit("R"))

        # Fallback
        .otherwise(lit("Blank"))
    )
    .select(
        # Time grain / date keys
        col("date_key"),
        col("week_ending_date"),
        col("week_start_date"),
        col("week_end_date"),
        col("calendar_year"),
        col("week_number"),

        # KPI identifiers / descriptors
        col("kpi_id"),
        col("kpi_name"),
        col("kpi_category"),
        col("organisational_unit"),

        # Measures
        col("actual_value"),
        col("target_value"),
        col("variance_value"),
        col("breach_direction"),
        col("rag_status"),

        # Audit
        col("calculation_timestamp")
    )
)

# --------------------------------------------------------------------------------------
# Persist as a Silver Lakehouse table (this is the one you shortcut into wh_sas_gold.staging)
# --------------------------------------------------------------------------------------
TARGET_TABLE = "dbo.fact_kpi_result_staging"

(
    fact_kpi_result_staging
    .write
    .mode("overwrite")
    .format("delta")
    .saveAsTable(TARGET_TABLE)
)

print(f"✅ Written staging KPI fact to Silver Lakehouse table: {TARGET_TABLE}")

# --------------------------------------------------------------------------------------
# Lightweight validation (recommended)
# --------------------------------------------------------------------------------------
print("Row count:", fact_kpi_result_staging.count())
fact_kpi_result_staging.groupBy("rag_status").count().orderBy("rag_status").show()
fact_kpi_result_staging.groupBy("calendar_year","week_number","kpi_id","organisational_unit").count().filter("count > 1").show(20, truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

kpi = spark.table("dbo.fact_kpi_result_staging")

print("NULL dates:", kpi.filter("date_key IS NULL").count())


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
