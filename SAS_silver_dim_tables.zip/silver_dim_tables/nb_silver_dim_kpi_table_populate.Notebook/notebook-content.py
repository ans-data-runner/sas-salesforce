# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         },
# META         {
# META           "id": "6950bf8e-2162-41a8-af31-7263ad5c1551"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DecimalType, BooleanType

# ---- Source table (Bronze) ----
# Backticks needed due to space in table name
src = spark.table("`bronze_lakehouse`.`Proposal Request`")  # adjust if your lakehouse/table naming differs

# ---- Validate we have the fields needed for KPI inputs ----
needed_cols = [
    "Closed_Date__c",
    "Opened_Date__c",
    "Estimated_Completion_Date__c",
    "Complete_By_Date__c",
    "Estimated_Value",
    "Opportunity_Value__c",
    "Rejected_Drawings__c",
    "CurrencyIsoCode",
    "Sales_Division__c",
    "Sales_Region__c"
]
missing = [c for c in needed_cols if c not in src.columns]
if missing:
    print("WARNING - these columns are missing in Proposal Request:", missing)

# ---- Define KPI catalogue (derived from what Proposal Request can support) ----
# Targets/thresholds can start NULL and be maintained in Fabric (not DAX, not Excel)
kpi_rows = [
    ("Productivity", "Volume Completed",
     "Count of proposal requests closed (Closed_Date__c not null).", "Count", "UNDER",
     None, None, None, True),

    ("Delivery", "OTIF %",
     "Average on_time_flag where Closed_Date__c <= Complete_By_Date__c (or Estimated_Completion_Date__c).", "Percent", "UNDER",
     None, None, None, True),

    ("Cost", "Opportunity Value per Proposal",
     "Average Opportunity_Value__c (or Estimated_Value) per closed proposal (normalise currency if needed).", "GBP", "UNDER",
     None, None, None, True),

    ("Quality", "Design Rejections",
     "Count of rejected drawings (Rejected_Drawings__c) aggregated weekly (source is Proposal Request fields).", "Count", "OVER",
     None, None, None, True),
]

schema = StructType([
    StructField("category", StringType(), False),
    StructField("kpi_name", StringType(), False),
    StructField("description", StringType(), True),
    StructField("uom", StringType(), True),
    StructField("breach_direction", StringType(), True),
    StructField("target_value", DecimalType(18,4), True),
    StructField("rag_threshold_low", DecimalType(18,4), True),
    StructField("rag_threshold_high", DecimalType(18,4), True),
    StructField("is_active", BooleanType(), True)
])

df_kpi = spark.createDataFrame(kpi_rows, schema=schema)

# ---- Deterministic BIGINT key (no identity required) ----
df_kpi = (
    df_kpi
    .withColumn("kpi_key_src", F.concat_ws("|", F.lower(F.col("category")), F.lower(F.col("kpi_name"))))
    .withColumn("kpi_id", F.abs(F.xxhash64("kpi_key_src")).cast("bigint"))
    .drop("kpi_key_src")
    .withColumn("created_utc", F.current_timestamp())
    .withColumn("updated_utc", F.current_timestamp())
)

# ---- Upsert into dim_kpi ----
df_kpi.createOrReplaceTempView("stg_dim_kpi")

spark.sql("""
MERGE INTO dim_kpi AS tgt
USING stg_dim_kpi AS src
ON tgt.kpi_id = src.kpi_id
WHEN MATCHED THEN UPDATE SET
  tgt.category = src.category,
  tgt.kpi_name = src.kpi_name,
  tgt.description = src.description,
  tgt.uom = src.uom,
  tgt.breach_direction = src.breach_direction,
  tgt.is_active = src.is_active,
  tgt.updated_utc = src.updated_utc
WHEN NOT MATCHED THEN INSERT *
""")

display(spark.table("dim_kpi").orderBy("category","kpi_name"))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
UPDATE dim_kpi
SET target_value =
  CASE category
    WHEN 'Productivity' THEN 35
    WHEN 'Delivery'     THEN 100
    WHEN 'Quality'      THEN 0
    ELSE target_value
  END,
    updated_utc = current_timestamp()
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
INSERT INTO kpi_target_rule
VALUES (
  1,
  'Cost',
  'Productivity',
  '<=',
  35,
  171000,
  true,
  current_timestamp(),
  current_timestamp()
)
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
