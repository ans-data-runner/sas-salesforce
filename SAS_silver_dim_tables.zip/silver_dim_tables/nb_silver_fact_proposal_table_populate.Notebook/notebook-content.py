# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         },
# META         {
# META           "id": "6950bf8e-2162-41a8-af31-7263ad5c1551"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import (
    col, year, weekofyear, month,
    current_timestamp, abs, xxhash64, coalesce, lit
)

src = spark.table("`bronze_lakehouse`.`Proposal Request`")

# Business key: prefer Proposal_Number__c, else fall back to Name, else Id
bk = coalesce(col("Proposal_Number__c"), col("Name"), col("Id")).alias("proposal_request_no")

# Opened date fallback
opened_date_col = col("Opened_Date__c") if "Opened_Date__c" in src.columns else col("CreatedDate")
closed_date_col  = col("Closed_Date__c") if "Closed_Date__c" in src.columns else lit(None)

df = (
    src
    .withColumn("proposal_request_no", bk)
    .withColumn("proposal_id", abs(xxhash64(col("proposal_request_no"))))
    .withColumn("opened_date", opened_date_col.cast("date"))
    .withColumn("closed_date", closed_date_col.cast("date"))
    .withColumn("is_closed", col("closed_date").isNotNull())
    .withColumn("closed_year", year(col("closed_date")))
    .withColumn("closed_week", weekofyear(col("closed_date")))
    .withColumn("closed_month", month(col("closed_date")))
    .withColumn("currency_code", col("CurrencyIsoCode"))
    .withColumn("estimated_value_native", col("Estimated_Value__c").cast("decimal(18,2)"))

    #FIX: no exchange rate column on this object (for now default to 1.0)
    .withColumn("exchange_rate_to_gbp", lit(1.0).cast("decimal(18,8)"))
    .withColumn("estimated_value_gbp", (col("estimated_value_native") * col("exchange_rate_to_gbp")).cast("decimal(18,2)"))

    #NEW: Quality input (NULL -> 0) and cast to INT
    .withColumn("rejected_drawings_count", coalesce(col("Rejected_Drawings__c").cast("int"), lit(0)))

    .select(
        "proposal_id",
        "proposal_request_no",
        col("Project_Name__c").alias("project_name"),
        col("RecordTypeId").alias("record_type"),
        col("Sales_Division__c").alias("sales_division"),
        col("Sales_Region__c").alias("geography"),
        "opened_date",
        "closed_date",
        "closed_year",
        "closed_week",
        "closed_month",
        "currency_code",
        "estimated_value_native",
        "exchange_rate_to_gbp",
        "estimated_value_gbp",
        "rejected_drawings_count",     
        "is_closed"
    )
    .withColumn("created_utc", current_timestamp())
    .withColumn("updated_utc", current_timestamp())
)

df.write.mode("overwrite").saveAsTable("fact_proposal")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
