# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         },
# META         {
# META           "id": "6950bf8e-2162-41a8-af31-7263ad5c1551"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

#Silver – Estimation Fact (same as proposals)

from pyspark.sql.functions import (
    col, year, weekofyear, month,
    current_timestamp, abs, xxhash64, coalesce, lit
)

src = spark.table("bronze_lakehouse.`Estimating Request`")

# Business key (same pattern as proposals)
bk = coalesce(
    col("Estimate Request No."),
    col("Name"),
    col("Id")
).alias("estimation_request_no")

opened_date_col = col("Opened_Date") if "Opened_Date" in src.columns else col("CreatedDate")
closed_date_col = col("Closed_Date") if "Closed_Date" in src.columns else lit(None)

df = (
    src
    .withColumn("estimation_request_no", bk)
    .withColumn("estimation_id", abs(xxhash64(col("estimation_request_no"))))
    .withColumn("opened_date", opened_date_col.cast("date"))
    .withColumn("closed_date", closed_date_col.cast("date"))
    .withColumn("is_closed", col("closed_date").isNotNull())
    .withColumn("closed_year", year(col("closed_date")))
    .withColumn("closed_week", weekofyear(col("closed_date")))
    .withColumn("closed_month", month(col("closed_date")))
    .withColumn("estimated_hours", col("Estimated_Hours").cast("double"))
)

df.write.mode("overwrite").saveAsTable("lh_sas_silver.fact_estimation")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Silver – Estimation Delivery (OTIF)


from pyspark.sql.functions import col, when, abs, xxhash64, coalesce

src = spark.table("bronze_lakehouse.`Estimating Request`")

bk = coalesce(
    col("Estimate Request No."),
    col("Name"),
    col("Id")
).alias("estimation_request_no")

df = (
    src
    .withColumn("estimation_request_no", bk)
    .withColumn("estimation_id", abs(xxhash64(col("estimation_request_no"))))
    .withColumn("due_date", col("Complete By Date").cast("date"))
    .withColumn("completed_date", col("Date/Time Closed").cast("date"))
    .withColumn(
        "on_time_flag",
        when(col("completed_date") <= col("due_date"), 1).otherwise(0)
    )
)

df.write.mode("overwrite").saveAsTable("lh_sas_silver.fact_estimation_delivery")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Silver – KPI Staging (utilise existing kpi tables)

kpi_est_volume = (
    fact_estimation
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(count("*").alias("kpi_value"))
    .withColumn("kpi_name", lit("Quotes Issued"))
    .withColumn("organisational_unit", lit("Estimating"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Delivery (On Time %) 

kpi_est_otif = (
    fact_estimation
    .join(fact_estimation_delivery, "estimation_id")
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(avg(col("on_time_flag").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("Quotes Issued On Time"))
    .withColumn("organisational_unit", lit("Estimating"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Quality (Estimated Hours)

kpi_est_hours = (
    fact_estimation
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(sum("estimated_hours").alias("kpi_value"))
    .withColumn("kpi_name", lit("Estimated Hours"))
    .withColumn("organisational_unit", lit("Estimating"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Cost (£ per sqm)

order_lines = spark.table("bronze_lakehouse.EstimateOrderLine")

kpi_est_cost = (
    order_lines
    .filter(col("Item_SQM") >= 0.03)
    .groupBy("closed_year", "closed_week")
    .agg(
        (sum("Net_Total") / sum("Line_SQM")).alias("kpi_value")
    )
    .withColumn("kpi_name", lit("Rate per sqm"))
    .withColumn("organisational_unit", lit("Estimating"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



kpi_result_silver = (
    kpi_result_existing   # silver kpi enrichment
    .unionByName(kpi_est_volume)
    .unionByName(kpi_est_otif)
    .unionByName(kpi_est_hours)
    .unionByName(kpi_est_cost)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
