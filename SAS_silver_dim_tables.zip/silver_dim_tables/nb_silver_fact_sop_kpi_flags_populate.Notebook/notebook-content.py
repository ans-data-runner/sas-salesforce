# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from pyspark.sql.functions import col, when

fact_order = spark.table("fact_order_tracking")

df = (
    fact_order

    # KPI FLAGS (these drive everything)
    .withColumn(
        "cleansing_on_time_flag",
        when(col("days_in_cleansing") <= 2, 1).otherwise(0)
    )

    .withColumn(
        "signoff_on_time_flag",
        when(col("days_in_signoff") <= 5, 1).otherwise(0)
    )

    .withColumn(
        "engineering_on_time_flag",
        when(col("days_in_engineering") <= 5, 1).otherwise(0)
    )

    .withColumn(
        "scheduling_on_time_flag",
        when(col("days_in_scheduling") <= 3, 1).otherwise(0)
    )
)

df.write.mode("overwrite").saveAsTable("fact_order_tracking_kpi_flags")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#SOP Volume KPI
from pyspark.sql.functions import col, count, lit

fact = spark.table("fact_order_tracking")

kpi_sop_volume = (
    fact
    .groupBy("created_year", "created_week")
    .agg(count("*").alias("kpi_value"))
    .withColumn("kpi_name", lit("Orders Processed"))
    .withColumn("organisational_unit", lit("SOP"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Cleansing KPI
from pyspark.sql.functions import avg

fact_flags = spark.table("fact_order_tracking_kpi_flags")

kpi_sop_cleansing = (
    fact_flags
    .groupBy("created_year", "created_week")
    .agg(avg(col("cleansing_on_time_flag").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("Cleansing OTIF"))
    .withColumn("organisational_unit", lit("SOP"))
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Sign Off KPI
kpi_sop_signoff = (
    fact_flags
    .groupBy("created_year", "created_week")
    .agg(avg(col("signoff_on_time_flag").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("Sign Off OTIF"))
    .withColumn("organisational_unit", lit("SOP"))
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Engineering KPI
kpi_sop_engineering = (
    fact_flags
    .groupBy("created_year", "created_week")
    .agg(avg(col("engineering_on_time_flag").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("Engineering OTIF"))
    .withColumn("organisational_unit", lit("SOP"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Scheduling KPI
kpi_sop_scheduling = (
    fact_flags
    .groupBy("created_year", "created_week")
    .agg(avg(col("scheduling_on_time_flag").cast("double")).alias("kpi_value"))
    .withColumn("kpi_name", lit("Scheduling OTIF"))
    .withColumn("organisational_unit", lit("SOP"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#union logic for including with ilver enriched kpi data

kpi_result_silver = (
    kpi_result_existing
    .unionByName(kpi_sop_volume)
    .unionByName(kpi_sop_cleansing)
    .unionByName(kpi_sop_signoff)
    .unionByName(kpi_sop_engineering)
    .unionByName(kpi_sop_scheduling)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
