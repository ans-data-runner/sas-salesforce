# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "6950bf8e-2162-41a8-af31-7263ad5c1551"
# META         },
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ---- Parameters ----
SOURCE_LH   = "bronze_lakehouse"
SOURCE_TBL  = "Record Type"          # keep the space here

# For Spark SQL / spark.table we must escape the table name with backticks,
# BUT those backticks must live INSIDE a Python string.
SOURCE_FULL = f"{SOURCE_LH}.`{SOURCE_TBL}`"   # -> bronze_lakehouse.`Record Type`

TARGET_FULL = "dbo.dim_record_type"

print("SOURCE:", SOURCE_FULL)
print("TARGET:", TARGET_FULL)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_raw = spark.table(SOURCE_FULL)
df_raw.printSchema()
print("Source row count:", df_raw.count())

src_cols = set([c.lower() for c in df_raw.columns])
print("Source columns (lowercase):", sorted(list(src_cols))[:50])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F


def pick(col_candidates, alias):
    """
    Returns a Column expression for the first matching column name (case-insensitive),
    else returns a NULL literal with the target alias.
    """
    for c in col_candidates:
        if c.lower() in src_cols:
            return F.col(next(actual for actual in df_raw.columns if actual.lower() == c.lower())).alias(alias)
    return F.lit(None).cast("string").alias(alias)

df_src = (
    df_raw.select(
        pick(["Id", "id", "recordtypeid"], "record_type_id"),
        pick(["Name", "name"], "record_type_name"),
        pick(["DeveloperName", "developername", "developer_name"], "developer_name"),
        pick(["SobjectType", "sobjecttype", "s_object_type"], "sobject_type"),
        # IsActive might be boolean or string, so cast safely later
        pick(["IsActive", "isactive", "is_active"], "is_active"),
        pick(["Description", "description"], "description")
    )
)

# Cast is_active safely
df_src = df_src.withColumn(
    "is_active",
    F.when(F.col("is_active").cast("string").isin("true", "True", "1"), F.lit(True))
     .when(F.col("is_active").cast("string").isin("false", "False", "0"), F.lit(False))
     .otherwise(F.col("is_active").cast("boolean"))
)
#).drop("is_active")

# Deterministic surrogate key (stable across reruns)
df_src = df_src.withColumn("record_type_key", F.xxhash64(F.coalesce(F.col("record_type_id"), F.lit(""))))

# Audit columns
df_src = df_src.withColumn("created_ts", F.current_timestamp()) \
               .withColumn("updated_ts", F.current_timestamp())

# De-dupe on natural key
df_src = df_src.dropDuplicates(["record_type_id"])

df_src.createOrReplaceTempView("src_dim_record_type")

print("Transformed row count (deduped):", df_src.count())
display(df_src.limit(20))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql(f"""
MERGE INTO {TARGET_FULL} AS tgt
USING src_dim_record_type AS src
ON tgt.record_type_id = src.record_type_id

WHEN MATCHED THEN UPDATE SET
  tgt.record_type_name = src.record_type_name,
  tgt.developer_name   = src.developer_name,
  tgt.sobject_type     = src.sobject_type,
  tgt.is_active        = src.is_active,
  tgt.description      = src.description,
  tgt.updated_ts       = current_timestamp()

WHEN NOT MATCHED THEN INSERT (
  record_type_key, record_type_id, record_type_name,
  developer_name, sobject_type, is_active, description,
  created_ts, updated_ts
)
VALUES (
  src.record_type_key, src.record_type_id, src.record_type_name,
  src.developer_name, src.sobject_type, src.is_active, src.description,
  src.created_ts, src.updated_ts
)
""")

print("MERGE complete:", TARGET_FULL)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_tgt = spark.table(TARGET_FULL)

print("Target row count:", df_tgt.count())
dupes = df_tgt.groupBy("record_type_id").count().where("count > 1").count()
print("Duplicate record_type_id rows:", dupes)

display(df_tgt.orderBy("record_type_name").limit(50))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
