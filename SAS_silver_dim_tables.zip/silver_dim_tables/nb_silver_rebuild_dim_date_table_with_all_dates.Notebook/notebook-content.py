# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# ---------
# Derive a safe date range from your actual data
# ---------
fact_proposal = spark.table("dbo.fact_proposal")

min_dt = fact_proposal.select(F.min(F.col("closed_date")).alias("min_dt")).collect()[0]["min_dt"]
max_dt = fact_proposal.select(F.max(F.col("closed_date")).alias("max_dt")).collect()[0]["max_dt"]

# Fallbacks (in case closed_date is sparse)
start_date = F.to_date(F.lit(min_dt if min_dt else "2023-01-01"))
end_date   = F.to_date(F.lit(max_dt if max_dt else "2026-12-31"))

# Extend end date forward a bit so you don't need to rebuild immediately
end_date_plus = F.date_add(end_date, 365)

# materialise scalar dates
start_date_val = spark.sql(f"SELECT {start_date._jc.toString()} AS d").collect()[0]["d"]
end_date_val   = spark.sql(f"SELECT {end_date_plus._jc.toString()} AS d").collect()[0]["d"]

print("Rebuilding dim_date from:", start_date_val, "to:", end_date_val)

# ---------
# Build a row per calendar date
# ---------
days = (spark
        .range(0, 100000)  # big enough then filtered
        .select(F.date_add(F.lit(start_date_val), F.col("id").cast("int")).alias("calendar_date"))
        .filter(F.col("calendar_date") <= F.lit(end_date_val))
       )

# Week logic:
# - week_start_date = Saturday? Monday? depends on your "customer week" convention.
# Your KPI logic is anchored to "Week ending (Fri)" so:
#   week_ending_date (Fri) = next Friday on/after calendar_date if you want rollups by week,
# but in a date dimension we simply mark week boundaries.
#
# We'll define:
# - day_of_week: Monday=1 ... Sunday=7 (Spark: dayofweek gives Sunday=1)
# - week_start_date = Saturday (to make week_end_date Friday) OR
# - week_start_date = Monday (ISO style) and week_end_date Sunday
#
# Since you want "week ending Friday", easiest is week_end_date = Friday and week_start_date = Saturday.

dim_date = (
    days
    .withColumn("date_key", F.date_format("calendar_date", "yyyyMMdd").cast("int"))
    .withColumn("day_name", F.date_format("calendar_date", "EEEE"))
    .withColumn("dayofweek_sun1", F.dayofweek("calendar_date"))  # Sun=1..Sat=7
    # Convert to Mon=1..Sun=7 for convenience
    .withColumn("day_of_week", F.when(F.col("dayofweek_sun1")==1, 7).otherwise(F.col("dayofweek_sun1")-1))
    .withColumn("is_weekday", F.when(F.col("day_of_week").between(1,5), F.lit(True)).otherwise(F.lit(False)))

    # Week ending Friday:
    # Find the Friday of the "week" containing calendar_date (where Fri is week end)
    .withColumn(
        "week_end_date",
        F.next_day(F.date_sub(F.col("calendar_date"), 1), "Friday")  # Friday on/after (calendar_date - 1)
    )
    .withColumn("week_start_date", F.date_add(F.col("week_end_date"), -6))

    # "customer year/week" derived from the week_end_date (so each week is labelled by its Friday)
    .withColumn("customer_year", F.year("week_end_date").cast("int"))
    .withColumn("customer_week_no", F.weekofyear("week_end_date").cast("int"))

    # optional period/quarter fields (keep if you use them)
    .withColumn("customer_period", F.month("week_end_date").cast("int"))
    .withColumn("calendar_quarter", F.quarter("calendar_date").cast("int"))
    .withColumn("calendar_quarter_name", F.concat(F.lit("Q"), F.col("calendar_quarter").cast("string")))

    # A stable week key
    .withColumn("week_key", (F.col("customer_year")*100 + F.col("customer_week_no")).cast("int"))

    # audit
    .withColumn("created_ts", F.current_timestamp())
    .withColumn("updated_ts", F.current_timestamp())

    .select(
        "date_key","calendar_date","day_of_week","day_name","is_weekday",
        "customer_week_no","customer_year","customer_period",
        "calendar_quarter","calendar_quarter_name",
        "week_start_date","week_end_date","week_key",
        "created_ts","updated_ts"
    )
)

# Write it
(dim_date.write
    .mode("overwrite")
    .format("delta")
    .saveAsTable("dbo.dim_date")
)

print("✅ dbo.dim_date rebuilt:", dim_date.count(), "rows")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
