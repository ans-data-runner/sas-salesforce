# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "456faf38-5358-45b2-bb3c-a845530e9c71",
# META       "default_lakehouse_name": "lh_sas_silver",
# META       "default_lakehouse_workspace_id": "1598ca6e-dca0-4c34-be8c-929255830e06",
# META       "known_lakehouses": [
# META         {
# META           "id": "456faf38-5358-45b2-bb3c-a845530e9c71"
# META         },
# META         {
# META           "id": "6950bf8e-2162-41a8-af31-7263ad5c1551"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, TimestampType
from pyspark.sql.functions import current_timestamp, col

schema = StructType([
    StructField("year", IntegerType(), False),
    StructField("week_number", IntegerType(), False),
    StructField("rejected_designs_count", IntegerType(), False),
    StructField("source", StringType(), False)
])

data = [
    (2026, 15, 2, "manual"),
    (2026, 16, 1, "manual")
]

df_quality = (
    spark.createDataFrame(data, schema=schema)
    .withColumn("created_utc", current_timestamp())
)

# Ensure exact types for early UAT phase population and testing
df_quality = (
    df_quality
    .withColumn("year", col("year").cast("int"))
    .withColumn("week_number", col("week_number").cast("int"))
    .withColumn("rejected_designs_count", col("rejected_designs_count").cast("int"))
)

df_quality.write.mode("append").saveAsTable("fact_quality_weekly")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
SELECT *
FROM fact_quality_weekly
ORDER BY year DESC, week_number DESC
""").show(truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
SELECT
  year,
  week_number,
  SUM(rejected_designs_count) AS total_rejected_designs
FROM fact_quality_weekly
GROUP BY year, week_number
ORDER BY year DESC, week_number DESC
""").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
SELECT
  Rejected_Drawings__c,
  COUNT(*) AS cnt
FROM `bronze_lakehouse`.`Proposal Request`
GROUP BY Rejected_Drawings__c
ORDER BY Rejected_Drawings__c
""").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, sum as _sum, lit, current_timestamp

df_q = (
    spark.table("fact_proposal")
    .filter(col("closed_date").isNotNull())
    .groupBy("closed_year", "closed_week")
    .agg(_sum("rejected_drawings_count").alias("rejected_designs_count"))
    .withColumnRenamed("closed_year", "year")
    .withColumnRenamed("closed_week", "week_number")
    .withColumn("source", lit("proposal_request"))
    .withColumn("created_utc", current_timestamp())
    .withColumn("rejected_designs_count", col("rejected_designs_count").cast("long"))  # enforce
)

(df_q.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable("fact_quality_weekly")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
