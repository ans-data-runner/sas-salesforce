# SAS Fabric KPI rebuild — Design & Estimating

This focused package replaces/amends the current Proposal, Proposal Delivery,
Estimation, KPI staging and Gold-load notebook logic for the two supplied reports.
It intentionally does **not** create a Gold staging schema, staging table or Lakehouse
shortcut.

## Architecture

```text
bronze_lakehouse (later lh_sas_bronze)
  dbo.Proposal Request
  dbo.Estimating Request
  dbo.Quote
  dbo.Quote Line
          |
          v
lh_sas_silver (schema-enabled; attach as notebook default)
  salesforce.fact_design_proposal
  salesforce.fact_estimating_request
  salesforce.fact_estimating_quote_line
  kpi.dim_department
  kpi.dim_kpi
  kpi.fact_kpi_target
  kpi.fact_kpi_manual_actual
  kpi.fact_kpi_commentary
  kpi.fact_kpi_actual_weekly
  kpi.fact_kpi_result_curated       <-- single Silver-to-Gold contract
          |
          | direct three-part SQL read
          v
wh_sas_gold
  reporting.fact_kpi_result
  reporting.vw_kpi_report
  etl.usp_load_kpi_result
```

## Notebook run order

1. Attach `lh_sas_silver` as the default Lakehouse.
2. Run `00_setup_silver_kpi_model.ipynb` once, then when metadata changes.
3. Populate `kpi.ref_exchange_rate_monthly` for any non-GBP Design proposals.
4. Run `10_build_design_kpis.ipynb`.
5. Run `11_build_estimating_kpis.ipynb`.
6. Run `20_build_kpi_result_curated.ipynb`.
7. Upload `reference/week42_expected_results.csv` to
   `lh_sas_silver/Files/kpi_framework/week42_expected_results.csv` and run
   `90_validate_week42_outputs.ipynb`.
8. In `wh_sas_gold`, run the SQL scripts in numeric order.
9. Execute `EXEC etl.usp_load_kpi_result @reporting_year = 2025;`.
10. Point Power BI at `reporting.vw_kpi_report` or the fact table.

## Parameter changes after Bronze migration

Each notebook has a Fabric `parameters` cell. Change only:

```python
p_bronze_lakehouse = "lh_sas_bronze"
p_bronze_schema = "dbo"
```

No calculation code needs to change.

## Gold output fields

The Gold fact includes Owner, Status, Completed up to week, Current Week,
Submission, Department, Category, KPI, Measure, UOM, Sign, Commentary, Week,
Friday week-ending date, Target, Actual, Variance, performance variance, variance
percentage, RAG, data status, source lineage and load audit fields.

## Important workbook decisions implemented

- Estimating workbook cell `C6` says `HR Monthly`, but this package uses
  `Estimating`; the workbook label is treated as a copy/paste error.
- Customer weeks come from `dbo.dim_date`, not Spark `weekofyear`.
- Design OTIF uses `Estimated_Completion_Date__c` and outputs 0–100 percentages.
- Missing Design due dates are treated as on time by default because that reproduces
  the supplied raw workbook; the rule is parameterised.
- Design cost is the average `Estimated_Value__c` of closed proposals after GBP
  conversion. Unknown non-GBP currencies are flagged and excluded, never defaulted
  to an exchange rate of 1.
- Design Rejections remains a controlled manual actual because the workbook says it
  is not in a system. The supplied history is seeded separately.
- Estimating Hours is the average of positive `Hours_Taken_to_Close__c`, not the sum.
- Estimating £/SQM uses Quote Line -> Quote -> Estimating Request and calculates the
  arithmetic average of eligible line rates, matching the workbook. It does not use
  the old/non-existent `EstimateOrderLine` columns.
- `OVER` amber is `actual <= target / 0.95`, which is the Excel formula; a zero target
  has no amber band.

## Assumptions to verify in the tenant

- `dbo.dim_date` has the existing customer calendar columns used by the supplied
  notebooks.
- `Quote.Estimating_Request__c` is the principal relationship to
  `Estimating Request.Id`; request-number fallback is included.
- Quote Line `Sqm_Rate__c` is the GBP rate used by the Salesforce report. The code
  derives `SBQQ__NetTotal__c / Line_SQM__c` only when that field is null and flags it.
- The Design report includes all closed Proposal Request records. Add a Record Type
  filter only if the live report proves that one is required.
- The Lakehouse and Warehouse are in the same Fabric workspace for direct
  three-part-name Warehouse loading.

The notebooks have been JSON-validated and all ordinary Python cells syntax-compiled.
They have not been executed against the customer's Fabric tenant.