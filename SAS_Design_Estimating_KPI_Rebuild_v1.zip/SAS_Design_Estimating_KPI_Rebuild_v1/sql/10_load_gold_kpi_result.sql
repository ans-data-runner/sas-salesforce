/*
Loads Gold directly from the Silver Lakehouse SQL analytics endpoint by three-part name.
Assumption: lh_sas_silver and wh_sas_gold are in the same Fabric workspace.
*/
CREATE OR ALTER PROCEDURE etl.usp_load_kpi_result
    @reporting_year int = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT kpi_result_key
        FROM [lh_sas_silver].[kpi].[fact_kpi_result_curated]
        WHERE @reporting_year IS NULL OR reporting_year = @reporting_year
        GROUP BY kpi_result_key
        HAVING COUNT(*) > 1
    )
        THROW 50001, 'Duplicate kpi_result_key values exist in Silver.', 1;

    MERGE reporting.fact_kpi_result AS target
    USING
    (
        SELECT
            kpi_result_key, reporting_year, week_number, week_key,
            week_start_date, week_end_date, week_state, owner_name,
            department_code, department_name, department_status,
            completed_up_to_week, current_week, submission_frequency,
            category, kpi_code, kpi_name, measure, uom, sign_label,
            breach_direction, commentary, target_value, actual_value,
            variance_value, performance_variance_value, variance_pct,
            rag_status, data_status, source_system, source_object,
            source_row_count, source_quality_flag, load_batch_id,
            calculation_timestamp
        FROM [lh_sas_silver].[kpi].[fact_kpi_result_curated]
        WHERE @reporting_year IS NULL OR reporting_year = @reporting_year
    ) AS source
    ON target.kpi_result_key = source.kpi_result_key

    WHEN MATCHED THEN UPDATE SET
        target.reporting_year = source.reporting_year,
        target.week_number = source.week_number,
        target.week_key = source.week_key,
        target.week_start_date = source.week_start_date,
        target.week_end_date = source.week_end_date,
        target.week_state = source.week_state,
        target.owner_name = source.owner_name,
        target.department_code = source.department_code,
        target.department_name = source.department_name,
        target.department_status = source.department_status,
        target.completed_up_to_week = source.completed_up_to_week,
        target.current_week = source.current_week,
        target.submission_frequency = source.submission_frequency,
        target.category = source.category,
        target.kpi_code = source.kpi_code,
        target.kpi_name = source.kpi_name,
        target.measure = source.measure,
        target.uom = source.uom,
        target.sign_label = source.sign_label,
        target.breach_direction = source.breach_direction,
        target.commentary = source.commentary,
        target.target_value = source.target_value,
        target.actual_value = source.actual_value,
        target.variance_value = source.variance_value,
        target.performance_variance_value = source.performance_variance_value,
        target.variance_pct = source.variance_pct,
        target.rag_status = source.rag_status,
        target.data_status = source.data_status,
        target.source_system = source.source_system,
        target.source_object = source.source_object,
        target.source_row_count = source.source_row_count,
        target.source_quality_flag = source.source_quality_flag,
        target.load_batch_id = source.load_batch_id,
        target.calculation_timestamp = source.calculation_timestamp,
        target.warehouse_loaded_timestamp = SYSUTCDATETIME()

    WHEN NOT MATCHED BY TARGET THEN INSERT
    (
        kpi_result_key, reporting_year, week_number, week_key,
        week_start_date, week_end_date, week_state, owner_name,
        department_code, department_name, department_status,
        completed_up_to_week, current_week, submission_frequency,
        category, kpi_code, kpi_name, measure, uom, sign_label,
        breach_direction, commentary, target_value, actual_value,
        variance_value, performance_variance_value, variance_pct,
        rag_status, data_status, source_system, source_object,
        source_row_count, source_quality_flag, load_batch_id,
        calculation_timestamp, warehouse_loaded_timestamp
    )
    VALUES
    (
        source.kpi_result_key, source.reporting_year, source.week_number, source.week_key,
        source.week_start_date, source.week_end_date, source.week_state, source.owner_name,
        source.department_code, source.department_name, source.department_status,
        source.completed_up_to_week, source.current_week, source.submission_frequency,
        source.category, source.kpi_code, source.kpi_name, source.measure, source.uom,
        source.sign_label, source.breach_direction, source.commentary,
        source.target_value, source.actual_value, source.variance_value,
        source.performance_variance_value, source.variance_pct, source.rag_status,
        source.data_status, source.source_system, source.source_object,
        source.source_row_count, source.source_quality_flag, source.load_batch_id,
        source.calculation_timestamp, SYSUTCDATETIME()
    );
END;
GO

-- Example:
-- EXEC etl.usp_load_kpi_result @reporting_year = 2025;