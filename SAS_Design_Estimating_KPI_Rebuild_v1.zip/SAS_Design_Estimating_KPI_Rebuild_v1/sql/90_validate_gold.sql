-- Gold quality checks.
SELECT kpi_result_key, COUNT(*) AS duplicate_count
FROM reporting.fact_kpi_result
GROUP BY kpi_result_key
HAVING COUNT(*) > 1;

SELECT *
FROM reporting.fact_kpi_result
WHERE owner_name IS NULL
   OR department_name IS NULL
   OR category IS NULL
   OR kpi_name IS NULL
   OR measure IS NULL
   OR uom IS NULL
   OR sign_label IS NULL;

SELECT *
FROM reporting.fact_kpi_result
WHERE uom = 'Percentage'
  AND actual_value IS NOT NULL
  AND (actual_value < 0 OR actual_value > 100);

SELECT *
FROM reporting.vw_kpi_report
WHERE reporting_year = 2025
  AND (
       ([Department] = 'Design & R&D' AND [Week] BETWEEN 36 AND 42)
    OR ([Department] = 'Estimating' AND [Week] BETWEEN 32 AND 42)
  )
ORDER BY [Department], [Category], [Week];