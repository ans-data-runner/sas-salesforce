CREATE OR ALTER VIEW reporting.vw_kpi_report
AS
SELECT
    kpi_result_key,
    owner_name AS [Owner],
    department_status AS [Status],
    completed_up_to_week AS [Completed up to week],
    current_week AS [Current Week],
    submission_frequency AS [Submission],
    department_name AS [Department],
    category AS [Category],
    kpi_name AS [KPI],
    measure AS [Measure],
    uom AS [UOM],
    sign_label AS [Sign],
    commentary AS [Commentary],
    reporting_year,
    week_number AS [Week],
    week_end_date AS [Date (Fri)],
    week_state,
    target_value AS [Target],
    actual_value AS [Actual],
    variance_value AS [Variance],
    performance_variance_value,
    variance_pct,
    rag_status AS [RAG],
    data_status,
    source_system,
    source_object,
    source_row_count,
    source_quality_flag,
    load_batch_id,
    calculation_timestamp,
    warehouse_loaded_timestamp
FROM reporting.fact_kpi_result;
GO

-- Optional compatibility view. Rename only after checking that it does not collide
-- with the existing salesforce.fact_kpi_result_v2 table.
CREATE OR ALTER VIEW reporting.vw_fact_kpi_result_v2_compat
AS
SELECT
    reporting_year AS calendar_year,
    week_number,
    kpi_name,
    category AS kpi_category,
    department_name AS organisational_unit,
    actual_value AS kpi_value,
    target_value,
    breach_direction,
    rag_status,
    calculation_timestamp
FROM reporting.fact_kpi_result;
GO