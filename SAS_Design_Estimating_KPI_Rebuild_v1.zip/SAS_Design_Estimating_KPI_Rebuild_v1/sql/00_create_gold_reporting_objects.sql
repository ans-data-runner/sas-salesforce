/*
Focused Design + Estimating KPI reporting model.
Run in wh_sas_gold. There is deliberately no staging schema or staging table.
*/

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'reporting')
    EXEC('CREATE SCHEMA reporting');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'etl')
    EXEC('CREATE SCHEMA etl');
GO

IF OBJECT_ID('reporting.fact_kpi_result', 'U') IS NULL
BEGIN
    CREATE TABLE reporting.fact_kpi_result
    (
        kpi_result_key             varchar(200) NOT NULL,
        reporting_year             int NULL,
        week_number                int NULL,
        week_key                   int NULL,
        week_start_date            date NULL,
        week_end_date              date NULL,
        week_state                 varchar(20) NULL,
        owner_name                 varchar(200) NULL,
        department_code            varchar(50) NULL,
        department_name            varchar(200) NULL,
        department_status          varchar(30) NULL,
        completed_up_to_week       int NULL,
        current_week               int NULL,
        submission_frequency       varchar(30) NULL,
        category                   varchar(100) NULL,
        kpi_code                   varchar(100) NULL,
        kpi_name                   varchar(300) NULL,
        measure                    varchar(1000) NULL,
        uom                        varchar(100) NULL,
        sign_label                 varchar(100) NULL,
        breach_direction           varchar(20) NULL,
        commentary                 varchar(4000) NULL,
        target_value               decimal(28,6) NULL,
        actual_value               decimal(28,6) NULL,
        variance_value             decimal(28,6) NULL,
        performance_variance_value decimal(28,6) NULL,
        variance_pct               decimal(28,10) NULL,
        rag_status                 varchar(30) NULL,
        data_status                varchar(30) NULL,
        source_system              varchar(100) NULL,
        source_object              varchar(500) NULL,
        source_row_count           bigint NULL,
        source_quality_flag        varchar(500) NULL,
        load_batch_id              varchar(100) NULL,
        calculation_timestamp      datetime2(6) NULL,
        warehouse_loaded_timestamp datetime2(6) NULL
    );
END;
GO