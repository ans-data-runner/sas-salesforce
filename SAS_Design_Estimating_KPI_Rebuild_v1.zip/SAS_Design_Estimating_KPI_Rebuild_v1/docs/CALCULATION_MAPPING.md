# Calculation mapping

## Design & R&D

| KPI | Bronze source | Calculation |
|---|---|---|
| Volume Completed | `Proposal Request` | Distinct closed Proposal Request count by customer week |
| OTIF | `Proposal Request` | `100 * AVG(on_time_flag)`, using `Closed_Date__c <= Estimated_Completion_Date__c`; missing due defaults to on time to reproduce workbook |
| Design Rejections | Silver manual input | Weekly value and explicit `OD` / `No Data` statuses from controlled input |
| Opportunity Value per proposal | `Proposal Request` + monthly FX | Average closed `Estimated_Value__c * rate_to_gbp` |

## Estimating

| KPI | Bronze source | Calculation |
|---|---|---|
| Quotes Issues | `Estimating Request` | Distinct closed request count by customer week |
| Quotes Issues on Time | `Estimating Request` | `100 * AVG(Date_Time_Closed__c <= Complete_By_Date__c)` |
| Estimated Hours | `Estimating Request` | Average `Hours_Taken_to_Close__c` where value is greater than zero |
| Rate of Sales per square meter | `Quote Line` -> `Quote` -> `Estimating Request` | Arithmetic average `Sqm_Rate__c` where `Item_SQM__c >= 0.03`; fallback is `SBQQ__NetTotal__c / Line_SQM__c` |

## RAG

Higher-is-better (`UNDER` breach):

- Green: actual >= target
- Amber: actual >= target * 0.95
- Red: otherwise

Lower-is-better (`OVER` breach):

- Green: actual <= target
- Amber: target > 0 and actual <= target / 0.95
- Red: otherwise

Explicit workbook statuses such as `OD`, `No Data`, `Blank`, `Missed` and `TBC`
are preserved instead of being converted to numeric zero.