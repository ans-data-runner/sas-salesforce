# Current-to-replacement notebook map

| Current notebook | Focused replacement | Main correction |
|---|---|---|
| `nb_silver_fact_proposal_table_populate.ipynb` | `10_build_design_kpis.ipynb` | Customer calendar, governed FX and report metadata |
| `nb_silver_fact_proposal_delivery_table_population.ipynb` | `10_build_design_kpis.ipynb` | Uses `Estimated_Completion_Date__c`; workbook missing-date rule |
| `nb_silver_fact_estimation_table_populate.ipynb` | `11_build_estimating_kpis.ipynb` | Actual Salesforce columns; average hours; Quote Line £/SQM |
| `nb_silver_fact_kpi_result_staging_table_populate.ipynb` | `20_build_kpi_result_curated.ipynb` | Renamed/reframed as final Silver load contract; no Gold staging |
| `nb_gold_fact_kpi_result_*` | Gold SQL scripts | Thin direct Silver-to-Gold MERGE and reporting view |

Do not run the old staging notebook in the new pipeline. Keep it only until the new
Week 42 validation has passed and the Power BI semantic model has been repointed.