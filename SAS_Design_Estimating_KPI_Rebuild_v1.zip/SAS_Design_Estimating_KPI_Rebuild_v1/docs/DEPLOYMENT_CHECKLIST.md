# Deployment checklist

## Silver

- [ ] Confirm `lh_sas_silver` is schema-enabled.
- [ ] Attach `lh_sas_silver` as default Lakehouse to all four build notebooks.
- [ ] Confirm `dbo.dim_date` includes every relevant source date and the customer week fields.
- [ ] Run notebook 00 and inspect the KPI metadata seed.
- [ ] Load non-GBP monthly rates into `kpi.ref_exchange_rate_monthly`.
- [ ] Run Design and Estimating notebooks.
- [ ] Inspect missing customer weeks, due dates, FX rates and derived SQM rate flags.
- [ ] Run notebook 20 and confirm one row per Department + KPI + Week.
- [ ] Upload the expected-results CSV and run notebook 90.

## Gold

- [ ] Confirm `lh_sas_silver` and `wh_sas_gold` are in the same workspace.
- [ ] Run `00_create_gold_reporting_objects.sql`.
- [ ] Run `10_load_gold_kpi_result.sql`.
- [ ] Run `20_create_reporting_views.sql`.
- [ ] Execute the load procedure for 2025.
- [ ] Run `90_validate_gold.sql`.
- [ ] Confirm there is no dependency on `staging.*` or a Lakehouse shortcut.

## Power BI

- [ ] Repoint the template to `reporting.vw_kpi_report`.
- [ ] Use Category/KPI/Measure/UOM/Sign/Commentary from the fact/view.
- [ ] Use Week and Date (Fri) from the row grain.
- [ ] Use Target, Actual and RAG for the three-row matrix pattern.
- [ ] Validate Design weeks 36–42 and Estimating weeks 32–42 against the supplied screenshots.