# SOP KPI Report — Source-to-Gold Mapping
**New KPIs: Complaints | Lines Released | £/FTE**
Bronze source: SAS Bronze Lakehouse v1 (Salesforce export, 29-07-2026)
Target: Gold `fpi_result` table

---

## 0. Recap — pattern already built (Cleansing & Sign-Off OTIF)

Your existing OTIF logic is the template the new KPIs should follow:

| Element | Cleansing OTIF | Sign-Off OTIF |
|---|---|---|
| Source table | `dbo.[Order Tracking]` | `dbo.[Order Tracking]` |
| Days field | `Days_In_Cleansing__c` | `Days_In_Customer_Sign_Off__c` |
| Target | ≤ 1 day (95%) | ≤ 5 days (95%) |
| On-time flag | `1` if Days ≤ target else `0` | same pattern |
| Week driver | `Order Tracking: Created Date` → week no | same |
| Aggregation | `SUM(On_Time) / COUNT(*)` per week | same |

The three new KPIs below reuse this **grain (weekly), this week-lookup approach, and this target/actual/variance shape** so they slot into the same `fpi_result` structure.

**Week lookup:** all new KPIs should join to `dbo.dim_date_reference` on `calendar_date = CAST(<date field> AS DATE)` to get `customer_week_no` — this matches the `Wk no's` tab logic in the source workbook (ISO-ish week starting Saturday, per the `Wk no's` sheet pattern) and keeps every KPI on the same calendar.

---

## 1. Complaints (Category: Quality — "Count of Customer Complaints", Sign: Over Breach)

### Source
`dbo.[Customer Service]` (Salesforce `Case` object, bronze layer) — one row per complaint/case.

### Grain
1 row per `Id` (Case).

### Candidate field mapping

| Workbook column (`No of Complaints raised per week` tab) | Bronze field | Notes |
|---|---|---|
| Customer Service Number | `CaseNumber` | complaint reference |
| Company Name | `Company.Name` via `AccountId` → `dbo.Company` | needs join |
| Contact Name | `Contact.Name` via `ContactId` → `dbo.Contact` | needs join |
| Project Name | `Project_Name__c` | denormalised text, no FK |
| Fault Category | `Fault_Category__c` | complaint reason |
| Department | `Department__c` | **raw value — needs mapping, see below** |
| Date/Time Opened | `Open_Date__c` (fallback `CreatedDate`) | **confirm canonical field — see open question** |
| Sales Divison | `Sales_Divison__c` | *(sic — typo in source field name)* |
| week No | derived from date field via `dim_date_reference` | |

### Department mapping (dimension table needed)
The workbook's `Lookup List` tab maps raw `Department__c` values (e.g. `UK SOP`, `Export SOP`, `Product Design/Engineering`) to canonical codes (`01 SOP`, `01 Export SOP`, `02 Product Design`, etc). This mapping doesn't exist as a table in the bronze lakehouse — it's currently a manual Excel lookup. **Recommend building this as a small Silver/Gold dimension table** (`dim_department_lookup`: `raw_department`, `mapped_department`) seeded from the `Lookup List` tab, so the logic isn't hardcoded in a notebook.

### Draft logic
```sql
SELECT
    d.customer_week_no                         AS week_no,
    COUNT(cs.Id)                                AS complaint_count
FROM dbo.[Customer Service] cs
LEFT JOIN dim_department_lookup dl
       ON cs.Department__c = dl.raw_department
LEFT JOIN dbo.dim_date_reference d
       ON CAST(cs.Open_Date__c AS DATE) = d.calendar_date   -- see open question below
WHERE dl.mapped_department = '01 SOP'                        -- see open question below
GROUP BY d.customer_week_no
```

### Open questions (need your/business confirmation before building)
1. **Canonical date field** — `CreatedDate` vs `Open_Date__c` vs `Date_of_Complaint__c` all exist on the table. The source workbook's `Analysis` tab notes the current manual KPI and the Power BI report already disagree on ~15 weeks of history, which strongly suggests date-field or scope inconsistency upstream. Pick one and use it everywhere.
2. **Department scope** — the `Analysis` tab explicitly says the current SOP KPI counts **`01 SOP` only, not `01 Export SOP`**. Confirm whether Gold should replicate that scope or fix it to include Export SOP.
3. The `Analysis` tab also flags that Bridgend Manufacturing, Maybole Manufacturing, and Quality complaints can't currently be isolated from this table — worth checking whether those are captured via `Department__c` values not visible in the sample I reviewed, or come from an entirely different source not yet in the bronze layer.

---

## 2. Lines Released (Category: Productivity — "Number of Order Lines being completed each week")

### ⚠️ This one needs validation before build — the obvious source table has no date field

### Candidate source
`dbo.EstimateOrderLine` is the only table in the bronze layer with order-line-level grain and real transactional fields: `co_num__c` (order number), `co_line__c` (line number), `item__c`, `qty_ordered__c`, `qty_invoiced__c`, `promise_date__c`, `stat__c` (status). Despite the table name, these fields look like actual order-line data (likely synced from Infor/Syteline via the `co_num`/`co_line` keys) rather than pre-sales estimating data.

### The gap
**`EstimateOrderLine` has no `CreatedDate`, `LastModifiedDate`, or completion-date field at all.** The only date on the table is `promise_date__c`, which is a *target* ship date, not an actual completion date. That means:
- We can count order lines and bucket them by `promise_date__c` week, but that measures **when lines were due**, not when they were **completed/released** — it will not match "Lines Released" as a productivity measure.
- `qty_invoiced__c > 0` could be used as a completion proxy (line has been invoiced = presumably released), but there's still no date to say *which week* that happened.

### Recommended next steps (pick one)
1. **Check for a source-system date** not yet in the bronze layer — if `co_num__c`/`co_line__c` map back to an ERP (Infor/Syteline) order-line table with a genuine release/completion timestamp, that's the correct source and would need adding to Bronze.
2. **Use `stat__c` values** — if one of the status codes specifically means "released this week" (need the full list of `stat__c` values from the business), combine with whichever date is closest to release.
3. **Fall back to `dbo.[Order Tracking]`** at header level (it does have good date coverage — `Date_shipped_out_of_factory__c`, `Final_Dispatch_Date__c`) if a header-level proxy for "lines completed" is acceptable, e.g. `SUM(Order_SQM__c)` or count of orders dispatched, rather than true order-line count.

### Draft logic (once date field is confirmed)
```sql
SELECT
    d.customer_week_no      AS week_no,
    COUNT(*)                AS lines_released
FROM dbo.EstimateOrderLine eol
LEFT JOIN dbo.dim_date_reference d
       ON CAST(eol.<CONFIRMED_DATE_FIELD> AS DATE) = d.calendar_date
WHERE eol.stat__c IN (<CONFIRMED RELEASED/COMPLETE STATUS CODES>)
GROUP BY d.customer_week_no
```

**Do not build this one until the date-field question is resolved** — whatever we pick now will need reworking otherwise.

---

## 3. £/FTE (Category: Cost — "FTE as a ratio of Orders Released")

Measure = Value of orders completed ÷ number of FTEs, expressed in £.

### Numerator — fully mappable from Bronze
`dbo.[Order Tracking]` has order-level value fields: `Order_Value__c`, `PO_Value__c`, `Value__c`. Combined with a "released/dispatched" date (`Date_shipped_out_of_factory__c` or `Final_Dispatch_Date__c` — same field-choice question as Cleansing/Sign-Off, i.e. confirm whether £/FTE should use the *created* week like the OTIF KPIs, or the *dispatch* week, since those can differ):

```sql
SELECT
    d.customer_week_no          AS week_no,
    SUM(ot.Order_Value__c)      AS order_value_released
FROM dbo.[Order Tracking] ot
LEFT JOIN dbo.dim_date_reference d
       ON CAST(ot.Date_shipped_out_of_factory__c AS DATE) = d.calendar_date
GROUP BY d.customer_week_no
```

### ⚠️ Denominator — not present anywhere in the Bronze lakehouse
FTE / headcount is a **workforce/HR measure**, not CRM data, and there is no table in `dbo.*` (Salesforce-sourced) that holds team headcount by week. This is a genuine gap, not a mapping question:

- **No HR system extract exists in this bronze layer.** `dbo.User` has a `Timesheet_Rate__c` field but that's a Salesforce user record (sales licence holders), not SOP team headcount, and isn't reliable for this purpose.
- **Recommend:** either (a) source a weekly/period FTE count from wherever payroll/HR data lives (Workday, ADP, a manually maintained spreadsheet, etc.) and land it as a small Bronze/Silver table (e.g. `dbo.fte_headcount(department, week_no, fte_count)`), or (b) if headcount is genuinely static/manually entered by the team lead each week, treat it as a manually-maintained Gold input table rather than something derived from Salesforce.

**This KPI cannot be completed end-to-end from Salesforce data alone — flagging so it doesn't get built partially and then stall.**

---

## 4. Suggested Gold `fpi_result` shape

To match the report layout in the screenshot (Category / KPI / Measure / UOM / Sign / Target / Actual per week / Variance), a long/tall fact table works better than wide-by-week:

| Column | Type | Notes |
|---|---|---|
| `week_no` | int | FK to `dim_date_reference.customer_week_no` |
| `category` | varchar | Productivity / Delivery / Quality / Cost |
| `kpi_name` | varchar | Lines Released / OTIF - Order Cleansing / OTIF - Order Sign Off / Complaints / £/FTE |
| `measure` | varchar | long description, as in the screenshot |
| `uom` | varchar | Count / Percentage / Days Target / £'s |
| `sign` | varchar | Under Breach / Over Breach |
| `target` | decimal | null where no target (e.g. Complaints) |
| `actual` | decimal | |
| `variance_flag` | varchar | R / A / G — derive from target vs actual + `sign` |

This lets Power BI (or whatever renders the report) pivot `week_no` into columns exactly like the existing xlsx, while keeping the Gold table itself tidy and extensible for future KPIs.

---

## 5. Summary of decisions needed before build

1. Complaints: canonical date field (`CreatedDate` vs `Open_Date__c` vs `Date_of_Complaint__c`)
2. Complaints: department scope (`01 SOP` only, or `01 SOP` + `01 Export SOP`)
3. Lines Released: source of a genuine completion/release date — likely requires an ERP field not yet in Bronze
4. Lines Released: which `stat__c` values represent "released/complete"
5. £/FTE: date field for order value (created vs dispatched week)
6. £/FTE: source for weekly FTE headcount — this is an HR data gap, not a mapping question
