# SAS Generic KPI Reporting Build — v2 (validated against source files)

One generic `kpi` schema in `wh_sas_gold` serving every departmental Top 4 report. KPIs are rows, not tables: onboarding a department = dim inserts + one silver notebook. All 17 departments and ~70 KPIs from the master workbook are pre-seeded (4 active, 13 as an inactive backlog ready for the Syteline phase).

## What changed from v1 (now that the source files landed)

1. **Calendar is data-driven, not computed.** You already load `ref_calendar_customer` → silver `dim_date` (Sat–Fri weeks, wk 1 ends first Friday of Jan). `kpi.dim_week` now loads from it via `nb_005` + `sp_load_dim_week`, and `week_key` keeps your existing **yyyyMMdd-of-Friday** convention — joins to current facts without translation.
2. **Conversion factors corrected**: gas **0.20264**, electricity **0.20705** (docx + CSVs; the screenshot's 0.20/0.21 were display rounding). nb_010 prefers the file's own factor columns with `ref_emission_factor` as fallback. **Validated: the notebook reproduces the workbook's Intensity Total with 0 mismatches across all 48 populated site-weeks.**
3. **KPI codes are the customer's own** lookup drivers from the master workbook (`EHS-KPI P1`, `Design-KPI D1`…).
4. **Legend semantics fixed**: `TBC` = **missing submission** (proc back-fills TBC rows for due-but-absent weeks, honouring per-department arrears), `NULL` = no submission expected (Blank). Target-less weeks (Maybole) carry the actual with no RAG.
5. **New dim_kpi attributes** the master workbook needs: `display_mode` ('Act Result' | '% of target' → the view exposes a ready `display_value`), `frequency` (W/M — Engineering/Finance/HR are monthly), sign `'Above Zero'` (zero-target KPIs: no amber band), and `pct_of_target` in the fact (direction-aware, ≥1 always favourable — matches the master's ratio maths).
6. **Categories corrected** to Productivity / Delivery / Quality / Cost; EHS is 5 KPIs including Lost Working Days (P1, target 0).
7. **Time-varying targets seeded**: inspections 100 → 110 (wk2 2026), Bridgend ratio 1 → 0.1 (2026 re-base) in `kpi.kpi_target`.
8. **Migration script (06)** carries `[salesforce].[fact_kpi_result_v2]` Design history into `kpi.fact_kpi_result` (kpi_name → kpi_code map, RAG recomputed). Old table untouched; run in parallel until sign-off.

## Deploy order

**Gold (`wh_sas_gold`):** `01_ddl_kpi_model.sql` → `02_sp_load_dim_week.sql` → `03_sp_load_fact_kpi_result.sql` → `04_vw_kpi_report.sql` → `05_seed_kpi_reference.sql` → (after parallel-run sign-off) `06_migrate_fact_kpi_result_v2.sql`.

**Notebooks:** import the `.py` files as five notebooks (`nb_020_030` splits into two at the marked divider); replace each commented `%run` with a real `%run nb_000_env_config` cell; run `seed_emission_factors()` once.

**Pipeline `pl_kpi_weekly`:** `nb_005` → `EXEC kpi.sp_load_dim_week` → [`nb_010` ∥ `nb_020` ∥ `nb_030`] → `nb_100` → `nb_110` → `EXEC kpi.sp_load_fact_kpi_result`. Weekly, Monday morning (EHS reports 1 week in arrears — handled by `arrears_weeks`, don't schedule around it).

**Bronze migration:** change `BRONZE_LAKEHOUSE` in nb_000 (or override from the pipeline parameter) — all bronze access goes through the ABFS helpers.

## Power BI wiring

Matrix body → `kpi.vw_kpi_report` (rows by `sort_order`: category / kpi / measure / uom / sign / kpi_commentary; columns `week_label` ordered by `week_end_date`; values target / `display_value` / conditional format on `rag_status` — G green, A amber, R red, TBC pink, NULL blank grey). Header card → `kpi.vw_kpi_report_header` (Status, Submission, current week, completed-up-to-week). Detail pages (visual checks, lost working days) → the silver `slv_ehs_inspection` / `slv_ehs_accident` tables.

## Confirm before first run (all flagged in-code)

1. **SafetyCulture bronze source** — assumed table `SafetyCultureTest` (per bronze PDF); confirm it holds the audit export columns.
2. **Accident tracker bronze location** — assumed `Files/ehs/accidents/accident_tracker.csv`.
3. **Energy CSV drop path** — assumed `Files/ehs/energy/…`; `CALENDAR_YEAR` param says which year the file's Week No belongs to.
4. **nb_110 Estimating/SOP column names** — marked `--- CONFIRM ---` blocks against `fact_estimation` / `fact_sop_kpi_flags`; Design needs no changes (columns verified from your notebooks).
5. **SOP C1 FTE headcount source** — no source identified in the workbook; KPI stages once `FTE_HEADCOUNT` is supplied.
6. **Maybole target** — master wk42 commentary said "Target 2.75", 2026 sheet has none; seeded target-less (add one row to `kpi.kpi_target` when agreed).
7. **Monthly KPIs** (Engineering/Finance/HR) — modelled (`frequency='M'`, `month_no` on dim_week) but the TBC back-fill currently covers weekly KPIs only; extend when those departments onboard.
