/*
SAS PRODUCT DESIGN - SAFE V3
============================

Purpose
-------
Deploy only the Product Design structures and downstream KPI procedures that are
safe based on currently confirmed information.

Removed from V3
---------------
- No reference to an assumed [Product_Design__c] Salesforce object.
- No reference to assumed Product Design Salesforce fields.
- No reference to [Case] / Customer Service, because that ingestion is currently
  missing from the new Salesforce pipeline.
- No source-build procedure that could fail against missing or incorrectly named
  Salesforce tables.
- No run-all procedure that would call blocked source logic.
- No SELECT TOP 0 INTO dependency on dbo.fact_kpi_result.
- No INSERT SELECT * publication.

Retained
--------
- Explicit Gold fact-table contracts.
- Weekly KPI calculations for:
    P1 Drawings Completed
    D1 Drawing Lead Time
    D2 Product Design OTIF
    Q1 Customer Complaints
- Explicit 26-column enriched KPI result contract.
- Explicit publication into dbo.fact_kpi_result.

Important
---------
These KPI procedures only produce rows after the two atomic facts are populated:
  salesforce_staging.fact_product_design_delivery
  salesforce_staging.fact_product_design_complaint

Populate those facts only after Engineering confirms the real Salesforce source
object and fields behind ProductDesign and restores Customer Service / Case.
*/

IF SCHEMA_ID('salesforce_staging') IS NULL
    EXEC('CREATE SCHEMA [salesforce_staging]');
GO

/* =============================================================
   00. ATOMIC FACT CONTRACTS
   ============================================================= */
IF OBJECT_ID('[salesforce_staging].[fact_product_design_delivery]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce_staging].[fact_product_design_delivery]
    (
        product_design_id       VARCHAR(255)   NOT NULL,
        project_id              VARCHAR(255)   NULL,
        project_name            VARCHAR(500)   NULL,
        reporting_date          DATE           NULL,
        completed_date          DATE           NULL,
        drawings_required       DECIMAL(18,4)  NULL,
        drawing_completed_flag  BIT            NULL,
        lead_time_days          DECIMAL(18,4)  NULL,
        outside_sla_flag        BIT            NULL,
        date_key                INT            NULL,
        closed_year             INT            NULL,
        closed_week             INT            NULL,
        week_key                INT            NULL,
        week_start_date         DATE           NULL,
        week_ending_date        DATE           NULL,
        source_row_count        BIGINT         NOT NULL,
        created_ts              DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[salesforce_staging].[fact_product_design_complaint]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce_staging].[fact_product_design_complaint]
    (
        case_id                 VARCHAR(255)  NOT NULL,
        case_number             VARCHAR(255)  NULL,
        project_id              VARCHAR(255)  NULL,
        project_name            VARCHAR(500)  NULL,
        complaint_open_date     DATE          NULL,
        date_key                INT           NULL,
        closed_year             INT           NULL,
        closed_week             INT           NULL,
        week_key                INT           NULL,
        week_start_date         DATE          NULL,
        week_ending_date        DATE          NULL,
        source_row_count        BIGINT        NOT NULL,
        created_ts              DATETIME2(6)  NOT NULL
    );
END;
GO

/* =============================================================
   01. WEEKLY FACT CONTRACTS
   ============================================================= */
IF OBJECT_ID('[salesforce_staging].[fact_product_design_drawings_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce_staging].[fact_product_design_drawings_weekly]
    (
        closed_year             INT           NOT NULL,
        closed_week             INT           NOT NULL,
        week_key                INT           NOT NULL,
        week_start_date         DATE          NOT NULL,
        week_ending_date        DATE          NOT NULL,
        drawings_completed      BIGINT        NOT NULL,
        total_drawings_required DECIMAL(18,4) NULL,
        source_row_count        BIGINT        NOT NULL,
        calculation_timestamp   DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[salesforce_staging].[fact_product_design_lead_time_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce_staging].[fact_product_design_lead_time_weekly]
    (
        closed_year             INT           NOT NULL,
        closed_week             INT           NOT NULL,
        week_key                INT           NOT NULL,
        week_start_date         DATE          NOT NULL,
        week_ending_date        DATE          NOT NULL,
        completed_records       BIGINT        NOT NULL,
        average_lead_time_days  DECIMAL(18,4) NULL,
        min_lead_time_days      DECIMAL(18,4) NULL,
        max_lead_time_days      DECIMAL(18,4) NULL,
        source_row_count        BIGINT        NOT NULL,
        calculation_timestamp   DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[salesforce_staging].[fact_product_design_otif_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce_staging].[fact_product_design_otif_weekly]
    (
        closed_year             INT           NOT NULL,
        closed_week             INT           NOT NULL,
        week_key                INT           NOT NULL,
        week_start_date         DATE          NOT NULL,
        week_ending_date        DATE          NOT NULL,
        sla_population          BIGINT        NOT NULL,
        outside_sla_count       BIGINT        NOT NULL,
        outside_sla_percentage  DECIMAL(18,6) NULL,
        within_sla_percentage   DECIMAL(18,6) NULL,
        source_row_count        BIGINT        NOT NULL,
        calculation_timestamp   DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[salesforce_staging].[fact_product_design_complaints_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce_staging].[fact_product_design_complaints_weekly]
    (
        closed_year             INT          NOT NULL,
        closed_week             INT          NOT NULL,
        week_key                INT          NOT NULL,
        week_start_date         DATE         NOT NULL,
        week_ending_date        DATE         NOT NULL,
        customer_complaints     BIGINT       NOT NULL,
        source_row_count        BIGINT       NOT NULL,
        calculation_timestamp   DATETIME2(6) NOT NULL
    );
END;
GO

/* =============================================================
   02. EXPLICIT 26-COLUMN ENRICHED KPI RESULT CONTRACT
   Column order follows the dashboard contract supplied by the user.
   ============================================================= */
IF OBJECT_ID('[salesforce_staging].[kpi_result_product_design]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce_staging].[kpi_result_product_design]
    (
        closed_year                    INT             NULL,
        closed_week                    INT             NULL,
        kpi_name                       VARCHAR(255)    NULL,
        kpi_value                      DECIMAL(18,6)   NULL,
        organisational_unit            VARCHAR(255)    NULL,
        kpi_id                         BIGINT          NULL,
        kpi_category                   VARCHAR(100)    NULL,
        target_value                   DECIMAL(18,6)   NULL,
        breach_direction               VARCHAR(20)     NULL,
        week_key                       INT             NULL,
        kpi_code                       VARCHAR(100)    NULL,
        department                     VARCHAR(255)    NULL,
        measure                        VARCHAR(500)    NULL,
        measure_name                   VARCHAR(500)    NULL,
        uom                            VARCHAR(50)     NULL,
        sign                           VARCHAR(100)    NULL,
        sign_label                     VARCHAR(100)    NULL,
        commentary                     VARCHAR(1000)   NULL,
        variance_value                 DECIMAL(18,6)   NULL,
        performance_variance_value     DECIMAL(18,6)   NULL,
        rag_status                     VARCHAR(20)     NULL,
        data_status                    VARCHAR(50)     NULL,
        source_system                  VARCHAR(100)    NULL,
        source_object                  VARCHAR(500)    NULL,
        source_row_count               BIGINT          NULL,
        calculation_timestamp          DATETIME2(6)    NULL
    );
END;
GO

/* =============================================================
   03. P1 - DRAWINGS COMPLETED
   Safe only after fact_product_design_delivery has approved source data.
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce_staging].[sp_build_kpi_product_design_drawings_completed]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [salesforce_staging].[fact_product_design_drawings_weekly];
    DELETE FROM [salesforce_staging].[kpi_result_product_design]
    WHERE kpi_code='ProductDesign-KPI-P1';

    INSERT INTO [salesforce_staging].[fact_product_design_drawings_weekly]
    (
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        drawings_completed,total_drawings_required,source_row_count,
        calculation_timestamp
    )
    SELECT
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(DISTINCT CASE WHEN drawing_completed_flag=1 THEN product_design_id END),
        SUM(drawings_required),SUM(source_row_count),SYSUTCDATETIME()
    FROM [salesforce_staging].[fact_product_design_delivery]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;

    INSERT INTO [salesforce_staging].[kpi_result_product_design]
    (
        closed_year,closed_week,kpi_name,kpi_value,organisational_unit,
        kpi_id,kpi_category,target_value,breach_direction,week_key,kpi_code,
        department,measure,measure_name,uom,sign,sign_label,commentary,
        variance_value,performance_variance_value,rag_status,data_status,
        source_system,source_object,source_row_count,calculation_timestamp
    )
    SELECT
        w.closed_year,w.closed_week,'Drawings Completed',
        CAST(w.drawings_completed AS DECIMAL(18,6)),'Product Design',
        k.kpi_id,'Productivity',CAST(k.target_value AS DECIMAL(18,6)),
        UPPER(k.breach_direction),w.week_key,'ProductDesign-KPI-P1',
        'Product Design','Count of completed Product Design records',
        'Drawings Completed','Count',NULL,NULL,
        CONCAT('Total drawings required=',COALESCE(CAST(w.total_drawings_required AS VARCHAR(50)),'NULL')),
        CASE WHEN k.target_value IS NULL THEN NULL
             ELSE CAST(w.drawings_completed AS DECIMAL(18,6))-k.target_value END,
        CASE WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN NULL
             WHEN UPPER(k.breach_direction)='OVER' THEN k.target_value-w.drawings_completed
             ELSE w.drawings_completed-k.target_value END,
        CASE WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN 'TBC'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.drawings_completed>=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.drawings_completed>=k.target_value*0.95 THEN 'A'
             WHEN UPPER(k.breach_direction)='OVER' AND w.drawings_completed<=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='OVER' AND w.drawings_completed<=k.target_value*1.05 THEN 'A'
             ELSE 'R' END,
        CASE WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Salesforce','Approved Product Design source -> fact_product_design_delivery',
        w.source_row_count,SYSUTCDATETIME()
    FROM [salesforce_staging].[fact_product_design_drawings_weekly] w
    LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code='ProductDesign-KPI-P1';
END;
GO

/* =============================================================
   04. D1 - DRAWING LEAD TIME
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce_staging].[sp_build_kpi_product_design_drawing_lead_time]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [salesforce_staging].[fact_product_design_lead_time_weekly];
    DELETE FROM [salesforce_staging].[kpi_result_product_design]
    WHERE kpi_code='ProductDesign-KPI-D1';

    INSERT INTO [salesforce_staging].[fact_product_design_lead_time_weekly]
    (
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        completed_records,average_lead_time_days,min_lead_time_days,
        max_lead_time_days,source_row_count,calculation_timestamp
    )
    SELECT
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(DISTINCT product_design_id),
        AVG(lead_time_days),MIN(lead_time_days),MAX(lead_time_days),
        SUM(source_row_count),SYSUTCDATETIME()
    FROM [salesforce_staging].[fact_product_design_delivery]
    WHERE week_key IS NOT NULL
      AND drawing_completed_flag=1
      AND lead_time_days IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;

    INSERT INTO [salesforce_staging].[kpi_result_product_design]
    (
        closed_year,closed_week,kpi_name,kpi_value,organisational_unit,
        kpi_id,kpi_category,target_value,breach_direction,week_key,kpi_code,
        department,measure,measure_name,uom,sign,sign_label,commentary,
        variance_value,performance_variance_value,rag_status,data_status,
        source_system,source_object,source_row_count,calculation_timestamp
    )
    SELECT
        w.closed_year,w.closed_week,'Drawing Lead Time',
        CAST(w.average_lead_time_days AS DECIMAL(18,6)),'Product Design',
        k.kpi_id,'Delivery',CAST(k.target_value AS DECIMAL(18,6)),
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'OVER'),
        w.week_key,'ProductDesign-KPI-D1','Product Design',
        'Average lead time for completed Product Design records',
        'Drawing Lead Time','Days','Over Breach','Over Breach',
        CONCAT('Completed records=',w.completed_records),
        CASE WHEN k.target_value IS NULL THEN NULL
             ELSE w.average_lead_time_days-k.target_value END,
        CASE WHEN k.target_value IS NULL THEN NULL
             ELSE k.target_value-w.average_lead_time_days END,
        CASE WHEN w.average_lead_time_days IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'TBC'
             WHEN w.average_lead_time_days<=k.target_value THEN 'G'
             WHEN w.average_lead_time_days<=k.target_value*1.05 THEN 'A'
             ELSE 'R' END,
        CASE WHEN w.average_lead_time_days IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'Actual - Target TBC'
             ELSE 'Actual' END,
        'Salesforce','Approved Product Design source -> fact_product_design_delivery',
        w.source_row_count,SYSUTCDATETIME()
    FROM [salesforce_staging].[fact_product_design_lead_time_weekly] w
    LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code='ProductDesign-KPI-D1';
END;
GO

/* =============================================================
   05. D2 - PRODUCT DESIGN OTIF
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce_staging].[sp_build_kpi_product_design_otif]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [salesforce_staging].[fact_product_design_otif_weekly];
    DELETE FROM [salesforce_staging].[kpi_result_product_design]
    WHERE kpi_code='ProductDesign-KPI-D2';

    INSERT INTO [salesforce_staging].[fact_product_design_otif_weekly]
    (
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        sla_population,outside_sla_count,outside_sla_percentage,
        within_sla_percentage,source_row_count,calculation_timestamp
    )
    SELECT
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(outside_sla_flag),
        SUM(CASE WHEN outside_sla_flag=1 THEN 1 ELSE 0 END),
        CAST(1.0*SUM(CASE WHEN outside_sla_flag=1 THEN 1 ELSE 0 END)
             /NULLIF(COUNT(outside_sla_flag),0) AS DECIMAL(18,6)),
        CAST(1.0-(1.0*SUM(CASE WHEN outside_sla_flag=1 THEN 1 ELSE 0 END)
             /NULLIF(COUNT(outside_sla_flag),0)) AS DECIMAL(18,6)),
        SUM(source_row_count),SYSUTCDATETIME()
    FROM [salesforce_staging].[fact_product_design_delivery]
    WHERE week_key IS NOT NULL
      AND outside_sla_flag IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;

    INSERT INTO [salesforce_staging].[kpi_result_product_design]
    (
        closed_year,closed_week,kpi_name,kpi_value,organisational_unit,
        kpi_id,kpi_category,target_value,breach_direction,week_key,kpi_code,
        department,measure,measure_name,uom,sign,sign_label,commentary,
        variance_value,performance_variance_value,rag_status,data_status,
        source_system,source_object,source_row_count,calculation_timestamp
    )
    SELECT
        w.closed_year,w.closed_week,'Product Design OTIF',
        w.within_sla_percentage,'Product Design',k.kpi_id,'Delivery',
        CAST(k.target_value AS DECIMAL(18,6)),
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'UNDER'),
        w.week_key,'ProductDesign-KPI-D2','Product Design',
        'Within SLA percentage = 1 - Outside SLA percentage',
        'Product Design OTIF','Percentage','Under Breach','Under Breach',
        CONCAT('SLA population=',w.sla_population,', outside SLA=',w.outside_sla_count),
        CASE WHEN k.target_value IS NULL THEN NULL
             ELSE w.within_sla_percentage-k.target_value END,
        CASE WHEN k.target_value IS NULL THEN NULL
             ELSE w.within_sla_percentage-k.target_value END,
        CASE WHEN w.within_sla_percentage IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'TBC'
             WHEN w.within_sla_percentage>=k.target_value THEN 'G'
             WHEN w.within_sla_percentage>=k.target_value*0.95 THEN 'A'
             ELSE 'R' END,
        CASE WHEN w.within_sla_percentage IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'Actual - Target TBC'
             ELSE 'Actual' END,
        'Salesforce','Approved Product Design source -> fact_product_design_delivery',
        w.source_row_count,SYSUTCDATETIME()
    FROM [salesforce_staging].[fact_product_design_otif_weekly] w
    LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code='ProductDesign-KPI-D2';
END;
GO

/* =============================================================
   06. Q1 - CUSTOMER COMPLAINTS
   Procedure is safe to CREATE but should only be EXECUTED after the complaint
   fact has been populated from the restored Customer Service / Case ingestion.
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce_staging].[sp_build_kpi_product_design_customer_complaints]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [salesforce_staging].[fact_product_design_complaints_weekly];
    DELETE FROM [salesforce_staging].[kpi_result_product_design]
    WHERE kpi_code='ProductDesign-KPI-Q1';

    INSERT INTO [salesforce_staging].[fact_product_design_complaints_weekly]
    (
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        customer_complaints,source_row_count,calculation_timestamp
    )
    SELECT
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(DISTINCT case_number),SUM(source_row_count),SYSUTCDATETIME()
    FROM [salesforce_staging].[fact_product_design_complaint]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;

    INSERT INTO [salesforce_staging].[kpi_result_product_design]
    (
        closed_year,closed_week,kpi_name,kpi_value,organisational_unit,
        kpi_id,kpi_category,target_value,breach_direction,week_key,kpi_code,
        department,measure,measure_name,uom,sign,sign_label,commentary,
        variance_value,performance_variance_value,rag_status,data_status,
        source_system,source_object,source_row_count,calculation_timestamp
    )
    SELECT
        w.closed_year,w.closed_week,'Customer Complaints',
        CAST(w.customer_complaints AS DECIMAL(18,6)),'Product Design',
        k.kpi_id,'Quality',CAST(k.target_value AS DECIMAL(18,6)),
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'OVER'),
        w.week_key,'ProductDesign-KPI-Q1','Product Design',
        'Count of Customer Service CaseNumber by Open_Date__c',
        'Customer Complaints','Count','Over Breach','Over Breach',NULL,
        CASE WHEN k.target_value IS NULL THEN NULL
             ELSE w.customer_complaints-k.target_value END,
        CASE WHEN k.target_value IS NULL THEN NULL
             ELSE k.target_value-w.customer_complaints END,
        CASE WHEN k.target_value IS NULL THEN 'TBC'
             WHEN w.customer_complaints<=k.target_value THEN 'G'
             WHEN w.customer_complaints<=k.target_value*1.05 THEN 'A'
             ELSE 'R' END,
        CASE WHEN k.target_value IS NULL THEN 'Actual - Target TBC'
             ELSE 'Actual' END,
        'Salesforce','Restored Customer Service source -> fact_product_design_complaint',
        w.source_row_count,SYSUTCDATETIME()
    FROM [salesforce_staging].[fact_product_design_complaints_weekly] w
    LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code='ProductDesign-KPI-Q1';
END;
GO

/* =============================================================
   07. SAFE RUNNERS
   No source extraction and no complaint dependency.
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce_staging].[sp_build_product_design_available_kpis]
AS
BEGIN
    SET NOCOUNT ON;

    EXEC [salesforce_staging].[sp_build_kpi_product_design_drawings_completed];
    EXEC [salesforce_staging].[sp_build_kpi_product_design_drawing_lead_time];
    EXEC [salesforce_staging].[sp_build_kpi_product_design_otif];
END;
GO

/* =============================================================
   08. EXPLICIT PUBLISHER
   Publishes whichever Product Design KPI rows currently exist.
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce_staging].[sp_publish_product_design_available_kpis]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [dbo].[fact_kpi_result]
    WHERE kpi_code IN
    (
        'ProductDesign-KPI-P1',
        'ProductDesign-KPI-D1',
        'ProductDesign-KPI-D2',
        'ProductDesign-KPI-Q1'
    );

    INSERT INTO [dbo].[fact_kpi_result]
    (
        closed_year,closed_week,kpi_name,kpi_value,organisational_unit,
        kpi_id,kpi_category,target_value,breach_direction,week_key,kpi_code,
        department,measure,measure_name,uom,sign,sign_label,commentary,
        variance_value,performance_variance_value,rag_status,data_status,
        source_system,source_object,source_row_count,calculation_timestamp
    )
    SELECT
        closed_year,closed_week,kpi_name,kpi_value,organisational_unit,
        kpi_id,kpi_category,target_value,breach_direction,week_key,kpi_code,
        department,measure,measure_name,uom,sign,sign_label,commentary,
        variance_value,performance_variance_value,rag_status,data_status,
        source_system,source_object,source_row_count,calculation_timestamp
    FROM [salesforce_staging].[kpi_result_product_design];
END;
GO

/* =============================================================
   SAFE EXECUTION ORDER
   =============================================================

1. Deploy this script. This creates tables and procedures only.

2. Do NOT run the Product Design KPI runner until
   salesforce_staging.fact_product_design_delivery has approved source data.

3. Once the delivery fact is correctly populated:

   EXEC [salesforce_staging].[sp_build_product_design_available_kpis];

4. Review:

   SELECT *
   FROM [salesforce_staging].[kpi_result_product_design]
   ORDER BY closed_year,closed_week,kpi_code;

5. Publish approved rows:

   EXEC [salesforce_staging].[sp_publish_product_design_available_kpis];

6. Only after Customer Service / Case is restored and the complaint fact is
   populated, run:

   EXEC [salesforce_staging].[sp_build_kpi_product_design_customer_complaints];
   EXEC [salesforce_staging].[sp_publish_product_design_available_kpis];
*/
