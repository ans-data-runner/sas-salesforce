/*
SAS PRODUCT DESIGN - FOUR MISSING GOLD KPI PROCEDURES
====================================================
KPI 1 Productivity: Drawings Completed
KPI 2 Delivery: Drawing Lead Time
KPI 3 Quality: Customer Complaints
KPI 4 Delivery: Product Design OTIF

Confirmed business definitions
------------------------------
- Drawings Completed: ProductDesign + Project; count completed/project records.
- Drawing Lead Time: ProductDesign + Project; average LeadTimeDays.
- Customer Complaints: CustomerService + Company + Project; count CaseNumber by Open_Date__c.
- Product Design OTIF: reported Within SLA percentage = 1 - Outside SLA percentage.

Mitigation for unresolved Salesforce physical lineage
-----------------------------------------------------
The customer material identifies source objects and measures, but not every physical
API join/filter used by the PBIX reports. To avoid inventing Salesforce field names,
this pack uses two explicit adapters:
  etl_input.product_design_delivery_source
  etl_input.product_design_complaint_source
Map the staged Salesforce objects into these contracts once physical columns are
confirmed. All downstream Gold facts and KPI procedures can then remain unchanged.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO
IF SCHEMA_ID('etl_input') IS NULL EXEC('CREATE SCHEMA [etl_input]');
GO

/* Source adapter for Drawings, Lead Time and OTIF. */
IF OBJECT_ID('[etl_input].[product_design_delivery_source]', 'U') IS NULL
CREATE TABLE [etl_input].[product_design_delivery_source]
(
 product_design_id VARCHAR(255) NOT NULL,
 project_id VARCHAR(255) NULL,
 project_name VARCHAR(500) NULL,
 reporting_date DATE NULL,
 completed_date DATE NULL,
 drawings_required DECIMAL(18,4) NULL,
 drawing_completed_flag BIT NULL,
 lead_time_days DECIMAL(18,4) NULL,
 outside_sla_flag BIT NULL,
 source_row_count BIGINT NULL
);
GO

/* Source adapter for Product Design complaints. */
IF OBJECT_ID('[etl_input].[product_design_complaint_source]', 'U') IS NULL
CREATE TABLE [etl_input].[product_design_complaint_source]
(
 case_id VARCHAR(255) NOT NULL,
 case_number VARCHAR(255) NULL,
 project_id VARCHAR(255) NULL,
 project_name VARCHAR(500) NULL,
 complaint_open_date DATE NULL,
 is_product_design_complaint BIT NOT NULL,
 source_row_count BIGINT NULL
);
GO

/* Atomic facts */
IF OBJECT_ID('[dbo].[fact_product_design_delivery]', 'U') IS NULL
CREATE TABLE [dbo].[fact_product_design_delivery]
(
 product_design_id VARCHAR(255) NOT NULL,
 project_id VARCHAR(255) NULL,
 project_name VARCHAR(500) NULL,
 reporting_date DATE NULL,
 completed_date DATE NULL,
 drawings_required DECIMAL(18,4) NULL,
 drawing_completed_flag BIT NULL,
 lead_time_days DECIMAL(18,4) NULL,
 outside_sla_flag BIT NULL,
 date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
 week_start_date DATE NULL, week_ending_date DATE NULL,
 source_row_count BIGINT NOT NULL, created_ts DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_product_design_complaint]', 'U') IS NULL
CREATE TABLE [dbo].[fact_product_design_complaint]
(
 case_id VARCHAR(255) NOT NULL,
 case_number VARCHAR(255) NULL,
 project_id VARCHAR(255) NULL,
 project_name VARCHAR(500) NULL,
 complaint_open_date DATE NULL,
 date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
 week_start_date DATE NULL, week_ending_date DATE NULL,
 source_row_count BIGINT NOT NULL, created_ts DATETIME2(6) NOT NULL
);
GO

/* Weekly facts */
IF OBJECT_ID('[dbo].[fact_product_design_drawings_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_product_design_drawings_weekly]
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 drawings_completed BIGINT NOT NULL, total_drawings_required DECIMAL(18,4) NULL,
 source_row_count BIGINT NOT NULL, calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_product_design_lead_time_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_product_design_lead_time_weekly]
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 completed_records BIGINT NOT NULL, average_lead_time_days DECIMAL(18,4) NULL,
 min_lead_time_days DECIMAL(18,4) NULL, max_lead_time_days DECIMAL(18,4) NULL,
 source_row_count BIGINT NOT NULL, calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_product_design_otif_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_product_design_otif_weekly]
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 sla_population BIGINT NOT NULL, outside_sla_count BIGINT NOT NULL,
 outside_sla_percentage DECIMAL(18,6) NULL, within_sla_percentage DECIMAL(18,6) NULL,
 source_row_count BIGINT NOT NULL, calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_product_design_complaints_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_product_design_complaints_weekly]
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 customer_complaints BIGINT NOT NULL, source_row_count BIGINT NOT NULL,
 calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[kpi_result_product_design]', 'U') IS NULL
SELECT TOP 0 * INTO [dbo].[kpi_result_product_design] FROM [dbo].[fact_kpi_result];
GO

/* Common atomic fact build. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_design_sources]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE dbo.fact_product_design_delivery;
 TRUNCATE TABLE dbo.fact_product_design_complaint;

 INSERT INTO dbo.fact_product_design_delivery
 SELECT s.product_design_id,s.project_id,s.project_name,
        COALESCE(s.reporting_date,s.completed_date),s.completed_date,
        s.drawings_required,s.drawing_completed_flag,s.lead_time_days,s.outside_sla_flag,
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        COALESCE(s.source_row_count,1),SYSUTCDATETIME()
 FROM etl_input.product_design_delivery_source s
 LEFT JOIN dbo.dim_date d ON d.calendar_date=COALESCE(s.reporting_date,s.completed_date);

 INSERT INTO dbo.fact_product_design_complaint
 SELECT s.case_id,s.case_number,s.project_id,s.project_name,s.complaint_open_date,
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        COALESCE(s.source_row_count,1),SYSUTCDATETIME()
 FROM etl_input.product_design_complaint_source s
 LEFT JOIN dbo.dim_date d ON d.calendar_date=s.complaint_open_date
 WHERE s.is_product_design_complaint=1;
END;
GO

/* KPI 1 - Drawings Completed */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_product_design_drawings_completed]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE dbo.fact_product_design_drawings_weekly;
 DELETE FROM dbo.kpi_result_product_design WHERE kpi_code='ProductDesign-KPI-P1';

 INSERT INTO dbo.fact_product_design_drawings_weekly
 SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(DISTINCT CASE WHEN drawing_completed_flag=1 THEN product_design_id END),
        SUM(drawings_required),SUM(source_row_count),SYSUTCDATETIME()
 FROM dbo.fact_product_design_delivery
 WHERE week_key IS NOT NULL
 GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;

 INSERT INTO dbo.kpi_result_product_design
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,'ProductDesign-KPI-P1',
        'Drawings Completed','Productivity','Product Design','Product Design',
        'Count of completed Product Design records','Drawings Completed','Count',NULL,NULL,
        CONCAT('Total drawings required=',COALESCE(CAST(w.total_drawings_required AS VARCHAR(50)),'NULL')),
        CAST(w.drawings_completed AS DECIMAL(18,4)),CAST(k.target_value AS DECIMAL(18,4)),
        CASE WHEN k.target_value IS NULL THEN NULL ELSE w.drawings_completed-k.target_value END,
        CASE WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN NULL
             WHEN UPPER(k.breach_direction)='OVER' THEN k.target_value-w.drawings_completed
             ELSE w.drawings_completed-k.target_value END,
        UPPER(k.breach_direction),
        CASE WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN 'TBC'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.drawings_completed>=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.drawings_completed>=k.target_value*0.95 THEN 'A'
             WHEN UPPER(k.breach_direction)='OVER' AND w.drawings_completed<=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='OVER' AND w.drawings_completed<=k.target_value*1.05 THEN 'A'
             ELSE 'R' END,
        CASE WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Salesforce','ProductDesign + Project via etl_input adapter',w.source_row_count,SYSUTCDATETIME()
 FROM dbo.fact_product_design_drawings_weekly w
 LEFT JOIN dbo.dim_kpi k ON k.kpi_code='ProductDesign-KPI-P1';
END;
GO

/* KPI 2 - Drawing Lead Time */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_product_design_drawing_lead_time]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE dbo.fact_product_design_lead_time_weekly;
 DELETE FROM dbo.kpi_result_product_design WHERE kpi_code='ProductDesign-KPI-D1';

 INSERT INTO dbo.fact_product_design_lead_time_weekly
 SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(DISTINCT CASE WHEN drawing_completed_flag=1 THEN product_design_id END),
        AVG(lead_time_days),MIN(lead_time_days),MAX(lead_time_days),SUM(source_row_count),SYSUTCDATETIME()
 FROM dbo.fact_product_design_delivery
 WHERE week_key IS NOT NULL AND drawing_completed_flag=1
 GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;

 INSERT INTO dbo.kpi_result_product_design
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,'ProductDesign-KPI-D1',
        'Drawing Lead Time','Delivery','Product Design','Product Design',
        'Average LeadTimeDays for completed Product Design records','Drawing Lead Time','Days',
        'Over Breach','Over Breach',CONCAT('Completed records=',w.completed_records),
        w.average_lead_time_days,CAST(k.target_value AS DECIMAL(18,4)),
        CASE WHEN k.target_value IS NULL THEN NULL ELSE w.average_lead_time_days-k.target_value END,
        CASE WHEN k.target_value IS NULL THEN NULL ELSE k.target_value-w.average_lead_time_days END,
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'OVER'),
        CASE WHEN w.average_lead_time_days IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'TBC'
             WHEN w.average_lead_time_days<=k.target_value THEN 'G'
             WHEN w.average_lead_time_days<=k.target_value*1.05 THEN 'A' ELSE 'R' END,
        CASE WHEN w.average_lead_time_days IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Salesforce','ProductDesign + Project via etl_input adapter',w.source_row_count,SYSUTCDATETIME()
 FROM dbo.fact_product_design_lead_time_weekly w
 LEFT JOIN dbo.dim_kpi k ON k.kpi_code='ProductDesign-KPI-D1';
END;
GO

/* KPI 3 - Customer Complaints */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_product_design_customer_complaints]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE dbo.fact_product_design_complaints_weekly;
 DELETE FROM dbo.kpi_result_product_design WHERE kpi_code='ProductDesign-KPI-Q1';

 INSERT INTO dbo.fact_product_design_complaints_weekly
 SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(DISTINCT case_number),SUM(source_row_count),SYSUTCDATETIME()
 FROM dbo.fact_product_design_complaint
 WHERE week_key IS NOT NULL
 GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;

 INSERT INTO dbo.kpi_result_product_design
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,'ProductDesign-KPI-Q1',
        'Customer Complaints','Quality','Product Design','Product Design',
        'Count of CustomerService CaseNumber by Open_Date__c','Customer Complaints','Count',
        'Over Breach','Over Breach',NULL,
        CAST(w.customer_complaints AS DECIMAL(18,4)),CAST(k.target_value AS DECIMAL(18,4)),
        CASE WHEN k.target_value IS NULL THEN NULL ELSE w.customer_complaints-k.target_value END,
        CASE WHEN k.target_value IS NULL THEN NULL ELSE k.target_value-w.customer_complaints END,
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'OVER'),
        CASE WHEN k.target_value IS NULL THEN 'TBC'
             WHEN w.customer_complaints<=k.target_value THEN 'G'
             WHEN w.customer_complaints<=k.target_value*1.05 THEN 'A' ELSE 'R' END,
        CASE WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Salesforce','CustomerService + Company + Project via etl_input adapter',w.source_row_count,SYSUTCDATETIME()
 FROM dbo.fact_product_design_complaints_weekly w
 LEFT JOIN dbo.dim_kpi k ON k.kpi_code='ProductDesign-KPI-Q1';
END;
GO

/* KPI 4 - Product Design OTIF / Within SLA */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_product_design_otif]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE dbo.fact_product_design_otif_weekly;
 DELETE FROM dbo.kpi_result_product_design WHERE kpi_code='ProductDesign-KPI-D2';

 INSERT INTO dbo.fact_product_design_otif_weekly
 SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(outside_sla_flag),
        SUM(CASE WHEN outside_sla_flag=1 THEN 1 ELSE 0 END),
        CAST(CASE WHEN COUNT(outside_sla_flag)>0
                  THEN 1.0*SUM(CASE WHEN outside_sla_flag=1 THEN 1 ELSE 0 END)/COUNT(outside_sla_flag) END AS DECIMAL(18,6)),
        CAST(CASE WHEN COUNT(outside_sla_flag)>0
                  THEN 1.0-(1.0*SUM(CASE WHEN outside_sla_flag=1 THEN 1 ELSE 0 END)/COUNT(outside_sla_flag)) END AS DECIMAL(18,6)),
        SUM(source_row_count),SYSUTCDATETIME()
 FROM dbo.fact_product_design_delivery
 WHERE week_key IS NOT NULL AND outside_sla_flag IS NOT NULL
 GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;

 INSERT INTO dbo.kpi_result_product_design
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,'ProductDesign-KPI-D2',
        'Product Design OTIF','Delivery','Product Design','Product Design',
        'Within SLA percentage = 1 - Outside SLA percentage','Product Design OTIF','Percentage',
        'Under Breach','Under Breach',CONCAT('SLA population=',w.sla_population,', outside SLA=',w.outside_sla_count),
        w.within_sla_percentage,CAST(k.target_value AS DECIMAL(18,4)),
        CASE WHEN k.target_value IS NULL THEN NULL ELSE w.within_sla_percentage-k.target_value END,
        CASE WHEN k.target_value IS NULL THEN NULL ELSE w.within_sla_percentage-k.target_value END,
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'UNDER'),
        CASE WHEN w.within_sla_percentage IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'TBC'
             WHEN w.within_sla_percentage>=k.target_value THEN 'G'
             WHEN w.within_sla_percentage>=k.target_value*0.95 THEN 'A' ELSE 'R' END,
        CASE WHEN w.within_sla_percentage IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Salesforce','ProductDesign + Project outside-SLA logic via etl_input adapter',w.source_row_count,SYSUTCDATETIME()
 FROM dbo.fact_product_design_otif_weekly w
 LEFT JOIN dbo.dim_kpi k ON k.kpi_code='ProductDesign-KPI-D2';
END;
GO

/* Orchestrators */
CREATE OR ALTER PROCEDURE [etl].[sp_build_product_design_all]
AS
BEGIN
 EXEC etl.sp_build_fact_product_design_sources;
 EXEC etl.sp_build_kpi_product_design_drawings_completed;
 EXEC etl.sp_build_kpi_product_design_drawing_lead_time;
 EXEC etl.sp_build_kpi_product_design_customer_complaints;
 EXEC etl.sp_build_kpi_product_design_otif;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_publish_product_design_all]
AS
BEGIN
 DELETE FROM dbo.fact_kpi_result
 WHERE kpi_code IN ('ProductDesign-KPI-P1','ProductDesign-KPI-D1','ProductDesign-KPI-Q1','ProductDesign-KPI-D2');
 INSERT INTO dbo.fact_kpi_result SELECT * FROM dbo.kpi_result_product_design;
END;
GO

/*
EXEC etl.sp_build_product_design_all;
SELECT * FROM dbo.kpi_result_product_design ORDER BY closed_year,closed_week,kpi_code;
*/
