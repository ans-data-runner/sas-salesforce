/*
SAS QUALITY MB - CUSTOMER COMPLAINTS KPI
========================================
Grounded customer mapping available:
  - Source system: Salesforce
  - Customer complaints are represented by Salesforce Case / Customer Service records.
  - KPI measure: count of CaseNumber by Open_Date__c.

Important limitation:
  The retrieved evidence does NOT expose the final Maybole-specific PBIX filter
  predicates. Do not invent them. This procedure therefore implements the confirmed
  complaint/date/count logic and isolates the Maybole scope in one marked predicate.
  Until the PBIX filter is recovered, either:
    A) replace the TODO predicate with the exact approved Maybole predicate; or
    B) run as-is for structural testing only and do not treat the result as UAT-ready.

Architecture:
  [stg_salesforce].[Case]
          -> [dbo].[fact_quality_mb_customer_complaint]
          -> [dbo].[fact_quality_mb_customer_complaints_weekly]
          -> [dbo].[kpi_result_quality_mb_customer_complaints]
          -> [dbo].[fact_kpi_result] (optional publish)

Assumed staged Salesforce columns used by the confirmed mapping:
  Id, CaseNumber, Open_Date__c, CreatedDate
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO

IF OBJECT_ID('[dbo].[fact_quality_mb_customer_complaint]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_quality_mb_customer_complaint]
    (
        case_id                    VARCHAR(255) NOT NULL,
        case_number                VARCHAR(255) NULL,
        complaint_open_date        DATE         NULL,
        source_created_timestamp   DATETIME2(6) NULL,
        date_key                   INT          NULL,
        closed_year                INT          NULL,
        closed_week                INT          NULL,
        week_key                   INT          NULL,
        week_start_date            DATE         NULL,
        week_ending_date           DATE         NULL,
        created_ts                 DATETIME2(6) NOT NULL,
        updated_ts                 DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_quality_mb_customer_complaints_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_quality_mb_customer_complaints_weekly]
    (
        closed_year                INT          NOT NULL,
        closed_week                INT          NOT NULL,
        week_key                   INT          NOT NULL,
        week_start_date            DATE         NOT NULL,
        week_ending_date           DATE         NOT NULL,
        customer_complaints        BIGINT       NOT NULL,
        source_row_count           BIGINT       NOT NULL,
        calculation_timestamp      DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[kpi_result_quality_mb_customer_complaints]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[kpi_result_quality_mb_customer_complaints]
    (
        closed_year                   INT            NOT NULL,
        closed_week                   INT            NOT NULL,
        week_key                      INT            NOT NULL,
        kpi_id                        BIGINT         NULL,
        kpi_code                      VARCHAR(100)   NOT NULL,
        kpi_name                      VARCHAR(255)   NOT NULL,
        kpi_category                  VARCHAR(100)   NOT NULL,
        organisational_unit           VARCHAR(255)   NOT NULL,
        department                    VARCHAR(255)   NOT NULL,
        measure                       VARCHAR(500)   NULL,
        measure_name                  VARCHAR(500)   NULL,
        uom                           VARCHAR(50)    NULL,
        sign                          VARCHAR(100)   NULL,
        sign_label                    VARCHAR(100)   NULL,
        commentary                    VARCHAR(1000)  NULL,
        kpi_value                     DECIMAL(18,4)  NULL,
        target_value                  DECIMAL(18,4)  NULL,
        variance_value                DECIMAL(18,4)  NULL,
        performance_variance_value    DECIMAL(18,4)  NULL,
        breach_direction              VARCHAR(20)    NULL,
        rag_status                    VARCHAR(20)    NOT NULL,
        data_status                   VARCHAR(50)    NOT NULL,
        source_system                 VARCHAR(100)   NOT NULL,
        source_object                 VARCHAR(500)   NOT NULL,
        source_row_count              BIGINT         NOT NULL,
        calculation_timestamp         DATETIME2(6)   NOT NULL
    );
END;
GO

/* 01. Atomic complaint fact */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_quality_mb_customer_complaint]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_quality_mb_customer_complaint];

    ;WITH src AS
    (
        SELECT
            CAST(c.[Id] AS VARCHAR(255)) AS case_id,
            CAST(c.[CaseNumber] AS VARCHAR(255)) AS case_number,
            TRY_CAST(c.[Open_Date__c] AS DATE) AS complaint_open_date,
            TRY_CAST(c.[CreatedDate] AS DATETIME2(6)) AS source_created_timestamp,
            ROW_NUMBER() OVER
            (
                PARTITION BY CAST(c.[Id] AS VARCHAR(255))
                ORDER BY TRY_CAST(c.[CreatedDate] AS DATETIME2(6)) DESC
            ) AS rn
        FROM [stg_salesforce].[Case] c
        WHERE c.[Id] IS NOT NULL
          AND c.[CaseNumber] IS NOT NULL
          AND c.[Open_Date__c] IS NOT NULL

          /* =====================================================
             TODO - INSERT THE APPROVED QUALITY MB / MAYBOLE PBIX
             FILTER HERE BEFORE UAT.

             Example intentionally NOT supplied because the retrieved
             customer evidence does not expose the exact predicate.
             ===================================================== */
    )
    INSERT INTO [dbo].[fact_quality_mb_customer_complaint]
    (
        case_id,case_number,complaint_open_date,source_created_timestamp,
        date_key,closed_year,closed_week,week_key,week_start_date,
        week_ending_date,created_ts,updated_ts
    )
    SELECT
        s.case_id,s.case_number,s.complaint_open_date,s.source_created_timestamp,
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,
        d.week_start_date,d.week_end_date,SYSUTCDATETIME(),SYSUTCDATETIME()
    FROM src s
    LEFT JOIN [dbo].[dim_date] d
      ON d.calendar_date=s.complaint_open_date
    WHERE s.rn=1;
END;
GO

/* 02. Weekly complaints */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_quality_mb_customer_complaints_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_quality_mb_customer_complaints_weekly];

    INSERT INTO [dbo].[fact_quality_mb_customer_complaints_weekly]
    (
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        customer_complaints,source_row_count,calculation_timestamp
    )
    SELECT
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(DISTINCT case_number),COUNT_BIG(*),SYSUTCDATETIME()
    FROM [dbo].[fact_quality_mb_customer_complaint]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;
END;
GO

/* 03. Enriched KPI result
   Provisional code only. Replace if the approved dim_kpi code differs.
*/
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_quality_mb_customer_complaints]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[kpi_result_quality_mb_customer_complaints];

    ;WITH b AS
    (
        SELECT w.*,CAST('Quality-MB-KPI-Q1' AS VARCHAR(100)) AS kpi_code
        FROM [dbo].[fact_quality_mb_customer_complaints_weekly] w
    ), e AS
    (
        SELECT b.*,k.kpi_id,CAST(k.target_value AS DECIMAL(18,4)) target_value,
               UPPER(NULLIF(k.breach_direction,'')) breach_direction
        FROM b LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code=b.kpi_code
    )
    INSERT INTO [dbo].[kpi_result_quality_mb_customer_complaints]
    SELECT
        closed_year,closed_week,week_key,kpi_id,kpi_code,
        'Customer Complaints','Quality','Quality MB','Quality MB',
        'Count of Salesforce customer complaint cases by Open_Date__c',
        'Customer Complaints','Count',NULL,NULL,
        'Maybole-specific PBIX filter must be confirmed before UAT.',
        CAST(customer_complaints AS DECIMAL(18,4)),target_value,
        CASE WHEN target_value IS NULL THEN NULL ELSE CAST(customer_complaints AS DECIMAL(18,4))-target_value END,
        CASE WHEN target_value IS NULL OR breach_direction IS NULL THEN NULL
             WHEN breach_direction='OVER' THEN target_value-CAST(customer_complaints AS DECIMAL(18,4))
             ELSE CAST(customer_complaints AS DECIMAL(18,4))-target_value END,
        breach_direction,
        CASE
          WHEN target_value IS NULL OR breach_direction IS NULL THEN 'TBC'
          WHEN breach_direction='UNDER' AND customer_complaints>=target_value THEN 'G'
          WHEN breach_direction='UNDER' AND customer_complaints>=target_value*0.95 THEN 'A'
          WHEN breach_direction='OVER' AND customer_complaints<=target_value THEN 'G'
          WHEN breach_direction='OVER' AND customer_complaints<=target_value*1.05 THEN 'A'
          ELSE 'R' END,
        CASE WHEN target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Salesforce','stg_salesforce.Case',source_row_count,SYSUTCDATETIME()
    FROM e;
END;
GO

/* 04. Optional canonical publication */
CREATE OR ALTER PROCEDURE [etl].[sp_publish_quality_mb_customer_complaints]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [dbo].[fact_kpi_result] WHERE kpi_code='Quality-MB-KPI-Q1';
    INSERT INTO [dbo].[fact_kpi_result]
    SELECT * FROM [dbo].[kpi_result_quality_mb_customer_complaints];
END;
GO

/* 05. Build without canonical publication */
CREATE OR ALTER PROCEDURE [etl].[sp_build_quality_mb_customer_complaints]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_quality_mb_customer_complaint];
    EXEC [etl].[sp_build_fact_quality_mb_customer_complaints_weekly];
    EXEC [etl].[sp_build_kpi_result_quality_mb_customer_complaints];
END;
GO

/* 06. Build + publish */
CREATE OR ALTER PROCEDURE [etl].[sp_build_quality_mb_customer_complaints_and_publish]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_quality_mb_customer_complaints];
    EXEC [etl].[sp_publish_quality_mb_customer_complaints];
END;
GO

/* TESTS
EXEC [etl].[sp_build_quality_mb_customer_complaints];
SELECT * FROM [dbo].[fact_quality_mb_customer_complaint]
ORDER BY complaint_open_date,case_number;
SELECT * FROM [dbo].[fact_quality_mb_customer_complaints_weekly]
ORDER BY week_ending_date;
SELECT * FROM [dbo].[kpi_result_quality_mb_customer_complaints]
ORDER BY closed_year,closed_week;

-- Baseline reconciliation BEFORE the Maybole PBIX predicate is applied:
SELECT
    TRY_CAST([Open_Date__c] AS DATE) AS complaint_open_date,
    COUNT(DISTINCT CAST([CaseNumber] AS VARCHAR(255))) AS source_complaints
FROM [stg_salesforce].[Case]
WHERE [CaseNumber] IS NOT NULL AND [Open_Date__c] IS NOT NULL
GROUP BY TRY_CAST([Open_Date__c] AS DATE)
ORDER BY complaint_open_date;
*/
