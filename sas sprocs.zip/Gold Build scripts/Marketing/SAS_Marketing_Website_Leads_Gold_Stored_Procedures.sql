/*
SAS MARKETING - WEBSITE LEADS KPI
=================================
Confirmed customer mapping:
  Source system: Salesforce
  Source object: Lead / Leads
  Filter: LeadSource = 'CAD downloads'
  Reporting date: CreatedDate

Architecture used here:
  Gold staging: [stg_salesforce].[Lead]
  Gold fact:    [dbo].[fact_marketing_website_lead]
  Weekly fact:  [dbo].[fact_marketing_website_leads_weekly]
  KPI result:   [dbo].[kpi_result_marketing_website_leads]
  Canonical:    [dbo].[fact_kpi_result] (optional publish proc)

Assumptions to validate in your environment:
  - Salesforce Lead is staged as [stg_salesforce].[Lead].
  - Columns are [Id], [LeadSource], [CreatedDate].
  - Website Leads is a count KPI. This is directly implied by the supplied
    mapping describing leads added in a timeframe; no target/RAG threshold was
    supplied in the customer evidence, so target and RAG remain TBC.
  - dbo.dim_date is the canonical reporting calendar.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO

/* =============================================================
   00. GOLD OUTPUT TABLES
   ============================================================= */
IF OBJECT_ID('[dbo].[fact_marketing_website_lead]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_marketing_website_lead]
    (
        lead_id                  VARCHAR(255)  NOT NULL,
        lead_source              VARCHAR(255)  NULL,
        created_timestamp        DATETIME2(6)  NULL,
        created_date             DATE          NULL,
        date_key                 INT           NULL,
        closed_year              INT           NULL,
        closed_week              INT           NULL,
        week_key                 INT           NULL,
        week_start_date          DATE          NULL,
        week_ending_date         DATE          NULL,
        created_ts               DATETIME2(6)  NOT NULL,
        updated_ts               DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_marketing_website_leads_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_marketing_website_leads_weekly]
    (
        closed_year              INT           NOT NULL,
        closed_week              INT           NOT NULL,
        week_key                 INT           NOT NULL,
        week_start_date          DATE          NOT NULL,
        week_ending_date         DATE          NOT NULL,
        website_leads            BIGINT        NOT NULL,
        source_row_count         BIGINT        NOT NULL,
        calculation_timestamp    DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[kpi_result_marketing_website_leads]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[kpi_result_marketing_website_leads]
    (
        closed_year                   INT             NOT NULL,
        closed_week                   INT             NOT NULL,
        week_key                      INT             NOT NULL,
        kpi_id                        BIGINT          NULL,
        kpi_code                      VARCHAR(100)    NOT NULL,
        kpi_name                      VARCHAR(255)    NOT NULL,
        kpi_category                  VARCHAR(100)    NOT NULL,
        organisational_unit           VARCHAR(255)    NOT NULL,
        department                    VARCHAR(255)    NOT NULL,
        measure                       VARCHAR(500)    NULL,
        measure_name                  VARCHAR(500)    NULL,
        uom                           VARCHAR(50)     NULL,
        sign                          VARCHAR(100)    NULL,
        sign_label                    VARCHAR(100)    NULL,
        commentary                    VARCHAR(1000)   NULL,
        kpi_value                     DECIMAL(18,4)   NULL,
        target_value                  DECIMAL(18,4)   NULL,
        variance_value                DECIMAL(18,4)   NULL,
        performance_variance_value    DECIMAL(18,4)   NULL,
        breach_direction              VARCHAR(20)     NULL,
        rag_status                    VARCHAR(20)     NOT NULL,
        data_status                   VARCHAR(50)     NOT NULL,
        source_system                 VARCHAR(100)    NOT NULL,
        source_object                 VARCHAR(500)    NOT NULL,
        source_row_count              BIGINT          NOT NULL,
        calculation_timestamp         DATETIME2(6)    NOT NULL
    );
END;
GO

/* =============================================================
   01. ATOMIC WEBSITE LEAD FACT
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_marketing_website_lead]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_marketing_website_lead];

    INSERT INTO [dbo].[fact_marketing_website_lead]
    (
        lead_id, lead_source, created_timestamp, created_date,
        date_key, closed_year, closed_week, week_key,
        week_start_date, week_ending_date, created_ts, updated_ts
    )
    SELECT
        CAST(l.[Id] AS VARCHAR(255)),
        CAST(l.[LeadSource] AS VARCHAR(255)),
        TRY_CAST(l.[CreatedDate] AS DATETIME2(6)),
        CAST(TRY_CAST(l.[CreatedDate] AS DATETIME2(6)) AS DATE),
        d.date_key,
        d.customer_year,
        d.customer_week_no,
        d.week_key,
        d.week_start_date,
        d.week_end_date,
        SYSUTCDATETIME(),
        SYSUTCDATETIME()
    FROM [stg_salesforce].[Lead] l
    LEFT JOIN [dbo].[dim_date] d
      ON d.calendar_date = CAST(TRY_CAST(l.[CreatedDate] AS DATETIME2(6)) AS DATE)
    WHERE LTRIM(RTRIM(CAST(l.[LeadSource] AS VARCHAR(255)))) = 'CAD downloads'
      AND l.[Id] IS NOT NULL;
END;
GO

/* =============================================================
   02. WEEKLY WEBSITE LEADS FACT
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_marketing_website_leads_weekly]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_marketing_website_leads_weekly];

    INSERT INTO [dbo].[fact_marketing_website_leads_weekly]
    (
        closed_year, closed_week, week_key,
        week_start_date, week_ending_date,
        website_leads, source_row_count, calculation_timestamp
    )
    SELECT
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        COUNT(DISTINCT lead_id),
        COUNT_BIG(*),
        SYSUTCDATETIME()
    FROM [dbo].[fact_marketing_website_lead]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year, closed_week, week_key, week_start_date, week_ending_date;
END;
GO

/* =============================================================
   03. ENRICHED KPI RESULT

   No KPI code/target was supplied in the retrieved customer mapping.
   Proposed code below: Marketing-KPI-WL1.
   If dim_kpi already uses a different Marketing code, replace the one
   constant below. Target/RAG remain TBC if no matching dim_kpi row exists.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_marketing_website_leads]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[kpi_result_marketing_website_leads];

    ;WITH base AS
    (
        SELECT
            w.*,
            CAST('Marketing-KPI-WL1' AS VARCHAR(100)) AS kpi_code
        FROM [dbo].[fact_marketing_website_leads_weekly] w
    ), enriched AS
    (
        SELECT
            b.*,
            k.kpi_id,
            CAST(k.target_value AS DECIMAL(18,4)) AS target_value,
            UPPER(NULLIF(k.breach_direction,'')) AS breach_direction
        FROM base b
        LEFT JOIN [dbo].[dim_kpi] k
          ON k.kpi_code = b.kpi_code
    )
    INSERT INTO [dbo].[kpi_result_marketing_website_leads]
    (
        closed_year, closed_week, week_key,
        kpi_id, kpi_code, kpi_name, kpi_category,
        organisational_unit, department,
        measure, measure_name, uom,
        sign, sign_label, commentary,
        kpi_value, target_value, variance_value,
        performance_variance_value, breach_direction,
        rag_status, data_status,
        source_system, source_object, source_row_count,
        calculation_timestamp
    )
    SELECT
        closed_year,
        closed_week,
        week_key,
        kpi_id,
        kpi_code,
        'Website Leads',
        'Marketing',
        'Marketing',
        'Marketing',
        'Salesforce Leads with LeadSource = CAD downloads',
        'Website Leads',
        'Count',
        NULL,
        NULL,
        'Website leads created in the reporting week.',
        CAST(website_leads AS DECIMAL(18,4)),
        target_value,
        CASE WHEN target_value IS NULL THEN NULL
             ELSE CAST(website_leads AS DECIMAL(18,4)) - target_value END,
        CASE
          WHEN target_value IS NULL OR breach_direction IS NULL THEN NULL
          WHEN breach_direction = 'OVER' THEN target_value - CAST(website_leads AS DECIMAL(18,4))
          ELSE CAST(website_leads AS DECIMAL(18,4)) - target_value
        END,
        breach_direction,
        CASE
          WHEN target_value IS NULL OR breach_direction IS NULL THEN 'TBC'
          WHEN breach_direction = 'UNDER' AND website_leads >= target_value THEN 'G'
          WHEN breach_direction = 'UNDER' AND website_leads >= target_value * 0.95 THEN 'A'
          WHEN breach_direction = 'OVER' AND website_leads <= target_value THEN 'G'
          WHEN breach_direction = 'OVER' AND website_leads <= target_value * 1.05 THEN 'A'
          ELSE 'R'
        END,
        CASE WHEN target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Salesforce',
        'stg_salesforce.Lead',
        source_row_count,
        SYSUTCDATETIME()
    FROM enriched;
END;
GO

/* =============================================================
   04. OPTIONAL CANONICAL KPI PUBLICATION
   Assumes dbo.fact_kpi_result follows the common enriched contract.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_publish_marketing_website_leads]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [dbo].[fact_kpi_result]
    WHERE kpi_code = 'Marketing-KPI-WL1';

    INSERT INTO [dbo].[fact_kpi_result]
    SELECT *
    FROM [dbo].[kpi_result_marketing_website_leads];
END;
GO

/* =============================================================
   05. ORCHESTRATORS
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_marketing_website_leads]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_marketing_website_lead];
    EXEC [etl].[sp_build_fact_marketing_website_leads_weekly];
    EXEC [etl].[sp_build_kpi_result_marketing_website_leads];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_marketing_website_leads_and_publish]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_marketing_website_leads];
    EXEC [etl].[sp_publish_marketing_website_leads];
END;
GO

/* =============================================================
   INITIAL TESTS
   =============================================================
EXEC [etl].[sp_build_marketing_website_leads];

SELECT *
FROM [dbo].[fact_marketing_website_lead]
ORDER BY created_date, lead_id;

SELECT *
FROM [dbo].[fact_marketing_website_leads_weekly]
ORDER BY week_ending_date;

SELECT *
FROM [dbo].[kpi_result_marketing_website_leads]
ORDER BY closed_year, closed_week;

-- Source reconciliation by calendar date
SELECT
    CAST(TRY_CAST([CreatedDate] AS DATETIME2(6)) AS DATE) AS created_date,
    COUNT(DISTINCT CAST([Id] AS VARCHAR(255))) AS expected_website_leads
FROM [stg_salesforce].[Lead]
WHERE LTRIM(RTRIM(CAST([LeadSource] AS VARCHAR(255)))) = 'CAD downloads'
GROUP BY CAST(TRY_CAST([CreatedDate] AS DATETIME2(6)) AS DATE)
ORDER BY created_date;
*/
