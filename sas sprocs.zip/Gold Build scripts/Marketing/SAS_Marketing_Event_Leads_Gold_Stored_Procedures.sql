/*
SAS MARKETING - EVENT LEADS KPI
===============================
Customer mapping used:
  Salesforce Campaign + CampaignMember
  Campaign Type = 'Conference'
  CampaignMember.CreatedDate = reporting date

Architecture:
  [stg_salesforce].[Campaign]
             +
  [stg_salesforce].[CampaignMember]
             |
             v
  [dbo].[fact_marketing_event_lead]
             |
             v
  [dbo].[fact_marketing_event_leads_weekly]
             |
             v
  [dbo].[kpi_result_marketing_event_leads]
             |
             v
  [dbo].[fact_kpi_result]  -- optional publication

Assumed Salesforce staging fields:
  Campaign:       Id, Name, Type
  CampaignMember: Id, CampaignId, LeadId, ContactId, CreatedDate

KPI code and target were not confirmed in the supplied mapping.
Provisional KPI code: Marketing-KPI-EL1.
If dim_kpi does not contain this code, Target/RAG remain TBC.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO

IF OBJECT_ID('[dbo].[fact_marketing_event_lead]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_marketing_event_lead]
    (
        campaign_member_id       VARCHAR(255)  NOT NULL,
        campaign_id              VARCHAR(255)  NOT NULL,
        campaign_name            VARCHAR(500)  NULL,
        campaign_type            VARCHAR(255)  NULL,
        lead_id                  VARCHAR(255)  NULL,
        contact_id               VARCHAR(255)  NULL,
        member_created_timestamp DATETIME2(6)  NULL,
        member_created_date      DATE          NULL,
        date_key                 INT           NULL,
        closed_year              INT           NULL,
        closed_week              INT           NULL,
        week_key                 INT           NULL,
        week_start_date          DATE          NULL,
        week_ending_date         DATE          NULL,
        created_ts               DATETIME2(6)  NOT NULL,
        updated_ts               DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_marketing_event_leads_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_marketing_event_leads_weekly]
    (
        closed_year              INT           NOT NULL,
        closed_week              INT           NOT NULL,
        week_key                 INT           NOT NULL,
        week_start_date          DATE          NOT NULL,
        week_ending_date         DATE          NOT NULL,
        event_leads              BIGINT        NOT NULL,
        source_row_count         BIGINT        NOT NULL,
        calculation_timestamp    DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[kpi_result_marketing_event_leads]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[kpi_result_marketing_event_leads]
    (
        closed_year                   INT             NOT NULL,
        closed_week                   INT             NOT NULL,
        week_key                      INT             NOT NULL,
        kpi_id                        BIGINT          NULL,
        kpi_code                      VARCHAR(100)    NOT NULL,
        kpi_name                      VARCHAR(255)    NOT NULL,
        kpi_category                  VARCHAR(100)    NOT NULL,
        organisational_unit           VARCHAR(255)    NOT NULL,
        department                    VARCHAR(255)    NOT NULL,
        measure                       VARCHAR(500)    NULL,
        measure_name                  VARCHAR(500)    NULL,
        uom                           VARCHAR(50)     NULL,
        sign                          VARCHAR(100)    NULL,
        sign_label                    VARCHAR(100)    NULL,
        commentary                    VARCHAR(1000)   NULL,
        kpi_value                     DECIMAL(18,4)   NULL,
        target_value                  DECIMAL(18,4)   NULL,
        variance_value                DECIMAL(18,4)   NULL,
        performance_variance_value    DECIMAL(18,4)   NULL,
        breach_direction              VARCHAR(20)     NULL,
        rag_status                    VARCHAR(20)     NOT NULL,
        data_status                   VARCHAR(50)     NOT NULL,
        source_system                 VARCHAR(100)    NOT NULL,
        source_object                 VARCHAR(500)    NOT NULL,
        source_row_count              BIGINT          NOT NULL,
        calculation_timestamp         DATETIME2(6)    NOT NULL
    );
END;
GO

/* 01. Atomic CampaignMember fact for Conference campaigns */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_marketing_event_lead]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_marketing_event_lead];

    ;WITH source_rows AS
    (
        SELECT
            CAST(cm.[Id] AS VARCHAR(255)) AS campaign_member_id,
            CAST(cm.[CampaignId] AS VARCHAR(255)) AS campaign_id,
            CAST(c.[Name] AS VARCHAR(500)) AS campaign_name,
            CAST(c.[Type] AS VARCHAR(255)) AS campaign_type,
            CAST(cm.[LeadId] AS VARCHAR(255)) AS lead_id,
            CAST(cm.[ContactId] AS VARCHAR(255)) AS contact_id,
            TRY_CAST(cm.[CreatedDate] AS DATETIME2(6)) AS member_created_timestamp,
            CAST(TRY_CAST(cm.[CreatedDate] AS DATETIME2(6)) AS DATE) AS member_created_date,
            ROW_NUMBER() OVER
            (
                PARTITION BY CAST(cm.[Id] AS VARCHAR(255))
                ORDER BY TRY_CAST(cm.[CreatedDate] AS DATETIME2(6)) DESC
            ) AS rn
        FROM [stg_salesforce].[CampaignMember] cm
        INNER JOIN [stg_salesforce].[Campaign] c
          ON CAST(c.[Id] AS VARCHAR(255)) = CAST(cm.[CampaignId] AS VARCHAR(255))
        WHERE LTRIM(RTRIM(CAST(c.[Type] AS VARCHAR(255)))) = 'Conference'
          AND cm.[Id] IS NOT NULL
    )
    INSERT INTO [dbo].[fact_marketing_event_lead]
    (
        campaign_member_id,campaign_id,campaign_name,campaign_type,
        lead_id,contact_id,member_created_timestamp,member_created_date,
        date_key,closed_year,closed_week,week_key,week_start_date,
        week_ending_date,created_ts,updated_ts
    )
    SELECT
        s.campaign_member_id,s.campaign_id,s.campaign_name,s.campaign_type,
        s.lead_id,s.contact_id,s.member_created_timestamp,s.member_created_date,
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,
        d.week_start_date,d.week_end_date,SYSUTCDATETIME(),SYSUTCDATETIME()
    FROM source_rows s
    LEFT JOIN [dbo].[dim_date] d
      ON d.calendar_date = s.member_created_date
    WHERE s.rn = 1;
END;
GO

/* 02. Weekly Event Leads */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_marketing_event_leads_weekly]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_marketing_event_leads_weekly];

    INSERT INTO [dbo].[fact_marketing_event_leads_weekly]
    (
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        event_leads,source_row_count,calculation_timestamp
    )
    SELECT
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        COUNT(DISTINCT campaign_member_id),
        COUNT_BIG(*),
        SYSUTCDATETIME()
    FROM [dbo].[fact_marketing_event_lead]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;
END;
GO

/* 03. Enriched Marketing Event Leads KPI */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_marketing_event_leads]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[kpi_result_marketing_event_leads];

    ;WITH base AS
    (
        SELECT w.*, CAST('Marketing-KPI-EL1' AS VARCHAR(100)) AS kpi_code
        FROM [dbo].[fact_marketing_event_leads_weekly] w
    ), enriched AS
    (
        SELECT b.*,k.kpi_id,
               CAST(k.target_value AS DECIMAL(18,4)) AS target_value,
               UPPER(NULLIF(k.breach_direction,'')) AS breach_direction
        FROM base b
        LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code=b.kpi_code
    )
    INSERT INTO [dbo].[kpi_result_marketing_event_leads]
    SELECT
        closed_year,closed_week,week_key,kpi_id,kpi_code,
        'Event Leads','Marketing','Marketing','Marketing',
        'Salesforce Campaign Members for Conference campaigns',
        'Event Leads','Count',NULL,NULL,
        'CampaignMember.CreatedDate used as the reporting date.',
        CAST(event_leads AS DECIMAL(18,4)),target_value,
        CASE WHEN target_value IS NULL THEN NULL ELSE CAST(event_leads AS DECIMAL(18,4))-target_value END,
        CASE WHEN target_value IS NULL OR breach_direction IS NULL THEN NULL
             WHEN breach_direction='OVER' THEN target_value-CAST(event_leads AS DECIMAL(18,4))
             ELSE CAST(event_leads AS DECIMAL(18,4))-target_value END,
        breach_direction,
        CASE
          WHEN target_value IS NULL OR breach_direction IS NULL THEN 'TBC'
          WHEN breach_direction='UNDER' AND event_leads>=target_value THEN 'G'
          WHEN breach_direction='UNDER' AND event_leads>=target_value*0.95 THEN 'A'
          WHEN breach_direction='OVER' AND event_leads<=target_value THEN 'G'
          WHEN breach_direction='OVER' AND event_leads<=target_value*1.05 THEN 'A'
          ELSE 'R' END,
        CASE WHEN target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Salesforce','stg_salesforce.CampaignMember + stg_salesforce.Campaign',
        source_row_count,SYSUTCDATETIME()
    FROM enriched;
END;
GO

/* 04. Optional publication to canonical KPI result */
CREATE OR ALTER PROCEDURE [etl].[sp_publish_marketing_event_leads]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [dbo].[fact_kpi_result]
    WHERE kpi_code='Marketing-KPI-EL1';

    INSERT INTO [dbo].[fact_kpi_result]
    SELECT * FROM [dbo].[kpi_result_marketing_event_leads];
END;
GO

/* 05. Build without publishing */
CREATE OR ALTER PROCEDURE [etl].[sp_build_marketing_event_leads]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_marketing_event_lead];
    EXEC [etl].[sp_build_fact_marketing_event_leads_weekly];
    EXEC [etl].[sp_build_kpi_result_marketing_event_leads];
END;
GO

/* 06. Build and publish */
CREATE OR ALTER PROCEDURE [etl].[sp_build_marketing_event_leads_and_publish]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_marketing_event_leads];
    EXEC [etl].[sp_publish_marketing_event_leads];
END;
GO

/* INITIAL TESTS
EXEC [etl].[sp_build_marketing_event_leads];

SELECT * FROM [dbo].[fact_marketing_event_lead]
ORDER BY member_created_date,campaign_name,campaign_member_id;

SELECT * FROM [dbo].[fact_marketing_event_leads_weekly]
ORDER BY week_ending_date;

SELECT * FROM [dbo].[kpi_result_marketing_event_leads]
ORDER BY closed_year,closed_week;

-- Direct source reconciliation
SELECT
    CAST(TRY_CAST(cm.[CreatedDate] AS DATETIME2(6)) AS DATE) AS member_created_date,
    COUNT(DISTINCT CAST(cm.[Id] AS VARCHAR(255))) AS expected_event_leads
FROM [stg_salesforce].[CampaignMember] cm
INNER JOIN [stg_salesforce].[Campaign] c
  ON CAST(c.[Id] AS VARCHAR(255))=CAST(cm.[CampaignId] AS VARCHAR(255))
WHERE LTRIM(RTRIM(CAST(c.[Type] AS VARCHAR(255))))='Conference'
GROUP BY CAST(TRY_CAST(cm.[CreatedDate] AS DATETIME2(6)) AS DATE)
ORDER BY member_created_date;
*/
