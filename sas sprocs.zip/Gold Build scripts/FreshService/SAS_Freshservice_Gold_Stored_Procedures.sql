/*
SAS IT - FRESHSERVICE KPIs
Confirmed customer definitions:
  1. Tickets Closed On Time - Freshservice TicketsExport; exact PBIX numerator,
     denominator, status/date and SLA fields are not stated in retrieved evidence.
  2. Employee Satisfaction - Freshservice SurveyResponses; average score; remove
     duplicate/non-scored 'any comments' question rows; test reporting used last week.

Physical tables now present:
  freshservice_staging.tickets
  freshservice_staging.surveys

Because physical column names are not visible in the supplied evidence/screenshot, this
script uses explicit adapter contracts. Populate the adapters from the physical staging
columns once names are confirmed. Downstream facts/KPIs then require no redesign.
*/
IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO
IF SCHEMA_ID('etl_input') IS NULL EXEC('CREATE SCHEMA [etl_input]');
GO

IF OBJECT_ID('[etl_input].[freshservice_ticket_kpi_source]', 'U') IS NULL
CREATE TABLE [etl_input].[freshservice_ticket_kpi_source]
(
 ticket_id VARCHAR(255) NOT NULL,
 ticket_type VARCHAR(100) NULL,
 created_timestamp DATETIME2(6) NULL,
 closed_timestamp DATETIME2(6) NULL,
 reporting_date DATE NULL,
 is_closed BIT NULL,
 is_closed_on_time BIT NULL,
 source_row_count BIGINT NULL
);
GO

IF OBJECT_ID('[etl_input].[freshservice_survey_kpi_source]', 'U') IS NULL
CREATE TABLE [etl_input].[freshservice_survey_kpi_source]
(
 survey_response_id VARCHAR(255) NOT NULL,
 ticket_id VARCHAR(255) NULL,
 response_timestamp DATETIME2(6) NULL,
 reporting_date DATE NULL,
 question VARCHAR(1000) NULL,
 score DECIMAL(18,4) NULL,
 source_row_count BIGINT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_it_freshservice_ticket_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_it_freshservice_ticket_weekly]
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 ticket_volume BIGINT NOT NULL, closed_tickets BIGINT NOT NULL,
 closed_on_time BIGINT NOT NULL, sla_compliance_rate DECIMAL(18,6) NULL,
 source_row_count BIGINT NOT NULL, calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_it_freshservice_survey_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_it_freshservice_survey_weekly]
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 scored_responses BIGINT NOT NULL, average_score DECIMAL(18,4) NULL,
 source_row_count BIGINT NOT NULL, calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[kpi_result_it_freshservice]', 'U') IS NULL
SELECT TOP 0 * INTO [dbo].[kpi_result_it_freshservice] FROM [dbo].[fact_kpi_result];
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_it_freshservice_ticket_weekly]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE [dbo].[fact_it_freshservice_ticket_weekly];
 INSERT INTO [dbo].[fact_it_freshservice_ticket_weekly]
 SELECT d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        COUNT(DISTINCT s.ticket_id),
        COUNT(DISTINCT CASE WHEN s.is_closed=1 THEN s.ticket_id END),
        COUNT(DISTINCT CASE WHEN s.is_closed=1 AND s.is_closed_on_time=1 THEN s.ticket_id END),
        CAST(CASE WHEN COUNT(DISTINCT CASE WHEN s.is_closed=1 THEN s.ticket_id END)>0
                  THEN 1.0*COUNT(DISTINCT CASE WHEN s.is_closed=1 AND s.is_closed_on_time=1 THEN s.ticket_id END)
                       /COUNT(DISTINCT CASE WHEN s.is_closed=1 THEN s.ticket_id END) END AS DECIMAL(18,6)),
        SUM(COALESCE(s.source_row_count,1)),SYSUTCDATETIME()
 FROM [etl_input].[freshservice_ticket_kpi_source] s
 JOIN [dbo].[dim_date] d ON d.calendar_date=s.reporting_date
 GROUP BY d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_it_freshservice_survey_weekly]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE [dbo].[fact_it_freshservice_survey_weekly];
 INSERT INTO [dbo].[fact_it_freshservice_survey_weekly]
 SELECT d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        COUNT(DISTINCT s.survey_response_id),CAST(AVG(s.score) AS DECIMAL(18,4)),
        SUM(COALESCE(s.source_row_count,1)),SYSUTCDATETIME()
 FROM [etl_input].[freshservice_survey_kpi_source] s
 JOIN [dbo].[dim_date] d ON d.calendar_date=s.reporting_date
 WHERE s.score IS NOT NULL
   AND LOWER(LTRIM(RTRIM(COALESCE(s.question,''))))<>'any comments'
 GROUP BY d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_it_tickets_closed_on_time]
AS
BEGIN
 SET NOCOUNT ON;
 DELETE FROM dbo.kpi_result_it_freshservice WHERE kpi_code='IT-KPI-D1';
 INSERT INTO dbo.kpi_result_it_freshservice
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,'IT-KPI-D1',
        'Tickets Closed On Time','Delivery','IT','IT','Freshservice tickets closed within SLA',
        'Tickets Closed On Time','Percentage',NULL,NULL,
        CONCAT('Closed=',w.closed_tickets,', closed on time=',w.closed_on_time,
               '. Adapter mapping must reproduce PBIX logic.'),
        w.sla_compliance_rate,CAST(k.target_value AS DECIMAL(18,4)),
        CASE WHEN k.target_value IS NULL OR w.sla_compliance_rate IS NULL THEN NULL ELSE w.sla_compliance_rate-k.target_value END,
        CASE WHEN k.target_value IS NULL OR w.sla_compliance_rate IS NULL OR k.breach_direction IS NULL THEN NULL
             WHEN UPPER(k.breach_direction)='OVER' THEN k.target_value-w.sla_compliance_rate
             ELSE w.sla_compliance_rate-k.target_value END,
        UPPER(k.breach_direction),
        CASE WHEN w.sla_compliance_rate IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN 'TBC'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.sla_compliance_rate>=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.sla_compliance_rate>=k.target_value*0.95 THEN 'A'
             WHEN UPPER(k.breach_direction)='OVER' AND w.sla_compliance_rate<=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='OVER' AND w.sla_compliance_rate<=k.target_value*1.05 THEN 'A'
             ELSE 'R' END,
        CASE WHEN w.sla_compliance_rate IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Freshservice','freshservice_staging.tickets via etl_input adapter',w.source_row_count,SYSUTCDATETIME()
 FROM dbo.fact_it_freshservice_ticket_weekly w
 LEFT JOIN dbo.dim_kpi k ON k.kpi_code='IT-KPI-D1';
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_it_employee_satisfaction]
AS
BEGIN
 SET NOCOUNT ON;
 DELETE FROM dbo.kpi_result_it_freshservice WHERE kpi_code='IT-KPI-Q1';
 INSERT INTO dbo.kpi_result_it_freshservice
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,'IT-KPI-Q1',
        'Employee Satisfaction','Quality','IT','IT','Average scored Freshservice survey response',
        'Employee Satisfaction','Score',NULL,NULL,
        CONCAT('Scored responses=',w.scored_responses,'; any comments rows excluded.'),
        w.average_score,CAST(k.target_value AS DECIMAL(18,4)),
        CASE WHEN k.target_value IS NULL OR w.average_score IS NULL THEN NULL ELSE w.average_score-k.target_value END,
        CASE WHEN k.target_value IS NULL OR w.average_score IS NULL OR k.breach_direction IS NULL THEN NULL
             WHEN UPPER(k.breach_direction)='OVER' THEN k.target_value-w.average_score
             ELSE w.average_score-k.target_value END,
        UPPER(k.breach_direction),
        CASE WHEN w.average_score IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN 'TBC'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.average_score>=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.average_score>=k.target_value*0.95 THEN 'A'
             WHEN UPPER(k.breach_direction)='OVER' AND w.average_score<=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='OVER' AND w.average_score<=k.target_value*1.05 THEN 'A'
             ELSE 'R' END,
        CASE WHEN w.average_score IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'Freshservice','freshservice_staging.surveys via etl_input adapter',w.source_row_count,SYSUTCDATETIME()
 FROM dbo.fact_it_freshservice_survey_weekly w
 LEFT JOIN dbo.dim_kpi k ON k.kpi_code='IT-KPI-Q1';
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_freshservice_kpis]
AS
BEGIN
 EXEC etl.sp_build_fact_it_freshservice_ticket_weekly;
 EXEC etl.sp_build_fact_it_freshservice_survey_weekly;
 EXEC etl.sp_build_kpi_it_tickets_closed_on_time;
 EXEC etl.sp_build_kpi_it_employee_satisfaction;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_publish_freshservice_kpis]
AS
BEGIN
 DELETE FROM dbo.fact_kpi_result WHERE kpi_code IN ('IT-KPI-D1','IT-KPI-Q1');
 INSERT INTO dbo.fact_kpi_result SELECT * FROM dbo.kpi_result_it_freshservice;
END;
GO

/* COLUMN DISCOVERY - run these before populating adapters:
SELECT TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA='freshservice_staging' AND TABLE_NAME IN ('tickets','surveys')
ORDER BY TABLE_NAME,ORDINAL_POSITION;
*/
