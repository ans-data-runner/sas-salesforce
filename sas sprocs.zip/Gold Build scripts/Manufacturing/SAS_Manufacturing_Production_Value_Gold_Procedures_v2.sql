/*
SAS MANUFACTURING PRODUCTION VALUE - GOLD WAREHOUSE BUILD V2
============================================================
Purpose
  Build Production Value and Production Value per Employee from Gold staging,
  then publish enriched KPI rows.

Confirmed source logic
  Production Value is the union of:
    1. SyteLine job transactions; and
    2. non-inventory invoiced lines, excluding carriage.
  Weekly value = SUM(qty_moved * transfer_price), grouped by warehouse and Friday week end.

Expected staging schemas
  stg_syteline: direct staged copies of SyteLine source tables.
  stg_hr: landed/cleansed HR PIT export.

Important test assumption
  The HR PIT physical contract has not yet been confirmed. This script assumes:
    stg_hr.hr_pit(snapshot_date, department_code, employee_id, fte_value)
  Rename these four references when the actual landed contract is known.

Implementation choices
  - Simple full refresh: TRUNCATE + INSERT.
  - No backup, preview, overwrite protection or test/live switch.
  - Canonical date attributes are resolved from dbo.dim_date.
  - Transfer-price selection follows the supplied customer SQL.
  - Production Value source is restricted to site_ref = 'RBMW'.
*/


/* =============================================================
   HR PIT STAGING TABLE
   Purpose:
     Temporary/initial staging contract for the SAS
     Manufacturing Production Value per Employee KPI.

   This table can remain empty until the HR PIT feed is available. need to review with Rob Samuel for HR data.
   ============================================================= */

IF SCHEMA_ID('stg_hr') IS NULL
    EXEC('CREATE SCHEMA [stg_hr]');
GO


IF OBJECT_ID('[stg_hr].[hr_pit]', 'U') IS NULL
BEGIN

    CREATE TABLE [stg_hr].[hr_pit]
    (
        snapshot_date       DATE            NULL,
        department_code     VARCHAR(100)    NULL,
        employee_id         VARCHAR(255)    NULL,
        fte_value           DECIMAL(18,4)   NULL
    );

END;
GO

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO

/* =============================================================
   00. GOLD OUTPUT TABLES
   ============================================================= */
IF OBJECT_ID('[dbo].[fact_syteline_production_value_detail]', 'U') IS NULL
CREATE TABLE [dbo].[fact_syteline_production_value_detail]
(
    production_value_detail_id BIGINT         NOT NULL,
    source_stream              VARCHAR(30)    NOT NULL,
    source_site_ref            VARCHAR(20)    NOT NULL,
    source_job                 VARCHAR(100)   NULL,
    source_suffix              INT            NULL,
    transaction_date           DATE           NOT NULL,
    warehouse_prefix           VARCHAR(10)    NOT NULL,
    quantity_moved             DECIMAL(18,4)  NULL,
    transfer_price             DECIMAL(18,6)  NULL,
    transfer_value             DECIMAL(18,4)  NULL,
    date_key                   INT            NULL,
    closed_year                INT            NULL,
    closed_week                INT            NULL,
    week_key                   INT            NULL,
    week_start_date            DATE           NULL,
    week_ending_date           DATE           NULL,
    created_utc                DATETIME2(6)   NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_syteline_production_value_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_syteline_production_value_weekly]
(
    closed_year                INT            NOT NULL,
    closed_week                INT            NOT NULL,
    week_key                   INT            NOT NULL,
    week_start_date            DATE           NOT NULL,
    week_ending_date           DATE           NOT NULL,
    warehouse_prefix           VARCHAR(10)    NOT NULL,
    site_name                  VARCHAR(100)   NOT NULL,
    production_value           DECIMAL(18,4)  NULL,
    source_row_count           BIGINT         NOT NULL,
    calculation_timestamp      DATETIME2(6)   NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_manufacturing_direct_headcount_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_manufacturing_direct_headcount_weekly]
(
    closed_year                    INT            NOT NULL,
    closed_week                    INT            NOT NULL,
    week_key                       INT            NOT NULL,
    week_ending_date               DATE           NOT NULL,
    warehouse_prefix               VARCHAR(10)    NOT NULL,
    headcount_snapshot_date        DATE           NULL,
    employee_count                 BIGINT         NULL,
    direct_manufacturing_headcount DECIMAL(18,4)  NULL,
    source_row_count               BIGINT         NOT NULL,
    calculation_timestamp          DATETIME2(6)   NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_manufacturing_production_value_per_employee_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_manufacturing_production_value_per_employee_weekly]
(
    closed_year                    INT            NOT NULL,
    closed_week                    INT            NOT NULL,
    week_key                       INT            NOT NULL,
    week_start_date                DATE           NOT NULL,
    week_ending_date               DATE           NOT NULL,
    warehouse_prefix               VARCHAR(10)    NOT NULL,
    site_name                      VARCHAR(100)   NOT NULL,
    production_value               DECIMAL(18,4)  NULL,
    headcount_snapshot_date        DATE           NULL,
    employee_count                 BIGINT         NULL,
    direct_manufacturing_headcount DECIMAL(18,4)  NULL,
    production_value_per_employee  DECIMAL(18,4)  NULL,
    source_row_count               BIGINT         NOT NULL,
    calculation_timestamp          DATETIME2(6)   NOT NULL
);
GO

IF OBJECT_ID('[dbo].[kpi_result_manufacturing_value]', 'U') IS NULL
CREATE TABLE [dbo].[kpi_result_manufacturing_value]
(
    closed_year                   INT            NOT NULL,
    closed_week                   INT            NOT NULL,
    week_key                      INT            NOT NULL,
    kpi_id                        BIGINT         NULL,
    kpi_code                      VARCHAR(100)   NOT NULL,
    kpi_name                      VARCHAR(255)   NOT NULL,
    kpi_category                  VARCHAR(100)   NOT NULL,
    organisational_unit           VARCHAR(255)   NOT NULL,
    department                    VARCHAR(255)   NOT NULL,
    measure                       VARCHAR(500)   NULL,
    measure_name                  VARCHAR(500)   NULL,
    uom                           VARCHAR(50)    NULL,
    sign                          VARCHAR(100)   NULL,
    sign_label                    VARCHAR(100)   NULL,
    commentary                    VARCHAR(1000)  NULL,
    kpi_value                     DECIMAL(18,4)  NULL,
    target_value                  DECIMAL(18,4)  NULL,
    variance_value                DECIMAL(18,4)  NULL,
    performance_variance_value    DECIMAL(18,4)  NULL,
    breach_direction              VARCHAR(20)    NULL,
    rag_status                    VARCHAR(20)    NOT NULL,
    data_status                   VARCHAR(50)    NOT NULL,
    source_system                 VARCHAR(100)   NOT NULL,
    source_object                 VARCHAR(500)   NOT NULL,
    source_row_count              BIGINT         NOT NULL,
    calculation_timestamp         DATETIME2(6)   NOT NULL
);
GO

/* =============================================================
   01. PRODUCTION VALUE DETAIL
   Reverse-engineered from the supplied customer SQL.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_syteline_production_value_detail]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_syteline_production_value_detail];

    DECLARE @datefrom DATE = DATEFROMPARTS(YEAR(GETDATE()),1,1);
    DECLARE @dateto   DATE = CAST(GETDATE() AS DATE);
    DECLARE @load_utc DATETIME2(6) = SYSUTCDATETIME();

    ;WITH source_union AS
    (
        /* Job transactions */
        SELECT
            source_stream   = CAST('JOB_TRANSACTION' AS VARCHAR(30)),
            source_site_ref = CAST(t.site_ref AS VARCHAR(20)),
            source_job      = CAST(t.job AS VARCHAR(100)),
            source_suffix   = CAST(t.suffix AS INT),
            transaction_date= CAST(t.trans_date AS DATE),
            warehouse_prefix= CAST(t.whse AS VARCHAR(10)),
            quantity_moved  = CAST(t.qty_moved AS DECIMAL(18,4)),
            transfer_price  = CAST(
                CASE
                  WHEN COALESCE(coi.uf_trnprice,ci.uf_trnprice,ip.unit_price6,0)=0
                  THEN COALESCE(ip2.unit_price6,0)
                  ELSE COALESCE(coi.uf_trnprice,ci.uf_trnprice,ip.unit_price6,0)
                END AS DECIMAL(18,6))
        FROM [stg_syteline].[jobtran_mst] t
        INNER JOIN [stg_syteline].[job_mst] j
          ON j.job=t.job AND j.suffix=t.suffix AND j.site_ref=t.site_ref
        INNER JOIN [stg_syteline].[item_mst] i
          ON i.item=j.item AND i.site_ref=j.site_ref
        INNER JOIN [stg_syteline].[prodcode_mst] pc
          ON pc.product_code=i.product_code AND pc.site_ref=i.site_ref
        LEFT JOIN [stg_syteline].[coitem_mst] ci
          ON ci.co_num=j.ord_num AND ci.co_line=j.ord_line
         AND ci.co_release=j.ord_release AND ci.site_ref=j.site_ref
        LEFT JOIN [stg_syteline].[coitem_mst] coi
          ON coi.co_num=j.uf_oldrefnum AND coi.co_line=j.uf_oldreflinsuf
         AND coi.co_release=j.Uf_OldRefRelease AND coi.site_ref=j.site_ref
        LEFT JOIN [stg_syteline].[itemprice_mst] ip
          ON ip.item=j.item AND ip.effect_date<=t.trans_date AND ip.site_ref=t.site_ref
        LEFT JOIN [stg_syteline].[itemprice_mst] ip1
          ON ip1.item=j.item AND ip1.effect_date<=t.trans_date
         AND ip1.effect_date>ip.effect_date AND ip1.site_ref=ip.site_ref
        LEFT JOIN [stg_syteline].[itemprice_mst] ip2
          ON ip2.item=j.item AND ip2.site_ref=j.site_ref
         AND ip2.unit_price6>0 AND ip2.effect_date<=GETDATE()
        LEFT JOIN [stg_syteline].[itemprice_mst] ip3
          ON ip3.item=j.item AND ip3.site_ref=j.site_ref
         AND ip3.unit_price6>0 AND ip3.effect_date<=GETDATE()
         AND ip3.effect_date>ip2.effect_date
        WHERE t.site_ref='RBMW'
          AND t.trans_date>=@datefrom AND t.trans_date<DATEADD(DAY,1,@dateto)
          AND t.trans_type IN ('M','F','R')
          AND t.suffix=0
          AND t.job NOT LIKE 'JC%'
          AND t.loc IS NOT NULL
          AND (j.ord_num IS NOT NULL OR pc.product_code LIKE 'BEFG%' OR pc.product_code LIKE 'MBFG%')
          AND ip1.effect_date IS NULL
          AND ip3.effect_date IS NULL

        UNION ALL

        /* Non-inventory invoiced lines */
        SELECT
            CAST('NON_INVENTORY_INVOICE' AS VARCHAR(30)),
            CAST(itm.site_ref AS VARCHAR(20)),
            CAST(ini.co_num AS VARCHAR(100)),
            CAST(ini.co_line AS INT),
            CAST(inh.inv_date AS DATE),
            CAST(LEFT(itm.product_code,2) AS VARCHAR(10)),
            CAST(ini.qty_invoiced AS DECIMAL(18,4)),
            CAST(CASE
              WHEN inh.bill_type='N' AND ini.qty_invoiced>0 THEN 0
              WHEN COALESCE(coi.uf_trnprice,ip.unit_price6,0)=0 THEN COALESCE(ip2.unit_price6,0)
              ELSE COALESCE(coi.uf_trnprice,ip.unit_price6,0)
            END AS DECIMAL(18,6))
        FROM [stg_syteline].[non_inventory_item_mst] itm
        INNER JOIN [stg_syteline].[prodcode_mst] pc
          ON pc.product_code=itm.product_code AND pc.site_ref=itm.site_ref
        INNER JOIN [stg_syteline].[inv_item_mst] ini
          ON ini.item=itm.item AND ini.site_ref=itm.site_ref
        INNER JOIN [stg_syteline].[inv_hdr_mst] inh
          ON inh.inv_num=ini.inv_num AND inh.site_ref=ini.site_ref
        INNER JOIN [stg_syteline].[coitem_mst] coi
          ON coi.co_num=ini.co_num AND coi.co_line=ini.co_line
         AND coi.co_release=ini.co_release AND coi.site_ref=ini.site_ref
        LEFT JOIN [stg_syteline].[itemprice_mst] ip
          ON ip.item=ini.item AND ip.effect_date<=inh.inv_date AND ip.site_ref=ini.site_ref
        LEFT JOIN [stg_syteline].[itemprice_mst] ip1
          ON ip1.item=ini.item AND ip1.effect_date<=inh.inv_date
         AND ip1.effect_date>ip.effect_date AND ip1.site_ref=ip.site_ref
        LEFT JOIN [stg_syteline].[itemprice_mst] ip2
          ON ip2.item=ini.item AND ip2.site_ref=ini.site_ref
         AND ip2.unit_price6>0 AND ip2.effect_date<=GETDATE()
        LEFT JOIN [stg_syteline].[itemprice_mst] ip3
          ON ip3.item=ini.item AND ip3.site_ref=ini.site_ref
         AND ip3.unit_price6>0 AND ip3.effect_date<=GETDATE()
         AND ip3.effect_date>ip2.effect_date
        WHERE itm.site_ref='RBMW'
          AND LEFT(itm.product_code,2) IN ('BE','MB')
          AND itm.product_code NOT LIKE '%CAR%'
          AND inh.inv_date>=@datefrom AND inh.inv_date<DATEADD(DAY,1,@dateto)
          AND ip1.effect_date IS NULL
          AND ip3.effect_date IS NULL
    ), shaped AS
    (
        SELECT s.*, d.date_key, d.customer_year, d.customer_week_no,
               d.week_key, d.week_start_date, d.week_end_date
        FROM source_union s
        LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=s.transaction_date
    )
    INSERT INTO [dbo].[fact_syteline_production_value_detail]
    SELECT
        CONVERT(BIGINT,SUBSTRING(HASHBYTES('SHA2_256',CONCAT(source_stream,'|',source_site_ref,'|',source_job,'|',source_suffix,'|',CONVERT(VARCHAR(10),transaction_date,23),'|',warehouse_prefix,'|',quantity_moved,'|',transfer_price)),1,8))
          & CONVERT(BIGINT,9223372036854775807),
        source_stream,source_site_ref,source_job,source_suffix,transaction_date,
        warehouse_prefix,quantity_moved,transfer_price,
        CAST(quantity_moved*transfer_price AS DECIMAL(18,4)),
        date_key,customer_year,customer_week_no,week_key,
        week_start_date,week_end_date,@load_utc
    FROM shaped
    WHERE warehouse_prefix IN ('BE','MB');
END;
GO

/* =============================================================
   02. WEEKLY PRODUCTION VALUE
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_syteline_production_value_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_syteline_production_value_weekly];

    INSERT INTO [dbo].[fact_syteline_production_value_weekly]
    SELECT
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        warehouse_prefix,
        CASE warehouse_prefix WHEN 'BE' THEN 'Bridgend' WHEN 'MB' THEN 'Maybole' END,
        CAST(SUM(transfer_value) AS DECIMAL(18,4)),
        COUNT_BIG(*),
        SYSUTCDATETIME()
    FROM [dbo].[fact_syteline_production_value_detail]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,warehouse_prefix;
END;
GO

/* =============================================================
   03. DIRECT MANUFACTURING HEADCOUNT
   Latest PIT snapshot on or before each production week end.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_manufacturing_direct_headcount_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_manufacturing_direct_headcount_weekly];

    ;WITH hc AS
    (
        SELECT CAST(snapshot_date AS DATE) snapshot_date,
               UPPER(LTRIM(RTRIM(CAST(department_code AS VARCHAR(100))))) department_code,
               LTRIM(RTRIM(CAST(employee_id AS VARCHAR(255)))) employee_id,
               CAST(COALESCE(fte_value,1.0) AS DECIMAL(18,4)) fte_value,
               CASE
                 WHEN UPPER(LTRIM(RTRIM(CAST(department_code AS VARCHAR(100))))) IN
                 ('ALUGRID','BAMADA','BASSEM2SP','BASSEMBLY','BASSEMBLY2','BBOXMAKER','BESUBLIM','BINSULAT','BPAINTLINE','BPRESS','BRAKEPRESS','BSLITTER','BWEMO','CHILLED','MANUBE','PERFORAT','RAS-SALV','ROLLFORM','WIDGETS','WOODSHOP') THEN 'BE'
                 WHEN UPPER(LTRIM(RTRIM(CAST(department_code AS VARCHAR(100))))) IN
                 ('MBASSY','MBBP','MBCNC','MBDRESS','MBPAINT','MBWELD') THEN 'MB'
               END warehouse_prefix
        FROM [stg_hr].[hr_pit]
        WHERE snapshot_date IS NOT NULL AND department_code IS NOT NULL AND employee_id IS NOT NULL
    ), weeks AS
    (
        SELECT DISTINCT closed_year,closed_week,week_key,week_ending_date,warehouse_prefix
        FROM [dbo].[fact_syteline_production_value_weekly]
    ), latest AS
    (
        SELECT w.*,MAX(h.snapshot_date) headcount_snapshot_date
        FROM weeks w LEFT JOIN hc h
          ON h.warehouse_prefix=w.warehouse_prefix AND h.snapshot_date<=w.week_ending_date
        GROUP BY w.closed_year,w.closed_week,w.week_key,w.week_ending_date,w.warehouse_prefix
    )
    INSERT INTO [dbo].[fact_manufacturing_direct_headcount_weekly]
    SELECT l.closed_year,l.closed_week,l.week_key,l.week_ending_date,l.warehouse_prefix,
           l.headcount_snapshot_date,COUNT(DISTINCT h.employee_id),
           CAST(SUM(h.fte_value) AS DECIMAL(18,4)),COUNT_BIG(h.employee_id),SYSUTCDATETIME()
    FROM latest l LEFT JOIN hc h
      ON h.warehouse_prefix=l.warehouse_prefix AND h.snapshot_date=l.headcount_snapshot_date
    GROUP BY l.closed_year,l.closed_week,l.week_key,l.week_ending_date,l.warehouse_prefix,l.headcount_snapshot_date;
END;
GO

/* =============================================================
   04. PRODUCTION VALUE PER EMPLOYEE
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_manufacturing_production_value_per_employee_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_manufacturing_production_value_per_employee_weekly];

    INSERT INTO [dbo].[fact_manufacturing_production_value_per_employee_weekly]
    SELECT p.closed_year,p.closed_week,p.week_key,p.week_start_date,p.week_ending_date,
           p.warehouse_prefix,p.site_name,p.production_value,h.headcount_snapshot_date,
           h.employee_count,h.direct_manufacturing_headcount,
           CAST(CASE WHEN h.direct_manufacturing_headcount>0
                     THEN p.production_value/h.direct_manufacturing_headcount END AS DECIMAL(18,4)),
           p.source_row_count+COALESCE(h.source_row_count,0),SYSUTCDATETIME()
    FROM [dbo].[fact_syteline_production_value_weekly] p
    LEFT JOIN [dbo].[fact_manufacturing_direct_headcount_weekly] h
      ON h.week_key=p.week_key AND h.warehouse_prefix=p.warehouse_prefix;
END;
GO

/* =============================================================
   05. ENRICHED KPI RESULTS
   Four outputs: BE/MB Production Value and BE/MB Value per Employee.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_manufacturing_value]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[kpi_result_manufacturing_value];

    ;WITH values_union AS
    (
        SELECT p.closed_year,p.closed_week,p.week_key,p.warehouse_prefix,
               CASE p.warehouse_prefix WHEN 'BE' THEN 'Bridgend Manuf-KPI P1' ELSE 'Maybole Manuf-KPI P1' END kpi_code,
               CAST('Production Value' AS VARCHAR(255)) kpi_name,
               CAST('Productivity' AS VARCHAR(100)) kpi_category,
               p.production_value kpi_value,p.source_row_count,
               CAST('dbo.fact_syteline_production_value_weekly' AS VARCHAR(500)) source_object,
               CAST(NULL AS VARCHAR(1000)) commentary
        FROM [dbo].[fact_syteline_production_value_weekly] p
        UNION ALL
        SELECT p.closed_year,p.closed_week,p.week_key,p.warehouse_prefix,
               CASE p.warehouse_prefix WHEN 'BE' THEN 'Bridgend Manuf-KPI C1' ELSE 'Maybole Manuf-KPI C1' END,
               'Production Value per Employee','Cost',p.production_value_per_employee,p.source_row_count,
               'dbo.fact_manufacturing_production_value_per_employee_weekly',
               CONCAT('Production Value=',CAST(p.production_value AS VARCHAR(50)),', Headcount=',CAST(p.direct_manufacturing_headcount AS VARCHAR(50)))
        FROM [dbo].[fact_manufacturing_production_value_per_employee_weekly] p
    ), enriched AS
    (
        SELECT v.*,k.kpi_id,CAST(k.target_value AS DECIMAL(18,4)) target_value,
               UPPER(k.breach_direction) breach_direction
        FROM values_union v LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code=v.kpi_code
    )
    INSERT INTO [dbo].[kpi_result_manufacturing_value]
    SELECT closed_year,closed_week,week_key,kpi_id,kpi_code,kpi_name,kpi_category,
           CASE warehouse_prefix WHEN 'BE' THEN 'Manufacturing Bridgend' ELSE 'Manufacturing Maybole' END,
           CASE warehouse_prefix WHEN 'BE' THEN 'Manufacturing Bridgend' ELSE 'Manufacturing Maybole' END,
           CASE WHEN kpi_name='Production Value' THEN 'From SyteLine - Production Value' ELSE 'Production output / Heads in direct manufacturing' END,
           CASE WHEN kpi_name='Production Value' THEN 'From SyteLine - Production Value' ELSE 'Production output / Heads in direct manufacturing' END,
           '£''s',NULL,NULL,commentary,kpi_value,target_value,
           CASE WHEN target_value IS NULL OR kpi_value IS NULL THEN NULL ELSE kpi_value-target_value END,
           CASE WHEN target_value IS NULL OR kpi_value IS NULL THEN NULL
                WHEN breach_direction='OVER' THEN target_value-kpi_value ELSE kpi_value-target_value END,
           breach_direction,
           CASE WHEN kpi_value IS NULL THEN 'No Data'
                WHEN target_value IS NULL OR breach_direction IS NULL THEN 'TBC'
                WHEN breach_direction='UNDER' AND kpi_value>=target_value THEN 'G'
                WHEN breach_direction='UNDER' AND kpi_value>=target_value*0.95 THEN 'A'
                WHEN breach_direction='OVER' AND kpi_value<=target_value THEN 'G'
                WHEN breach_direction='OVER' AND kpi_value<=target_value*1.05 THEN 'A'
                ELSE 'R' END,
           CASE WHEN kpi_value IS NULL THEN 'No Data'
                WHEN target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
           CASE WHEN kpi_name='Production Value' THEN 'SyteLine' ELSE 'SyteLine + HR PIT' END,
           source_object,source_row_count,SYSUTCDATETIME()
    FROM enriched;
END;
GO

/* =============================================================
   06. PUBLISH TO CANONICAL KPI FACT
   Requires dbo.fact_kpi_result with the same enriched column order.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_publish_manufacturing_value_kpis]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [dbo].[fact_kpi_result]
    WHERE kpi_code IN ('Bridgend Manuf-KPI P1','Maybole Manuf-KPI P1','Bridgend Manuf-KPI C1','Maybole Manuf-KPI C1');

    INSERT INTO [dbo].[fact_kpi_result]
    SELECT * FROM [dbo].[kpi_result_manufacturing_value];
END;
GO

/* =============================================================
   07. BUILD ORCHESTRATORS
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_manufacturing_production_value]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_syteline_production_value_detail];
    EXEC [etl].[sp_build_fact_syteline_production_value_weekly];
    EXEC [etl].[sp_build_kpi_result_manufacturing_value];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_manufacturing_production_value_per_employee]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_manufacturing_direct_headcount_weekly];
    EXEC [etl].[sp_build_fact_manufacturing_production_value_per_employee_weekly];
    EXEC [etl].[sp_build_kpi_result_manufacturing_value];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_manufacturing_value_kpis_all]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_syteline_production_value_detail];
    EXEC [etl].[sp_build_fact_syteline_production_value_weekly];
    EXEC [etl].[sp_build_fact_manufacturing_direct_headcount_weekly];
    EXEC [etl].[sp_build_fact_manufacturing_production_value_per_employee_weekly];
    EXEC [etl].[sp_build_kpi_result_manufacturing_value];
    EXEC [etl].[sp_publish_manufacturing_value_kpis];
END;
GO

/* =============================================================
   08. TEST QUERIES
   =============================================================
EXEC [etl].[sp_build_manufacturing_production_value];
SELECT * FROM [dbo].[fact_syteline_production_value_weekly] ORDER BY week_ending_date,warehouse_prefix;

-- Run this only after stg_hr.hr_pit has been mapped.
EXEC [etl].[sp_build_manufacturing_production_value_per_employee];
SELECT * FROM [dbo].[fact_manufacturing_production_value_per_employee_weekly] ORDER BY week_ending_date,warehouse_prefix;

-- Full publication once dbo.fact_kpi_result is available.
EXEC [etl].[sp_build_manufacturing_value_kpis_all];
*/
