/*
SAS EHS - SAFETYCULTURE VISUAL INSPECTION KPIs
Source: safety_culture_staging.inspections
Confirmed fields/rules from customer mapping:
  Delivery: COUNT(audit_id) by conducted_on reporting week
  Quality:  AVG(score_percentage) by conducted_on reporting week

Expected source columns:
  audit_id, conducted_on, score_percentage

If physical names differ, amend only the source CTE in
etl.sp_build_fact_ehs_visual_inspection.
*/
IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO

IF OBJECT_ID('[dbo].[fact_ehs_visual_inspection]', 'U') IS NULL
CREATE TABLE [dbo].[fact_ehs_visual_inspection]
(
 audit_id VARCHAR(255) NOT NULL,
 conducted_timestamp DATETIME2(6) NULL,
 conducted_date DATE NULL,
 score_percentage DECIMAL(18,6) NULL,
 date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
 week_start_date DATE NULL, week_ending_date DATE NULL,
 created_ts DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_ehs_visual_inspection_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_ehs_visual_inspection_weekly]
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 inspection_count BIGINT NOT NULL, scored_inspection_count BIGINT NOT NULL,
 average_pass_rate DECIMAL(18,6) NULL, source_row_count BIGINT NOT NULL,
 calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[kpi_result_ehs_safetyculture]', 'U') IS NULL
SELECT TOP 0 * INTO [dbo].[kpi_result_ehs_safetyculture]
FROM [dbo].[fact_kpi_result];
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_ehs_visual_inspection]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE [dbo].[fact_ehs_visual_inspection];

 ;WITH src AS
 (
  SELECT CAST([audit_id] AS VARCHAR(255)) audit_id,
         TRY_CAST([conducted_on] AS DATETIME2(6)) conducted_timestamp,
         TRY_CAST([score_percentage] AS DECIMAL(18,6)) score_raw,
         ROW_NUMBER() OVER
           (PARTITION BY CAST([audit_id] AS VARCHAR(255))
            ORDER BY TRY_CAST([conducted_on] AS DATETIME2(6)) DESC) rn
  FROM [safety_culture_staging].[inspections]
  WHERE [audit_id] IS NOT NULL AND [conducted_on] IS NOT NULL
 ), shaped AS
 (
  SELECT audit_id,conducted_timestamp,CAST(conducted_timestamp AS DATE) conducted_date,
         /* Mitigation: support either 0-1 or 0-100 source scale. */
         CAST(CASE WHEN score_raw>1 THEN score_raw/100.0 ELSE score_raw END AS DECIMAL(18,6)) score_percentage
  FROM src WHERE rn=1
 )
 INSERT INTO [dbo].[fact_ehs_visual_inspection]
 SELECT s.audit_id,s.conducted_timestamp,s.conducted_date,s.score_percentage,
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,
        d.week_start_date,d.week_end_date,SYSUTCDATETIME()
 FROM shaped s
 LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=s.conducted_date;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_ehs_visual_inspection_weekly]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE [dbo].[fact_ehs_visual_inspection_weekly];
 INSERT INTO [dbo].[fact_ehs_visual_inspection_weekly]
 SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
        COUNT(DISTINCT audit_id),COUNT(score_percentage),
        CAST(AVG(score_percentage) AS DECIMAL(18,6)),COUNT_BIG(*),SYSUTCDATETIME()
 FROM [dbo].[fact_ehs_visual_inspection]
 WHERE week_key IS NOT NULL
 GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_ehs_visual_inspection_count]
AS
BEGIN
 SET NOCOUNT ON;
 DELETE FROM [dbo].[kpi_result_ehs_safetyculture] WHERE kpi_code='EHS-KPI-D1';
 INSERT INTO [dbo].[kpi_result_ehs_safetyculture]
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,'EHS-KPI-D1',
        'Visual Inspections Count','Delivery','EHS','EHS',
        'Count of SafetyCulture audit_id by conducted_on week','Visual Inspections','Count',
        NULL,NULL,CONCAT('Scored inspections=',w.scored_inspection_count),
        CAST(w.inspection_count AS DECIMAL(18,4)),CAST(k.target_value AS DECIMAL(18,4)),
        CASE WHEN k.target_value IS NULL THEN NULL ELSE w.inspection_count-k.target_value END,
        CASE WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN NULL
             WHEN UPPER(k.breach_direction)='OVER' THEN k.target_value-w.inspection_count
             ELSE w.inspection_count-k.target_value END,
        UPPER(k.breach_direction),
        CASE WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN 'TBC'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.inspection_count>=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.inspection_count>=k.target_value*0.95 THEN 'A'
             WHEN UPPER(k.breach_direction)='OVER' AND w.inspection_count<=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='OVER' AND w.inspection_count<=k.target_value*1.05 THEN 'A'
             ELSE 'R' END,
        CASE WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'SafetyCulture','safety_culture_staging.inspections',w.source_row_count,SYSUTCDATETIME()
 FROM [dbo].[fact_ehs_visual_inspection_weekly] w
 LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code='EHS-KPI-D1';
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_ehs_visual_inspection_pass_rate]
AS
BEGIN
 SET NOCOUNT ON;
 DELETE FROM [dbo].[kpi_result_ehs_safetyculture] WHERE kpi_code='EHS-KPI-Q1';
 INSERT INTO [dbo].[kpi_result_ehs_safetyculture]
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,'EHS-KPI-Q1',
        'Visual Inspections Pass Rate','Quality','EHS','EHS',
        'Average SafetyCulture score_percentage by conducted_on week','Visual Inspection Pass Rate','Percentage',
        NULL,NULL,CONCAT('Scored inspections=',w.scored_inspection_count),
        w.average_pass_rate,CAST(k.target_value AS DECIMAL(18,4)),
        CASE WHEN k.target_value IS NULL OR w.average_pass_rate IS NULL THEN NULL ELSE w.average_pass_rate-k.target_value END,
        CASE WHEN k.target_value IS NULL OR w.average_pass_rate IS NULL OR k.breach_direction IS NULL THEN NULL
             WHEN UPPER(k.breach_direction)='OVER' THEN k.target_value-w.average_pass_rate
             ELSE w.average_pass_rate-k.target_value END,
        UPPER(k.breach_direction),
        CASE WHEN w.average_pass_rate IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL OR k.breach_direction IS NULL THEN 'TBC'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.average_pass_rate>=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='UNDER' AND w.average_pass_rate>=k.target_value*0.95 THEN 'A'
             WHEN UPPER(k.breach_direction)='OVER' AND w.average_pass_rate<=k.target_value THEN 'G'
             WHEN UPPER(k.breach_direction)='OVER' AND w.average_pass_rate<=k.target_value*1.05 THEN 'A'
             ELSE 'R' END,
        CASE WHEN w.average_pass_rate IS NULL THEN 'No Data'
             WHEN k.target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'SafetyCulture','safety_culture_staging.inspections',w.source_row_count,SYSUTCDATETIME()
 FROM [dbo].[fact_ehs_visual_inspection_weekly] w
 LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code='EHS-KPI-Q1';
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_ehs_safetyculture_kpis]
AS
BEGIN
 EXEC [etl].[sp_build_fact_ehs_visual_inspection];
 EXEC [etl].[sp_build_fact_ehs_visual_inspection_weekly];
 EXEC [etl].[sp_build_kpi_ehs_visual_inspection_count];
 EXEC [etl].[sp_build_kpi_ehs_visual_inspection_pass_rate];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_publish_ehs_safetyculture_kpis]
AS
BEGIN
 DELETE FROM [dbo].[fact_kpi_result] WHERE kpi_code IN ('EHS-KPI-D1','EHS-KPI-Q1');
 INSERT INTO [dbo].[fact_kpi_result]
 SELECT * FROM [dbo].[kpi_result_ehs_safetyculture];
END;
GO
