/*
SAS SOP COMPLETE GOLD STORED-PROCEDURE PACK
===========================================
Builds the five SOP measures identified in the customer mapping:
  1. Productivity - Order Lines Released
  2. Delivery - Order Cleansing OTIF
  3. Delivery - Order Sign-Off OTIF
  4. Quality - Customer Complaints
  5. Cost - Value of Orders Completed per FTE

Gold staging contracts:
  stg_salesforce.[Order Tracking]
  stg_salesforce.[Case]
  stg_syteline.coitem_mst
  stg_syteline.co_mst
  stg_sharepoint.sop_fte_headcount
  stg_syteline.sop_order_line_release   -- temporary contract pending original SQL attachment

Canonical shared tables:
  dbo.dim_date
  dbo.dim_kpi
  dbo.fact_kpi_result

Known decisions implemented:
  - Cleansing target: <= 1 day; weekly KPI target 95%.
  - Sign-off target: <= 5 days; weekly KPI target 95%.
  - OTIF reporting week: Order Tracking CreatedDate joined to dbo.dim_date.
  - Complaints: Salesforce Case, Open_Date__c fallback CreatedDate, SOP department only.
  - £/FTE numerator: customer-provided SyteLine ValueOfOrdersCompleted SQL.
  - £/FTE denominator: SharePoint FTE table by WeekEndingFriday.
  - Historic OTIF weeks are rebuilt on every run.

Explicit limitation:
  The customer email proves that the Lines Released SQL existed and was validated in
  RBMW Live/UAT, but the SQL text itself was not available in the retrieved artefacts.
  This pack therefore defines a narrow staging contract for that output. Replace the
  staging load with the original query when recovered; downstream Gold procedures
  will not need to change.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
IF SCHEMA_ID('stg_sharepoint') IS NULL EXEC('CREATE SCHEMA [stg_sharepoint]');
GO

/* =============================================================
   00. TEMPORARY / LANDING CONTRACTS
   ============================================================= */
IF OBJECT_ID('[stg_sharepoint].[sop_fte_headcount]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_sharepoint].[sop_fte_headcount]
    (
        source_name         VARCHAR(500)   NULL,
        week_no             INT            NULL,
        week_ending_friday  DATE           NOT NULL,
        fte_headcount       DECIMAL(18,4)  NULL
    );
END;
GO

IF OBJECT_ID('[stg_syteline].[sop_order_line_release]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_syteline].[sop_order_line_release]
    (
        order_number        VARCHAR(100)   NULL,
        order_line          INT            NULL,
        released_date       DATE           NOT NULL,
        site_ref            VARCHAR(20)    NULL,
        source_status       VARCHAR(50)    NULL
    );
END;
GO

/* =============================================================
   01. DOMAIN FACT TABLES
   ============================================================= */
IF OBJECT_ID('[dbo].[fact_sop_order_tracking]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_order_tracking]
    (
        order_id                  VARCHAR(255)   NOT NULL,
        order_tracking_no         VARCHAR(255)   NULL,
        project_name              VARCHAR(500)   NULL,
        infor_order_reference     VARCHAR(255)   NULL,
        created_date              DATE           NULL,
        days_in_cleansing         DECIMAL(18,4)  NULL,
        days_in_signoff           DECIMAL(18,4)  NULL,
        cleansing_on_time_flag    INT            NOT NULL,
        signoff_on_time_flag      INT            NOT NULL,
        date_key                  INT            NULL,
        closed_year               INT            NULL,
        closed_week               INT            NULL,
        week_key                  INT            NULL,
        week_start_date           DATE           NULL,
        week_ending_date          DATE           NULL,
        created_ts                DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_sop_otif_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_otif_weekly]
    (
        closed_year               INT            NOT NULL,
        closed_week               INT            NOT NULL,
        week_key                  INT            NOT NULL,
        week_start_date           DATE           NOT NULL,
        week_ending_date          DATE           NOT NULL,
        kpi_code                  VARCHAR(100)   NOT NULL,
        kpi_name                  VARCHAR(255)   NOT NULL,
        total_orders              BIGINT         NOT NULL,
        on_time_orders            BIGINT         NOT NULL,
        otif_percentage           DECIMAL(18,6)  NULL,
        calculation_timestamp     DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_sop_customer_complaint]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_customer_complaint]
    (
        case_id                   VARCHAR(255)   NOT NULL,
        case_number               VARCHAR(255)   NULL,
        raw_department            VARCHAR(255)   NULL,
        complaint_date            DATE           NULL,
        date_key                  INT            NULL,
        closed_year               INT            NULL,
        closed_week               INT            NULL,
        week_key                  INT            NULL,
        week_start_date           DATE           NULL,
        week_ending_date          DATE           NULL,
        created_ts                DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_sop_complaints_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_complaints_weekly]
    (
        closed_year               INT            NOT NULL,
        closed_week               INT            NOT NULL,
        week_key                  INT            NOT NULL,
        week_start_date           DATE           NOT NULL,
        week_ending_date          DATE           NOT NULL,
        complaint_count           BIGINT         NOT NULL,
        source_row_count          BIGINT         NOT NULL,
        calculation_timestamp     DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_sop_order_lines_released_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_order_lines_released_weekly]
    (
        closed_year               INT            NOT NULL,
        closed_week               INT            NOT NULL,
        week_key                  INT            NOT NULL,
        week_start_date           DATE           NOT NULL,
        week_ending_date          DATE           NOT NULL,
        lines_released            BIGINT         NOT NULL,
        source_row_count          BIGINT         NOT NULL,
        calculation_timestamp     DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_sop_order_value_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_order_value_weekly]
    (
        closed_year               INT            NOT NULL,
        closed_week               INT            NOT NULL,
        week_key                  INT            NOT NULL,
        week_start_date           DATE           NOT NULL,
        week_ending_date          DATE           NOT NULL,
        order_value_completed     DECIMAL(18,4)  NULL,
        source_row_count          BIGINT         NOT NULL,
        calculation_timestamp     DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_sop_value_per_fte_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_value_per_fte_weekly]
    (
        closed_year               INT            NOT NULL,
        closed_week               INT            NOT NULL,
        week_key                  INT            NOT NULL,
        week_start_date           DATE           NOT NULL,
        week_ending_date          DATE           NOT NULL,
        order_value_completed     DECIMAL(18,4)  NULL,
        fte_headcount             DECIMAL(18,4)  NULL,
        value_per_fte             DECIMAL(18,4)  NULL,
        source_row_count          BIGINT         NOT NULL,
        calculation_timestamp     DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[kpi_result_sop]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[kpi_result_sop]
    (
        closed_year                   INT            NOT NULL,
        closed_week                   INT            NOT NULL,
        week_key                      INT            NOT NULL,
        kpi_id                        BIGINT         NULL,
        kpi_code                      VARCHAR(100)   NOT NULL,
        kpi_name                      VARCHAR(255)   NOT NULL,
        kpi_category                  VARCHAR(100)   NOT NULL,
        organisational_unit           VARCHAR(255)   NOT NULL,
        department                    VARCHAR(255)   NOT NULL,
        measure                       VARCHAR(500)   NULL,
        measure_name                  VARCHAR(500)   NULL,
        uom                           VARCHAR(50)    NULL,
        sign                          VARCHAR(100)   NULL,
        sign_label                    VARCHAR(100)   NULL,
        commentary                    VARCHAR(1000)  NULL,
        kpi_value                     DECIMAL(18,6)  NULL,
        target_value                  DECIMAL(18,6)  NULL,
        variance_value                DECIMAL(18,6)  NULL,
        performance_variance_value    DECIMAL(18,6)  NULL,
        breach_direction              VARCHAR(20)    NULL,
        rag_status                    VARCHAR(20)    NOT NULL,
        data_status                   VARCHAR(50)    NOT NULL,
        source_system                 VARCHAR(100)   NOT NULL,
        source_object                 VARCHAR(500)   NOT NULL,
        source_row_count              BIGINT         NOT NULL,
        calculation_timestamp         DATETIME2(6)   NOT NULL
    );
END;
GO

/* =============================================================
   02. ORDER TRACKING + OTIF
   Expected staged fields mirror the Salesforce Order Tracking object.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_order_tracking]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_order_tracking];

    ;WITH src AS
    (
        SELECT
            order_id              = CAST([Id] AS VARCHAR(255)),
            order_tracking_no     = CAST([Name] AS VARCHAR(255)),
            project_name          = CAST([Project_Name__c] AS VARCHAR(500)),
            infor_order_reference = CAST([Infor_Order_Reference__c] AS VARCHAR(255)),
            created_date          = CAST(TRY_CAST([CreatedDate] AS DATETIME2(6)) AS DATE),
            days_in_cleansing     = TRY_CAST([Days_In_Cleansing__c] AS DECIMAL(18,4)),
            days_in_signoff       = TRY_CAST([Days_In_Customer_Sign_Off__c] AS DECIMAL(18,4)),
            rn = ROW_NUMBER() OVER
                 (PARTITION BY CAST([Id] AS VARCHAR(255)) ORDER BY TRY_CAST([LastModifiedDate] AS DATETIME2(6)) DESC)
        FROM [stg_salesforce].[Order Tracking]
        WHERE [Id] IS NOT NULL
    )
    INSERT INTO [dbo].[fact_sop_order_tracking]
    SELECT
        s.order_id,s.order_tracking_no,s.project_name,s.infor_order_reference,
        s.created_date,s.days_in_cleansing,s.days_in_signoff,
        CASE WHEN s.days_in_cleansing IS NOT NULL AND s.days_in_cleansing<=1 THEN 1 ELSE 0 END,
        CASE WHEN s.days_in_signoff IS NOT NULL AND s.days_in_signoff<=5 THEN 1 ELSE 0 END,
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        SYSUTCDATETIME()
    FROM src s LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=s.created_date
    WHERE s.rn=1;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_otif_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_otif_weekly];

    INSERT INTO [dbo].[fact_sop_otif_weekly]
    SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
           'SOP-KPI-D1','Order Cleansing OTIF',COUNT_BIG(*),SUM(cleansing_on_time_flag),
           CAST(1.0*SUM(cleansing_on_time_flag)/NULLIF(COUNT_BIG(*),0) AS DECIMAL(18,6)),SYSUTCDATETIME()
    FROM [dbo].[fact_sop_order_tracking]
    WHERE week_key IS NOT NULL AND days_in_cleansing IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date

    UNION ALL

    SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
           'SOP-KPI-D2','Order Sign-Off OTIF',COUNT_BIG(*),SUM(signoff_on_time_flag),
           CAST(1.0*SUM(signoff_on_time_flag)/NULLIF(COUNT_BIG(*),0) AS DECIMAL(18,6)),SYSUTCDATETIME()
    FROM [dbo].[fact_sop_order_tracking]
    WHERE week_key IS NOT NULL AND days_in_signoff IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;
END;
GO

/* =============================================================
   03. SOP CUSTOMER COMPLAINTS
   Current confirmed SOP scope is Department__c = 'UK SOP'.
   Open_Date__c is canonical with CreatedDate fallback.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_customer_complaint]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_customer_complaint];

    ;WITH src AS
    (
        SELECT
            case_id=CAST([Id] AS VARCHAR(255)),
            case_number=CAST([CaseNumber] AS VARCHAR(255)),
            raw_department=CAST([Department__c] AS VARCHAR(255)),
            complaint_date=COALESCE(TRY_CAST([Open_Date__c] AS DATE),CAST(TRY_CAST([CreatedDate] AS DATETIME2(6)) AS DATE)),
            rn=ROW_NUMBER() OVER(PARTITION BY CAST([Id] AS VARCHAR(255)) ORDER BY TRY_CAST([CreatedDate] AS DATETIME2(6)) DESC)
        FROM [stg_salesforce].[Case]
        WHERE [Id] IS NOT NULL
          AND LTRIM(RTRIM(CAST([Department__c] AS VARCHAR(255))))='UK SOP'
    )
    INSERT INTO [dbo].[fact_sop_customer_complaint]
    SELECT s.case_id,s.case_number,s.raw_department,s.complaint_date,
           d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,SYSUTCDATETIME()
    FROM src s LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=s.complaint_date
    WHERE s.rn=1;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_complaints_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_complaints_weekly];

    INSERT INTO [dbo].[fact_sop_complaints_weekly]
    SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
           COUNT(DISTINCT case_number),COUNT_BIG(*),SYSUTCDATETIME()
    FROM [dbo].[fact_sop_customer_complaint]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;
END;
GO

/* =============================================================
   04. ORDER LINES RELEASED
   Reads the temporary staging contract populated from the original SQL output.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_order_lines_released_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_order_lines_released_weekly];

    INSERT INTO [dbo].[fact_sop_order_lines_released_weekly]
    SELECT d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
           COUNT_BIG(*),COUNT_BIG(*),SYSUTCDATETIME()
    FROM [stg_syteline].[sop_order_line_release] s
    INNER JOIN [dbo].[dim_date] d ON d.calendar_date=s.released_date
    GROUP BY d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date;
END;
GO

/* =============================================================
   05. VALUE OF ORDERS COMPLETED + £/FTE
   Customer-provided SyteLine SQL, mapped to canonical dim_date.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_order_value_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_order_value_weekly];

    ;WITH order_lines AS
    (
        SELECT
            ordered_date=TRY_CAST(ci.[Uf_OrderedDate] AS DATE),
            order_value=TRY_CAST(ci.[qty_ordered_conv] AS DECIMAL(18,6))
                       * (TRY_CAST(ci.[price_conv] AS DECIMAL(18,6))
                       * (1-TRY_CAST(ci.[disc] AS DECIMAL(18,6))/100.0))
                       / NULLIF(COALESCE(TRY_CAST(co.[exch_rate] AS DECIMAL(18,6)),1),0)
        FROM [stg_syteline].[coitem_mst] ci
        INNER JOIN [stg_syteline].[co_mst] co
          ON co.[site_ref]=ci.[site_ref] AND co.[co_num]=ci.[co_num]
        WHERE ci.[site_ref]='RBMW'
          AND ci.[stat]<'P'
          AND co.[type] IN ('B','R')
          AND LEFT(co.[co_num],1)<>'I'
          AND co.[end_user_type] IN ('2','13','26','28')
          AND ci.[rma_num] IS NULL
          AND COALESCE(CAST(ci.[Uf_LongDescription] AS VARCHAR(8000)),'') NOT LIKE '%CARRIAGE%'
          AND ci.[Uf_OrderedDate] IS NOT NULL
    )
    INSERT INTO [dbo].[fact_sop_order_value_weekly]
    SELECT d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
           CAST(ROUND(SUM(o.order_value),0) AS DECIMAL(18,4)),COUNT_BIG(*),SYSUTCDATETIME()
    FROM order_lines o INNER JOIN [dbo].[dim_date] d ON d.calendar_date=o.ordered_date
    GROUP BY d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_value_per_fte_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_value_per_fte_weekly];

    ;WITH fte AS
    (
        SELECT week_ending_friday,SUM(fte_headcount) fte_headcount,COUNT_BIG(*) source_rows
        FROM [stg_sharepoint].[sop_fte_headcount]
        GROUP BY week_ending_friday
    )
    INSERT INTO [dbo].[fact_sop_value_per_fte_weekly]
    SELECT v.closed_year,v.closed_week,v.week_key,v.week_start_date,v.week_ending_date,
           v.order_value_completed,f.fte_headcount,
           CAST(CASE WHEN f.fte_headcount>0 THEN v.order_value_completed/f.fte_headcount END AS DECIMAL(18,4)),
           v.source_row_count+COALESCE(f.source_rows,0),SYSUTCDATETIME()
    FROM [dbo].[fact_sop_order_value_weekly] v
    LEFT JOIN fte f ON f.week_ending_friday=v.week_ending_date;
END;
GO

/* =============================================================
   06. ENRICHED SOP KPI RESULT
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_sop]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[kpi_result_sop];

    ;WITH u AS
    (
        SELECT closed_year,closed_week,week_key,kpi_code,kpi_name,
               CAST('Delivery' AS VARCHAR(100)) category,
               CAST(otif_percentage AS DECIMAL(18,6)) actual,
               CAST(0.95 AS DECIMAL(18,6)) default_target,
               CAST('UNDER' AS VARCHAR(20)) default_direction,
               total_orders source_rows,
               CONCAT('On time=',on_time_orders,', total=',total_orders) commentary,
               CAST('dbo.fact_sop_otif_weekly' AS VARCHAR(500)) source_object
        FROM [dbo].[fact_sop_otif_weekly]
        UNION ALL
        SELECT closed_year,closed_week,week_key,'SOP-KPI-P1','Order Lines Released','Productivity',
               CAST(lines_released AS DECIMAL(18,6)),NULL,NULL,source_row_count,
               'Original order-line release SQL output required in staging.',
               'stg_syteline.sop_order_line_release'
        FROM [dbo].[fact_sop_order_lines_released_weekly]
        UNION ALL
        SELECT closed_year,closed_week,week_key,'SOP-KPI-Q1','Customer Complaints','Quality',
               CAST(complaint_count AS DECIMAL(18,6)),NULL,'OVER',source_row_count,
               'Salesforce Case population scoped to Department__c = UK SOP.',
               'dbo.fact_sop_complaints_weekly'
        FROM [dbo].[fact_sop_complaints_weekly]
        UNION ALL
        SELECT closed_year,closed_week,week_key,'SOP-KPI-C1','Value of Orders Completed per FTE','Cost',
               CAST(value_per_fte AS DECIMAL(18,6)),NULL,NULL,source_row_count,
               CONCAT('Order value=',CAST(order_value_completed AS VARCHAR(50)),', FTE=',CAST(fte_headcount AS VARCHAR(50))),
               'dbo.fact_sop_value_per_fte_weekly'
        FROM [dbo].[fact_sop_value_per_fte_weekly]
    ), e AS
    (
        SELECT u.*,k.kpi_id,
               COALESCE(CAST(k.target_value AS DECIMAL(18,6)),u.default_target) target_value,
               COALESCE(UPPER(NULLIF(k.breach_direction,'')),u.default_direction) breach_direction
        FROM u LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code=u.kpi_code
    )
    INSERT INTO [dbo].[kpi_result_sop]
    SELECT closed_year,closed_week,week_key,kpi_id,kpi_code,kpi_name,category,
           'SOP','SOP',kpi_name,kpi_name,
           CASE WHEN kpi_code LIKE 'SOP-KPI-D%' THEN 'Percentage'
                WHEN kpi_code='SOP-KPI-C1' THEN 'GBP'
                ELSE 'Count' END,
           CASE WHEN breach_direction='OVER' THEN 'Over Breach'
                WHEN breach_direction='UNDER' THEN 'Under Breach' END,
           CASE WHEN breach_direction='OVER' THEN 'Over Breach'
                WHEN breach_direction='UNDER' THEN 'Under Breach' END,
           commentary,actual,target_value,
           CASE WHEN target_value IS NULL OR actual IS NULL THEN NULL ELSE actual-target_value END,
           CASE WHEN target_value IS NULL OR actual IS NULL OR breach_direction IS NULL THEN NULL
                WHEN breach_direction='OVER' THEN target_value-actual ELSE actual-target_value END,
           breach_direction,
           CASE
             WHEN actual IS NULL THEN 'No Data'
             WHEN target_value IS NULL OR breach_direction IS NULL THEN 'TBC'
             WHEN target_value=0 AND actual=0 THEN 'G'
             WHEN target_value=0 AND actual>0 THEN 'R'
             WHEN breach_direction='UNDER' AND actual>=target_value THEN 'G'
             WHEN breach_direction='UNDER' AND actual>=target_value*0.95 THEN 'A'
             WHEN breach_direction='OVER' AND actual<=target_value THEN 'G'
             WHEN breach_direction='OVER' AND actual<=target_value*1.05 THEN 'A'
             ELSE 'R' END,
           CASE WHEN actual IS NULL THEN 'No Data'
                WHEN target_value IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
           CASE WHEN kpi_code='SOP-KPI-C1' THEN 'SyteLine + SharePoint'
                WHEN kpi_code='SOP-KPI-Q1' THEN 'Salesforce'
                ELSE 'SyteLine / Salesforce' END,
           source_object,source_rows,SYSUTCDATETIME()
    FROM e;
END;
GO

/* =============================================================
   07. PUBLICATION + ORCHESTRATION
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_publish_sop_kpis]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [dbo].[fact_kpi_result] WHERE kpi_code LIKE 'SOP-KPI-%';
    INSERT INTO [dbo].[fact_kpi_result]
    SELECT * FROM [dbo].[kpi_result_sop];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_sop_kpis]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_sop_order_tracking];
    EXEC [etl].[sp_build_fact_sop_otif_weekly];
    EXEC [etl].[sp_build_fact_sop_customer_complaint];
    EXEC [etl].[sp_build_fact_sop_complaints_weekly];
    EXEC [etl].[sp_build_fact_sop_order_lines_released_weekly];
    EXEC [etl].[sp_build_fact_sop_order_value_weekly];
    EXEC [etl].[sp_build_fact_sop_value_per_fte_weekly];
    EXEC [etl].[sp_build_kpi_result_sop];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_sop_kpis_and_publish]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_sop_kpis];
    EXEC [etl].[sp_publish_sop_kpis];
END;
GO

/* TEST
EXEC [etl].[sp_build_sop_kpis];
SELECT * FROM dbo.fact_sop_otif_weekly ORDER BY week_ending_date,kpi_name;
SELECT * FROM dbo.fact_sop_complaints_weekly ORDER BY week_ending_date;
SELECT * FROM dbo.fact_sop_order_lines_released_weekly ORDER BY week_ending_date;
SELECT * FROM dbo.fact_sop_value_per_fte_weekly ORDER BY week_ending_date;
SELECT * FROM dbo.kpi_result_sop ORDER BY closed_year,closed_week,kpi_code;
*/
