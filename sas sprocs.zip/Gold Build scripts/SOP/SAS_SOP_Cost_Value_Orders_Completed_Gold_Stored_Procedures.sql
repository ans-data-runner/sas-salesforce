/*
SAS SOP - COST KPI: VALUE OF ORDERS COMPLETED / FTE
===================================================
Gold Warehouse implementation based on customer-confirmed SyteLine SQL.

Confirmed numerator SQL rules:
  source tables: stg_syteline.coitem_mst + stg_syteline.co_mst
  join: site_ref + co_num
  site_ref = RBMW
  coitem stat < P
  order type B or R
  co_num does not start I
  end_user_type in 2,13,26,28
  rma_num is null
  Uf_LongDescription does not contain CARRIAGE
  value = qty_ordered_conv * price_conv * (1-disc/100) / exch_rate
  reporting date = coitem_mst.Uf_OrderedDate
  week attributes are obtained from dbo.dim_date rather than hard-coded year logic.

Confirmed final KPI rule:
  SOP Cost KPI = weekly Value of Orders Completed / weekly FTE headcount.

FTE source identified by customer:
  SharePoint Excel: SOP KPIs - FTE headcount.xlsx, tab FabricStagingSheet
  confirmed fields: WeekNo, WeekEndingFriday, FTEHeadcount.

Staging contract used here:
  stg_sop.fte_headcount(WeekNo, WeekEndingFriday, FTEHeadcount, SourceName)
  Create the empty shell below now if the SharePoint feed is not landed yet.

Customer/PBIX target: 33026 GBP per FTE.
Simple full refresh only. No overwrite-protection/backups.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO
IF SCHEMA_ID('stg_sop') IS NULL EXEC('CREATE SCHEMA [stg_sop]');
GO

/* Empty FTE staging shell. Safe to leave empty until ingestion exists. */
IF OBJECT_ID('[stg_sop].[fte_headcount]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_sop].[fte_headcount]
    (
        SourceName          VARCHAR(500)   NULL,
        WeekNo              INT            NULL,
        WeekEndingFriday    DATE           NULL,
        FTEHeadcount        DECIMAL(18,4)  NULL
    );
END;
GO

/* =============================================================
   GOLD OUTPUT TABLES
   ============================================================= */
IF OBJECT_ID('[dbo].[fact_sop_order_value_completed_detail]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_order_value_completed_detail]
    (
        site_ref             VARCHAR(20)    NOT NULL,
        co_num               VARCHAR(100)   NOT NULL,
        co_line              INT            NULL,
        co_release           INT            NULL,
        ordered_date         DATE           NOT NULL,
        qty_ordered_conv     DECIMAL(18,4)  NULL,
        price_conv           DECIMAL(18,6)  NULL,
        discount_pct         DECIMAL(18,6)  NULL,
        exchange_rate        DECIMAL(18,8)  NULL,
        order_value          DECIMAL(18,4)  NULL,
        date_key             INT            NULL,
        closed_year          INT            NULL,
        closed_week          INT            NULL,
        week_key             INT            NULL,
        week_start_date      DATE           NULL,
        week_ending_date     DATE           NULL,
        created_ts           DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_sop_order_value_completed_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_order_value_completed_weekly]
    (
        closed_year          INT            NOT NULL,
        closed_week          INT            NOT NULL,
        week_key             INT            NOT NULL,
        week_start_date      DATE           NOT NULL,
        week_ending_date     DATE           NOT NULL,
        order_value          DECIMAL(18,4)  NULL,
        source_row_count     BIGINT         NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_sop_cost_per_fte_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_sop_cost_per_fte_weekly]
    (
        closed_year          INT            NOT NULL,
        closed_week          INT            NOT NULL,
        week_key             INT            NOT NULL,
        week_start_date      DATE           NOT NULL,
        week_ending_date     DATE           NOT NULL,
        order_value          DECIMAL(18,4)  NULL,
        fte_headcount        DECIMAL(18,4)  NULL,
        value_per_fte        DECIMAL(18,4)  NULL,
        source_row_count     BIGINT         NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[kpi_result_sop_cost]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[kpi_result_sop_cost]
    (
        closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
        kpi_id BIGINT NULL, kpi_code VARCHAR(100) NOT NULL,
        kpi_name VARCHAR(255) NOT NULL, kpi_category VARCHAR(100) NOT NULL,
        organisational_unit VARCHAR(255) NOT NULL, department VARCHAR(255) NOT NULL,
        measure VARCHAR(500) NULL, measure_name VARCHAR(500) NULL, uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL, sign_label VARCHAR(100) NULL, commentary VARCHAR(1000) NULL,
        kpi_value DECIMAL(18,4) NULL, target_value DECIMAL(18,4) NULL,
        variance_value DECIMAL(18,4) NULL, performance_variance_value DECIMAL(18,4) NULL,
        breach_direction VARCHAR(20) NULL, rag_status VARCHAR(20) NOT NULL,
        data_status VARCHAR(50) NOT NULL, source_system VARCHAR(100) NOT NULL,
        source_object VARCHAR(500) NOT NULL, source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

/* =============================================================
   01. DETAIL FACT FROM SYTELINE
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_order_value_completed_detail]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_order_value_completed_detail];

    INSERT INTO [dbo].[fact_sop_order_value_completed_detail]
    (
        site_ref,co_num,co_line,co_release,ordered_date,
        qty_ordered_conv,price_conv,discount_pct,exchange_rate,order_value,
        date_key,closed_year,closed_week,week_key,week_start_date,week_ending_date,created_ts
    )
    SELECT
        CAST(ci.site_ref AS VARCHAR(20)),
        CAST(ci.co_num AS VARCHAR(100)),
        TRY_CAST(ci.co_line AS INT),
        TRY_CAST(ci.co_release AS INT),
        CAST(ci.Uf_OrderedDate AS DATE),
        TRY_CAST(ci.qty_ordered_conv AS DECIMAL(18,4)),
        TRY_CAST(ci.price_conv AS DECIMAL(18,6)),
        TRY_CAST(ci.disc AS DECIMAL(18,6)),
        CAST(COALESCE(TRY_CAST(ch.exch_rate AS DECIMAL(18,8)),1.0) AS DECIMAL(18,8)),
        CAST(
            TRY_CAST(ci.qty_ordered_conv AS DECIMAL(18,4)) *
            (TRY_CAST(ci.price_conv AS DECIMAL(18,6)) *
             (1 - COALESCE(TRY_CAST(ci.disc AS DECIMAL(18,6)),0) / 100.0)) /
            COALESCE(NULLIF(TRY_CAST(ch.exch_rate AS DECIMAL(18,8)),0),1.0)
            AS DECIMAL(18,4)
        ),
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        SYSUTCDATETIME()
    FROM [stg_syteline].[coitem_mst] ci
    INNER JOIN [stg_syteline].[co_mst] ch
      ON ch.site_ref=ci.site_ref AND ch.co_num=ci.co_num
    LEFT JOIN [dbo].[dim_date] d
      ON d.calendar_date=CAST(ci.Uf_OrderedDate AS DATE)
    WHERE ci.site_ref='RBMW'
      AND ci.stat<'P'
      AND ch.type IN ('B','R')
      AND LEFT(ch.co_num,1)<>'I'
      AND ch.end_user_type IN ('2','13','26','28')
      AND ci.rma_num IS NULL
      AND COALESCE(ci.Uf_LongDescription,'') NOT LIKE '%CARRIAGE%'
      AND ci.Uf_OrderedDate IS NOT NULL;
END;
GO

/* =============================================================
   02. WEEKLY ORDER VALUE
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_order_value_completed_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_order_value_completed_weekly];

    INSERT INTO [dbo].[fact_sop_order_value_completed_weekly]
    SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
           CAST(ROUND(SUM(order_value),0) AS DECIMAL(18,4)),COUNT_BIG(*),SYSUTCDATETIME()
    FROM [dbo].[fact_sop_order_value_completed_detail]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;
END;
GO

/* =============================================================
   03. COST / FTE FACT
   Empty FTE staging produces NULL fte_headcount and NULL value_per_fte.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_sop_cost_per_fte_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_sop_cost_per_fte_weekly];

    ;WITH fte AS
    (
        SELECT WeekEndingFriday,
               MAX(FTEHeadcount) AS FTEHeadcount
        FROM [stg_sop].[fte_headcount]
        GROUP BY WeekEndingFriday
    )
    INSERT INTO [dbo].[fact_sop_cost_per_fte_weekly]
    SELECT w.closed_year,w.closed_week,w.week_key,w.week_start_date,w.week_ending_date,
           w.order_value,f.FTEHeadcount,
           CAST(CASE WHEN f.FTEHeadcount>0 THEN w.order_value/f.FTEHeadcount END AS DECIMAL(18,4)),
           w.source_row_count,SYSUTCDATETIME()
    FROM [dbo].[fact_sop_order_value_completed_weekly] w
    LEFT JOIN fte f ON f.WeekEndingFriday=w.week_ending_date;
END;
GO

/* =============================================================
   04. ENRICHED KPI
   Confirmed historical reporting code/category: SOP-KPI C1 / Cost.
   Customer/PBIX target: GBP 33,026 per FTE.
   Higher value is favourable -> UNDER breach.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_sop_cost]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[kpi_result_sop_cost];

    ;WITH x AS
    (
        SELECT f.*,
               COALESCE(k.kpi_id,NULL) AS kpi_id,
               COALESCE(CAST(k.target_value AS DECIMAL(18,4)),CAST(33026 AS DECIMAL(18,4))) AS target_value,
               COALESCE(NULLIF(UPPER(k.breach_direction),''),'UNDER') AS breach_direction
        FROM [dbo].[fact_sop_cost_per_fte_weekly] f
        LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code='SOP-KPI C1'
    )
    INSERT INTO [dbo].[kpi_result_sop_cost]
    SELECT closed_year,closed_week,week_key,kpi_id,'SOP-KPI C1',
           'FTE as a ratio of Orders Released','Cost','SOP','SOP',
           'Value of orders completed / FTE headcount','Value per FTE','GBP',
           'Under Breach','Under Breach',
           CONCAT('Weekly order value=',CAST(order_value AS VARCHAR(50)),
                  ', FTE=',COALESCE(CAST(fte_headcount AS VARCHAR(50)),'NULL')),
           value_per_fte,target_value,
           CASE WHEN value_per_fte IS NULL THEN NULL ELSE value_per_fte-target_value END,
           CASE WHEN value_per_fte IS NULL THEN NULL ELSE value_per_fte-target_value END,
           breach_direction,
           CASE WHEN value_per_fte IS NULL THEN 'No Data'
                WHEN value_per_fte>=target_value THEN 'G'
                WHEN value_per_fte>=target_value*0.95 THEN 'A'
                ELSE 'R' END,
           CASE WHEN value_per_fte IS NULL THEN 'No Data' ELSE 'Actual' END,
           'SyteLine + SharePoint FTE',
           'dbo.fact_sop_order_value_completed_weekly + stg_sop.fte_headcount',
           source_row_count,SYSUTCDATETIME()
    FROM x;
END;
GO

/* =============================================================
   05. OPTIONAL CANONICAL PUBLISH
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_publish_sop_cost]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [dbo].[fact_kpi_result] WHERE kpi_code='SOP-KPI C1';
    INSERT INTO [dbo].[fact_kpi_result]
    SELECT * FROM [dbo].[kpi_result_sop_cost];
END;
GO

/* =============================================================
   06. ORCHESTRATORS
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_sop_cost]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_sop_order_value_completed_detail];
    EXEC [etl].[sp_build_fact_sop_order_value_completed_weekly];
    EXEC [etl].[sp_build_fact_sop_cost_per_fte_weekly];
    EXEC [etl].[sp_build_kpi_result_sop_cost];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_sop_cost_and_publish]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_sop_cost];
    EXEC [etl].[sp_publish_sop_cost];
END;
GO

/* =============================================================
   TESTS
   =============================================================
EXEC [etl].[sp_build_sop_cost];

SELECT * FROM [dbo].[fact_sop_order_value_completed_weekly]
ORDER BY week_ending_date;

SELECT * FROM [dbo].[fact_sop_cost_per_fte_weekly]
ORDER BY week_ending_date;

SELECT * FROM [dbo].[kpi_result_sop_cost]
ORDER BY closed_year,closed_week;

-- Direct numerator reconciliation using customer query logic:
SELECT
    d.week_end_date AS WeekEnding,
    ROUND(SUM(ci.qty_ordered_conv*(ci.price_conv*(1-ci.disc/100.0))/COALESCE(NULLIF(ch.exch_rate,0),1)),0) AS OrderValue
FROM [stg_syteline].[coitem_mst] ci
JOIN [stg_syteline].[co_mst] ch
  ON ch.site_ref=ci.site_ref AND ch.co_num=ci.co_num
LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=CAST(ci.Uf_OrderedDate AS DATE)
WHERE ci.site_ref='RBMW'
  AND ci.stat<'P'
  AND ch.type IN ('B','R')
  AND LEFT(ch.co_num,1)<>'I'
  AND ch.end_user_type IN ('2','13','26','28')
  AND ci.rma_num IS NULL
  AND COALESCE(ci.Uf_LongDescription,'') NOT LIKE '%CARRIAGE%'
GROUP BY d.week_end_date
ORDER BY d.week_end_date;
*/
