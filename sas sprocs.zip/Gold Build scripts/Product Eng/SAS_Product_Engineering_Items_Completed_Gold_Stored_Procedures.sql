/*
SAS PRODUCT ENGINEERING - ITEMS COMPLETED
=========================================
Purpose
  Derive daily and weekly Product Engineering Items Completed for Bridgend (BE)
  and Maybole (MB) from the point-in-time Planning Load and New Items snapshots.

Working calculation
  Items Completed = Previous workday Planning Load
                  + Current-day New Items
                  - Current-day Planning Load

Evidence and mitigation
  - Planning Load and New Items are confirmed daily inputs captured at 08:00.
  - The recovered workbook values support the inventory-flow relationship above.
  - The literal workbook formula was not exposed, so this output is labelled
    ESTIMATED_FORMULA_V1 until reconciled against the customer workbook.
  - Negative results are retained, not forced to zero, so source timing/data issues
    remain visible during testing.
  - A result is NULL when prior Planning Load, current Planning Load, or New Items
    is unavailable.
  - LAG uses the preceding available 08:00 snapshot for the same site. This handles
    weekends naturally, but missing weekdays must be reviewed through gap flags.

Required existing Gold facts
  dbo.fact_product_engineering_planning_load_snapshot
  dbo.fact_product_engineering_new_items_snapshot

Outputs
  dbo.fact_product_engineering_items_completed_daily
  dbo.fact_product_engineering_items_completed_weekly

This is a supporting operational measure. It is not automatically published to
fact_kpi_result because customer evidence identifies it primarily as an input and
validation measure for Product Engineering Productivity.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_items_completed_daily]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_items_completed_daily]
    (
        snapshot_date              DATE          NOT NULL,
        warehouse_prefix           VARCHAR(10)   NOT NULL,
        site_name                  VARCHAR(100)  NOT NULL,
        prior_snapshot_date        DATE          NULL,
        snapshot_gap_days          INT           NULL,
        prior_planning_load        DECIMAL(18,4) NULL,
        new_items                  DECIMAL(18,4) NULL,
        current_planning_load      DECIMAL(18,4) NULL,
        items_completed            DECIMAL(18,4) NULL,
        calculation_source         VARCHAR(100)  NOT NULL,
        data_status                VARCHAR(50)   NOT NULL,
        date_key                   INT           NULL,
        closed_year                INT           NULL,
        closed_week                INT           NULL,
        week_key                   INT           NULL,
        week_start_date            DATE          NULL,
        week_ending_date           DATE          NULL,
        calculation_timestamp      DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_items_completed_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_items_completed_weekly]
    (
        closed_year                INT           NOT NULL,
        closed_week                INT           NOT NULL,
        week_key                   INT           NOT NULL,
        week_start_date            DATE          NOT NULL,
        week_ending_date           DATE          NOT NULL,
        warehouse_prefix           VARCHAR(10)   NOT NULL,
        site_name                  VARCHAR(100)  NOT NULL,
        snapshot_days              INT           NOT NULL,
        complete_days              INT           NOT NULL,
        gap_flag_days              INT           NOT NULL,
        negative_result_days       INT           NOT NULL,
        items_completed_total      DECIMAL(18,4) NULL,
        items_completed_average    DECIMAL(18,4) NULL,
        items_completed_min        DECIMAL(18,4) NULL,
        items_completed_max        DECIMAL(18,4) NULL,
        data_status                VARCHAR(50)   NOT NULL,
        calculation_timestamp      DATETIME2(6)  NOT NULL
    );
END;
GO

/* =============================================================
   01. DAILY ITEMS COMPLETED
   Uses one consolidated 08:00 value per site/date.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_items_completed_daily]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_product_engineering_items_completed_daily];

    ;WITH planning_daily AS
    (
        SELECT
            snapshot_date,
            warehouse_prefix,
            MAX(site_name) AS site_name,
            AVG(planning_load) AS current_planning_load,
            MAX(date_key) AS date_key,
            MAX(closed_year) AS closed_year,
            MAX(closed_week) AS closed_week,
            MAX(week_key) AS week_key,
            MAX(week_start_date) AS week_start_date,
            MAX(week_ending_date) AS week_ending_date
        FROM [dbo].[fact_product_engineering_planning_load_snapshot]
        WHERE snapshot_hour = 8
          AND warehouse_prefix IN ('BE','MB')
        GROUP BY snapshot_date, warehouse_prefix
    ), planning_with_prior AS
    (
        SELECT
            p.*,
            LAG(snapshot_date) OVER
              (PARTITION BY warehouse_prefix ORDER BY snapshot_date) AS prior_snapshot_date,
            LAG(current_planning_load) OVER
              (PARTITION BY warehouse_prefix ORDER BY snapshot_date) AS prior_planning_load
        FROM planning_daily p
    ), new_items_daily AS
    (
        SELECT
            snapshot_date,
            warehouse_prefix,
            AVG(new_items) AS new_items
        FROM [dbo].[fact_product_engineering_new_items_snapshot]
        WHERE snapshot_hour = 8
          AND warehouse_prefix IN ('BE','MB')
        GROUP BY snapshot_date, warehouse_prefix
    ), calculated AS
    (
        SELECT
            p.*,
            n.new_items,
            DATEDIFF(DAY,p.prior_snapshot_date,p.snapshot_date) AS snapshot_gap_days,
            CAST(
                CASE
                  WHEN p.prior_planning_load IS NOT NULL
                   AND p.current_planning_load IS NOT NULL
                   AND n.new_items IS NOT NULL
                  THEN p.prior_planning_load + n.new_items - p.current_planning_load
                END AS DECIMAL(18,4)
            ) AS items_completed
        FROM planning_with_prior p
        LEFT JOIN new_items_daily n
          ON n.snapshot_date = p.snapshot_date
         AND n.warehouse_prefix = p.warehouse_prefix
    )
    INSERT INTO [dbo].[fact_product_engineering_items_completed_daily]
    (
        snapshot_date,warehouse_prefix,site_name,prior_snapshot_date,
        snapshot_gap_days,prior_planning_load,new_items,current_planning_load,
        items_completed,calculation_source,data_status,date_key,closed_year,
        closed_week,week_key,week_start_date,week_ending_date,
        calculation_timestamp
    )
    SELECT
        snapshot_date,
        warehouse_prefix,
        site_name,
        prior_snapshot_date,
        snapshot_gap_days,
        prior_planning_load,
        new_items,
        current_planning_load,
        items_completed,
        'ESTIMATED_FORMULA_V1',
        CASE
          WHEN prior_planning_load IS NULL THEN 'No Prior Snapshot'
          WHEN new_items IS NULL THEN 'Missing New Items'
          WHEN current_planning_load IS NULL THEN 'Missing Planning Load'
          WHEN snapshot_gap_days > 3 THEN 'Snapshot Gap Review'
          WHEN items_completed < 0 THEN 'Negative Result Review'
          ELSE 'Estimated Formula'
        END,
        date_key,
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        SYSUTCDATETIME()
    FROM calculated;
END;
GO

/* =============================================================
   02. WEEKLY ITEMS COMPLETED SUPPORTING FACT
   Total is the sum of valid daily results. Average is also retained for
   comparison with workbook reporting and productivity calculations.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_items_completed_weekly]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_product_engineering_items_completed_weekly];

    INSERT INTO [dbo].[fact_product_engineering_items_completed_weekly]
    (
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        warehouse_prefix,site_name,snapshot_days,complete_days,gap_flag_days,
        negative_result_days,items_completed_total,items_completed_average,
        items_completed_min,items_completed_max,data_status,
        calculation_timestamp
    )
    SELECT
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        warehouse_prefix,
        MAX(site_name),
        COUNT(*),
        COUNT(items_completed),
        SUM(CASE WHEN data_status IN ('No Prior Snapshot','Missing New Items',
                                     'Missing Planning Load','Snapshot Gap Review')
                 THEN 1 ELSE 0 END),
        SUM(CASE WHEN items_completed < 0 THEN 1 ELSE 0 END),
        CAST(SUM(items_completed) AS DECIMAL(18,4)),
        CAST(AVG(items_completed) AS DECIMAL(18,4)),
        CAST(MIN(items_completed) AS DECIMAL(18,4)),
        CAST(MAX(items_completed) AS DECIMAL(18,4)),
        CASE
          WHEN COUNT(items_completed)=0 THEN 'No Data'
          WHEN SUM(CASE WHEN data_status='Snapshot Gap Review' THEN 1 ELSE 0 END)>0
            THEN 'Snapshot Gap Review'
          WHEN SUM(CASE WHEN items_completed<0 THEN 1 ELSE 0 END)>0
            THEN 'Negative Result Review'
          WHEN COUNT(items_completed)<5 THEN 'Partial Week - Estimated Formula'
          ELSE 'Estimated Formula'
        END,
        SYSUTCDATETIME()
    FROM [dbo].[fact_product_engineering_items_completed_daily]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,
             warehouse_prefix;
END;
GO

/* =============================================================
   03. ORCHESTRATOR
   Assumes Planning Load and New Items snapshots have already been captured.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_items_completed]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_fact_product_engineering_items_completed_daily];
    EXEC [etl].[sp_build_fact_product_engineering_items_completed_weekly];
END;
GO

/* =============================================================
   TESTS
   =============================================================
EXEC [etl].[sp_build_product_engineering_items_completed];

SELECT *
FROM [dbo].[fact_product_engineering_items_completed_daily]
ORDER BY snapshot_date,warehouse_prefix;

SELECT *
FROM [dbo].[fact_product_engineering_items_completed_weekly]
ORDER BY week_ending_date,warehouse_prefix;

-- Validate the arithmetic identity:
SELECT *,
       prior_planning_load + new_items - current_planning_load
         AS recalculated_items_completed,
       items_completed -
       (prior_planning_load + new_items - current_planning_load)
         AS calculation_difference
FROM [dbo].[fact_product_engineering_items_completed_daily]
WHERE items_completed IS NOT NULL
ORDER BY snapshot_date,warehouse_prefix;

-- Expected: calculation_difference = 0 for every populated row.
*/
