/*
SAS PRODUCT ENGINEERING - COST / 4 WEEK GBP K
=============================================
Evidence-backed business rule:
  - Separate BE (Bridgend) and MB (Maybole) values.
  - Capture the SyteLine point-in-time value at 08:00 Monday-Friday.
  - Weekly KPI = average of the available Mon-Fri daily values.
  - Daily source calculation:
      ROUND(SUM((qty_ordered - qty_shipped) * Uf_TrnPrice) / 1000, 0)
  - Filters recovered from the customer material:
      coitem_mst + item_mst
      site_ref = 'RBMW'
      co_num LIKE 'C%'
      stat = 'O'
      whse IN ('BE','MB')
      Uf_CustDelDate < DATEADD(week,5,end of current day)
      Uf_BomStatus IN ('B','D','E','P')

Mitigation / validation notes:
  1. The retrieved query fragment did not explicitly show the item_mst join line, but
     the other Product Engineering queries use item + site_ref; that same join is
     applied here and must be reconciled against the customer workbook.
  2. The retrieved query fragment states a five-week date boundary despite the KPI
     label saying 4 Week GBP K. The SQL preserves the supplied DATEADD(week,5,...)
     rule and labels this for UAT rather than silently changing it.
  3. The source query result is recorded as GBP thousands. Example: 250 = GBP250k.
  4. Targets and breach direction are resolved from dbo.dim_kpi. No target is invented.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_4_week_value_snapshot]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_4_week_value_snapshot]
    (
        snapshot_date        DATE          NOT NULL,
        snapshot_timestamp   DATETIME2(6)  NOT NULL,
        snapshot_hour        TINYINT       NOT NULL,
        warehouse_prefix     VARCHAR(10)   NOT NULL,
        site_name            VARCHAR(100)  NOT NULL,
        four_week_value_gbp_k DECIMAL(18,4) NULL,
        source_row_count     BIGINT        NOT NULL,
        date_key             INT           NULL,
        closed_year          INT           NULL,
        closed_week          INT           NULL,
        week_key             INT           NULL,
        week_start_date      DATE          NULL,
        week_ending_date     DATE          NULL,
        created_ts           DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_4_week_value_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_4_week_value_weekly]
    (
        closed_year          INT           NOT NULL,
        closed_week          INT           NOT NULL,
        week_key             INT           NOT NULL,
        week_start_date      DATE          NOT NULL,
        week_ending_date     DATE          NOT NULL,
        warehouse_prefix     VARCHAR(10)   NOT NULL,
        site_name            VARCHAR(100)  NOT NULL,
        snapshot_days        INT           NOT NULL,
        four_week_value_avg_gbp_k DECIMAL(18,4) NULL,
        four_week_value_min_gbp_k DECIMAL(18,4) NULL,
        four_week_value_max_gbp_k DECIMAL(18,4) NULL,
        source_row_count     BIGINT        NOT NULL,
        data_status          VARCHAR(50)   NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[kpi_result_product_engineering_cost]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[kpi_result_product_engineering_cost]
    (
        closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
        kpi_id BIGINT NULL, kpi_code VARCHAR(100) NOT NULL,
        kpi_name VARCHAR(255) NOT NULL, kpi_category VARCHAR(100) NOT NULL,
        organisational_unit VARCHAR(255) NOT NULL, department VARCHAR(255) NOT NULL,
        measure VARCHAR(500) NULL, measure_name VARCHAR(500) NULL, uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL, sign_label VARCHAR(100) NULL, commentary VARCHAR(1000) NULL,
        kpi_value DECIMAL(18,4) NULL, target_value DECIMAL(18,4) NULL,
        variance_value DECIMAL(18,4) NULL, performance_variance_value DECIMAL(18,4) NULL,
        breach_direction VARCHAR(20) NULL, rag_status VARCHAR(20) NOT NULL,
        data_status VARCHAR(50) NOT NULL, source_system VARCHAR(100) NOT NULL,
        source_object VARCHAR(500) NOT NULL, source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

/* 01. Capture point-in-time SyteLine value. Schedule at 08:00 Mon-Fri. */
CREATE OR ALTER PROCEDURE [etl].[sp_capture_product_engineering_4_week_value_snapshot]
    @snapshot_timestamp DATETIME2(6)=NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @capture_ts DATETIME2(6)=COALESCE(@snapshot_timestamp,SYSUTCDATETIME());
    DECLARE @snapshot_date DATE=CAST(@capture_ts AS DATE);
    DECLARE @snapshot_hour TINYINT=DATEPART(HOUR,@capture_ts);
    DECLARE @five_week_boundary DATETIME2(6)=
        DATEADD(WEEK,5,DATEADD(DAY,1,CAST(@snapshot_date AS DATETIME2(6))));

    DELETE FROM [dbo].[fact_product_engineering_4_week_value_snapshot]
    WHERE snapshot_date=@snapshot_date
      AND snapshot_hour=@snapshot_hour
      AND warehouse_prefix IN ('BE','MB');

    ;WITH calculated AS
    (
        SELECT
            UPPER(LTRIM(RTRIM(CAST(c.whse AS VARCHAR(10))))) AS warehouse_prefix,
            CAST(ROUND(SUM(
                (COALESCE(TRY_CAST(c.qty_ordered AS DECIMAL(18,4)),0)
                 - COALESCE(TRY_CAST(c.qty_shipped AS DECIMAL(18,4)),0))
                * COALESCE(TRY_CAST(c.Uf_TrnPrice AS DECIMAL(18,6)),0)
            )/1000.0,0) AS DECIMAL(18,4)) AS four_week_value_gbp_k,
            COUNT_BIG(*) AS source_row_count
        FROM [stg_syteline].[coitem_mst] c
        LEFT JOIN [stg_syteline].[item_mst] i
          ON c.item=i.item AND c.site_ref=i.site_ref
        WHERE c.site_ref='RBMW'
          AND c.co_num LIKE 'C%'
          AND c.stat='O'
          AND c.whse IN ('BE','MB')
          AND c.Uf_CustDelDate < @five_week_boundary
          AND i.Uf_BomStatus IN ('B','D','E','P')
        GROUP BY c.whse
    )
    INSERT INTO [dbo].[fact_product_engineering_4_week_value_snapshot]
    (
        snapshot_date,snapshot_timestamp,snapshot_hour,warehouse_prefix,site_name,
        four_week_value_gbp_k,source_row_count,date_key,closed_year,closed_week,
        week_key,week_start_date,week_ending_date,created_ts
    )
    SELECT
        @snapshot_date,@capture_ts,@snapshot_hour,c.warehouse_prefix,
        CASE c.warehouse_prefix WHEN 'BE' THEN 'Bridgend' ELSE 'Maybole' END,
        c.four_week_value_gbp_k,c.source_row_count,
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,
        d.week_start_date,d.week_end_date,SYSUTCDATETIME()
    FROM calculated c
    LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=@snapshot_date;
END;
GO

/* 02. Weekly average of 08:00 daily values. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_4_week_value_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_product_engineering_4_week_value_weekly];

    ;WITH daily AS
    (
        SELECT snapshot_date,closed_year,closed_week,week_key,
               week_start_date,week_ending_date,warehouse_prefix,site_name,
               AVG(four_week_value_gbp_k) AS daily_value,
               SUM(source_row_count) AS daily_rows
        FROM [dbo].[fact_product_engineering_4_week_value_snapshot]
        WHERE snapshot_hour=8 AND week_key IS NOT NULL
        GROUP BY snapshot_date,closed_year,closed_week,week_key,
                 week_start_date,week_ending_date,warehouse_prefix,site_name
    )
    INSERT INTO [dbo].[fact_product_engineering_4_week_value_weekly]
    SELECT
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        warehouse_prefix,site_name,COUNT(*),
        CAST(AVG(daily_value) AS DECIMAL(18,4)),
        CAST(MIN(daily_value) AS DECIMAL(18,4)),
        CAST(MAX(daily_value) AS DECIMAL(18,4)),
        SUM(daily_rows),
        CASE WHEN COUNT(*)>=5 THEN 'Actual' ELSE 'Partial Week' END,
        SYSUTCDATETIME()
    FROM daily
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,
             warehouse_prefix,site_name;
END;
GO

/* 03. Enriched KPI result. Codes are provisional until dim_kpi confirms them. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_product_engineering_cost]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[kpi_result_product_engineering_cost];

    ;WITH b AS
    (
        SELECT w.*,
               CASE warehouse_prefix WHEN 'BE' THEN 'ProductEng-BE-KPI-C1'
                                     ELSE 'ProductEng-MB-KPI-C1' END AS kpi_code,
               CASE warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend'
                                     ELSE 'Product Engineering Maybole' END AS org_unit
        FROM [dbo].[fact_product_engineering_4_week_value_weekly] w
    ), e AS
    (
        SELECT b.*,k.kpi_id,CAST(k.target_value AS DECIMAL(18,4)) AS target_value,
               UPPER(NULLIF(k.breach_direction,'')) AS breach_direction
        FROM b LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code=b.kpi_code
    )
    INSERT INTO [dbo].[kpi_result_product_engineering_cost]
    SELECT
        closed_year,closed_week,week_key,kpi_id,kpi_code,
        'Product Engineering 4 Week Value','Cost',org_unit,org_unit,
        'Weekly average of Mon-Fri Product Engineering 4 Week GBP K snapshots',
        'Product Engineering 4 Week GBP K','GBP000',NULL,NULL,
        CONCAT('Snapshot days=',snapshot_days,
               '; source date boundary preserves supplied five-week query rule.'),
        four_week_value_avg_gbp_k,target_value,
        CASE WHEN target_value IS NULL THEN NULL
             ELSE four_week_value_avg_gbp_k-target_value END,
        CASE WHEN target_value IS NULL OR breach_direction IS NULL THEN NULL
             WHEN breach_direction='OVER' THEN target_value-four_week_value_avg_gbp_k
             ELSE four_week_value_avg_gbp_k-target_value END,
        breach_direction,
        CASE
          WHEN four_week_value_avg_gbp_k IS NULL THEN 'No Data'
          WHEN target_value IS NULL OR breach_direction IS NULL THEN 'TBC'
          WHEN breach_direction='UNDER' AND four_week_value_avg_gbp_k>=target_value THEN 'G'
          WHEN breach_direction='UNDER' AND four_week_value_avg_gbp_k>=target_value*0.95 THEN 'A'
          WHEN breach_direction='OVER' AND four_week_value_avg_gbp_k<=target_value THEN 'G'
          WHEN breach_direction='OVER' AND four_week_value_avg_gbp_k<=target_value*1.05 THEN 'A'
          ELSE 'R' END,
        data_status,'SyteLine',
        'stg_syteline.coitem_mst + stg_syteline.item_mst',
        source_row_count,SYSUTCDATETIME()
    FROM e;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_publish_product_engineering_cost]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [dbo].[fact_kpi_result]
    WHERE kpi_code IN ('ProductEng-BE-KPI-C1','ProductEng-MB-KPI-C1');
    INSERT INTO [dbo].[fact_kpi_result]
    SELECT * FROM [dbo].[kpi_result_product_engineering_cost];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_cost]
    @snapshot_timestamp DATETIME2(6)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_capture_product_engineering_4_week_value_snapshot]
         @snapshot_timestamp=@snapshot_timestamp;
    EXEC [etl].[sp_build_fact_product_engineering_4_week_value_weekly];
    EXEC [etl].[sp_build_kpi_result_product_engineering_cost];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_cost_and_publish]
    @snapshot_timestamp DATETIME2(6)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_product_engineering_cost]
         @snapshot_timestamp=@snapshot_timestamp;
    EXEC [etl].[sp_publish_product_engineering_cost];
END;
GO

/* TEST
EXEC [etl].[sp_build_product_engineering_cost]
     @snapshot_timestamp='2026-10-30T08:00:00';

SELECT * FROM dbo.fact_product_engineering_4_week_value_snapshot
ORDER BY snapshot_date,warehouse_prefix;
SELECT * FROM dbo.fact_product_engineering_4_week_value_weekly
ORDER BY week_ending_date,warehouse_prefix;
SELECT * FROM dbo.kpi_result_product_engineering_cost
ORDER BY closed_year,closed_week,organisational_unit;
*/
