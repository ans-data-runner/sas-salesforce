/*
SAS PRODUCT ENGINEERING - PRODUCTIVITY KPI
==========================================
Confirmed customer logic:
  - Separate BE (Bridgend) and MB (Maybole) outputs.
  - Planning Load and New Items are captured from SyteLine at 08:00 Monday-Friday.
  - The spreadsheet calculates a daily Productivity Percentage.
  - Weekly KPI = average of the Monday-Friday daily Productivity Percentages.
  - BE spreadsheet output row = row 10; MB output row = row 19.

Confirmed SyteLine query inputs recovered from prior customer work:
  Planning Load:
    coitem_mst + item_mst; RBMW; co_num C%; open lines; BE/MB;
    Uf_BomStatus B/D/E/P; count items by warehouse.
  New Items:
    same population restricted to Uf_OrderedDate = previous day.

Evidence limitation:
  The exact spreadsheet formula that converts Planning Load + New Items + Capacity
  into the daily Productivity Percentage is not exposed in the retrieved text.
  This script therefore does not invent that formula. It creates:
    1. the New Items snapshot; and
    2. a small daily-calculation staging contract containing the spreadsheet-equivalent
       productivity_percentage.
  Once the spreadsheet formula is recovered, replace the population of
  stg_syteline.product_engineering_productivity_daily_current with SQL.

Required existing object from prior pack:
  dbo.fact_product_engineering_planning_load_snapshot
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO
IF SCHEMA_ID('stg_syteline') IS NULL EXEC('CREATE SCHEMA [stg_syteline]');
GO

/* Current New Items query output. */
IF OBJECT_ID('[stg_syteline].[product_engineering_new_items_current]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_syteline].[product_engineering_new_items_current]
    (
        warehouse_prefix VARCHAR(10)   NOT NULL,
        new_items        DECIMAL(18,4) NULL,
        source_row_count BIGINT        NULL
    );
END;
GO

/* Spreadsheet-equivalent daily calculation contract.
   Value scale must be 0-100, e.g. 87.5 = 87.5%.
*/
IF OBJECT_ID('[stg_syteline].[product_engineering_productivity_daily_current]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_syteline].[product_engineering_productivity_daily_current]
    (
        snapshot_date           DATE          NOT NULL,
        warehouse_prefix        VARCHAR(10)   NOT NULL,
        productivity_percentage DECIMAL(18,4) NULL,
        calculation_source      VARCHAR(255)  NULL
    );
END;
GO

/* Optional direct SyteLine query for current New Items. */
CREATE OR ALTER PROCEDURE [etl].[sp_refresh_product_engineering_new_items_current]
    @snapshot_timestamp DATETIME2(6)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @capture_ts DATETIME2(6)=COALESCE(@snapshot_timestamp,SYSUTCDATETIME());
    DECLARE @previous_date DATE=DATEADD(DAY,-1,CAST(@capture_ts AS DATE));

    TRUNCATE TABLE [stg_syteline].[product_engineering_new_items_current];

    INSERT INTO [stg_syteline].[product_engineering_new_items_current]
    (warehouse_prefix,new_items,source_row_count)
    SELECT
        UPPER(LTRIM(RTRIM(CAST(c.whse AS VARCHAR(10))))),
        CAST(COUNT(c.item) AS DECIMAL(18,4)),
        COUNT_BIG(*)
    FROM [stg_syteline].[coitem_mst] c
    LEFT JOIN [stg_syteline].[item_mst] i
      ON c.item=i.item AND c.site_ref=i.site_ref
    WHERE c.site_ref='RBMW'
      AND c.co_num LIKE 'C%'
      AND c.stat='O'
      AND c.whse IN ('BE','MB')
      AND CAST(c.Uf_OrderedDate AS DATE)=@previous_date
      AND i.Uf_BomStatus IN ('B','D','E','P')
    GROUP BY c.whse;
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_new_items_snapshot]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_new_items_snapshot]
    (
        snapshot_date DATE NOT NULL, snapshot_timestamp DATETIME2(6) NOT NULL,
        snapshot_hour TINYINT NOT NULL, warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL, new_items DECIMAL(18,4) NULL,
        source_row_count BIGINT NOT NULL, date_key INT NULL,
        closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
        week_start_date DATE NULL, week_ending_date DATE NULL,
        created_ts DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_productivity_daily]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_productivity_daily]
    (
        snapshot_date DATE NOT NULL, warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL, planning_load DECIMAL(18,4) NULL,
        new_items DECIMAL(18,4) NULL, productivity_percentage DECIMAL(18,4) NULL,
        calculation_source VARCHAR(255) NULL, closed_year INT NULL,
        closed_week INT NULL, week_key INT NULL, week_start_date DATE NULL,
        week_ending_date DATE NULL, data_status VARCHAR(50) NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_productivity_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_productivity_weekly]
    (
        closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
        week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL, site_name VARCHAR(100) NOT NULL,
        snapshot_days INT NOT NULL, planning_load_avg DECIMAL(18,4) NULL,
        new_items_avg DECIMAL(18,4) NULL, productivity_percentage DECIMAL(18,4) NULL,
        source_row_count BIGINT NOT NULL, data_status VARCHAR(50) NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[kpi_result_product_engineering_productivity]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[kpi_result_product_engineering_productivity]
    (
        closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
        kpi_id BIGINT NULL, kpi_code VARCHAR(100) NOT NULL,
        kpi_name VARCHAR(255) NOT NULL, kpi_category VARCHAR(100) NOT NULL,
        organisational_unit VARCHAR(255) NOT NULL, department VARCHAR(255) NOT NULL,
        measure VARCHAR(500) NULL, measure_name VARCHAR(500) NULL, uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL, sign_label VARCHAR(100) NULL, commentary VARCHAR(1000) NULL,
        kpi_value DECIMAL(18,4) NULL, target_value DECIMAL(18,4) NULL,
        variance_value DECIMAL(18,4) NULL, performance_variance_value DECIMAL(18,4) NULL,
        breach_direction VARCHAR(20) NULL, rag_status VARCHAR(20) NOT NULL,
        data_status VARCHAR(50) NOT NULL, source_system VARCHAR(100) NOT NULL,
        source_object VARCHAR(500) NOT NULL, source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

/* 01. Capture 08:00 New Items snapshot. */
CREATE OR ALTER PROCEDURE [etl].[sp_capture_product_engineering_new_items_snapshot]
    @snapshot_timestamp DATETIME2(6)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @capture_ts DATETIME2(6)=COALESCE(@snapshot_timestamp,SYSUTCDATETIME());
    DECLARE @snapshot_date DATE=CAST(@capture_ts AS DATE);
    DECLARE @snapshot_hour TINYINT=DATEPART(HOUR,@capture_ts);

    EXEC [etl].[sp_refresh_product_engineering_new_items_current]
         @snapshot_timestamp=@capture_ts;

    DELETE FROM [dbo].[fact_product_engineering_new_items_snapshot]
    WHERE snapshot_date=@snapshot_date AND snapshot_hour=@snapshot_hour
      AND warehouse_prefix IN ('BE','MB');

    INSERT INTO [dbo].[fact_product_engineering_new_items_snapshot]
    SELECT @snapshot_date,@capture_ts,@snapshot_hour,
           UPPER(LTRIM(RTRIM(s.warehouse_prefix))),
           CASE UPPER(LTRIM(RTRIM(s.warehouse_prefix))) WHEN 'BE' THEN 'Bridgend' ELSE 'Maybole' END,
           s.new_items,COALESCE(s.source_row_count,0),
           d.date_key,d.customer_year,d.customer_week_no,d.week_key,
           d.week_start_date,d.week_end_date,SYSUTCDATETIME()
    FROM [stg_syteline].[product_engineering_new_items_current] s
    LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=@snapshot_date
    WHERE UPPER(LTRIM(RTRIM(s.warehouse_prefix))) IN ('BE','MB');
END;
GO


/* =============================================================
   MITIGATED DAILY PRODUCTIVITY FORMULA

   Evidence basis:
     - Daily Productivity is derived from Planning Load and New Items.
     - Inventory movement identity used:
         items_completed = prior_workday_planning_load
                         + current_new_items
                         - current_planning_load
     - Retrieved workbook values are consistent with a 0-1 ratio against daily
       capacity, but the literal Excel formula was not exposed.
     - Working capacities retained as configurable assumptions:
         BE = 31.00 (4 x 7.75)
         MB = 23.25 (3 x 7.75)

   Mitigation controls:
     1. Formula is labelled ESTIMATED_FORMULA_V1 in calculation_source.
     2. Negative items_completed is preserved for review, not silently forced to 0.
     3. Daily KPI is NULL where prior workday load, new items or capacity is absent.
     4. Weekly status is Estimated Formula until workbook/UAT validation is complete.
     5. Capacities are held in a configuration table so corrections do not require
        structural changes to downstream facts or the canonical KPI result.
   ============================================================= */
IF OBJECT_ID('[dbo].[product_engineering_productivity_capacity]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[product_engineering_productivity_capacity]
    (
        warehouse_prefix VARCHAR(10) NOT NULL,
        daily_capacity DECIMAL(18,4) NOT NULL,
        capacity_basis VARCHAR(255) NOT NULL,
        is_approved BIT NOT NULL,
        updated_ts DATETIME2(6) NOT NULL
    );

    INSERT INTO [dbo].[product_engineering_productivity_capacity]
    VALUES
      ('BE',31.00,'Working assumption: 4 resources x 7.75',0,SYSUTCDATETIME()),
      ('MB',23.25,'Working assumption: 3 resources x 7.75',0,SYSUTCDATETIME());
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_calculate_product_engineering_productivity_daily_estimated]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [stg_syteline].[product_engineering_productivity_daily_current];

    ;WITH planning AS
    (
        SELECT snapshot_date,warehouse_prefix,AVG(planning_load) AS planning_load
        FROM [dbo].[fact_product_engineering_planning_load_snapshot]
        WHERE snapshot_hour=8
        GROUP BY snapshot_date,warehouse_prefix
    ), newitems AS
    (
        SELECT snapshot_date,warehouse_prefix,AVG(new_items) AS new_items
        FROM [dbo].[fact_product_engineering_new_items_snapshot]
        WHERE snapshot_hour=8
        GROUP BY snapshot_date,warehouse_prefix
    ), prior_workday AS
    (
        SELECT p.*,
               LAG(p.planning_load) OVER
                 (PARTITION BY p.warehouse_prefix ORDER BY p.snapshot_date) AS prior_planning_load
        FROM planning p
    ), calculated AS
    (
        SELECT p.snapshot_date,p.warehouse_prefix,p.planning_load,
               p.prior_planning_load,n.new_items,c.daily_capacity,
               CAST(p.prior_planning_load + n.new_items - p.planning_load AS DECIMAL(18,4)) AS items_completed
        FROM prior_workday p
        LEFT JOIN newitems n
          ON n.snapshot_date=p.snapshot_date AND n.warehouse_prefix=p.warehouse_prefix
        LEFT JOIN [dbo].[product_engineering_productivity_capacity] c
          ON c.warehouse_prefix=p.warehouse_prefix
    )
    INSERT INTO [stg_syteline].[product_engineering_productivity_daily_current]
    (snapshot_date,warehouse_prefix,productivity_percentage,calculation_source)
    SELECT snapshot_date,warehouse_prefix,
           CAST(CASE WHEN prior_planning_load IS NOT NULL
                           AND new_items IS NOT NULL
                           AND daily_capacity>0
                     THEN items_completed/daily_capacity END AS DECIMAL(18,4)),
           CONCAT('ESTIMATED_FORMULA_V1: (prior planning load + new items - current planning load) / capacity; capacity=',
                  CAST(daily_capacity AS VARCHAR(30)))
    FROM calculated;
END;
GO

/* 02. Combine Planning Load, New Items and supplied daily spreadsheet percentage. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_productivity_daily]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_product_engineering_productivity_daily];

    ;WITH planning AS
    (
        SELECT snapshot_date,warehouse_prefix,site_name,closed_year,closed_week,
               week_key,week_start_date,week_ending_date,AVG(planning_load) planning_load
        FROM [dbo].[fact_product_engineering_planning_load_snapshot]
        WHERE snapshot_hour=8
        GROUP BY snapshot_date,warehouse_prefix,site_name,closed_year,closed_week,
                 week_key,week_start_date,week_ending_date
    ), newitems AS
    (
        SELECT snapshot_date,warehouse_prefix,AVG(new_items) new_items
        FROM [dbo].[fact_product_engineering_new_items_snapshot]
        WHERE snapshot_hour=8
        GROUP BY snapshot_date,warehouse_prefix
    )
    INSERT INTO [dbo].[fact_product_engineering_productivity_daily]
    SELECT p.snapshot_date,p.warehouse_prefix,p.site_name,p.planning_load,n.new_items,
           x.productivity_percentage,x.calculation_source,
           p.closed_year,p.closed_week,p.week_key,p.week_start_date,p.week_ending_date,
           CASE WHEN x.productivity_percentage IS NULL THEN 'Formula Pending'
                WHEN x.calculation_source LIKE 'ESTIMATED_FORMULA_V1%' THEN 'Estimated Formula'
                ELSE 'Actual' END,
           SYSUTCDATETIME()
    FROM planning p
    LEFT JOIN newitems n
      ON n.snapshot_date=p.snapshot_date AND n.warehouse_prefix=p.warehouse_prefix
    LEFT JOIN [stg_syteline].[product_engineering_productivity_daily_current] x
      ON x.snapshot_date=p.snapshot_date AND UPPER(x.warehouse_prefix)=p.warehouse_prefix;
END;
GO

/* 03. Weekly KPI basis = average of available Monday-Friday daily percentages. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_productivity_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_product_engineering_productivity_weekly];

    INSERT INTO [dbo].[fact_product_engineering_productivity_weekly]
    SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
           warehouse_prefix,site_name,COUNT(*) snapshot_days,
           CAST(AVG(planning_load) AS DECIMAL(18,4)),
           CAST(AVG(new_items) AS DECIMAL(18,4)),
           CAST(AVG(productivity_percentage) AS DECIMAL(18,4)),
           COUNT_BIG(*),
           CASE WHEN COUNT(productivity_percentage)=0 THEN 'Formula Pending'
                WHEN MAX(CASE WHEN data_status='Estimated Formula' THEN 1 ELSE 0 END)=1 THEN 'Estimated Formula'
                WHEN COUNT(productivity_percentage)<5 THEN 'Partial Week'
                ELSE 'Actual' END,
           SYSUTCDATETIME()
    FROM [dbo].[fact_product_engineering_productivity_daily]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,
             warehouse_prefix,site_name;
END;
GO

/* 04. Enriched KPI. Provisional codes until dim_kpi confirms final codes. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_product_engineering_productivity]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[kpi_result_product_engineering_productivity];

    ;WITH b AS
    (
        SELECT w.*,
               CASE warehouse_prefix WHEN 'BE' THEN 'ProductEng-BE-KPI-P1'
                                     ELSE 'ProductEng-MB-KPI-P1' END kpi_code,
               CASE warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend'
                                     ELSE 'Product Engineering Maybole' END org_unit
        FROM [dbo].[fact_product_engineering_productivity_weekly] w
    ), e AS
    (
        SELECT b.*,k.kpi_id,CAST(k.target_value AS DECIMAL(18,4)) target_value,
               UPPER(NULLIF(k.breach_direction,'')) breach_direction
        FROM b LEFT JOIN [dbo].[dim_kpi] k ON k.kpi_code=b.kpi_code
    )
    INSERT INTO [dbo].[kpi_result_product_engineering_productivity]
    SELECT closed_year,closed_week,week_key,kpi_id,kpi_code,
           'Product Engineering Productivity','Productivity',org_unit,org_unit,
           'Weekly average of Mon-Fri daily Product Engineering productivity percentage',
           'Product Engineering Productivity','Percentage',NULL,NULL,
           CONCAT('Snapshot days=',snapshot_days,', Planning Load avg=',planning_load_avg,
                  ', New Items avg=',new_items_avg),
           productivity_percentage,target_value,
           CASE WHEN productivity_percentage IS NULL OR target_value IS NULL THEN NULL
                ELSE productivity_percentage-target_value END,
           CASE WHEN productivity_percentage IS NULL OR target_value IS NULL OR breach_direction IS NULL THEN NULL
                WHEN breach_direction='OVER' THEN target_value-productivity_percentage
                ELSE productivity_percentage-target_value END,
           breach_direction,
           CASE WHEN productivity_percentage IS NULL THEN 'No Data'
                WHEN target_value IS NULL OR breach_direction IS NULL THEN 'TBC'
                WHEN breach_direction='UNDER' AND productivity_percentage>=target_value THEN 'G'
                WHEN breach_direction='UNDER' AND productivity_percentage>=target_value*0.95 THEN 'A'
                WHEN breach_direction='OVER' AND productivity_percentage<=target_value THEN 'G'
                WHEN breach_direction='OVER' AND productivity_percentage<=target_value*1.05 THEN 'A'
                ELSE 'R' END,
           data_status,'SyteLine + spreadsheet-equivalent daily calculation',
           'Planning Load + New Items + product_engineering_productivity_daily_current',
           source_row_count,SYSUTCDATETIME()
    FROM e;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_publish_product_engineering_productivity]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [dbo].[fact_kpi_result]
    WHERE kpi_code IN ('ProductEng-BE-KPI-P1','ProductEng-MB-KPI-P1');
    INSERT INTO [dbo].[fact_kpi_result]
    SELECT * FROM [dbo].[kpi_result_product_engineering_productivity];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_productivity]
    @snapshot_timestamp DATETIME2(6)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_capture_product_engineering_new_items_snapshot]
         @snapshot_timestamp=@snapshot_timestamp;
    EXEC [etl].[sp_calculate_product_engineering_productivity_daily_estimated];
    EXEC [etl].[sp_build_fact_product_engineering_productivity_daily];
    EXEC [etl].[sp_build_fact_product_engineering_productivity_weekly];
    EXEC [etl].[sp_build_kpi_result_product_engineering_productivity];
END;
GO

/* TEST
EXEC [etl].[sp_build_product_engineering_productivity]
     @snapshot_timestamp='2026-10-30T08:00:00';
SELECT * FROM dbo.fact_product_engineering_productivity_daily ORDER BY snapshot_date,warehouse_prefix;
SELECT * FROM dbo.fact_product_engineering_productivity_weekly ORDER BY week_ending_date,warehouse_prefix;
SELECT * FROM dbo.kpi_result_product_engineering_productivity ORDER BY closed_year,closed_week,organisational_unit;
*/
