/*
SAS PRODUCT ENGINEERING QUALITY - BRIDGEND + MAYBOLE
=====================================================
Confirmed common calculation:
    Quality defect rate = complaints / output items
    Expressed as a percentage/ratio.

Confirmed site-specific numerator sources:
  MB: SafetyCulture issues table.
  BE: SharePoint BOM Helpdesk; exclude tickets with Status = 'Non-valid'.

Confirmed denominator evidence is inconsistent:
  A) Number of items completed; and
  B) Number of new lines set to BOM status C on a given day.

Mitigation:
  - Both denominator methods are supported through configuration.
  - Default is ITEMS_COMPLETED because the later shared mapping describes the common
    BE/MB calculation as complaints divided by items completed.
  - No result is represented as approved until denominator_method is confirmed.
  - Maybole SafetyCulture issue filters from the PBIX are not available, so an
    explicit adapter is used rather than inventing predicates.
  - Bridgend SharePoint BOM Helpdesk is not yet shown as landed, so an empty adapter
    is created and may remain empty.

Required existing fact:
  dbo.fact_product_engineering_items_completed_daily

Optional direct denominator input:
  stg_syteline.product_engineering_bom_status_c_daily
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO
IF SCHEMA_ID('etl_input') IS NULL EXEC('CREATE SCHEMA [etl_input]');
GO
IF SCHEMA_ID('stg_syteline') IS NULL EXEC('CREATE SCHEMA [stg_syteline]');
GO

/* SafetyCulture adapter: populate from safety_culture_staging issues when landed. */
IF OBJECT_ID('[etl_input].[product_engineering_mb_quality_issue]', 'U') IS NULL
CREATE TABLE [etl_input].[product_engineering_mb_quality_issue]
(
 issue_id VARCHAR(255) NOT NULL,
 issue_date DATE NOT NULL,
 warehouse_prefix VARCHAR(10) NOT NULL,
 is_in_scope BIT NOT NULL,
 source_row_count BIGINT NULL
);
GO

/* SharePoint BOM Helpdesk adapter for Bridgend. */
IF OBJECT_ID('[etl_input].[product_engineering_be_bom_helpdesk]', 'U') IS NULL
CREATE TABLE [etl_input].[product_engineering_be_bom_helpdesk]
(
 ticket_id VARCHAR(255) NOT NULL,
 ticket_date DATE NOT NULL,
 status VARCHAR(100) NULL,
 warehouse_prefix VARCHAR(10) NOT NULL,
 source_row_count BIGINT NULL
);
GO

/* Optional exact denominator when BOM-status-C output is available. */
IF OBJECT_ID('[stg_syteline].[product_engineering_bom_status_c_daily]', 'U') IS NULL
CREATE TABLE [stg_syteline].[product_engineering_bom_status_c_daily]
(
 output_date DATE NOT NULL,
 warehouse_prefix VARCHAR(10) NOT NULL,
 bom_status_c_items DECIMAL(18,4) NULL,
 source_row_count BIGINT NULL
);
GO

IF OBJECT_ID('[dbo].[product_engineering_quality_config]', 'U') IS NULL
BEGIN
 CREATE TABLE [dbo].[product_engineering_quality_config]
 (
  warehouse_prefix VARCHAR(10) NOT NULL,
  denominator_method VARCHAR(50) NOT NULL,
  target_value DECIMAL(18,6) NULL,
  breach_direction VARCHAR(20) NOT NULL,
  is_approved BIT NOT NULL,
  notes VARCHAR(1000) NULL,
  updated_ts DATETIME2(6) NOT NULL
 );
 INSERT INTO [dbo].[product_engineering_quality_config]
 VALUES
 ('BE','ITEMS_COMPLETED',0.025,'OVER',0,'Working method; customer evidence also references BOM_STATUS_C.',SYSUTCDATETIME()),
 ('MB','ITEMS_COMPLETED',0.025,'OVER',0,'Working method; customer evidence also references BOM_STATUS_C.',SYSUTCDATETIME());
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_quality_daily]', 'U') IS NULL
CREATE TABLE [dbo].[fact_product_engineering_quality_daily]
(
 reporting_date DATE NOT NULL,
 warehouse_prefix VARCHAR(10) NOT NULL,
 site_name VARCHAR(100) NOT NULL,
 complaint_count BIGINT NOT NULL,
 denominator_method VARCHAR(50) NOT NULL,
 output_items DECIMAL(18,4) NULL,
 defect_rate DECIMAL(18,6) NULL,
 numerator_source VARCHAR(500) NOT NULL,
 denominator_source VARCHAR(500) NOT NULL,
 config_approved BIT NOT NULL,
 data_status VARCHAR(100) NOT NULL,
 date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
 week_start_date DATE NULL, week_ending_date DATE NULL,
 source_row_count BIGINT NOT NULL,
 calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_quality_weekly]', 'U') IS NULL
CREATE TABLE [dbo].[fact_product_engineering_quality_weekly]
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 warehouse_prefix VARCHAR(10) NOT NULL, site_name VARCHAR(100) NOT NULL,
 complaint_count BIGINT NOT NULL, output_items DECIMAL(18,4) NULL,
 defect_rate DECIMAL(18,6) NULL, denominator_method VARCHAR(50) NOT NULL,
 complete_days INT NOT NULL, config_approved BIT NOT NULL,
 data_status VARCHAR(100) NOT NULL, source_row_count BIGINT NOT NULL,
 calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[dbo].[kpi_result_product_engineering_quality]', 'U') IS NULL
SELECT TOP 0 * INTO [dbo].[kpi_result_product_engineering_quality]
FROM [dbo].[fact_kpi_result];
GO

/* 01. Build common daily numerator and configured denominator. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_quality_daily]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE [dbo].[fact_product_engineering_quality_daily];

 ;WITH complaints AS
 (
  SELECT issue_date reporting_date,'MB' warehouse_prefix,
         COUNT(DISTINCT issue_id) complaint_count,
         SUM(COALESCE(source_row_count,1)) source_rows,
         CAST('SafetyCulture issues adapter' AS VARCHAR(500)) numerator_source
  FROM [etl_input].[product_engineering_mb_quality_issue]
  WHERE is_in_scope=1
  GROUP BY issue_date
  UNION ALL
  SELECT ticket_date,'BE',COUNT(DISTINCT ticket_id),SUM(COALESCE(source_row_count,1)),
         CAST('SharePoint BOM Helpdesk adapter' AS VARCHAR(500))
  FROM [etl_input].[product_engineering_be_bom_helpdesk]
  WHERE LOWER(LTRIM(RTRIM(COALESCE(status,''))))<>'non-valid'
  GROUP BY ticket_date
 ), items_completed AS
 (
  SELECT snapshot_date reporting_date,warehouse_prefix,
         SUM(items_completed) output_items,
         CAST('dbo.fact_product_engineering_items_completed_daily' AS VARCHAR(500)) denominator_source
  FROM [dbo].[fact_product_engineering_items_completed_daily]
  WHERE items_completed IS NOT NULL
  GROUP BY snapshot_date,warehouse_prefix
 ), bom_c AS
 (
  SELECT output_date reporting_date,UPPER(warehouse_prefix) warehouse_prefix,
         SUM(bom_status_c_items) output_items,
         CAST('stg_syteline.product_engineering_bom_status_c_daily' AS VARCHAR(500)) denominator_source
  FROM [stg_syteline].[product_engineering_bom_status_c_daily]
  GROUP BY output_date,UPPER(warehouse_prefix)
 ), dates AS
 (
  SELECT reporting_date,warehouse_prefix FROM complaints
  UNION
  SELECT reporting_date,warehouse_prefix FROM items_completed
  UNION
  SELECT reporting_date,warehouse_prefix FROM bom_c
 ), combined AS
 (
  SELECT x.reporting_date,x.warehouse_prefix,
         CASE x.warehouse_prefix WHEN 'BE' THEN 'Bridgend' ELSE 'Maybole' END site_name,
         COALESCE(c.complaint_count,0) complaint_count,
         cfg.denominator_method,cfg.is_approved,
         CASE WHEN cfg.denominator_method='BOM_STATUS_C' THEN b.output_items ELSE i.output_items END output_items,
         c.numerator_source,
         CASE WHEN cfg.denominator_method='BOM_STATUS_C' THEN b.denominator_source ELSE i.denominator_source END denominator_source,
         COALESCE(c.source_rows,0) source_rows
  FROM dates x
  JOIN dbo.product_engineering_quality_config cfg ON cfg.warehouse_prefix=x.warehouse_prefix
  LEFT JOIN complaints c ON c.reporting_date=x.reporting_date AND c.warehouse_prefix=x.warehouse_prefix
  LEFT JOIN items_completed i ON i.reporting_date=x.reporting_date AND i.warehouse_prefix=x.warehouse_prefix
  LEFT JOIN bom_c b ON b.reporting_date=x.reporting_date AND b.warehouse_prefix=x.warehouse_prefix
 )
 INSERT INTO dbo.fact_product_engineering_quality_daily
 SELECT x.reporting_date,x.warehouse_prefix,x.site_name,x.complaint_count,
        x.denominator_method,x.output_items,
        CAST(CASE WHEN x.output_items>0 THEN 1.0*x.complaint_count/x.output_items END AS DECIMAL(18,6)),
        COALESCE(x.numerator_source,'No numerator rows'),
        COALESCE(x.denominator_source,'Denominator source unavailable'),
        x.is_approved,
        CASE WHEN x.output_items IS NULL THEN 'Missing Denominator'
             WHEN x.output_items<=0 THEN 'Invalid Denominator'
             WHEN x.is_approved=0 THEN 'Working Logic - Approval Required'
             ELSE 'Actual' END,
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        x.source_rows,SYSUTCDATETIME()
 FROM combined x
 LEFT JOIN dbo.dim_date d ON d.calendar_date=x.reporting_date;
END;
GO

/* 02. Weekly rate uses summed numerator / summed denominator, not average daily rates. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_quality_weekly]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE dbo.fact_product_engineering_quality_weekly;
 INSERT INTO dbo.fact_product_engineering_quality_weekly
 SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
        warehouse_prefix,MAX(site_name),SUM(complaint_count),SUM(output_items),
        CAST(CASE WHEN SUM(output_items)>0 THEN 1.0*SUM(complaint_count)/SUM(output_items) END AS DECIMAL(18,6)),
        MAX(denominator_method),COUNT(CASE WHEN output_items>0 THEN 1 END),MIN(config_approved),
        CASE WHEN SUM(output_items) IS NULL OR SUM(output_items)<=0 THEN 'No Data'
             WHEN MIN(config_approved)=0 THEN 'Working Logic - Approval Required'
             ELSE 'Actual' END,
        SUM(source_row_count),SYSUTCDATETIME()
 FROM dbo.fact_product_engineering_quality_daily
 WHERE week_key IS NOT NULL
 GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,warehouse_prefix;
END;
GO

/* 03. Enriched KPI, target 2.5% unless dim_kpi overrides. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_product_engineering_quality]
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE dbo.kpi_result_product_engineering_quality;
 INSERT INTO dbo.kpi_result_product_engineering_quality
 SELECT w.closed_year,w.closed_week,w.week_key,k.kpi_id,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'ProductEng-BE-KPI-Q1' ELSE 'ProductEng-MB-KPI-Q1' END,
        'Quality Defects as a Percentage of Items Output','Quality',
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
        'Complaints divided by output items','Quality Defect Rate','Percentage',
        'Over Breach','Over Breach',
        CONCAT('Complaints=',w.complaint_count,', output=',w.output_items,
               ', denominator=',w.denominator_method,', approved=',w.config_approved),
        w.defect_rate,COALESCE(CAST(k.target_value AS DECIMAL(18,4)),CAST(0.025 AS DECIMAL(18,4))),
        CASE WHEN w.defect_rate IS NULL THEN NULL ELSE w.defect_rate-COALESCE(CAST(k.target_value AS DECIMAL(18,4)),0.025) END,
        CASE WHEN w.defect_rate IS NULL THEN NULL ELSE COALESCE(CAST(k.target_value AS DECIMAL(18,4)),0.025)-w.defect_rate END,
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'OVER'),
        CASE WHEN w.defect_rate IS NULL THEN 'No Data'
             WHEN w.config_approved=0 THEN 'TBC'
             WHEN w.defect_rate<=COALESCE(CAST(k.target_value AS DECIMAL(18,4)),0.025) THEN 'G'
             WHEN w.defect_rate<=COALESCE(CAST(k.target_value AS DECIMAL(18,4)),0.025)*1.05 THEN 'A'
             ELSE 'R' END,
        w.data_status,'SafetyCulture / SharePoint + SyteLine',
        'Quality adapters + Product Engineering output fact',w.source_row_count,SYSUTCDATETIME()
 FROM dbo.fact_product_engineering_quality_weekly w
 LEFT JOIN dbo.dim_kpi k
   ON k.kpi_code=CASE w.warehouse_prefix WHEN 'BE' THEN 'ProductEng-BE-KPI-Q1' ELSE 'ProductEng-MB-KPI-Q1' END;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_quality]
AS
BEGIN
 EXEC etl.sp_build_fact_product_engineering_quality_daily;
 EXEC etl.sp_build_fact_product_engineering_quality_weekly;
 EXEC etl.sp_build_kpi_product_engineering_quality;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_publish_product_engineering_quality]
AS
BEGIN
 DELETE FROM dbo.fact_kpi_result WHERE kpi_code IN ('ProductEng-BE-KPI-Q1','ProductEng-MB-KPI-Q1');
 INSERT INTO dbo.fact_kpi_result SELECT * FROM dbo.kpi_result_product_engineering_quality;
END;
GO

/* EXEC etl.sp_build_product_engineering_quality; */
