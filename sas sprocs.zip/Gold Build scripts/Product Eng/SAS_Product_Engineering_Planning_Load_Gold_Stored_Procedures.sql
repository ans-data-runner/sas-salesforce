/*
SAS PRODUCT ENGINEERING - PLANNING LOAD SNAPSHOT FOUNDATION
==========================================================
Confirmed customer requirements:
  - Applies to Product Engineering BE (Bridgend) and MB (Maybole).
  - Planning Load and New Items are SyteLine inputs to the Productivity KPI.
  - Values are point-in-time and must be captured daily at 08:00 Monday-Friday.
  - Weekly Productivity is an average of daily calculated values, so daily history
    must be persisted rather than reconstructed later.

IMPORTANT EVIDENCE LIMITATION
  The retrieved customer material says the Planning Load SQL is contained in the
  supplied Product Engineering spreadsheet, but the actual SQL text is not exposed
  in the currently retrieved evidence. Therefore this pack does NOT invent SyteLine
  table joins or filters.

Best buildable contract now:
  1. Create a Gold staging contract into which Sarah's confirmed Planning Load query
     can be landed/executed once recovered.
  2. Persist an append-only 08:00 snapshot fact by site/date.
  3. Derive a weekly Planning Load supporting fact from those daily snapshots.

Staging input expected:
  stg_syteline.product_engineering_planning_load_current
    warehouse_prefix  VARCHAR(10)   -- BE / MB
    planning_load     DECIMAL(18,4)
    source_row_count  BIGINT

This staging object represents the OUTPUT of Sarah's Planning Load SQL, not a manual
runtime KPI source. Replace its population step with the exact SyteLine SQL as soon
as that query is recovered.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO
IF SCHEMA_ID('stg_syteline') IS NULL EXEC('CREATE SCHEMA [stg_syteline]');
GO

/* Empty staging shell for the recovered Sarah Planning Load query output. */
IF OBJECT_ID('[stg_syteline].[product_engineering_planning_load_current]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_syteline].[product_engineering_planning_load_current]
    (
        warehouse_prefix VARCHAR(10)   NOT NULL,
        planning_load    DECIMAL(18,4) NULL,
        source_row_count BIGINT        NULL
    );
END;
GO

/* =============================================================
   00. GOLD TABLES
   ============================================================= */
IF OBJECT_ID('[dbo].[fact_product_engineering_planning_load_snapshot]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_planning_load_snapshot]
    (
        snapshot_date        DATE          NOT NULL,
        snapshot_timestamp   DATETIME2(6)  NOT NULL,
        snapshot_hour        TINYINT       NOT NULL,
        warehouse_prefix     VARCHAR(10)   NOT NULL,
        site_name            VARCHAR(100)  NOT NULL,
        planning_load        DECIMAL(18,4) NULL,
        source_row_count     BIGINT        NOT NULL,
        date_key             INT           NULL,
        closed_year          INT           NULL,
        closed_week          INT           NULL,
        week_key             INT           NULL,
        week_start_date      DATE          NULL,
        week_ending_date     DATE          NULL,
        created_ts           DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_planning_load_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_planning_load_weekly]
    (
        closed_year             INT           NOT NULL,
        closed_week             INT           NOT NULL,
        week_key                INT           NOT NULL,
        week_start_date         DATE          NOT NULL,
        week_ending_date        DATE          NOT NULL,
        warehouse_prefix        VARCHAR(10)   NOT NULL,
        site_name               VARCHAR(100)  NOT NULL,
        snapshot_days           INT           NOT NULL,
        planning_load_avg       DECIMAL(18,4) NULL,
        planning_load_min       DECIMAL(18,4) NULL,
        planning_load_max       DECIMAL(18,4) NULL,
        source_row_count        BIGINT        NOT NULL,
        calculation_timestamp   DATETIME2(6)  NOT NULL
    );
END;
GO

/* =============================================================
   01. CAPTURE DAILY PLANNING LOAD SNAPSHOT

   Designed to be scheduled at 08:00 Mon-Fri.
   This procedure deliberately does not delete historical snapshots.
   It replaces only the same site/date/hour capture if rerun, allowing the
   scheduled 08:00 load to be retried without creating duplicate snapshots.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_capture_product_engineering_planning_load_snapshot]
    @snapshot_timestamp DATETIME2(6) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @capture_ts DATETIME2(6) = COALESCE(@snapshot_timestamp, SYSUTCDATETIME());
    DECLARE @snapshot_date DATE = CAST(@capture_ts AS DATE);
    DECLARE @snapshot_hour TINYINT = DATEPART(HOUR,@capture_ts);

    DELETE FROM [dbo].[fact_product_engineering_planning_load_snapshot]
    WHERE snapshot_date=@snapshot_date
      AND snapshot_hour=@snapshot_hour
      AND warehouse_prefix IN ('BE','MB');

    INSERT INTO [dbo].[fact_product_engineering_planning_load_snapshot]
    (
        snapshot_date,snapshot_timestamp,snapshot_hour,
        warehouse_prefix,site_name,planning_load,source_row_count,
        date_key,closed_year,closed_week,week_key,
        week_start_date,week_ending_date,created_ts
    )
    SELECT
        @snapshot_date,
        @capture_ts,
        @snapshot_hour,
        UPPER(LTRIM(RTRIM(s.warehouse_prefix))),
        CASE UPPER(LTRIM(RTRIM(s.warehouse_prefix)))
            WHEN 'BE' THEN 'Bridgend'
            WHEN 'MB' THEN 'Maybole'
        END,
        CAST(s.planning_load AS DECIMAL(18,4)),
        COALESCE(s.source_row_count,0),
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,
        d.week_start_date,d.week_end_date,SYSUTCDATETIME()
    FROM [stg_syteline].[product_engineering_planning_load_current] s
    LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=@snapshot_date
    WHERE UPPER(LTRIM(RTRIM(s.warehouse_prefix))) IN ('BE','MB');
END;
GO

/* =============================================================
   02. WEEKLY SUPPORTING FACT

   This is intentionally a supporting fact only. The customer evidence says
   final Productivity uses daily spreadsheet calculations derived from both
   Planning Load and New Items. Therefore Planning Load alone must not be
   published as the Productivity KPI.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_planning_load_weekly]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_product_engineering_planning_load_weekly];

    ;WITH daily AS
    (
        SELECT
            snapshot_date,closed_year,closed_week,week_key,
            week_start_date,week_ending_date,
            warehouse_prefix,site_name,
            AVG(planning_load) AS daily_planning_load,
            SUM(source_row_count) AS daily_source_rows
        FROM [dbo].[fact_product_engineering_planning_load_snapshot]
        WHERE week_key IS NOT NULL
          AND snapshot_hour=8
        GROUP BY snapshot_date,closed_year,closed_week,week_key,
                 week_start_date,week_ending_date,warehouse_prefix,site_name
    )
    INSERT INTO [dbo].[fact_product_engineering_planning_load_weekly]
    SELECT
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        warehouse_prefix,site_name,
        COUNT(*) AS snapshot_days,
        CAST(AVG(daily_planning_load) AS DECIMAL(18,4)),
        CAST(MIN(daily_planning_load) AS DECIMAL(18,4)),
        CAST(MAX(daily_planning_load) AS DECIMAL(18,4)),
        SUM(daily_source_rows),
        SYSUTCDATETIME()
    FROM daily
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,
             warehouse_prefix,site_name;
END;
GO

/* =============================================================
   03. BUILD CURRENT SNAPSHOT + WEEKLY SUPPORT
   Run this after the exact Sarah SQL has populated
   stg_syteline.product_engineering_planning_load_current.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_planning_load]
    @snapshot_timestamp DATETIME2(6) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_capture_product_engineering_planning_load_snapshot]
         @snapshot_timestamp=@snapshot_timestamp;
    EXEC [etl].[sp_build_fact_product_engineering_planning_load_weekly];
END;
GO

/* =============================================================
   TEST / VALIDATION QUERIES
   =============================================================
-- Example structural test using an explicit 08:00 timestamp:
EXEC [etl].[sp_build_product_engineering_planning_load]
     @snapshot_timestamp='2026-10-30T08:00:00';

SELECT *
FROM [dbo].[fact_product_engineering_planning_load_snapshot]
ORDER BY snapshot_date,warehouse_prefix,snapshot_timestamp;

SELECT *
FROM [dbo].[fact_product_engineering_planning_load_weekly]
ORDER BY week_ending_date,warehouse_prefix;

-- Production scheduling expectation from customer evidence:
-- run at 08:00 Monday-Friday once Sarah's Planning Load query output is wired in.
*/
