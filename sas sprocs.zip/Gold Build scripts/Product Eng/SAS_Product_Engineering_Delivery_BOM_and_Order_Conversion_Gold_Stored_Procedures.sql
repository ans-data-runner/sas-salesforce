/*
SAS PRODUCT ENGINEERING DELIVERY KPIs
BOM LEAD TIME + FULL ORDER CONVERSION LEAD TIME
================================================
Two separate KPI stored procedures as requested.

Customer-defined KPI contracts recovered from SAS mapping:

1) BOM Lead Time
   Name: BOM Leadtime
   UOM: Days
   Target: 5 days
   Breach: OVER
   Source: existing Power BI BOM report
   Calculation: BOM lead time expressed as days

2) Full Order Conversion Lead Time
   Name: Lead Time for Full Order
   UOM: Days
   Target: 10 days
   Breach: OVER
   Source: Ops Process Mgmt Performance Figures.xlsx
   Calculation: for drawings completed that week, average Lead Time in days
                for full order conversion.

IMPORTANT MITIGATION
--------------------
The retrieved mapping defines the KPI outputs but does not expose the physical source
columns / joins used by the existing BOM Power BI report or the workbook's full-order
conversion calculation. Those predicates are therefore NOT invented here.

The procedures use narrow Gold-staging contracts that can be populated from the
recovered PBIX/SQL logic without changing downstream KPI procedures:

  stg_syteline.product_engineering_bom_lead_time
  stg_syteline.product_engineering_order_conversion

Both contracts support BE / MB and event-level dates/durations. If the landed source
already provides lead-time days, populate lead_time_days directly. If start/end dates
are available instead, the procedures derive DATEDIFF(day,start,end).

No overwrite-protection / backup logic is included.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO
IF SCHEMA_ID('stg_syteline') IS NULL EXEC('CREATE SCHEMA [stg_syteline]');
GO

/* =============================================================
   STAGING CONTRACTS
   ============================================================= */
IF OBJECT_ID('[stg_syteline].[product_engineering_bom_lead_time]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_syteline].[product_engineering_bom_lead_time]
    (
        source_record_id   VARCHAR(255)  NOT NULL,
        warehouse_prefix   VARCHAR(10)   NOT NULL,
        reporting_date     DATE          NULL,
        bom_start_date     DATE          NULL,
        bom_complete_date  DATE          NULL,
        lead_time_days     DECIMAL(18,4) NULL,
        source_row_count   BIGINT        NULL
    );
END;
GO

IF OBJECT_ID('[stg_syteline].[product_engineering_order_conversion]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_syteline].[product_engineering_order_conversion]
    (
        source_record_id       VARCHAR(255)  NOT NULL,
        warehouse_prefix       VARCHAR(10)   NOT NULL,
        drawing_completed_date DATE          NULL,
        conversion_start_date  DATE          NULL,
        conversion_end_date    DATE          NULL,
        lead_time_days         DECIMAL(18,4) NULL,
        source_row_count       BIGINT        NULL
    );
END;
GO

/* =============================================================
   GOLD FACTS
   ============================================================= */
IF OBJECT_ID('[dbo].[fact_product_engineering_bom_lead_time]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_bom_lead_time]
    (
        source_record_id VARCHAR(255) NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL,
        reporting_date DATE NULL,
        bom_start_date DATE NULL,
        bom_complete_date DATE NULL,
        lead_time_days DECIMAL(18,4) NULL,
        date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
        week_start_date DATE NULL, week_ending_date DATE NULL,
        source_row_count BIGINT NOT NULL,
        created_ts DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_bom_lead_time_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_bom_lead_time_weekly]
    (
        closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
        week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL, site_name VARCHAR(100) NOT NULL,
        completed_records BIGINT NOT NULL,
        average_lead_time_days DECIMAL(18,4) NULL,
        min_lead_time_days DECIMAL(18,4) NULL,
        max_lead_time_days DECIMAL(18,4) NULL,
        source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_order_conversion]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_order_conversion]
    (
        source_record_id VARCHAR(255) NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL,
        drawing_completed_date DATE NULL,
        conversion_start_date DATE NULL,
        conversion_end_date DATE NULL,
        lead_time_days DECIMAL(18,4) NULL,
        date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
        week_start_date DATE NULL, week_ending_date DATE NULL,
        source_row_count BIGINT NOT NULL,
        created_ts DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_order_conversion_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_order_conversion_weekly]
    (
        closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
        week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL, site_name VARCHAR(100) NOT NULL,
        drawings_completed BIGINT NOT NULL,
        average_lead_time_days DECIMAL(18,4) NULL,
        min_lead_time_days DECIMAL(18,4) NULL,
        max_lead_time_days DECIMAL(18,4) NULL,
        source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

/* =============================================================
   KPI RESULT TABLES
   ============================================================= */
IF OBJECT_ID('[dbo].[kpi_result_product_engineering_bom_delivery]', 'U') IS NULL
SELECT TOP 0 * INTO [dbo].[kpi_result_product_engineering_bom_delivery]
FROM [dbo].[fact_kpi_result];
GO

IF OBJECT_ID('[dbo].[kpi_result_product_engineering_order_conversion_delivery]', 'U') IS NULL
SELECT TOP 0 * INTO [dbo].[kpi_result_product_engineering_order_conversion_delivery]
FROM [dbo].[fact_kpi_result];
GO

/* =============================================================
   SUPPORT: BUILD BOM EVENT + WEEKLY FACT
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_bom_lead_time_facts]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_product_engineering_bom_lead_time];
    TRUNCATE TABLE [dbo].[fact_product_engineering_bom_lead_time_weekly];

    INSERT INTO [dbo].[fact_product_engineering_bom_lead_time]
    SELECT
        s.source_record_id,
        UPPER(LTRIM(RTRIM(s.warehouse_prefix))),
        CASE UPPER(LTRIM(RTRIM(s.warehouse_prefix))) WHEN 'BE' THEN 'Bridgend' ELSE 'Maybole' END,
        COALESCE(s.reporting_date,s.bom_complete_date),
        s.bom_start_date,s.bom_complete_date,
        CAST(COALESCE(s.lead_time_days,
            CASE WHEN s.bom_start_date IS NOT NULL AND s.bom_complete_date IS NOT NULL
                 THEN DATEDIFF(DAY,s.bom_start_date,s.bom_complete_date) END) AS DECIMAL(18,4)),
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        COALESCE(s.source_row_count,1),SYSUTCDATETIME()
    FROM [stg_syteline].[product_engineering_bom_lead_time] s
    LEFT JOIN [dbo].[dim_date] d
      ON d.calendar_date=COALESCE(s.reporting_date,s.bom_complete_date)
    WHERE UPPER(LTRIM(RTRIM(s.warehouse_prefix))) IN ('BE','MB');

    INSERT INTO [dbo].[fact_product_engineering_bom_lead_time_weekly]
    SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
           warehouse_prefix,MAX(site_name),COUNT(DISTINCT source_record_id),
           CAST(AVG(lead_time_days) AS DECIMAL(18,4)),
           CAST(MIN(lead_time_days) AS DECIMAL(18,4)),
           CAST(MAX(lead_time_days) AS DECIMAL(18,4)),
           SUM(source_row_count),SYSUTCDATETIME()
    FROM [dbo].[fact_product_engineering_bom_lead_time]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,warehouse_prefix;
END;
GO

/* =============================================================
   KPI PROCEDURE 1: BOM LEAD TIME
   Customer target = 5 days; OVER is breach.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_product_engineering_bom_lead_time]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_product_engineering_bom_lead_time_facts];
    TRUNCATE TABLE [dbo].[kpi_result_product_engineering_bom_delivery];

    /* Canonical column order assumed to match fact_kpi_result. */
    INSERT INTO [dbo].[kpi_result_product_engineering_bom_delivery]
    SELECT
        w.closed_year,w.closed_week,w.week_key,
        k.kpi_id,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'ProductEng-BE-KPI-D1' ELSE 'ProductEng-MB-KPI-D1' END,
        'BOM Leadtime','Delivery',
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
        'Average BOM lead time in days','BOM Leadtime','Days','Over Breach','Over Breach',
        CONCAT('Completed records=',w.completed_records,'; staging contract used until PBIX physical mapping is recovered.'),
        w.average_lead_time_days,
        COALESCE(CAST(k.target_value AS DECIMAL(18,4)),CAST(5 AS DECIMAL(18,4))),
        w.average_lead_time_days-COALESCE(CAST(k.target_value AS DECIMAL(18,4)),5),
        COALESCE(CAST(k.target_value AS DECIMAL(18,4)),5)-w.average_lead_time_days,
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'OVER'),
        CASE WHEN w.average_lead_time_days IS NULL THEN 'No Data'
             WHEN w.average_lead_time_days<=COALESCE(CAST(k.target_value AS DECIMAL(18,4)),5) THEN 'G'
             WHEN w.average_lead_time_days<=COALESCE(CAST(k.target_value AS DECIMAL(18,4)),5)*1.05 THEN 'A'
             ELSE 'R' END,
        'Actual','SyteLine / existing BOM report','stg_syteline.product_engineering_bom_lead_time',
        w.source_row_count,SYSUTCDATETIME()
    FROM [dbo].[fact_product_engineering_bom_lead_time_weekly] w
    LEFT JOIN [dbo].[dim_kpi] k
      ON k.kpi_code=CASE w.warehouse_prefix WHEN 'BE' THEN 'ProductEng-BE-KPI-D1' ELSE 'ProductEng-MB-KPI-D1' END;
END;
GO

/* =============================================================
   SUPPORT: BUILD ORDER CONVERSION EVENT + WEEKLY FACT
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_order_conversion_facts]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_product_engineering_order_conversion];
    TRUNCATE TABLE [dbo].[fact_product_engineering_order_conversion_weekly];

    INSERT INTO [dbo].[fact_product_engineering_order_conversion]
    SELECT
        s.source_record_id,
        UPPER(LTRIM(RTRIM(s.warehouse_prefix))),
        CASE UPPER(LTRIM(RTRIM(s.warehouse_prefix))) WHEN 'BE' THEN 'Bridgend' ELSE 'Maybole' END,
        s.drawing_completed_date,s.conversion_start_date,s.conversion_end_date,
        CAST(COALESCE(s.lead_time_days,
            CASE WHEN s.conversion_start_date IS NOT NULL AND s.conversion_end_date IS NOT NULL
                 THEN DATEDIFF(DAY,s.conversion_start_date,s.conversion_end_date) END) AS DECIMAL(18,4)),
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        COALESCE(s.source_row_count,1),SYSUTCDATETIME()
    FROM [stg_syteline].[product_engineering_order_conversion] s
    LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=s.drawing_completed_date
    WHERE UPPER(LTRIM(RTRIM(s.warehouse_prefix))) IN ('BE','MB');

    INSERT INTO [dbo].[fact_product_engineering_order_conversion_weekly]
    SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
           warehouse_prefix,MAX(site_name),COUNT(DISTINCT source_record_id),
           CAST(AVG(lead_time_days) AS DECIMAL(18,4)),
           CAST(MIN(lead_time_days) AS DECIMAL(18,4)),
           CAST(MAX(lead_time_days) AS DECIMAL(18,4)),
           SUM(source_row_count),SYSUTCDATETIME()
    FROM [dbo].[fact_product_engineering_order_conversion]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,warehouse_prefix;
END;
GO

/* =============================================================
   KPI PROCEDURE 2: FULL ORDER CONVERSION LEAD TIME
   Customer target = 10 days; OVER is breach.
   Grain/filter: drawings completed in the reporting week.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_product_engineering_full_order_conversion]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_product_engineering_order_conversion_facts];
    TRUNCATE TABLE [dbo].[kpi_result_product_engineering_order_conversion_delivery];

    INSERT INTO [dbo].[kpi_result_product_engineering_order_conversion_delivery]
    SELECT
        w.closed_year,w.closed_week,w.week_key,
        k.kpi_id,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'ProductEng-BE-KPI-D2' ELSE 'ProductEng-MB-KPI-D2' END,
        'Lead Time for Full Order','Delivery',
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
        'Average lead time in days for drawings completed in the reporting week',
        'Lead Time for Full Order','Days','Over Breach','Over Breach',
        CONCAT('Drawings completed=',w.drawings_completed,'; exact workbook extraction predicate remains a staging-mapping dependency.'),
        w.average_lead_time_days,
        COALESCE(CAST(k.target_value AS DECIMAL(18,4)),CAST(10 AS DECIMAL(18,4))),
        w.average_lead_time_days-COALESCE(CAST(k.target_value AS DECIMAL(18,4)),10),
        COALESCE(CAST(k.target_value AS DECIMAL(18,4)),10)-w.average_lead_time_days,
        COALESCE(NULLIF(UPPER(k.breach_direction),''),'OVER'),
        CASE WHEN w.average_lead_time_days IS NULL THEN 'No Data'
             WHEN w.average_lead_time_days<=COALESCE(CAST(k.target_value AS DECIMAL(18,4)),10) THEN 'G'
             WHEN w.average_lead_time_days<=COALESCE(CAST(k.target_value AS DECIMAL(18,4)),10)*1.05 THEN 'A'
             ELSE 'R' END,
        'Actual','SyteLine + Product Engineering workbook','stg_syteline.product_engineering_order_conversion',
        w.source_row_count,SYSUTCDATETIME()
    FROM [dbo].[fact_product_engineering_order_conversion_weekly] w
    LEFT JOIN [dbo].[dim_kpi] k
      ON k.kpi_code=CASE w.warehouse_prefix WHEN 'BE' THEN 'ProductEng-BE-KPI-D2' ELSE 'ProductEng-MB-KPI-D2' END;
END;
GO

/* Optional combined runner; the KPI calculations remain two distinct procedures. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_delivery_all]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_build_kpi_product_engineering_bom_lead_time];
    EXEC [etl].[sp_build_kpi_product_engineering_full_order_conversion];
END;
GO

/* TEST
EXEC etl.sp_build_kpi_product_engineering_bom_lead_time;
EXEC etl.sp_build_kpi_product_engineering_full_order_conversion;
SELECT * FROM dbo.kpi_result_product_engineering_bom_delivery;
SELECT * FROM dbo.kpi_result_product_engineering_order_conversion_delivery;
*/
