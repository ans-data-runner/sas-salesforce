/*
SAS PRODUCT ENGINEERING - NEW ITEMS SNAPSHOT FOUNDATION
======================================================
Confirmed customer requirements:
  - Product Engineering BE (Bridgend) and MB (Maybole).
  - New Items is a SyteLine input to the Product Engineering Productivity KPI.
  - New Items is captured at 08:00 daily Monday-Friday.
  - Values are point-in-time; daily snapshots must be persisted because historical
    states are difficult to recreate.
  - Final Productivity uses Planning Load + New Items and spreadsheet calculations;
    New Items alone is not the final KPI.

Evidence limitation:
  Customer material states that Sarah's SQL for New Items is in the Product
  Engineering spreadsheet, but the actual source SQL text is not available in the
  evidence currently retrieved. No SyteLine joins/filters are invented here.

Staging contract:
  stg_syteline.product_engineering_new_items_current
    warehouse_prefix VARCHAR(10)  -- BE / MB
    new_items        DECIMAL(18,4)
    source_row_count BIGINT

Once Sarah's SQL is recovered, replace/populate this staging contract directly from
stg_syteline source tables before executing the snapshot capture.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO
IF SCHEMA_ID('stg_syteline') IS NULL EXEC('CREATE SCHEMA [stg_syteline]');
GO

IF OBJECT_ID('[stg_syteline].[product_engineering_new_items_current]', 'U') IS NULL
BEGIN
    CREATE TABLE [stg_syteline].[product_engineering_new_items_current]
    (
        warehouse_prefix VARCHAR(10)   NOT NULL,
        new_items        DECIMAL(18,4) NULL,
        source_row_count BIGINT        NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_new_items_snapshot]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_new_items_snapshot]
    (
        snapshot_date        DATE          NOT NULL,
        snapshot_timestamp   DATETIME2(6)  NOT NULL,
        snapshot_hour        TINYINT       NOT NULL,
        warehouse_prefix     VARCHAR(10)   NOT NULL,
        site_name            VARCHAR(100)  NOT NULL,
        new_items            DECIMAL(18,4) NULL,
        source_row_count     BIGINT        NOT NULL,
        date_key             INT           NULL,
        closed_year          INT           NULL,
        closed_week          INT           NULL,
        week_key             INT           NULL,
        week_start_date      DATE          NULL,
        week_ending_date     DATE          NULL,
        created_ts           DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_product_engineering_new_items_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_product_engineering_new_items_weekly]
    (
        closed_year             INT           NOT NULL,
        closed_week             INT           NOT NULL,
        week_key                INT           NOT NULL,
        week_start_date         DATE          NOT NULL,
        week_ending_date        DATE          NOT NULL,
        warehouse_prefix        VARCHAR(10)   NOT NULL,
        site_name               VARCHAR(100)  NOT NULL,
        snapshot_days           INT           NOT NULL,
        new_items_avg           DECIMAL(18,4) NULL,
        new_items_min           DECIMAL(18,4) NULL,
        new_items_max           DECIMAL(18,4) NULL,
        source_row_count        BIGINT        NOT NULL,
        calculation_timestamp   DATETIME2(6)  NOT NULL
    );
END;
GO

/* Capture current New Items value. Schedule at 08:00 Monday-Friday.
   Same site/date/hour is replaced on retry; prior dates remain intact. */
CREATE OR ALTER PROCEDURE [etl].[sp_capture_product_engineering_new_items_snapshot]
    @snapshot_timestamp DATETIME2(6) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @capture_ts DATETIME2(6) = COALESCE(@snapshot_timestamp,SYSUTCDATETIME());
    DECLARE @snapshot_date DATE = CAST(@capture_ts AS DATE);
    DECLARE @snapshot_hour TINYINT = DATEPART(HOUR,@capture_ts);

    DELETE FROM [dbo].[fact_product_engineering_new_items_snapshot]
    WHERE snapshot_date=@snapshot_date
      AND snapshot_hour=@snapshot_hour
      AND warehouse_prefix IN ('BE','MB');

    INSERT INTO [dbo].[fact_product_engineering_new_items_snapshot]
    (
        snapshot_date,snapshot_timestamp,snapshot_hour,warehouse_prefix,
        site_name,new_items,source_row_count,date_key,closed_year,
        closed_week,week_key,week_start_date,week_ending_date,created_ts
    )
    SELECT
        @snapshot_date,@capture_ts,@snapshot_hour,
        UPPER(LTRIM(RTRIM(s.warehouse_prefix))),
        CASE UPPER(LTRIM(RTRIM(s.warehouse_prefix)))
            WHEN 'BE' THEN 'Bridgend'
            WHEN 'MB' THEN 'Maybole'
        END,
        CAST(s.new_items AS DECIMAL(18,4)),
        COALESCE(s.source_row_count,0),
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,
        d.week_start_date,d.week_end_date,SYSUTCDATETIME()
    FROM [stg_syteline].[product_engineering_new_items_current] s
    LEFT JOIN [dbo].[dim_date] d ON d.calendar_date=@snapshot_date
    WHERE UPPER(LTRIM(RTRIM(s.warehouse_prefix))) IN ('BE','MB');
END;
GO

/* Weekly supporting fact. Uses only scheduled 08:00 snapshots. */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_new_items_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [dbo].[fact_product_engineering_new_items_weekly];

    ;WITH daily AS
    (
        SELECT
            snapshot_date,closed_year,closed_week,week_key,
            week_start_date,week_ending_date,warehouse_prefix,site_name,
            AVG(new_items) AS daily_new_items,
            SUM(source_row_count) AS daily_source_rows
        FROM [dbo].[fact_product_engineering_new_items_snapshot]
        WHERE week_key IS NOT NULL
          AND snapshot_hour=8
        GROUP BY snapshot_date,closed_year,closed_week,week_key,
                 week_start_date,week_ending_date,warehouse_prefix,site_name
    )
    INSERT INTO [dbo].[fact_product_engineering_new_items_weekly]
    SELECT
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        warehouse_prefix,site_name,
        COUNT(*) AS snapshot_days,
        CAST(AVG(daily_new_items) AS DECIMAL(18,4)),
        CAST(MIN(daily_new_items) AS DECIMAL(18,4)),
        CAST(MAX(daily_new_items) AS DECIMAL(18,4)),
        SUM(daily_source_rows),SYSUTCDATETIME()
    FROM daily
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,
             warehouse_prefix,site_name;
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_build_product_engineering_new_items]
    @snapshot_timestamp DATETIME2(6) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [etl].[sp_capture_product_engineering_new_items_snapshot]
         @snapshot_timestamp=@snapshot_timestamp;
    EXEC [etl].[sp_build_fact_product_engineering_new_items_weekly];
END;
GO

/* TESTS
-- Put BE/MB output from Sarah's New Items query into current staging first.
-- Structural example using required 08:00 capture time:
EXEC [etl].[sp_build_product_engineering_new_items]
     @snapshot_timestamp='2026-10-30T08:00:00';

SELECT *
FROM [dbo].[fact_product_engineering_new_items_snapshot]
ORDER BY snapshot_date,warehouse_prefix,snapshot_timestamp;

SELECT *
FROM [dbo].[fact_product_engineering_new_items_weekly]
ORDER BY week_ending_date,warehouse_prefix;

-- Readiness check: expected weekday snapshot count is normally 5 once a full
-- Monday-Friday capture cycle exists. This query surfaces, rather than hides,
-- incomplete weeks.
SELECT week_ending_date,warehouse_prefix,snapshot_days,new_items_avg
FROM [dbo].[fact_product_engineering_new_items_weekly]
ORDER BY week_ending_date,warehouse_prefix;
*/
