/*
SAS PRODUCT ENGINEERING PRODUCTIVITY - GOLD WAREHOUSE
=====================================================
Reverse-engineered from SAS_Syteline_Product_Engineering_Productivity (1).py.

Source tables in Gold staging
  [stg_syteline].[coitem_mst]
  [stg_syteline].[item_mst]

Reference tables in Gold
  [dbo].[dim_date]
  [dbo].[dim_kpi]

Gold outputs
  [dbo].[fact_syteline_product_engineering_daily_snapshot]
  [dbo].[fact_syteline_product_engineering_productivity_weekly]
  [dbo].[kpi_result_product_engineering_productivity]
  [dbo].[fact_kpi_result] (canonical publication target)

Critical operating rule
  Planning Load is point-in-time. Execute the daily snapshot procedure once per
  business day at a consistent point in the day. Missing historic snapshots cannot
  be reconstructed reliably from the current state of coitem_mst and item_mst.

Business logic
  Planning Load   = current eligible open order-line count
  New Items       = eligible open order lines ordered on the previous calendar day
  Items Completed = previous captured Planning Load + current New Items - current Planning Load
  BE capacity     = 4 resources x 7.75 = 31.00 per day
  MB capacity     = 3 resources x 7.75 = 23.25 per day
  Daily KPI       = Items Completed / Daily Capacity
  Weekly KPI      = average Monday-Friday Daily KPI
  Target          = 0.80

The script uses straightforward build logic. The daily snapshot is intentionally
preserved because it is the required historical input, not overwrite protection.
*/

IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA [etl]');
GO

/* =============================================================
   00. GOLD OUTPUT TABLES
   ============================================================= */
IF OBJECT_ID('[dbo].[fact_syteline_product_engineering_daily_snapshot]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_syteline_product_engineering_daily_snapshot]
    (
        snapshot_date               DATE           NOT NULL,
        warehouse                   VARCHAR(10)    NOT NULL,
        site_name                   VARCHAR(100)   NOT NULL,
        site_ref                    VARCHAR(20)    NOT NULL,
        new_items_order_date        DATE           NOT NULL,
        planning_load               BIGINT         NOT NULL,
        distinct_planning_rows      BIGINT         NOT NULL,
        new_items                   BIGINT         NOT NULL,
        distinct_new_item_rows      BIGINT         NOT NULL,
        resource_count              DECIMAL(18,4)  NOT NULL,
        output_per_resource         DECIMAL(18,4)  NOT NULL,
        daily_capacity              DECIMAL(18,4)  NOT NULL,
        snapshot_timestamp          DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[fact_syteline_product_engineering_productivity_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[fact_syteline_product_engineering_productivity_weekly]
    (
        closed_year                 INT            NOT NULL,
        closed_week                 INT            NOT NULL,
        week_key                    INT            NOT NULL,
        week_start_date             DATE           NOT NULL,
        week_ending_date            DATE           NOT NULL,
        warehouse                   VARCHAR(10)    NOT NULL,
        site_name                   VARCHAR(100)   NOT NULL,
        site_ref                    VARCHAR(20)    NOT NULL,
        resource_count              DECIMAL(18,4)  NOT NULL,
        output_per_resource         DECIMAL(18,4)  NOT NULL,
        daily_capacity              DECIMAL(18,4)  NOT NULL,
        weekly_productivity         DECIMAL(18,6)  NULL,
        weekly_items_completed      BIGINT         NULL,
        average_planning_load       DECIMAL(18,4)  NULL,
        average_new_items           DECIMAL(18,4)  NULL,
        productivity_days           BIGINT         NOT NULL,
        snapshot_days               BIGINT         NOT NULL,
        maximum_snapshot_gap_days   INT            NULL,
        source_row_count            BIGINT         NOT NULL,
        target_value                DECIMAL(18,6)  NOT NULL,
        calculation_timestamp       DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[dbo].[kpi_result_product_engineering_productivity]', 'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[kpi_result_product_engineering_productivity]
    (
        closed_year                   INT            NOT NULL,
        closed_week                   INT            NOT NULL,
        week_key                      INT            NOT NULL,
        kpi_id                        BIGINT         NULL,
        kpi_code                      VARCHAR(100)   NOT NULL,
        kpi_name                      VARCHAR(255)   NOT NULL,
        kpi_category                  VARCHAR(100)   NOT NULL,
        organisational_unit           VARCHAR(255)  NOT NULL,
        department                    VARCHAR(255)  NOT NULL,
        measure                       VARCHAR(500)  NULL,
        measure_name                  VARCHAR(500)  NULL,
        uom                           VARCHAR(50)   NULL,
        sign                          VARCHAR(100)  NULL,
        sign_label                    VARCHAR(100)  NULL,
        commentary                    VARCHAR(1000) NULL,
        kpi_value                     DECIMAL(18,6) NULL,
        target_value                  DECIMAL(18,6) NULL,
        variance_value                DECIMAL(18,6) NULL,
        performance_variance_value    DECIMAL(18,6) NULL,
        breach_direction              VARCHAR(20)   NULL,
        rag_status                    VARCHAR(20)   NOT NULL,
        data_status                   VARCHAR(50)   NOT NULL,
        source_system                 VARCHAR(100)  NOT NULL,
        source_object                 VARCHAR(500)  NOT NULL,
        source_row_count              BIGINT        NOT NULL,
        calculation_timestamp         DATETIME2(6) NOT NULL
    );
END;
GO

/* =============================================================
   01. CAPTURE ONE DAILY POINT-IN-TIME SNAPSHOT

   @SnapshotDate allows controlled testing/backfill execution, but the source is
   still the CURRENT state of SyteLine. It must not be used to pretend that a
   missing historic point-in-time state can be reconstructed.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_capture_product_engineering_daily_snapshot]
    @SnapshotDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RunDate DATE = COALESCE(@SnapshotDate, CAST(GETDATE() AS DATE));
    DECLARE @NewItemsDate DATE = DATEADD(DAY, -1, @RunDate);
    DECLARE @CapturedAt DATETIME2(6) = SYSUTCDATETIME();

    /* Re-running the same date replaces only that date's two site snapshots. */
    DELETE FROM [dbo].[fact_syteline_product_engineering_daily_snapshot]
    WHERE snapshot_date = @RunDate;

    ;WITH eligible_orders AS
    (
        SELECT
            c.RowPointer AS source_row_id,
            LTRIM(RTRIM(CAST(c.item AS VARCHAR(255)))) AS item,
            UPPER(LTRIM(RTRIM(CAST(c.site_ref AS VARCHAR(20))))) AS site_ref,
            LTRIM(RTRIM(CAST(c.co_num AS VARCHAR(100)))) AS co_num,
            UPPER(LTRIM(RTRIM(CAST(c.stat AS VARCHAR(20))))) AS order_status,
            UPPER(LTRIM(RTRIM(CAST(c.whse AS VARCHAR(10))))) AS warehouse,
            TRY_CAST(c.uf_ordereddate AS DATE) AS ordered_date,
            UPPER(LTRIM(RTRIM(CAST(i.uf_bomstatus AS VARCHAR(20))))) AS bom_status
        FROM [stg_syteline].[coitem_mst] c
        INNER JOIN [stg_syteline].[item_mst] i
          ON LTRIM(RTRIM(CAST(c.item AS VARCHAR(255)))) = LTRIM(RTRIM(CAST(i.item AS VARCHAR(255))))
         AND UPPER(LTRIM(RTRIM(CAST(c.site_ref AS VARCHAR(20))))) = UPPER(LTRIM(RTRIM(CAST(i.site_ref AS VARCHAR(20)))))
        WHERE UPPER(LTRIM(RTRIM(CAST(c.site_ref AS VARCHAR(20))))) = 'RBMW'
          AND LTRIM(RTRIM(CAST(c.co_num AS VARCHAR(100)))) LIKE 'C%'
          AND UPPER(LTRIM(RTRIM(CAST(c.stat AS VARCHAR(20))))) = 'O'
          AND UPPER(LTRIM(RTRIM(CAST(c.whse AS VARCHAR(10))))) IN ('BE','MB')
          AND UPPER(LTRIM(RTRIM(CAST(i.uf_bomstatus AS VARCHAR(20))))) IN ('B','D','E','P')
    ),
    planning AS
    (
        SELECT warehouse,
               COUNT_BIG(item) AS planning_load,
               COUNT_BIG(DISTINCT CAST(source_row_id AS VARCHAR(100))) AS distinct_planning_rows
        FROM eligible_orders
        GROUP BY warehouse
    ),
    new_items AS
    (
        SELECT warehouse,
               COUNT_BIG(item) AS new_items,
               COUNT_BIG(DISTINCT CAST(source_row_id AS VARCHAR(100))) AS distinct_new_item_rows
        FROM eligible_orders
        WHERE ordered_date = @NewItemsDate
        GROUP BY warehouse
    ),
    warehouse_config AS
    (
        SELECT 'BE' warehouse, 'Bridgend' site_name,
               CAST(4.0 AS DECIMAL(18,4)) resource_count,
               CAST(7.75 AS DECIMAL(18,4)) output_per_resource,
               CAST(31.00 AS DECIMAL(18,4)) daily_capacity
        UNION ALL
        SELECT 'MB', 'Maybole', CAST(3.0 AS DECIMAL(18,4)),
               CAST(7.75 AS DECIMAL(18,4)), CAST(23.25 AS DECIMAL(18,4))
    )
    INSERT INTO [dbo].[fact_syteline_product_engineering_daily_snapshot]
    (
        snapshot_date, warehouse, site_name, site_ref, new_items_order_date,
        planning_load, distinct_planning_rows, new_items, distinct_new_item_rows,
        resource_count, output_per_resource, daily_capacity, snapshot_timestamp
    )
    SELECT
        @RunDate, w.warehouse, w.site_name, 'RBMW', @NewItemsDate,
        COALESCE(p.planning_load, 0), COALESCE(p.distinct_planning_rows, 0),
        COALESCE(n.new_items, 0), COALESCE(n.distinct_new_item_rows, 0),
        w.resource_count, w.output_per_resource, w.daily_capacity, @CapturedAt
    FROM warehouse_config w
    LEFT JOIN planning p ON p.warehouse = w.warehouse
    LEFT JOIN new_items n ON n.warehouse = w.warehouse;
END;
GO

/* =============================================================
   02. BUILD WEEKLY PRODUCTIVITY FACT FROM SNAPSHOT HISTORY
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_fact_product_engineering_productivity_weekly]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[fact_syteline_product_engineering_productivity_weekly];

    ;WITH snapshots_with_calendar AS
    (
        SELECT
            s.*,
            d.customer_year AS closed_year,
            d.customer_week_no AS closed_week,
            d.week_key,
            d.week_start_date,
            d.week_end_date AS week_ending_date,
            /* Canonical dim_date: Monday=1 through Sunday=7. */
            d.day_of_week,
            LAG(s.snapshot_date) OVER
              (PARTITION BY s.warehouse ORDER BY s.snapshot_date) AS previous_snapshot_date,
            LAG(s.planning_load) OVER
              (PARTITION BY s.warehouse ORDER BY s.snapshot_date) AS previous_planning_load
        FROM [dbo].[fact_syteline_product_engineering_daily_snapshot] s
        LEFT JOIN [dbo].[dim_date] d
          ON d.calendar_date = s.snapshot_date
    ),
    daily_productivity AS
    (
        SELECT *,
            CASE
              WHEN previous_planning_load IS NOT NULL
              THEN previous_planning_load + new_items - planning_load
            END AS items_completed,
            CASE
              WHEN previous_planning_load IS NOT NULL AND daily_capacity > 0
              THEN CAST(previous_planning_load + new_items - planning_load AS DECIMAL(18,6))
                   / CAST(daily_capacity AS DECIMAL(18,6))
            END AS daily_productivity,
            CASE WHEN previous_snapshot_date IS NOT NULL
                 THEN DATEDIFF(DAY, previous_snapshot_date, snapshot_date) END AS snapshot_gap_days
        FROM snapshots_with_calendar
    )
    INSERT INTO [dbo].[fact_syteline_product_engineering_productivity_weekly]
    (
        closed_year, closed_week, week_key, week_start_date, week_ending_date,
        warehouse, site_name, site_ref, resource_count, output_per_resource,
        daily_capacity, weekly_productivity, weekly_items_completed,
        average_planning_load, average_new_items, productivity_days, snapshot_days,
        maximum_snapshot_gap_days, source_row_count, target_value,
        calculation_timestamp
    )
    SELECT
        closed_year, closed_week, week_key, week_start_date, week_ending_date,
        warehouse, site_name, site_ref, resource_count, output_per_resource,
        daily_capacity,
        CAST(AVG(daily_productivity) AS DECIMAL(18,6)),
        SUM(items_completed),
        CAST(AVG(CAST(planning_load AS DECIMAL(18,4))) AS DECIMAL(18,4)),
        CAST(AVG(CAST(new_items AS DECIMAL(18,4))) AS DECIMAL(18,4)),
        COUNT_BIG(daily_productivity),
        COUNT_BIG(*),
        MAX(snapshot_gap_days),
        SUM(distinct_planning_rows),
        CAST(0.80 AS DECIMAL(18,6)),
        SYSUTCDATETIME()
    FROM daily_productivity
    WHERE day_of_week BETWEEN 1 AND 5
      AND week_key IS NOT NULL
    GROUP BY
        closed_year, closed_week, week_key, week_start_date, week_ending_date,
        warehouse, site_name, site_ref, resource_count, output_per_resource,
        daily_capacity;
END;
GO

/* =============================================================
   03. BUILD ENRICHED 26-COLUMN KPI OUTPUT
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_build_kpi_result_product_engineering_productivity]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [dbo].[kpi_result_product_engineering_productivity];

    ;WITH configured AS
    (
        SELECT
            w.*,
            CASE w.warehouse
              WHEN 'BE' THEN 'Product Eng - BE-KPI P1'
              WHEN 'MB' THEN 'Product Eng - MB-KPI P1'
            END AS kpi_code,
            CASE w.warehouse
              WHEN 'BE' THEN 'Product Engineering - Bridgend'
              WHEN 'MB' THEN 'Product Engineering - Maybole'
            END AS organisational_unit
        FROM [dbo].[fact_syteline_product_engineering_productivity_weekly] w
    ),
    enriched AS
    (
        SELECT
            c.*,
            k.kpi_id,
            COALESCE(CAST(k.target_value AS DECIMAL(18,6)), CAST(0.80 AS DECIMAL(18,6))) AS resolved_target,
            COALESCE(NULLIF(UPPER(k.breach_direction), ''), 'UNDER') AS resolved_breach_direction
        FROM configured c
        LEFT JOIN [dbo].[dim_kpi] k
          ON k.kpi_code = c.kpi_code
    )
    INSERT INTO [dbo].[kpi_result_product_engineering_productivity]
    (
        closed_year, closed_week, week_key, kpi_id, kpi_code, kpi_name,
        kpi_category, organisational_unit, department, measure, measure_name,
        uom, sign, sign_label, commentary, kpi_value, target_value,
        variance_value, performance_variance_value, breach_direction,
        rag_status, data_status, source_system, source_object,
        source_row_count, calculation_timestamp
    )
    SELECT
        closed_year,
        closed_week,
        week_key,
        kpi_id,
        kpi_code,
        '% Productivity',
        'Productivity',
        organisational_unit,
        organisational_unit,
        'Output of Lines vs Capacity %',
        'Output of Lines vs Capacity %',
        'Output Lines',
        'Under Breach',
        'Under Breach',
        CONCAT(
            'Weekly average Product Engineering Productivity. Days=',
            CAST(productivity_days AS VARCHAR(20)),
            ', items completed=', CAST(weekly_items_completed AS VARCHAR(20)),
            ', daily capacity=', CAST(daily_capacity AS VARCHAR(30))
        ),
        weekly_productivity,
        resolved_target,
        CASE WHEN weekly_productivity IS NULL THEN NULL
             ELSE weekly_productivity - resolved_target END,
        CASE
          WHEN weekly_productivity IS NULL THEN NULL
          WHEN resolved_breach_direction = 'OVER'
            THEN resolved_target - weekly_productivity
          ELSE weekly_productivity - resolved_target
        END,
        resolved_breach_direction,
        CASE
          WHEN weekly_productivity IS NULL THEN 'No Data'
          WHEN resolved_breach_direction = 'UNDER' AND weekly_productivity >= resolved_target THEN 'G'
          WHEN resolved_breach_direction = 'UNDER' AND weekly_productivity >= resolved_target * 0.95 THEN 'A'
          WHEN resolved_breach_direction = 'OVER'  AND weekly_productivity <= resolved_target THEN 'G'
          WHEN resolved_breach_direction = 'OVER'  AND weekly_productivity <= resolved_target * 1.05 THEN 'A'
          ELSE 'R'
        END,
        CASE WHEN weekly_productivity IS NULL THEN 'No Data' ELSE 'Actual' END,
        'SyteLine',
        'dbo.fact_syteline_product_engineering_productivity_weekly',
        source_row_count,
        SYSUTCDATETIME()
    FROM enriched;
END;
GO

/* =============================================================
   04. PUBLISH TO CANONICAL KPI RESULT

   dbo.fact_kpi_result must use the same 26-column enriched contract.
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_publish_product_engineering_productivity_kpis]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [dbo].[fact_kpi_result]
    WHERE kpi_code IN ('Product Eng - BE-KPI P1', 'Product Eng - MB-KPI P1');

    INSERT INTO [dbo].[fact_kpi_result]
    (
        closed_year, closed_week, week_key, kpi_id, kpi_code, kpi_name,
        kpi_category, organisational_unit, department, measure, measure_name,
        uom, sign, sign_label, commentary, kpi_value, target_value,
        variance_value, performance_variance_value, breach_direction,
        rag_status, data_status, source_system, source_object,
        source_row_count, calculation_timestamp
    )
    SELECT
        closed_year, closed_week, week_key, kpi_id, kpi_code, kpi_name,
        kpi_category, organisational_unit, department, measure, measure_name,
        uom, sign, sign_label, commentary, kpi_value, target_value,
        variance_value, performance_variance_value, breach_direction,
        rag_status, data_status, source_system, source_object,
        source_row_count, calculation_timestamp
    FROM [dbo].[kpi_result_product_engineering_productivity];
END;
GO

/* =============================================================
   05. ORCHESTRATORS
   ============================================================= */
CREATE OR ALTER PROCEDURE [etl].[sp_run_product_engineering_daily]
    @SnapshotDate DATE = NULL,
    @PublishToCanonicalKpi BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    EXEC [etl].[sp_capture_product_engineering_daily_snapshot]
         @SnapshotDate = @SnapshotDate;

    EXEC [etl].[sp_build_fact_product_engineering_productivity_weekly];
    EXEC [etl].[sp_build_kpi_result_product_engineering_productivity];

    IF @PublishToCanonicalKpi = 1
        EXEC [etl].[sp_publish_product_engineering_productivity_kpis];
END;
GO

CREATE OR ALTER PROCEDURE [etl].[sp_rebuild_product_engineering_outputs]
    @PublishToCanonicalKpi BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    /* Does not capture a new daily snapshot. Rebuilds from existing history. */
    EXEC [etl].[sp_build_fact_product_engineering_productivity_weekly];
    EXEC [etl].[sp_build_kpi_result_product_engineering_productivity];

    IF @PublishToCanonicalKpi = 1
        EXEC [etl].[sp_publish_product_engineering_productivity_kpis];
END;
GO

/* =============================================================
   06. VALIDATION QUERIES
   =============================================================

-- Daily scheduled execution:
EXEC [etl].[sp_run_product_engineering_daily];

-- Controlled test execution without canonical publication:
EXEC [etl].[sp_run_product_engineering_daily]
     @SnapshotDate = '2026-10-30',
     @PublishToCanonicalKpi = 0;

-- Inspect daily history:
SELECT *
FROM [dbo].[fact_syteline_product_engineering_daily_snapshot]
ORDER BY snapshot_date, warehouse;

-- Inspect weekly results:
SELECT *
FROM [dbo].[fact_syteline_product_engineering_productivity_weekly]
ORDER BY closed_year, closed_week, warehouse;

-- Incomplete weeks and snapshot gaps:
SELECT *
FROM [dbo].[fact_syteline_product_engineering_productivity_weekly]
WHERE productivity_days < 5
   OR maximum_snapshot_gap_days > 3;

-- Final KPI rows:
SELECT *
FROM [dbo].[kpi_result_product_engineering_productivity]
ORDER BY closed_year, closed_week, organisational_unit;
*/
