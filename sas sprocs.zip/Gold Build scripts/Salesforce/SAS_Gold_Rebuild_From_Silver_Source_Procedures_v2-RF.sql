/*
SAS GOLD REBUILD FROM SILVER SOURCE TABLES - V2

Architecture enforced by this script:
  Silver Lakehouse [lh_sas_silver] = cleansed source-aligned tables only.
  Gold Warehouse                  = all dimensions, facts and KPI aggregates.

IMPORTANT:
  - No procedure reads a dim_* or fact_* object from [lh_sas_silver].
  - Names containing spaces are the source-aligned Salesforce tables formerly read from Bronze.
  - Run this script in the Gold Warehouse.
  - Gold target tables must exist with the columns used below. Keep DDL separately controlled.
  - HASH keys use SHA2_256 -> first 8 bytes -> BIGINT. Validate against any historical xxhash64 keys.
*/

IF SCHEMA_ID('salesforce') IS NULL EXEC('CREATE SCHEMA [salesforce]');
GO

/* ============================================================
   01. GOLD DIM_DATE
   Built in Gold. Range is derived from Silver source dates.
   Customer week runs Saturday-Friday and is labelled by Friday.
   ============================================================ */
CREATE OR ALTER PROCEDURE [dbo].[sp_build_dim_date]
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @min_date date, @max_date date;

    SELECT
        @min_date = MIN(d),
        @max_date = MAX(d)
    FROM (
        SELECT CAST([CreatedDate] AS date) d FROM [lh_sas_silver].[dbo].[Proposal Request]
        UNION ALL SELECT CAST([Opened_Date__c] AS date) FROM [lh_sas_silver].[dbo].[Proposal Request]
        UNION ALL SELECT CAST([Closed_Date__c] AS date) FROM [lh_sas_silver].[dbo].[Proposal Request]
        UNION ALL SELECT CAST([Created_Date__c] AS date) FROM [lh_sas_silver].[dbo].[Order Tracking]
        UNION ALL SELECT CAST([CreatedDate] AS date) FROM [lh_sas_silver].[dbo].[Estimating Request]
        UNION ALL SELECT CAST([Date_Closed__c] AS date) FROM [lh_sas_silver].[dbo].[Estimating Request]
        UNION ALL SELECT CAST([Quote_Date__c] AS date) FROM [lh_sas_silver].[dbo].[Quote]
        UNION ALL SELECT CAST([Closed_Date__c] AS date) FROM [lh_sas_silver].[dbo].[Quote]
    ) s
    WHERE d IS NOT NULL;

    SET @min_date = COALESCE(@min_date, CONVERT(date,'20230101'));
    SET @max_date = COALESCE(@max_date, CONVERT(date,'20261231'));

    /* expand to complete Saturday-Friday boundary and one future year */
    DECLARE @anchor_saturday date = CONVERT(date,'19000106');
    DECLARE @start_date date = DATEADD(day, -((DATEDIFF(day,@anchor_saturday,@min_date)%7+7)%7), @min_date);
    DECLARE @raw_end date = DATEADD(day,365,@max_date);
    DECLARE @end_date date = DATEADD(day, 6-((DATEDIFF(day,@anchor_saturday,@raw_end)%7+7)%7), @raw_end);

    TRUNCATE TABLE [dbo].[dim_date];

    ;WITH n AS (
        SELECT TOP (DATEDIFF(day,@start_date,@end_date)+1)
               ROW_NUMBER() OVER (ORDER BY (SELECT NULL))-1 AS n
        FROM sys.all_columns a CROSS JOIN sys.all_columns b
    ), d AS (
        SELECT DATEADD(day,n,@start_date) AS calendar_date FROM n
    ), w AS (
        SELECT calendar_date,
               DATEADD(day,-((DATEDIFF(day,@anchor_saturday,calendar_date)%7+7)%7),calendar_date) AS week_start_date
        FROM d
    ), x AS (
        SELECT calendar_date, week_start_date, DATEADD(day,6,week_start_date) AS week_end_date
        FROM w
    )
    INSERT INTO [dbo].[dim_date] (
        date_key, calendar_date, day_of_week, day_name, is_weekday,
        customer_week_no, customer_year, customer_period,
        calendar_quarter, calendar_quarter_name,
        week_start_date, week_end_date, week_key, created_ts, updated_ts
    )
    SELECT
        CONVERT(int,CONVERT(char(8),calendar_date,112)),
        calendar_date,
        ((DATEDIFF(day,CONVERT(date,'19000101'),calendar_date)%7+7)%7)+1,
        DATENAME(weekday,calendar_date),
        CAST(CASE WHEN ((DATEDIFF(day,CONVERT(date,'19000101'),calendar_date)%7+7)%7)+1 BETWEEN 1 AND 5 THEN 1 ELSE 0 END AS bit),
        DATEPART(iso_week,week_end_date),
        YEAR(week_end_date),
        MONTH(week_end_date),
        DATEPART(quarter,calendar_date),
        CONCAT('Q',DATEPART(quarter,calendar_date)),
        week_start_date,
        week_end_date,
        YEAR(week_end_date)*100 + DATEPART(iso_week,week_end_date),
        SYSUTCDATETIME(),SYSUTCDATETIME()
    FROM x;

    IF EXISTS (SELECT calendar_date FROM dbo.dim_date GROUP BY calendar_date HAVING COUNT(*)<>1)
       THROW 51001,'dim_date failed uniqueness validation.',1;
    IF EXISTS (SELECT 1 FROM dbo.dim_date WHERE DATEDIFF(day,week_start_date,week_end_date)<>6 OR calendar_date NOT BETWEEN week_start_date AND week_end_date)
       THROW 51002,'dim_date failed week-boundary validation.',1;
END;
GO

/* ============================================================
   02. GOLD DIM_KPI
   Built directly in Gold from the notebook's governed catalogue.
   No Silver dim_kpi dependency.
   ============================================================ */
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_dim_kpi]
AS
BEGIN
    SET NOCOUNT ON;
 
TRUNCATE TABLE [salesforce].[dim_kpi]

;WITH catalogue AS
(
    SELECT
        create_kpi.kpi_code,
        create_kpi.category,
        create_kpi.kpi_name,
        create_kpi.[description],
        create_kpi.uom,
        create_kpi.breach_direction,
        create_kpi.target_value,
        create_kpi.rag_threshold_low,
        create_kpi.rag_threshold_high,
        create_kpi.is_active
    FROM
    (
        VALUES
            (
                'PROP_VOLUME',
                'Productivity',
                'Volume Completed',
                'Count of closed proposal requests.',
                'Count',
                'UNDER',
                CAST(35.0 AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'PROP_OTIF',
                'Delivery',
                'OTIF %',
                'Percentage of completed proposals delivered by due date.',
                'Percentage',
                'UNDER',
                CAST(100.0 AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'PROP_VALUE',
                'Cost',
                'Opportunity Value per Proposal',
                'Average GBP opportunity value per closed proposal.',
                'GBP',
                'UNDER',
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'PROP_REJECTIONS',
                'Quality',
                'Design Rejections',
                'Rejected drawings for closed proposals.',
                'Count',
                'OVER',
                CAST(0.0 AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'SOP_CLEANSING',
                'Delivery',
                'Cleansing',
                'Percentage of orders cleansed within the approved threshold.',
                'Percentage',
                'UNDER',
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'SOP_SIGNOFF',
                'Delivery',
                'Sign Off',
                'Percentage of orders signed off within five days.',
                'Percentage',
                'UNDER',
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'EST_QUOTES_ISSUED',
                'Productivity',
                'Quotes Issued',
                'Count of closed estimating requests.',
                'Count',
                'UNDER',
                CAST(126.0 AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'EST_QUOTES_ON_TIME',
                'Delivery',
                'Quotes Issued On Time',
                'Percentage of closed estimating requests completed by due date.',
                'Percentage',
                'UNDER',
                CAST(85.0 AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'EST_AVG_HOURS',
                'Quality',
                'Estimated Hours',
                'Average positive hours used to close estimating requests.',
                'Hours',
                'OVER',
                CAST(28.0 AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            ),
            (
                'EST_RATE_PER_SQM',
                'Cost',
                'Rate of Sales per sqm',
                'Average eligible quote-line sales rate per square metre.',
                'GBP',
                'UNDER',
                CAST(75.0 AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(NULL AS decimal(18, 4)),
                CAST(1 AS bit)
            )
    ) AS create_kpi
    (
        kpi_code,
        category,
        kpi_name,
        [description],
        uom,
        breach_direction,
        target_value,
        rag_threshold_low,
        rag_threshold_high,
        is_active
    )
)

INSERT INTO [salesforce].[dim_kpi]
(
    kpi_id,
    kpi_code,
    category,
    kpi_name,
    [description],
    uom,
    breach_direction,
    target_value,
    rag_threshold_low,
    rag_threshold_high,
    is_active,
    created_utc,
    updated_utc
)
SELECT
    ABS(
        CONVERT(
            bigint,
            SUBSTRING(
                HASHBYTES('SHA2_256', c.kpi_code),
                1,
                8
            )
        )
    ) AS kpi_id,
    c.kpi_code,
    c.category,
    c.kpi_name,
    c.[description],
    c.uom,
    c.breach_direction,
    c.target_value,
    c.rag_threshold_low,
    c.rag_threshold_high,
    c.is_active,
    CAST(SYSUTCDATETIME() AS datetime2(6)) AS created_utc,
    CAST(SYSUTCDATETIME() AS datetime2(6)) AS updated_utc
FROM catalogue AS c;

/*==================================================================================
       03. GOLD DIM_RECORD_TYPE built from Silver source-aligned Salesforce table 
===================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_dim_record_type]
AS
BEGIN
    SET NOCOUNT ON;
       TRUNCATE TABLE salesforce.dim_record_type;
       WITH src
       AS (
              SELECT
              id,
              [name],
              [developer_name],
              [sobject_type],
              [is_active],
              [description],
              ROW_NUMBER() OVER (PARTITION BY
                                   id
                                   ORDER BY
                                   [system_modstamp] DESC,
                                   [last_modified_date] DESC,
                                   [created_date] DESC
                                   ) rn
              FROM
              [salesforce_staging].[record_type]
       )
       INSERT INTO salesforce.dim_record_type
       (
              record_type_key,
              record_type_id,
              record_type_name,
              developer_name,
              subject_type,
              is_active,
              [description],
              created_ts,
              updated_ts
       )
              SELECT
                     ABS(CONVERT(bigint, SUBSTRING(HASHBYTES('SHA2_256', COALESCE(id, '')), 1, 8))),
                     id,
                     name,
                     developer_name,
                     [sobject_type],
                     [is_active],
                     [description],
                     CAST(SYSUTCDATETIME() AS [datetime2](6)) AS [created_ts],
                     CAST(SYSUTCDATETIME() AS [datetime2](6)) AS [updated_ts]
              FROM
                     src
              WHERE
                     rn = 1;
END;
GO

/*==================================================================================
       04. GOLD FACT_PROPOSAL built from Silver Proposal Request 
==================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_proposal]
AS
BEGIN
       TRUNCATE TABLE [salesforce].[fact_proposal];

       WITH latest
       AS (SELECT [id],
              [is_deleted],
              [name],
              [currency_iso_code],
              [record_type_id],
              [created_date],
              [last_modified_date],
              [system_modstamp],
              [project_name],
              [opened_date],
              [closed_date],
              [proposal_number],
              [estimated_value],
              [sales_division],
              [rejected_drawings],
              [sales_region],
              ROW_NUMBER() OVER (PARTITION BY [id]
                                   ORDER BY [system_modstamp] DESC,
                                          [last_modified_date] DESC,
                                          [created_date] DESC
                                   ) AS [rn]
       FROM [salesforce_staging].[proposal_request]
       ),
       src
       AS (SELECT [id],
              [name],
              [currency_iso_code],
              [record_type_id],
              [project_name],
              [sales_division],
              [sales_region],
              [estimated_value],
              [rejected_drawings],
              COALESCE([proposal_number], [name], [id]) AS [proposal_request_no],
              CAST(COALESCE([opened_date], [created_date]) AS date) AS [fact_opened_date],
              CAST([closed_date] AS date) AS [fact_closed_date]
       FROM latest
       WHERE [rn] = 1
              AND COALESCE([is_deleted], 0) = 0
       )

       INSERT INTO [salesforce].[fact_proposal]
       (
       [proposal_id],
       [proposal_request_no],
       [project_name],
       [record_type],
       [sales_division],
       [geography],
       [opened_date],
       [closed_date],
       [date_key],
       [week_key],
       [currency_code],
       [estimated_value_native],
       [exchange_rate_to_gbp],
       [estimated_value_gbp],
       [rejected_drawings_count],
       [is_closed],
       [created_utc],
       [updated_utc]
       )

       SELECT ABS(CONVERT(bigint, SUBSTRING(HASHBYTES('SHA2_256', [proposal_request_no]), 1, 8))) AS [proposal_id],
              [proposal_request_no] AS [proposal_request_no],
              [project_name] AS [project_name],
              [record_type_id] AS [record_type],
              [sales_division] AS [sales_division],
              [sales_region] AS [geography],
              [fact_opened_date] AS [opened_date],
              [fact_closed_date] AS [closed_date],
              CASE
              WHEN [fact_closed_date] IS NULL THEN
                     NULL
              ELSE
                     YEAR([fact_closed_date]) * 10000 + MONTH([fact_closed_date]) * 100 + DAY([fact_closed_date])
              END AS [date_key],
              CASE
              WHEN [fact_closed_date] IS NULL THEN
                     NULL
              ELSE
                     YEAR([fact_closed_date]) * 10000 + MONTH([fact_closed_date]) * 100 + DAY([fact_closed_date])
              END AS [week_key],
              [currency_iso_code] AS [currency_code],
              CAST([estimated_value] AS decimal(18, 2)) AS [estimated_value_native],
              CAST(1.0 AS decimal(18, 8)) AS [exchange_rate_to_gbp],
              CAST([estimated_value] AS decimal(18, 2)) AS [estimated_value_gbp],
              COALESCE(CAST([rejected_drawings] AS int), 0) AS [rejected_drawings_count],
              CAST(CASE
                     WHEN [fact_closed_date] IS NULL THEN
                     0
                     ELSE
                     1
              END AS bit) AS [is_closed],
              CAST(SYSUTCDATETIME() AS [datetime2](6)) AS [created_utc],
              CAST(SYSUTCDATETIME() AS [datetime2](6)) AS [updated_utc]
       FROM src;
END;
GO

/*==================================================================================
       05. GOLD FACT_PROPOSAL_DELIVERY from Silver Proposal Request 
==================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_proposal_delivery]
AS
BEGIN
    SET NOCOUNT ON;
       TRUNCATE TABLE [salesforce].[fact_proposal_delivery];

       WITH latest
       AS (SELECT [id],
              [is_deleted],
              [name],
              [created_date],
              [last_modified_date],
              [system_modstamp],
              [complete_by_date],
              [closed_date],
              [proposal_number],
              ROW_NUMBER() OVER (PARTITION BY [id]
                                   ORDER BY [system_modstamp] DESC,
                                          [last_modified_date] DESC,
                                          [created_date] DESC
                                   ) AS [rn]
       FROM [salesforce_staging].[proposal_request]
       ),
       src
       AS (SELECT COALESCE([proposal_number], [name], [id]) AS [proposal_request_no],
              CAST([complete_by_date] AS date) AS [due_date],
              CAST([closed_date] AS date) AS [completed_date]
       FROM latest
       WHERE [rn] = 1
              AND COALESCE([is_deleted], 0) = 0
       )

       INSERT INTO [salesforce].[fact_proposal_delivery]
       (
       [proposal_id],
       [proposal_request_no],
       [due_date],
       [completed_date],
       [on_time_flag],
       [is_on_time],
       [created_utc]
       )

       SELECT ABS(CONVERT(bigint, SUBSTRING(HASHBYTES('SHA2_256', [proposal_request_no]), 1, 8))) AS [proposal_id],
              [proposal_request_no],
              [due_date],
              [completed_date],
              CASE
              WHEN [completed_date] IS NULL THEN
                     NULL
              WHEN [due_date] IS NULL THEN
                     0
              WHEN [completed_date] <= [due_date] THEN
                     1
              ELSE
                     0
              END AS [on_time_flag],
              CAST(CASE
                     WHEN [completed_date] IS NOT NULL
                            AND [due_date] IS NOT NULL
                            AND [completed_date] <= [due_date] THEN
                     1
                     ELSE
                     0
              END AS bit) AS [is_on_time],
              CAST(SYSUTCDATETIME() AS datetime2(6)) AS [created_utc]
       FROM src;
END;
GO

/*==================================================================================
       06. GOLD FACT_QUALITY_WEEKLY derived from Gold fact_proposal
       This is dependant on 04. GOLD FACT_PROPOSAL built from Silver Proposal Request
       being run first to create [salesforce].[fact_proposal]

       Robert French - this can be done in Power BI semtantic model
       This should be be built
==================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_quality_weekly]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE salesforce.fact_quality_weekly;
    INSERT salesforce.fact_quality_weekly
    (
        [year],
        week_number,
        week_key,
        rejected_designs_count,
        source,
        created_utc
    )
    SELECT d.customer_year,
           d.customer_week_no,
           d.week_key,
           SUM(p.rejected_drawings_count),
           'Proposal Request',
           SYSUTCDATETIME()
    FROM salesforce.fact_proposal p
        JOIN dbo.dim_date d
            ON d.date_key = p.closed_date_key
    WHERE p.is_closed = 1
    GROUP BY d.customer_year,
             d.customer_week_no,
             d.week_key;
END;
GO


/*==================================================================================
       07. GOLD FACT_ORDER_TRACKING from Silver Order Tracking 

==================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_order_tracking]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE salesforce.fact_order_tracking;
    WITH latest
    AS (SELECT *,
               ROW_NUMBER() OVER (PARTITION BY Id
                                  ORDER BY SystemModstamp DESC,
                                           LastModifiedDate DESC,
                                           CreatedDate DESC
                                 ) rn
        FROM [lh_sas_silver].[dbo].[Order Tracking]
       ),
         src
    AS (SELECT *,
               COALESCE(Name, Id) order_tracking_no,
               CAST(Created_Date__c AS date) created_date
        FROM latest
        WHERE rn = 1
              AND COALESCE(IsDeleted, 0) = 0
       )
    INSERT salesforce.fact_order_tracking
    (
        order_id,
        order_tracking_no,
        project_name,
        infor_order_reference,
        created_date,
        created_date_key,
        created_week_key,
        days_in_cleansing,
        days_in_signoff,
        days_in_engineering,
        days_in_scheduling,
        created_ts,
        updated_ts
    )
    SELECT ABS(CONVERT(bigint, SUBSTRING(HASHBYTES('SHA2_256', order_tracking_no), 1, 8))),
           order_tracking_no,
           Project_Description__c,
           Infor_Order_Reference__c,
           created_date,
           d.date_key,
           d.week_key,
           CAST(Days_In_Cleansing__c AS decimal(18, 4)),
           CAST(Days_In_Customer_Sign_Off__c AS decimal(18, 4)),
           CAST(Days_In_Engineering__c AS decimal(18, 4)),
           CAST(Days_in_Scheduling__c AS decimal(18, 4)),
           SYSUTCDATETIME(),
           SYSUTCDATETIME()
    FROM src
        LEFT JOIN dbo.dim_date d
            ON d.calendar_date = src.created_date;
END;
GO

/*============================================================================================================================
       08. GOLD ORDER KPI FACT. Approved cleansing threshold is parameterised; default 1 reproduces order-tracking notebook. 
===============================================================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_order_tracking_kpi]
    @cleansing_target decimal(18, 4) = 1.0,
    @signoff_target decimal(18, 4) = 5.0,
    @engineering_target decimal(18, 4) = 5.0,
    @scheduling_target decimal(18, 4) = 3.0
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE salesforce.fact_order_tracking_kpi;
    WITH flags
    AS (SELECT *,
               CASE
                   WHEN days_in_cleansing <= @cleansing_target THEN
                       1
                   ELSE
                       0
               END cleansing_on_time,
               CASE
                   WHEN days_in_signoff <= @signoff_target THEN
                       1
                   ELSE
                       0
               END signoff_on_time,
               CASE
                   WHEN days_in_engineering <= @engineering_target THEN
                       1
                   ELSE
                       0
               END engineering_on_time,
               CASE
                   WHEN days_in_scheduling <= @scheduling_target THEN
                       1
                   ELSE
                       0
               END scheduling_on_time
        FROM salesforce.fact_order_tracking
       ),
         u
    AS (SELECT created_week_key,
               'SOP_CLEANSING' kpi_code,
               cleansing_on_time flag
        FROM flags
        UNION ALL
        SELECT created_week_key,
               'SOP_SIGNOFF',
               signoff_on_time
        FROM flags
        UNION ALL
        SELECT created_week_key,
               'SOP_ENGINEERING',
               engineering_on_time
        FROM flags
        UNION ALL
        SELECT created_week_key,
               'SOP_SCHEDULING',
               scheduling_on_time
        FROM flags
       )
    INSERT salesforce.fact_order_tracking_kpi
    (
        week_key,
        kpi_code,
        total_count,
        on_time_count,
        on_time_pct,
        department,
        created_ts
    )
    SELECT week_key,
           kpi_code,
           COUNT_BIG(*),
           SUM(flag),
           CAST(100.0 * SUM(flag) / NULLIF(COUNT_BIG(*), 0) AS decimal(18, 2)),
           'SOP',
           SYSUTCDATETIME()
    FROM u
    GROUP BY week_key,
             kpi_code;
END;
GO

/*==================================================================================
        09. GOLD FACT_ESTIMATING from Silver source tables plus Gold dim_date 
==================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_estimating]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE salesforce.fact_estimating;
    WITH r
    AS (SELECT *,
               ROW_NUMBER() OVER (PARTITION BY Id
                                  ORDER BY SystemModstamp DESC,
                                           LastModifiedDate DESC,
                                           CreatedDate DESC
                                 ) rn
        FROM [lh_sas_silver].[dbo].[Estimating Request]
       ),
         u
    AS (SELECT *,
               ROW_NUMBER() OVER (PARTITION BY Id
                                  ORDER BY SystemModstamp DESC,
                                           LastModifiedDate DESC,
                                           CreatedDate DESC
                                 ) rn
        FROM [lh_sas_silver].[dbo].[User]
       ),
         rt
    AS (SELECT *,
               ROW_NUMBER() OVER (PARTITION BY Id
                                  ORDER BY SystemModstamp DESC,
                                           LastModifiedDate DESC,
                                           CreatedDate DESC
                                 ) rn
        FROM [lh_sas_silver].[dbo].[Record Type]
       )
    INSERT salesforce.fact_estimating
    (
        estimating_request_id,
        estimating_request_no,
        project_name,
        source_owner_id,
        source_owner_name,
        record_type_name,
        complete_by_date,
        closed_timestamp,
        closed_date,
        hours_taken_to_close,
        sales_division,
        project_region,
        request_status,
        currency_code,
        is_closed,
        on_time_flag,
        closed_date_key,
        closed_customer_year,
        closed_customer_week_no,
        closed_week_start_date,
        closed_week_end_date,
        closed_week_key,
        source_created_ts,
        source_modified_ts,
        created_ts,
        updated_ts
    )
    SELECT r.Id,
           COALESCE(r.Name, r.Id),
           r.Project_Name__c,
           r.OwnerId,
           COALESCE(u.Full_Name__c, u.Name),
           rt.Name,
           CAST(r.Complete_By_Date__c AS date),
           CAST(r.Date_Closed__c AS datetime2),
           CAST(r.Date_Closed__c AS date),
           CAST(r.Hours_Taken_to_Close__c AS decimal(18, 4)),
           r.Sales_Division__c,
           r.Project_Region__c,
           r.Status__c,
           r.CurrencyIsoCode,
           CAST(CASE
                    WHEN r.Date_Closed__c IS NULL THEN
                        0
                    ELSE
                        1
                END AS bit),
           CASE
               WHEN r.Date_Closed__c IS NULL THEN
                   NULL
               WHEN r.Complete_By_Date__c IS NULL THEN
                   0
               WHEN CAST(r.Date_Closed__c AS date) <= CAST(r.Complete_By_Date__c AS date) THEN
                   1
               ELSE
                   0
           END,
           d.date_key,
           d.customer_year,
           d.customer_week_no,
           d.week_start_date,
           d.week_end_date,
           d.week_key,
           CAST(r.CreatedDate AS datetime2),
           CAST(r.SystemModstamp AS datetime2),
           SYSUTCDATETIME(),
           SYSUTCDATETIME()
    FROM r
        LEFT JOIN u
            ON u.Id = r.OwnerId
               AND u.rn = 1
        LEFT JOIN rt
            ON rt.Id = r.RecordTypeId
               AND rt.rn = 1
        LEFT JOIN dbo.dim_date d
            ON d.calendar_date = CAST(r.Date_Closed__c AS date)
    WHERE r.rn = 1
          AND COALESCE(r.IsDeleted, 0) = 0;
END;
GO

/*==================================================================================
       10. GOLD FACT_ESTIMATING_QUOTE from Silver Quote + Estimating Request 
==================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_estimating_quote]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE salesforce.fact_estimating_quote;
    WITH q
    AS (SELECT *,
               ROW_NUMBER() OVER (PARTITION BY Id
                                  ORDER BY SystemModstamp DESC,
                                           LastModifiedDate DESC,
                                           CreatedDate DESC
                                 ) rn
        FROM [lh_sas_silver].[dbo].[Quote]
       ),
         r
    AS (SELECT *,
               ROW_NUMBER() OVER (PARTITION BY Id
                                  ORDER BY SystemModstamp DESC,
                                           LastModifiedDate DESC,
                                           CreatedDate DESC
                                 ) rn
        FROM [lh_sas_silver].[dbo].[Estimating Request]
       )
    INSERT salesforce.fact_estimating_quote
    (
        quote_id,
        quote_name,
        estimating_request_id,
        estimating_request_no,
        project_name,
        currency_code,
        quote_status,
        is_primary_quote,
        quote_net_amount,
        quote_sqm,
        quote_sqm_rate,
        sales_division,
        sales_region,
        quote_date,
        closed_date,
        cost_kpi_reporting_date,
        quote_date_week_key,
        closed_date_week_key,
        cost_kpi_date_key,
        cost_kpi_customer_year,
        cost_kpi_customer_week_no,
        cost_kpi_week_start_date,
        cost_kpi_week_end_date,
        cost_kpi_week_key,
        cost_reporting_date_basis,
        source_created_ts,
        source_modified_ts,
        created_ts,
        updated_ts
    )
    SELECT q.Id,
           q.Name,
           COALESCE(r.Id, q.Estimating_Request__c),
           COALESCE(r.Name, q.Estimating_Request_No__c),
           r.Project_Name__c,
           q.CurrencyIsoCode,
           q.SBQQ__Status__c,
           CAST(q.SBQQ__Primary__c AS bit),
           CAST(q.SBQQ__NetAmount__c AS decimal(18, 2)),
           CAST(q.Quote_SQM__c AS decimal(18, 4)),
           CAST(q.SQM_Rate__c AS decimal(18, 4)),
           q.Sales_Division__c,
           q.Region__c,
           CAST(q.Quote_Date__c AS date),
           CAST(q.Closed_Date__c AS date),
           CAST(q.Quote_Date__c AS date),
           qd.week_key,
           cd.week_key,
           qd.date_key,
           qd.customer_year,
           qd.customer_week_no,
           qd.week_start_date,
           qd.week_end_date,
           qd.week_key,
           'Quote_Date__c',
           CAST(q.CreatedDate AS datetime2),
           CAST(q.SystemModstamp AS datetime2),
           SYSUTCDATETIME(),
           SYSUTCDATETIME()
    FROM q
        LEFT JOIN r
            ON r.rn = 1
               AND (
                       q.Estimating_Request__c = r.Id
                       OR (
                              q.Estimating_Request__c IS NULL
                              AND q.Estimating_Request_No__c = r.Name
                          )
                   )
        LEFT JOIN dbo.dim_date qd
            ON qd.calendar_date = CAST(q.Quote_Date__c AS date)
        LEFT JOIN dbo.dim_date cd
            ON cd.calendar_date = CAST(q.Closed_Date__c AS date)
    WHERE q.rn = 1
          AND COALESCE(q.IsDeleted, 0) = 0;
END;
GO

/*==================================================================================
       11. GOLD FACT_ESTIMATING_QUOTE_LINE from Silver Quote Line + Gold fact_quote 
==================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_estimating_quote_line]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE salesforce.fact_estimating_quote_line;
    WITH ql
    AS (SELECT *,
               ROW_NUMBER() OVER (PARTITION BY Id
                                  ORDER BY SystemModstamp DESC,
                                           LastModifiedDate DESC,
                                           CreatedDate DESC
                                 ) rn
        FROM [lh_sas_silver].[dbo].[Quote Line]
       )
    INSERT salesforce.fact_estimating_quote_line
    (
        quote_line_id,
        quote_line_name,
        quote_id,
        quote_name,
        estimating_request_id,
        estimating_request_no,
        project_name,
        quote_status,
        is_primary_quote,
        sales_division,
        sales_region,
        currency_code,
        quantity,
        net_total,
        line_description,
        item_sqm,
        line_sqm,
        sqm_rate,
        price_excluded,
        is_sqm_kpi_eligible,
        quote_date,
        closed_date,
        cost_kpi_reporting_date,
        cost_kpi_date_key,
        cost_kpi_customer_year,
        cost_kpi_customer_week_no,
        cost_kpi_week_start_date,
        cost_kpi_week_end_date,
        cost_kpi_week_key,
        cost_reporting_date_basis,
        source_created_ts,
        source_modified_ts,
        created_ts,
        updated_ts
    )
    SELECT ql.Id,
           ql.Name,
           q.quote_id,
           q.quote_name,
           q.estimating_request_id,
           q.estimating_request_no,
           q.project_name,
           q.quote_status,
           q.is_primary_quote,
           q.sales_division,
           q.sales_region,
           ql.CurrencyIsoCode,
           CAST(ql.SBQQ__Quantity__c AS decimal(18, 4)),
           CAST(ql.SBQQ__NetTotal__c AS decimal(18, 2)),
           ql.SBQQ__Description__c,
           CAST(ql.Item_SQM__c AS decimal(18, 4)),
           CAST(ql.Line_SQM__c AS decimal(18, 4)),
           CAST(ql.Sqm_Rate__c AS decimal(18, 4)),
           CAST(ql.Price_Excluded__c AS bit),
           CAST(CASE
                    WHEN CAST(ql.Item_SQM__c AS decimal(18, 4)) >= 0.03
                         AND ql.Sqm_Rate__c IS NOT NULL THEN
                        1
                    ELSE
                        0
                END AS bit),
           q.quote_date,
           q.closed_date,
           q.cost_kpi_reporting_date,
           q.cost_kpi_date_key,
           q.cost_kpi_customer_year,
           q.cost_kpi_customer_week_no,
           q.cost_kpi_week_start_date,
           q.cost_kpi_week_end_date,
           q.cost_kpi_week_key,
           q.cost_reporting_date_basis,
           CAST(ql.CreatedDate AS datetime2),
           CAST(ql.SystemModstamp AS datetime2),
           SYSUTCDATETIME(),
           SYSUTCDATETIME()
    FROM ql
        JOIN salesforce.fact_estimating_quote q
            ON q.quote_id = ql.SBQQ__Quote__c
    WHERE ql.rn = 1
          AND COALESCE(ql.IsDeleted, 0) = 0;
END;
GO

/*==================================================================================
       12. GOLD ESTIMATING KPI fact built from Gold atomic facts 
==================================================================================*/
CREATE OR ALTER PROCEDURE [salesforce].[sp_build_fact_estimating_kpi] @reporting_year int = 2025
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM salesforce.fact_kpi_result_v3
    WHERE department = 'Estimating';

    WITH request_weekly
    AS (SELECT closed_customer_year closed_year,
               closed_customer_week_no closed_week,
               closed_week_key week_key,
               COUNT(DISTINCT estimating_request_id) quotes_issued,
               100.0 * SUM(CAST(on_time_flag AS float)) / NULLIF(COUNT(DISTINCT estimating_request_id), 0) quotes_on_time_pct,
               AVG(   CASE
                          WHEN hours_taken_to_close > 0 THEN
                              CAST(hours_taken_to_close AS float)
                      END
                  ) average_positive_hours,
               COUNT(DISTINCT estimating_request_id) request_count
        FROM salesforce.fact_estimating
        WHERE is_closed = 1
              AND closed_customer_year = @reporting_year
        GROUP BY closed_customer_year,
                 closed_customer_week_no,
                 closed_week_key
       ),
         cost_weekly
    AS (SELECT cost_kpi_customer_year closed_year,
               cost_kpi_customer_week_no closed_week,
               cost_kpi_week_key week_key,
               AVG(CAST(sqm_rate AS float)) rate_per_sqm,
               COUNT_BIG(*) source_count
        FROM salesforce.fact_estimating_quote_line
        WHERE is_sqm_kpi_eligible = 1
              AND cost_kpi_customer_year = @reporting_year
        GROUP BY cost_kpi_customer_year,
                 cost_kpi_customer_week_no,
                 cost_kpi_week_key
       ),
         k
    AS (SELECT closed_year,
               closed_week,
               week_key,
               'EST_QUOTES_ISSUED' kpi_code,
               'Quotes Issued' kpi_name,
               'Productivity' category,
               CAST(quotes_issued AS float) actual,
               126.0 target,
               'UNDER' breach,
               'Count' uom,
               request_count source_count
        FROM request_weekly
        UNION ALL
        SELECT closed_year,
               closed_week,
               week_key,
               'EST_QUOTES_ON_TIME',
               'Quotes Issued On Time',
               'Delivery',
               quotes_on_time_pct,
               85.0,
               'UNDER',
               'Percentage',
               request_count
        FROM request_weekly
        UNION ALL
        SELECT closed_year,
               closed_week,
               week_key,
               'EST_AVG_HOURS',
               'Estimated Hours',
               'Quality',
               average_positive_hours,
               28.0,
               'OVER',
               'Hours',
               request_count
        FROM request_weekly
        UNION ALL
        SELECT closed_year,
               closed_week,
               week_key,
               'EST_RATE_PER_SQM',
               'Rate of Sales per sqm',
               'Cost',
               rate_per_sqm,
               75.0,
               'UNDER',
               'GBP',
               source_count
        FROM cost_weekly
       )
    INSERT salesforce.fact_kpi_result_v3
    (
        closed_year,
        closed_week,
        week_key,
        kpi_id,
        kpi_code,
        kpi_name,
        kpi_category,
        organisational_unit,
        department,
        measure,
        measure_name,
        uom,
        sign,
        sign_label,
        commentary,
        breach_direction,
        kpi_value,
        target_value,
        variance_value,
        performance_variance_value,
        rag_status,
        data_status,
        source_system,
        source_object,
        source_row_count,
        calculation_timestamp
    )
    SELECT k.closed_year,
           k.closed_week,
           k.week_key,
           d.kpi_id,
           k.kpi_code,
           k.kpi_name,
           k.category,
           'HR Monthly',
           'Estimating',
           k.kpi_name,
           k.kpi_name,
           k.uom,
           CASE
               WHEN k.breach = 'OVER' THEN
                   'Over Breach'
               ELSE
                   'Under Breach'
           END,
           CASE
               WHEN k.breach = 'OVER' THEN
                   'Over Breach'
               ELSE
                   'Under Breach'
           END,
           'Targets from Estimating notebook',
           k.breach,
           k.actual,
           k.target,
           k.actual - k.target,
           CASE
               WHEN k.breach = 'OVER' THEN
                   k.target - k.actual
               ELSE
                   k.actual - k.target
           END,
           CASE
               WHEN k.actual IS NULL THEN
                   'No Data'
               WHEN k.breach = 'UNDER'
                    AND k.actual >= k.target THEN
                   'G'
               WHEN k.breach = 'UNDER'
                    AND k.actual >= k.target * 0.95 THEN
                   'A'
               WHEN k.breach = 'OVER'
                    AND k.actual <= k.target THEN
                   'G'
               WHEN k.breach = 'OVER'
                    AND k.target > 0
                    AND k.actual <= k.target / 0.95 THEN
                   'A'
               ELSE
                   'R'
           END,
           CASE
               WHEN k.actual IS NULL THEN
                   'No Data'
               ELSE
                   'Actual'
           END,
           'Salesforce',
           'Gold atomic facts',
           k.source_count,
           SYSUTCDATETIME()
    FROM k
        JOIN dbo.dim_kpi d
            ON d.kpi_code = k.kpi_code;
END;
GO

/*==================================================================================
       MASTER: dimensions -> atomic facts -> aggregates 
==================================================================================*/
CREATE OR ALTER PROCEDURE [dbo].[sp_build_sas_gold_all]
AS
BEGIN
 SET NOCOUNT ON;
 EXEC dbo.sp_build_dim_date;
 EXEC dbo.sp_build_dim_kpi;
 EXEC salesforce.sp_build_dim_record_type;
 EXEC salesforce.sp_build_fact_proposal;
 EXEC salesforce.sp_build_fact_proposal_delivery;
 EXEC salesforce.sp_build_fact_quality_weekly;
 EXEC salesforce.sp_build_fact_order_tracking;
 EXEC salesforce.sp_build_fact_order_tracking_kpi;
 EXEC salesforce.sp_build_fact_estimating;
 EXEC salesforce.sp_build_fact_estimating_quote;
 EXEC salesforce.sp_build_fact_estimating_quote_line;
 EXEC salesforce.sp_build_fact_estimating_kpi;
END;
GO
