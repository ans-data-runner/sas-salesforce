/*
    Create the 
*/

CREATE TABLE salesforce.dim_kpi
    (
        kpi_id             bigint         NOT NULL,
        kpi_code           varchar(50)    NOT NULL,
        category           varchar(50)    NOT NULL,
        kpi_name           varchar(100)   NOT NULL,
        [description]      varchar(500)   NULL,
        uom                varchar(50)    NOT NULL,
        breach_direction   varchar(10)    NOT NULL,
        target_value       decimal(18, 4) NULL,
        rag_threshold_low  decimal(18, 4) NULL,
        rag_threshold_high decimal(18, 4) NULL,
        is_active          bit            NOT NULL,
        created_utc        datetime2(6)   NOT NULL,
        updated_utc        datetime2(6)   NOT NULL
    )
GO

CREATE TABLE [salesforce].[dim_record_type]
    (
        [record_type_key]  [bigint]        NOT NULL,
        [record_type_id]   [varchar](18)   NOT NULL,
        [record_type_name] [varchar](255)  NULL,
        [developer_name]   [varchar](255)  NULL,
        [sobject_type]     [varchar](255)  NULL,
        [is_active]        [bit]           NOT NULL,
        [description]      [varchar](1000) NULL,
        [created_ts]       [datetime2](6)  NOT NULL,
        [updated_ts]       [datetime2](6)  NOT NULL
    )
GO

CREATE TABLE [salesforce].[fact_proposal]
(
	[proposal_id] [bigint] NOT NULL,
	[proposal_request_no] [varchar](255) NOT NULL,
	[project_name] [varchar](500) NULL,
	[record_type] [varchar](50) NULL,
	[sales_division] [varchar](255) NULL,
	[geography] [varchar](255) NULL,
	[opened_date] [date] NULL,
	[closed_date] [date] NULL,
	[date_key] [int] NULL,
	[week_key] [int] NULL,
	[currency_code] [varchar](10) NULL,
	[estimated_value_native] [decimal](18,2) NULL,
	[exchange_rate_to_gbp] [decimal](18,8) NULL,
	[estimated_value_gbp] [decimal](18,2) NULL,
	[rejected_drawings_count] [int] NOT NULL,
	[is_closed] [bit] NOT NULL,
	[created_utc] [datetime2](6) NOT NULL,
	[updated_utc] [datetime2](6) NOT NULL
)
GO