/* SCHEMA CORRECTION NOTE
   All domain facts, KPI result tables, publishers and stored procedures in this file use [syteline].
   Shared calendar joins use [reporting].[dim_date].
   No [dbo] references remain. Existing non-v1 procedures are not modified.
*/
/* ACTIVE SAS GOLD V1 DEPLOYMENT
   Stored procedures versioned with _v1.
   KPI business logic and historical weekly aggregation retained from supplied script.
*/
/*
SAS SOP VALUE OF ORDERS COMPLETED - END-TO-END GOLD KPI BUILD V1
================================================================
Warehouse: wh_sas_gold

Customer calculation source:
    SyteLine query supplied for the SOP Cost KPI.

Expected Gold staging schema:
    [syteline_staging]

Required source tables:
    coitem_mst
    co_mst

Gold outputs:
    syteline.fact_sop_order_value_completed_detail
    syteline.fact_sop_order_value_completed_weekly
    syteline.kpi_result_sop_order_value_completed
    syteline.fact_kpi_result

KPI output:
    SOP-KPI-C0 - Value of Orders Completed

This script deliberately delivers the SyteLine numerator independently.
The final SOP Cost KPI remains:
    Value of Orders Completed / FTE
and can be layered on later when the SharePoint FTE source is populated.

Confirmed business calculation:
    qty_ordered_conv
    * price_conv
    * (1 - disc / 100)
    / COALESCE(exch_rate, 1)

Confirmed filters:
    site_ref = RBMW
    coitem stat < P
    co type IN (B, R)
    co_num does not begin I
    end_user_type IN (2, 13, 26, 28)
    rma_num IS NULL
    long description does not contain CARRIAGE
    reporting date = Uf_OrderedDate

Mitigations:
1. Physical SyteLine field names are assumed to be snake_case equivalents of the
   customer SQL. Run the schema validation at the bottom first.
2. This is the numerator KPI/output, not the final GBP per FTE Cost KPI.
3. No syteline.dim_kpi dependency. Target and RAG remain TBC.
4. reporting.dim_date must cover all uf_ordered_date values.
5. Explicit 26-column publication to syteline.fact_kpi_result.
*/

IF SCHEMA_ID('syteline_staging') IS NULL EXEC('CREATE SCHEMA [syteline_staging]');
GO

IF OBJECT_ID('[syteline].[fact_kpi_result]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_kpi_result]
    (
        closed_year INT NULL,
        closed_week INT NULL,
        kpi_name VARCHAR(255) NULL,
        kpi_value DECIMAL(18,6) NULL,
        organisational_unit VARCHAR(255) NULL,
        kpi_id BIGINT NULL,
        kpi_category VARCHAR(100) NULL,
        target_value DECIMAL(18,6) NULL,
        breach_direction VARCHAR(20) NULL,
        week_key INT NULL,
        kpi_code VARCHAR(100) NULL,
        department VARCHAR(255) NULL,
        measure VARCHAR(500) NULL,
        measure_name VARCHAR(500) NULL,
        uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL,
        sign_label VARCHAR(100) NULL,
        commentary VARCHAR(1000) NULL,
        variance_value DECIMAL(18,6) NULL,
        performance_variance_value DECIMAL(18,6) NULL,
        rag_status VARCHAR(20) NULL,
        data_status VARCHAR(50) NULL,
        source_system VARCHAR(100) NULL,
        source_object VARCHAR(500) NULL,
        source_row_count BIGINT NULL,
        calculation_timestamp DATETIME2(6) NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[fact_sop_order_value_completed_detail]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_sop_order_value_completed_detail]
    (
        order_number VARCHAR(100) NOT NULL,
        order_line INT NULL,
        order_release INT NULL,
        site_ref VARCHAR(50) NULL,
        order_type VARCHAR(20) NULL,
        end_user_type VARCHAR(50) NULL,
        item VARCHAR(255) NULL,
        long_description VARCHAR(2000) NULL,
        ordered_date DATE NULL,
        quantity_ordered DECIMAL(18,6) NULL,
        unit_price DECIMAL(18,6) NULL,
        discount_percentage DECIMAL(18,6) NULL,
        exchange_rate DECIMAL(18,6) NULL,
        order_value_completed DECIMAL(18,6) NULL,
        date_key INT NULL,
        closed_year INT NULL,
        closed_week INT NULL,
        week_key INT NULL,
        week_start_date DATE NULL,
        week_ending_date DATE NULL,
        source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[fact_sop_order_value_completed_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_sop_order_value_completed_weekly]
    (
        closed_year INT NOT NULL,
        closed_week INT NOT NULL,
        week_key INT NOT NULL,
        week_start_date DATE NOT NULL,
        week_ending_date DATE NOT NULL,
        order_lines BIGINT NOT NULL,
        distinct_orders BIGINT NOT NULL,
        order_value_completed DECIMAL(18,6) NULL,
        source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[kpi_result_sop_order_value_completed]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[kpi_result_sop_order_value_completed]
    (
        closed_year INT NULL,
        closed_week INT NULL,
        kpi_name VARCHAR(255) NULL,
        kpi_value DECIMAL(18,6) NULL,
        organisational_unit VARCHAR(255) NULL,
        kpi_id BIGINT NULL,
        kpi_category VARCHAR(100) NULL,
        target_value DECIMAL(18,6) NULL,
        breach_direction VARCHAR(20) NULL,
        week_key INT NULL,
        kpi_code VARCHAR(100) NULL,
        department VARCHAR(255) NULL,
        measure VARCHAR(500) NULL,
        measure_name VARCHAR(500) NULL,
        uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL,
        sign_label VARCHAR(100) NULL,
        commentary VARCHAR(1000) NULL,
        variance_value DECIMAL(18,6) NULL,
        performance_variance_value DECIMAL(18,6) NULL,
        rag_status VARCHAR(20) NULL,
        data_status VARCHAR(50) NULL,
        source_system VARCHAR(100) NULL,
        source_object VARCHAR(500) NULL,
        source_row_count BIGINT NULL,
        calculation_timestamp DATETIME2(6) NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_fact_sop_order_value_completed_detail_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [syteline].[fact_sop_order_value_completed_detail];

    /* SOURCE MAPPING CTE: change only this section if physical names differ. */
    ;WITH source_rows AS
    (
        SELECT
            order_number = CAST(ci.[co_num] AS VARCHAR(100)),
            order_line = TRY_CAST(ci.[co_line] AS INT),
            order_release = TRY_CAST(ci.[co_release] AS INT),
            site_ref = CAST(ci.[site_ref] AS VARCHAR(50)),
            order_type = CAST(co.[type] AS VARCHAR(20)),
            end_user_type = CAST(co.[end_user_type] AS VARCHAR(50)),
            item = CAST(ci.[item] AS VARCHAR(255)),
            long_description = CAST(ci.[long_description] AS VARCHAR(2000)),
            ordered_date = CAST(ci.[uf_ordereddate] AS DATE),
            quantity_ordered = TRY_CAST(ci.[qty_ordered_conv] AS DECIMAL(18,6)),
            unit_price = TRY_CAST(ci.[price_conv] AS DECIMAL(18,6)),
            discount_percentage = COALESCE(TRY_CAST(ci.[disc] AS DECIMAL(18,6)), 0),
            exchange_rate = COALESCE(NULLIF(TRY_CAST(co.[exch_rate] AS DECIMAL(18,6)), 0), 1),
            source_row_count = CAST(1 AS BIGINT)
        FROM [syteline_staging].[coitem_mst] ci
        INNER JOIN [syteline_staging].[co_mst] co
            ON co.[co_num] = ci.[co_num]
           AND co.[site_ref] = ci.[site_ref]
        WHERE ci.[site_ref] = 'RBMW'
          AND ci.[stat] < 'P'
          AND co.[type] IN ('B', 'R')
          AND ci.[co_num] NOT LIKE 'I%'
          AND CAST(co.[end_user_type] AS VARCHAR(50)) IN ('2', '13', '26', '28')
          AND co.[rma_num] IS NULL
          AND UPPER(COALESCE(ci.[long_description], '')) NOT LIKE '%CARRIAGE%'
          AND ci.[uf_ordereddate] IS NOT NULL
    )
    INSERT INTO [syteline].[fact_sop_order_value_completed_detail]
    (
        order_number,
        order_line,
        order_release,
        site_ref,
        order_type,
        end_user_type,
        item,
        long_description,
        ordered_date,
        quantity_ordered,
        unit_price,
        discount_percentage,
        exchange_rate,
        order_value_completed,
        date_key,
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        source_row_count,
        calculation_timestamp
    )
    SELECT
        s.order_number,
        s.order_line,
        s.order_release,
        s.site_ref,
        s.order_type,
        s.end_user_type,
        s.item,
        s.long_description,
        s.ordered_date,
        s.quantity_ordered,
        s.unit_price,
        s.discount_percentage,
        s.exchange_rate,
        CAST(
            s.quantity_ordered
            * s.unit_price
            * (1 - (s.discount_percentage / 100.0))
            / NULLIF(s.exchange_rate, 0)
            AS DECIMAL(18,6)
        ),
        d.date_key,
        d.customer_year,
        d.customer_week_no,
        d.week_key,
        d.week_start_date,
        d.week_end_date,
        s.source_row_count,
        SYSUTCDATETIME()
    FROM source_rows s
    LEFT JOIN [reporting].[dim_date] d
        ON d.calendar_date = s.ordered_date;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_fact_sop_order_value_completed_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [syteline].[fact_sop_order_value_completed_weekly];

    INSERT INTO [syteline].[fact_sop_order_value_completed_weekly]
    (
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        order_lines,
        distinct_orders,
        order_value_completed,
        source_row_count,
        calculation_timestamp
    )
    SELECT
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        COUNT_BIG(*),
        COUNT_BIG(DISTINCT order_number),
        CAST(SUM(order_value_completed) AS DECIMAL(18,6)),
        SUM(source_row_count),
        SYSUTCDATETIME()
    FROM [syteline].[fact_sop_order_value_completed_detail]
    WHERE week_key IS NOT NULL
    GROUP BY
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_kpi_result_sop_order_value_completed_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [syteline].[kpi_result_sop_order_value_completed]
    WHERE kpi_code = 'SOP-KPI-C0';

    INSERT INTO [syteline].[kpi_result_sop_order_value_completed]
    (
        closed_year,
        closed_week,
        kpi_name,
        kpi_value,
        organisational_unit,
        kpi_id,
        kpi_category,
        target_value,
        breach_direction,
        week_key,
        kpi_code,
        department,
        measure,
        measure_name,
        uom,
        sign,
        sign_label,
        commentary,
        variance_value,
        performance_variance_value,
        rag_status,
        data_status,
        source_system,
        source_object,
        source_row_count,
        calculation_timestamp
    )
    SELECT
        w.closed_year,
        w.closed_week,
        'Value of Orders Completed',
        w.order_value_completed,
        'SOP',
        NULL,
        'Cost',
        NULL,
        NULL,
        w.week_key,
        'SOP-KPI-C0',
        'SOP',
        'SyteLine value of eligible orders using converted quantity, price, discount and exchange rate',
        'Value of Orders Completed',
        'Currency',
        NULL,
        NULL,
        CONCAT(
            'Order lines=', w.order_lines,
            '; distinct orders=', w.distinct_orders,
            '; this is the numerator for the final SOP GBP per FTE KPI.'
        ),
        NULL,
        NULL,
        'TBC',
        'Actual - Target TBC',
        'SyteLine',
        'syteline_staging.coitem_mst + syteline_staging.co_mst',
        w.source_row_count,
        SYSUTCDATETIME()
    FROM [syteline].[fact_sop_order_value_completed_weekly] w;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_sop_order_value_completed_all_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[sp_build_fact_sop_order_value_completed_detail_v1];
    EXEC [syteline].[sp_build_fact_sop_order_value_completed_weekly_v1];
    EXEC [syteline].[sp_build_kpi_result_sop_order_value_completed_v1];
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_publish_sop_order_value_completed_kpi_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [syteline].[fact_kpi_result]
    WHERE kpi_code = 'SOP-KPI-C0';

    INSERT INTO [syteline].[fact_kpi_result]
    (
        closed_year,
        closed_week,
        kpi_name,
        kpi_value,
        organisational_unit,
        kpi_id,
        kpi_category,
        target_value,
        breach_direction,
        week_key,
        kpi_code,
        department,
        measure,
        measure_name,
        uom,
        sign,
        sign_label,
        commentary,
        variance_value,
        performance_variance_value,
        rag_status,
        data_status,
        source_system,
        source_object,
        source_row_count,
        calculation_timestamp
    )
    SELECT
        closed_year,
        closed_week,
        kpi_name,
        kpi_value,
        organisational_unit,
        kpi_id,
        kpi_category,
        target_value,
        breach_direction,
        week_key,
        kpi_code,
        department,
        measure,
        measure_name,
        uom,
        sign,
        sign_label,
        commentary,
        variance_value,
        performance_variance_value,
        rag_status,
        data_status,
        source_system,
        source_object,
        source_row_count,
        calculation_timestamp
    FROM [syteline].[kpi_result_sop_order_value_completed];
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_and_publish_sop_order_value_completed_all_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[sp_build_sop_order_value_completed_all_v1];
    EXEC [syteline].[sp_publish_sop_order_value_completed_kpi_v1];
END;
GO

/* =============================================================
   VALIDATION / TEST QUERIES
   =============================================================

-- A. Confirm required tables
SELECT TABLE_SCHEMA, TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'syteline_staging'
  AND TABLE_NAME IN ('coitem_mst', 'co_mst')
ORDER BY TABLE_NAME;

-- B. Confirm expected physical columns before compiling the build procedure
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'syteline_staging'
  AND TABLE_NAME IN ('coitem_mst', 'co_mst')
  AND COLUMN_NAME IN
  (
      'co_num', 'co_line', 'co_release', 'site_ref', 'stat', 'item',
      'long_description', 'uf_ordereddate', 'qty_ordered_conv',
      'price_conv', 'disc', 'type', 'end_user_type', 'rma_num', 'exch_rate'
  )
ORDER BY TABLE_NAME, ORDINAL_POSITION;

-- C. Source counts
SELECT 'coitem_mst' AS source_table, COUNT_BIG(*) AS row_count
FROM [syteline_staging].[coitem_mst]
UNION ALL
SELECT 'co_mst', COUNT_BIG(*)
FROM [syteline_staging].[co_mst];

-- D. Build without publishing
EXEC [syteline].[sp_build_sop_order_value_completed_all_v1];

-- E. Detail fact validation
SELECT
    COUNT_BIG(*) AS detail_rows,
    COUNT_BIG(DISTINCT order_number) AS distinct_orders,
    SUM(order_value_completed) AS order_value_completed,
    MIN(ordered_date) AS first_ordered_date,
    MAX(ordered_date) AS last_ordered_date,
    SUM(CASE WHEN week_key IS NULL THEN 1 ELSE 0 END) AS missing_week_keys
FROM [syteline].[fact_sop_order_value_completed_detail];

-- F. Weekly fact
SELECT *
FROM [syteline].[fact_sop_order_value_completed_weekly]
ORDER BY closed_year, closed_week;

-- G. Detail-to-weekly reconciliation
SELECT
    d.week_key,
    SUM(d.order_value_completed) AS detail_value,
    w.order_value_completed AS weekly_value,
    SUM(d.order_value_completed) - w.order_value_completed AS difference
FROM [syteline].[fact_sop_order_value_completed_detail] d
LEFT JOIN [syteline].[fact_sop_order_value_completed_weekly] w
    ON w.week_key = d.week_key
WHERE d.week_key IS NOT NULL
GROUP BY d.week_key, w.order_value_completed
ORDER BY d.week_key;

-- H. Review dashboard-shaped KPI result
SELECT *
FROM [syteline].[kpi_result_sop_order_value_completed]
ORDER BY closed_year, closed_week, kpi_code;

-- I. Publish after review
EXEC [syteline].[sp_publish_sop_order_value_completed_kpi_v1];

-- J. Review final dashboard result
SELECT *
FROM [syteline].[fact_kpi_result]
WHERE kpi_code = 'SOP-KPI-C0'
ORDER BY closed_year, closed_week;

-- K. Domain-to-final reconciliation
SELECT
    d.week_key,
    d.kpi_code,
    d.kpi_value AS domain_kpi_value,
    f.kpi_value AS final_kpi_value,
    d.kpi_value - f.kpi_value AS value_difference,
    d.source_row_count AS domain_source_rows,
    f.source_row_count AS final_source_rows
FROM [syteline].[kpi_result_sop_order_value_completed] d
LEFT JOIN [syteline].[fact_kpi_result] f
    ON f.week_key = d.week_key
   AND f.kpi_code = d.kpi_code
ORDER BY d.week_key;

-- L. Duplicate check
SELECT week_key, kpi_code, COUNT_BIG(*) AS row_count
FROM [syteline].[fact_kpi_result]
WHERE kpi_code = 'SOP-KPI-C0'
GROUP BY week_key, kpi_code
HAVING COUNT_BIG(*) > 1;

-- M. After validation
EXEC [syteline].[sp_build_and_publish_sop_order_value_completed_all_v1];
*/
