/* SCHEMA CORRECTION NOTE
   All domain facts, KPI result tables, publishers and stored procedures in this file use [syteline].
   Shared calendar joins use [reporting].[dim_date].
   No [dbo] references remain. Existing non-v1 procedures are not modified.
*/
/* VERSIONING NOTE
   All stored procedures in this deployment script use the required _v1 suffix.
   Business logic, tables, KPI codes, targets and source filters are unchanged
   from the supplied active Product Engineering result script.
*/
/*
SAS PRODUCT ENGINEERING COST / 4 WEEK GBP K - END-TO-END GOLD KPI BUILD V2
===========================================================================
Warehouse: wh_sas_gold

Required sources:
    [syteline_staging].[coitem_mst]
    [syteline_staging].[item_mst]
    [reporting].[dim_date]

Gold outputs:
    [syteline].[fact_product_engineering_4_week_value_snapshot]
    [syteline].[fact_product_engineering_4_week_value_weekly]
    [syteline].[kpi_result_product_engineering_cost]
    [syteline].[fact_kpi_result]

KPI outputs:
    Product Eng - BE-KPI C1
    Product Eng - MB-KPI C1

Recovered calculation:
    ROUND(SUM((qty_ordered - qty_shipped) * uf_trnprice) / 1000, 0)

Recovered filters:
    site_ref = RBMW
    co_num begins C
    stat = O
    whse IN (BE, MB)
    BOM status IN (B, D, E, P)
    customer delivery date less than a forward boundary

Important mitigations:
1. The recovered SQL used a five-week forward boundary although the metric is labelled
   "4 Week GBP K". V2 retains five weeks so the supplied logic is not silently changed.
2. The join between coitem_mst and item_mst is item + site_ref.
3. Daily snapshots are retained because this is a point-in-time open-order measure.
4. Re-running the same snapshot date replaces only that date's BE/MB records.
5. Weekly KPI is the average of available Monday-Friday snapshot values.
6. Targets are set from the historic reporting requirement:
      Bridgend = 110 GBP K
      Maybole  = 40 GBP K
   Lower is treated as favourable, so breach_direction = OVER.
7. Source column names are the expected snake_case equivalents. Run the schema
   validation queries before compiling the procedure. If names differ, amend only
   the source CTE in sp_capture_product_engineering_4_week_value_snapshot.
8. Publication uses the explicit 26-column syteline.fact_kpi_result contract.
*/

IF SCHEMA_ID('syteline_staging') IS NULL EXEC('CREATE SCHEMA [syteline_staging]');
GO

IF OBJECT_ID('[syteline].[fact_kpi_result]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_kpi_result]
    (
        closed_year INT NULL, closed_week INT NULL, kpi_name VARCHAR(255) NULL,
        kpi_value DECIMAL(18,6) NULL, organisational_unit VARCHAR(255) NULL,
        kpi_id BIGINT NULL, kpi_category VARCHAR(100) NULL,
        target_value DECIMAL(18,6) NULL, breach_direction VARCHAR(20) NULL,
        week_key INT NULL, kpi_code VARCHAR(100) NULL, department VARCHAR(255) NULL,
        measure VARCHAR(500) NULL, measure_name VARCHAR(500) NULL, uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL, sign_label VARCHAR(100) NULL, commentary VARCHAR(1000) NULL,
        variance_value DECIMAL(18,6) NULL, performance_variance_value DECIMAL(18,6) NULL,
        rag_status VARCHAR(20) NULL, data_status VARCHAR(50) NULL,
        source_system VARCHAR(100) NULL, source_object VARCHAR(500) NULL,
        source_row_count BIGINT NULL, calculation_timestamp DATETIME2(6) NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[fact_product_engineering_4_week_value_snapshot]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_product_engineering_4_week_value_snapshot]
    (
        snapshot_date DATE NOT NULL,
        snapshot_timestamp DATETIME2(6) NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL,
        open_order_lines BIGINT NOT NULL,
        four_week_value_k DECIMAL(18,6) NULL,
        horizon_weeks INT NOT NULL,
        date_key INT NULL,
        closed_year INT NULL,
        closed_week INT NULL,
        week_key INT NULL,
        week_start_date DATE NULL,
        week_ending_date DATE NULL,
        source_row_count BIGINT NOT NULL,
        calculation_source VARCHAR(100) NOT NULL,
        created_ts DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[fact_product_engineering_4_week_value_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_product_engineering_4_week_value_weekly]
    (
        closed_year INT NOT NULL,
        closed_week INT NOT NULL,
        week_key INT NOT NULL,
        week_start_date DATE NOT NULL,
        week_ending_date DATE NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL,
        snapshot_days INT NOT NULL,
        average_four_week_value_k DECIMAL(18,6) NULL,
        minimum_four_week_value_k DECIMAL(18,6) NULL,
        maximum_four_week_value_k DECIMAL(18,6) NULL,
        source_row_count BIGINT NOT NULL,
        data_status VARCHAR(50) NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[kpi_result_product_engineering_cost]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[kpi_result_product_engineering_cost]
    (
        closed_year INT NULL, closed_week INT NULL, kpi_name VARCHAR(255) NULL,
        kpi_value DECIMAL(18,6) NULL, organisational_unit VARCHAR(255) NULL,
        kpi_id BIGINT NULL, kpi_category VARCHAR(100) NULL,
        target_value DECIMAL(18,6) NULL, breach_direction VARCHAR(20) NULL,
        week_key INT NULL, kpi_code VARCHAR(100) NULL, department VARCHAR(255) NULL,
        measure VARCHAR(500) NULL, measure_name VARCHAR(500) NULL, uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL, sign_label VARCHAR(100) NULL, commentary VARCHAR(1000) NULL,
        variance_value DECIMAL(18,6) NULL, performance_variance_value DECIMAL(18,6) NULL,
        rag_status VARCHAR(20) NULL, data_status VARCHAR(50) NULL,
        source_system VARCHAR(100) NULL, source_object VARCHAR(500) NULL,
        source_row_count BIGINT NULL, calculation_timestamp DATETIME2(6) NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_capture_product_engineering_4_week_value_snapshot_v1]
    @snapshot_timestamp DATETIME2(6) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @snapshot_timestamp IS NULL
        SET @snapshot_timestamp = SYSUTCDATETIME();

    DECLARE @snapshot_date DATE = CAST(@snapshot_timestamp AS DATE);
    DECLARE @horizon_end DATE = DATEADD(WEEK, 5, @snapshot_date);

    DELETE FROM [syteline].[fact_product_engineering_4_week_value_snapshot]
    WHERE snapshot_date = @snapshot_date
      AND warehouse_prefix IN ('BE', 'MB');

    ;WITH source_rows AS
    (
        SELECT
            warehouse_prefix = CAST(c.[whse] AS VARCHAR(10)),
            open_value = CAST(
                (COALESCE(TRY_CAST(c.[qty_ordered] AS DECIMAL(18,6)), 0)
                 - COALESCE(TRY_CAST(c.[qty_shipped] AS DECIMAL(18,6)), 0))
                * COALESCE(TRY_CAST(c.[uf_trnprice] AS DECIMAL(18,6)), 0)
                AS DECIMAL(18,6)),
            source_row_count = CAST(1 AS BIGINT)
        FROM [syteline_staging].[coitem_mst] c
        INNER JOIN [syteline_staging].[item_mst] i
            ON i.[item] = c.[item]
           AND i.[site_ref] = c.[site_ref]
        WHERE c.[site_ref] = 'RBMW'
          AND c.[co_num] LIKE 'C%'
          AND c.[stat] = 'O'
          AND c.[whse] IN ('BE', 'MB')
          AND i.[uf_bomstatus] IN ('B', 'D', 'E', 'P')
          AND c.[uf_custdeldate] IS NOT NULL
          AND CAST(c.[uf_custdeldate] AS DATE) < @horizon_end
    ), aggregated AS
    (
        SELECT
            warehouse_prefix,
            open_order_lines = COUNT_BIG(*),
            four_week_value_k = CAST(ROUND(SUM(open_value) / 1000.0, 0) AS DECIMAL(18,6)),
            source_row_count = SUM(source_row_count)
        FROM source_rows
        GROUP BY warehouse_prefix
    ), sites AS
    (
        SELECT 'BE' AS warehouse_prefix, 'Bridgend' AS site_name
        UNION ALL
        SELECT 'MB', 'Maybole'
    )
    INSERT INTO [syteline].[fact_product_engineering_4_week_value_snapshot]
    (
        snapshot_date, snapshot_timestamp, warehouse_prefix, site_name,
        open_order_lines, four_week_value_k, horizon_weeks,
        date_key, closed_year, closed_week, week_key, week_start_date,
        week_ending_date, source_row_count, calculation_source, created_ts
    )
    SELECT
        @snapshot_date,
        @snapshot_timestamp,
        s.warehouse_prefix,
        s.site_name,
        COALESCE(a.open_order_lines, 0),
        COALESCE(a.four_week_value_k, 0),
        5,
        d.date_key,
        d.customer_year,
        d.customer_week_no,
        d.week_key,
        d.week_start_date,
        d.week_end_date,
        COALESCE(a.source_row_count, 0),
        'RECOVERED_SYTELINE_SQL_5_WEEK_BOUNDARY',
        SYSUTCDATETIME()
    FROM sites s
    LEFT JOIN aggregated a
        ON a.warehouse_prefix = s.warehouse_prefix
    LEFT JOIN [reporting].[dim_date] d
        ON d.calendar_date = @snapshot_date;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_fact_product_engineering_4_week_value_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [syteline].[fact_product_engineering_4_week_value_weekly];

    INSERT INTO [syteline].[fact_product_engineering_4_week_value_weekly]
    (
        closed_year, closed_week, week_key, week_start_date, week_ending_date,
        warehouse_prefix, site_name, snapshot_days, average_four_week_value_k,
        minimum_four_week_value_k, maximum_four_week_value_k, source_row_count,
        data_status, calculation_timestamp
    )
    SELECT
        closed_year,
        closed_week,
        week_key,
        week_start_date,
        week_ending_date,
        warehouse_prefix,
        site_name,
        COUNT(DISTINCT snapshot_date),
        CAST(AVG(four_week_value_k) AS DECIMAL(18,6)),
        CAST(MIN(four_week_value_k) AS DECIMAL(18,6)),
        CAST(MAX(four_week_value_k) AS DECIMAL(18,6)),
        SUM(source_row_count),
        CASE WHEN COUNT(DISTINCT snapshot_date) >= 5 THEN 'Actual' ELSE 'Partial Week' END,
        SYSUTCDATETIME()
    FROM [syteline].[fact_product_engineering_4_week_value_snapshot]
    WHERE week_key IS NOT NULL
      AND snapshot_date >= week_start_date
      AND snapshot_date <= week_ending_date
      AND DATEPART(WEEKDAY, snapshot_date) IS NOT NULL
    GROUP BY
        closed_year, closed_week, week_key, week_start_date, week_ending_date,
        warehouse_prefix, site_name;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_kpi_result_product_engineering_cost_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [syteline].[kpi_result_product_engineering_cost]
    WHERE kpi_code IN ('Product Eng - BE-KPI C1', 'Product Eng - MB-KPI C1');

    INSERT INTO [syteline].[kpi_result_product_engineering_cost]
    (
        closed_year, closed_week, kpi_name, kpi_value, organisational_unit,
        kpi_id, kpi_category, target_value, breach_direction, week_key,
        kpi_code, department, measure, measure_name, uom, sign, sign_label,
        commentary, variance_value, performance_variance_value, rag_status,
        data_status, source_system, source_object, source_row_count,
        calculation_timestamp
    )
    SELECT
        w.closed_year,
        w.closed_week,
        'Cost Transfer Value Per Day',
        w.average_four_week_value_k,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
        NULL,
        'Cost',
        CAST(CASE w.warehouse_prefix WHEN 'BE' THEN 110.0 ELSE 40.0 END AS DECIMAL(18,6)),
        'OVER',
        w.week_key,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Eng - BE-KPI C1' ELSE 'Product Eng - MB-KPI C1' END,
        CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
        'Average Monday-Friday point-in-time value of eligible open Product Engineering order lines in GBP thousands',
        'Prod. Eng. 4 Week GBP K',
        'GBP K',
        'Over Breach',
        'Over Breach',
        CONCAT(
            'Snapshot days=', w.snapshot_days,
            '; minimum=', COALESCE(CAST(w.minimum_four_week_value_k AS VARCHAR(50)), 'NULL'),
            '; maximum=', COALESCE(CAST(w.maximum_four_week_value_k AS VARCHAR(50)), 'NULL'),
            '; recovered source logic uses a five-week horizon despite the 4 Week label.'
        ),
        w.average_four_week_value_k - CASE w.warehouse_prefix WHEN 'BE' THEN 110.0 ELSE 40.0 END,
        CASE w.warehouse_prefix WHEN 'BE' THEN 110.0 ELSE 40.0 END - w.average_four_week_value_k,
        CASE
            WHEN w.average_four_week_value_k IS NULL THEN 'No Data'
            WHEN w.average_four_week_value_k <= CASE w.warehouse_prefix WHEN 'BE' THEN 110.0 ELSE 40.0 END THEN 'G'
            WHEN w.average_four_week_value_k <= (CASE w.warehouse_prefix WHEN 'BE' THEN 110.0 ELSE 40.0 END) * 1.05 THEN 'A'
            ELSE 'R'
        END,
        w.data_status,
        'SyteLine',
        'syteline_staging.coitem_mst + syteline_staging.item_mst',
        w.source_row_count,
        SYSUTCDATETIME()
    FROM [syteline].[fact_product_engineering_4_week_value_weekly] w;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_product_engineering_cost_v1]
    @snapshot_timestamp DATETIME2(6) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[sp_capture_product_engineering_4_week_value_snapshot_v1] @snapshot_timestamp;
    EXEC [syteline].[sp_build_fact_product_engineering_4_week_value_weekly_v1];
    EXEC [syteline].[sp_build_kpi_result_product_engineering_cost_v1];
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_publish_product_engineering_cost_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [syteline].[fact_kpi_result]
    WHERE kpi_code IN ('Product Eng - BE-KPI C1', 'Product Eng - MB-KPI C1');

    INSERT INTO [syteline].[fact_kpi_result]
    (
        closed_year, closed_week, kpi_name, kpi_value, organisational_unit,
        kpi_id, kpi_category, target_value, breach_direction, week_key,
        kpi_code, department, measure, measure_name, uom, sign, sign_label,
        commentary, variance_value, performance_variance_value, rag_status,
        data_status, source_system, source_object, source_row_count,
        calculation_timestamp
    )
    SELECT
        closed_year, closed_week, kpi_name, kpi_value, organisational_unit,
        kpi_id, kpi_category, target_value, breach_direction, week_key,
        kpi_code, department, measure, measure_name, uom, sign, sign_label,
        commentary, variance_value, performance_variance_value, rag_status,
        data_status, source_system, source_object, source_row_count,
        calculation_timestamp
    FROM [syteline].[kpi_result_product_engineering_cost];
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_and_publish_product_engineering_cost_v1]
    @snapshot_timestamp DATETIME2(6) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[sp_build_product_engineering_cost_v1] @snapshot_timestamp;
    EXEC [syteline].[sp_publish_product_engineering_cost_v1];
END;
GO

/* =============================================================
   VALIDATION / TEST QUERIES
   =============================================================

-- A. Confirm the expected source columns before compiling/running
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'syteline_staging'
  AND TABLE_NAME IN ('coitem_mst', 'item_mst')
  AND COLUMN_NAME IN
  (
      'item', 'site_ref', 'co_num', 'stat', 'whse', 'qty_ordered',
      'qty_shipped', 'uf_trnprice', 'uf_custdeldate', 'uf_bomstatus'
  )
ORDER BY TABLE_NAME, ORDINAL_POSITION;

-- B. Source counts
SELECT 'coitem_mst' AS source_table, COUNT_BIG(*) AS row_count
FROM [syteline_staging].[coitem_mst]
UNION ALL
SELECT 'item_mst', COUNT_BIG(*)
FROM [syteline_staging].[item_mst];

-- C. Initial test snapshot. Use an explicit 08:00 timestamp if required.
EXEC [syteline].[sp_build_product_engineering_cost_v1]
     @snapshot_timestamp = '2026-11-04T08:00:00';

-- D. Review the captured daily snapshot
SELECT *
FROM [syteline].[fact_product_engineering_4_week_value_snapshot]
ORDER BY snapshot_date, warehouse_prefix;

-- E. Review weekly result
SELECT *
FROM [syteline].[fact_product_engineering_4_week_value_weekly]
ORDER BY closed_year, closed_week, warehouse_prefix;

-- F. Review dashboard-shaped domain KPI result
SELECT *
FROM [syteline].[kpi_result_product_engineering_cost]
ORDER BY closed_year, closed_week, kpi_code;

-- G. Publish after review
EXEC [syteline].[sp_publish_product_engineering_cost_v1];

-- H. Review final dashboard table
SELECT *
FROM [syteline].[fact_kpi_result]
WHERE kpi_code IN ('Product Eng - BE-KPI C1', 'Product Eng - MB-KPI C1')
ORDER BY closed_year, closed_week, kpi_code;

-- I. Domain-to-final reconciliation
SELECT
    d.week_key,
    d.kpi_code,
    d.kpi_value AS domain_kpi_value,
    f.kpi_value AS final_kpi_value,
    d.kpi_value - f.kpi_value AS value_difference,
    d.source_row_count AS domain_source_rows,
    f.source_row_count AS final_source_rows
FROM [syteline].[kpi_result_product_engineering_cost] d
LEFT JOIN [syteline].[fact_kpi_result] f
    ON f.week_key = d.week_key
   AND f.kpi_code = d.kpi_code
ORDER BY d.week_key, d.kpi_code;

-- J. Duplicate check
SELECT week_key, kpi_code, COUNT_BIG(*) AS row_count
FROM [syteline].[fact_kpi_result]
WHERE kpi_code IN ('Product Eng - BE-KPI C1', 'Product Eng - MB-KPI C1')
GROUP BY week_key, kpi_code
HAVING COUNT_BIG(*) > 1;

-- K. Normal scheduled run after validation
EXEC [syteline].[sp_build_and_publish_product_engineering_cost_v1]
     @snapshot_timestamp = NULL;
*/
