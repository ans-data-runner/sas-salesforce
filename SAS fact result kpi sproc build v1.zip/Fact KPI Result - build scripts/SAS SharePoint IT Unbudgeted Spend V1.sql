/*
    SAS SharePoint IT Unbudgeted Spend KPI - V1

    Source:
      sharepoint_staging.it_purchasing_2026_staging
      Workbook: IT Purchasing 26.xlsx / ITPurchasing2026StagingSheet

    Business rule from SAS KPI Logic Catalogue:
      - Use the source field identifying whether spend is budgeted.
      - Calculate unbudgeted spend for the selected month.
      - Source is a rolling monthly value; preserve snapshots/history.

    This implementation:
      - treats budgeted values of N/NO/FALSE/0/UNBUDGETED as unbudgeted;
      - uses final_total as the spend amount;
      - uses date_ordered for period assignment;
      - creates a daily snapshot of the current monthly total so history is preserved;
      - produces one weekly reporting row from the latest snapshot available in each reporting week;
      - joins reporting.kpi_control for target/RAG metadata;
      - publishes only to sharepoint.fact_kpi_result.

    NOTE:
      If the physical budgeted values differ, amend the clearly marked predicate in
      usp_capture_it_unbudgeted_spend_snapshot_v1 after reviewing the source values.
*/

/* ================================================================
   0. Domain KPI result table
   ================================================================ */

IF OBJECT_ID('[sharepoint].[fact_kpi_result]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_kpi_result]
    (
        [closed_year]                  INT             NULL,
        [closed_week]                  INT             NULL,
        [week_key]                     INT             NULL,
        [kpi_id]                       BIGINT          NULL,
        [kpi_code]                     VARCHAR(1000)   NULL,
        [kpi_name]                     VARCHAR(1000)   NULL,
        [kpi_category]                 VARCHAR(1000)   NULL,
        [organisational_unit]          VARCHAR(1000)   NULL,
        [department]                   VARCHAR(1000)   NULL,
        [measure]                      VARCHAR(1000)   NULL,
        [measure_name]                 VARCHAR(1000)   NULL,
        [uom]                          VARCHAR(1000)   NULL,
        [sign]                         VARCHAR(1000)   NULL,
        [sign_label]                   VARCHAR(1000)   NULL,
        [commentary]                   VARCHAR(1000)   NULL,
        [breach_direction]             VARCHAR(1000)   NULL,
        [kpi_value]                    DECIMAL(18,4)   NULL,
        [target_value]                 DECIMAL(18,4)   NULL,
        [variance_value]               DECIMAL(18,4)   NULL,
        [performance_variance_value]   DECIMAL(18,4)   NULL,
        [rag_status]                   VARCHAR(1000)   NULL,
        [data_status]                  VARCHAR(1000)   NULL,
        [source_system]                VARCHAR(1000)   NULL,
        [source_object]                VARCHAR(1000)   NULL,
        [source_row_count]             BIGINT          NULL,
        [calculation_timestamp]        DATETIME2(6)    NULL
    );
END;
GO

/* ================================================================
   1. Snapshot fact
   ================================================================ */

IF OBJECT_ID('[sharepoint].[fact_it_unbudgeted_spend_snapshot_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_it_unbudgeted_spend_snapshot_v1]
    (
        [snapshot_date]        DATE            NOT NULL,
        [period_year]          INT             NOT NULL,
        [period_month]         INT             NOT NULL,
        [unbudgeted_spend]     DECIMAL(18,4)   NOT NULL,
        [source_row_count]     BIGINT          NOT NULL,
        [calculation_timestamp] DATETIME2(6)   NOT NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_capture_it_unbudgeted_spend_snapshot_v1]
    @snapshot_date DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @snapshot_date = COALESCE(@snapshot_date, CAST(SYSUTCDATETIME() AS DATE));

    IF NOT EXISTS (SELECT 1 FROM [sharepoint_staging].[it_purchasing_2026_staging])
    BEGIN
        THROW 50001, 'ABORTED: sharepoint_staging.it_purchasing_2026_staging is empty. Existing IT snapshot history has been preserved.', 1;
    END;

    DECLARE @period_year INT = YEAR(@snapshot_date);
    DECLARE @period_month INT = MONTH(@snapshot_date);

    DELETE FROM [sharepoint].[fact_it_unbudgeted_spend_snapshot_v1]
    WHERE [snapshot_date] = @snapshot_date;

    ;WITH [src] AS
    (
        SELECT
            TRY_CONVERT(DATE, [date_ordered], 103) AS [date_ordered_uk],
            TRY_CONVERT(DATE, [date_ordered]) AS [date_ordered_iso],
            UPPER(LTRIM(RTRIM(COALESCE([budgeted], '')))) AS [budgeted_value],
            TRY_CONVERT
            (
                DECIMAL(18,4),
                REPLACE(REPLACE(REPLACE(REPLACE(COALESCE([final_total], ''), '£', ''), ',', ''), 'GBP', ''), ' ', '')
            ) AS [final_total_value]
        FROM [sharepoint_staging].[it_purchasing_2026_staging]
    ),
    [normalised] AS
    (
        SELECT
            COALESCE([date_ordered_uk], [date_ordered_iso]) AS [ordered_date],
            [budgeted_value],
            [final_total_value]
        FROM [src]
    )
    INSERT INTO [sharepoint].[fact_it_unbudgeted_spend_snapshot_v1]
    (
        [snapshot_date],
        [period_year],
        [period_month],
        [unbudgeted_spend],
        [source_row_count],
        [calculation_timestamp]
    )
    SELECT
        @snapshot_date,
        @period_year,
        @period_month,
        CAST(COALESCE(SUM([final_total_value]), 0) AS DECIMAL(18,4)),
        COUNT_BIG(*),
        CAST(SYSUTCDATETIME() AS DATETIME2(6))
    FROM [normalised]
    WHERE YEAR([ordered_date]) = @period_year
      AND MONTH([ordered_date]) = @period_month
      AND [budgeted_value] IN ('N','NO','FALSE','0','UNBUDGETED','UN-BUDGETED','NOT BUDGETED');
END;
GO

/* ================================================================
   2. Weekly representation of rolling monthly snapshot
   ================================================================ */

IF OBJECT_ID('[sharepoint].[fact_it_unbudgeted_spend_weekly_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_it_unbudgeted_spend_weekly_v1]
    (
        [closed_year]           INT            NULL,
        [closed_week]           INT            NULL,
        [week_key]              INT            NULL,
        [week_ending_date]      DATE           NULL,
        [snapshot_date]         DATE           NULL,
        [unbudgeted_spend]      DECIMAL(18,4)  NULL,
        [source_row_count]      BIGINT         NULL,
        [calculation_timestamp] DATETIME2(6)   NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_it_unbudgeted_spend_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [sharepoint].[fact_it_unbudgeted_spend_weekly_v1];

    ;WITH [ranked] AS
    (
        SELECT
            d.[customer_year] AS [closed_year],
            d.[customer_week_no] AS [closed_week],
            d.[week_key],
            CAST(d.[week_end_date] AS DATE) AS [week_ending_date],
            s.[snapshot_date],
            s.[unbudgeted_spend],
            s.[source_row_count],
            s.[calculation_timestamp],
            ROW_NUMBER() OVER
            (
                PARTITION BY d.[week_key]
                ORDER BY s.[snapshot_date] DESC, s.[calculation_timestamp] DESC
            ) AS [rn]
        FROM [sharepoint].[fact_it_unbudgeted_spend_snapshot_v1] s
        INNER JOIN [reporting].[dim_date] d
            ON d.[calendar_date] = s.[snapshot_date]
    )
    INSERT INTO [sharepoint].[fact_it_unbudgeted_spend_weekly_v1]
    (
        [closed_year], [closed_week], [week_key], [week_ending_date],
        [snapshot_date], [unbudgeted_spend], [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [week_key], [week_ending_date],
        [snapshot_date], [unbudgeted_spend], [source_row_count], [calculation_timestamp]
    FROM [ranked]
    WHERE [rn] = 1;
END;
GO

/* ================================================================
   3. KPI result
   ================================================================ */

IF OBJECT_ID('[sharepoint].[kpi_result_it_unbudgeted_spend_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[kpi_result_it_unbudgeted_spend_v1]
    (
        [closed_year]                  INT            NULL,
        [closed_week]                  INT            NULL,
        [week_key]                     INT            NULL,
        [kpi_id]                       BIGINT         NULL,
        [kpi_code]                     VARCHAR(1000)  NULL,
        [kpi_name]                     VARCHAR(1000)  NULL,
        [kpi_category]                 VARCHAR(1000)  NULL,
        [organisational_unit]          VARCHAR(1000)  NULL,
        [department]                   VARCHAR(1000)  NULL,
        [measure]                      VARCHAR(1000)  NULL,
        [measure_name]                 VARCHAR(1000)  NULL,
        [uom]                          VARCHAR(1000)  NULL,
        [sign]                         VARCHAR(1000)  NULL,
        [sign_label]                   VARCHAR(1000)  NULL,
        [commentary]                   VARCHAR(1000)  NULL,
        [breach_direction]             VARCHAR(1000)  NULL,
        [kpi_value]                    DECIMAL(18,4)  NULL,
        [target_value]                 DECIMAL(18,4)  NULL,
        [variance_value]               DECIMAL(18,4)  NULL,
        [performance_variance_value]   DECIMAL(18,4)  NULL,
        [rag_status]                   VARCHAR(1000)  NULL,
        [data_status]                  VARCHAR(1000)  NULL,
        [source_system]                VARCHAR(1000)  NULL,
        [source_object]                VARCHAR(1000)  NULL,
        [source_row_count]             BIGINT         NULL,
        [calculation_timestamp]        DATETIME2(6)   NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_kpi_result_it_unbudgeted_spend_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [sharepoint].[kpi_result_it_unbudgeted_spend_v1];

    ;WITH [base] AS
    (
        SELECT
            w.[closed_year],
            w.[closed_week],
            w.[week_key],
            w.[week_ending_date],
            w.[unbudgeted_spend] AS [kpi_value],
            w.[source_row_count]
        FROM [sharepoint].[fact_it_unbudgeted_spend_weekly_v1] w
    ),
    [enriched] AS
    (
        SELECT
            b.*,
            c.[kpi_id],
            c.[kpi_code],
            c.[kpi_name],
            c.[kpi_category],
            c.[organisational_unit],
            c.[department],
            c.[measure],
            c.[measure_name],
            c.[uom],
            c.[sign],
            c.[sign_label],
            c.[commentary] AS [control_commentary],
            c.[breach_direction],
            c.[target_value],
            c.[rag_threshold_low],
            c.[rag_threshold_high]
        FROM [base] b
        LEFT JOIN [reporting].[kpi_control] c
            ON c.[kpi_code] = 'IT-KPI-C1'
           AND c.[is_active] = 1
           AND b.[week_ending_date] >= c.[effective_from]
           AND (c.[effective_to] IS NULL OR b.[week_ending_date] <= c.[effective_to])
    )
    INSERT INTO [sharepoint].[kpi_result_it_unbudgeted_spend_v1]
    (
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year],
        [closed_week],
        [week_key],
        COALESCE([kpi_id], 0),
        COALESCE([kpi_code], 'IT-KPI-C1'),
        COALESCE([kpi_name], 'Unbudgeted IT Spend'),
        COALESCE([kpi_category], 'Cost'),
        COALESCE([organisational_unit], 'IT'),
        COALESCE([department], 'IT'),
        COALESCE([measure], 'Unbudgeted Spend'),
        COALESCE([measure_name], 'Unbudgeted IT Spend'),
        COALESCE([uom], 'GBP'),
        COALESCE([sign], 'Over Breach'),
        COALESCE([sign_label], 'Over Breach'),
        CAST(COALESCE([control_commentary], 'Rolling monthly unbudgeted spend using latest snapshot available in the reporting week.') AS VARCHAR(1000)),
        COALESCE([breach_direction], 'OVER'),
        CAST([kpi_value] AS DECIMAL(18,4)),
        CAST([target_value] AS DECIMAL(18,4)),
        CAST(CASE WHEN [target_value] IS NULL THEN NULL ELSE [kpi_value] - [target_value] END AS DECIMAL(18,4)),
        CAST(CASE
            WHEN [target_value] IS NULL THEN NULL
            WHEN COALESCE([breach_direction], 'OVER') = 'OVER' THEN [target_value] - [kpi_value]
            ELSE [kpi_value] - [target_value]
        END AS DECIMAL(18,4)),
        CASE
            WHEN [target_value] IS NULL THEN 'TBC'
            WHEN [target_value] = 0 AND [kpi_value] = 0 THEN 'G'
            WHEN [target_value] = 0 AND [kpi_value] > 0 THEN 'R'
            WHEN COALESCE([breach_direction], 'OVER') = 'OVER' AND [kpi_value] <= [target_value] THEN 'G'
            WHEN COALESCE([breach_direction], 'OVER') = 'OVER' AND [kpi_value] <= [target_value] * 1.05 THEN 'A'
            WHEN COALESCE([breach_direction], 'OVER') = 'UNDER' AND [kpi_value] >= [target_value] THEN 'G'
            WHEN COALESCE([breach_direction], 'OVER') = 'UNDER' AND [kpi_value] >= [target_value] * 0.95 THEN 'A'
            ELSE 'R'
        END,
        CASE WHEN [target_value] IS NULL THEN 'Target Missing' ELSE 'Calculated' END,
        'SharePoint',
        'sharepoint_staging.it_purchasing_2026_staging',
        [source_row_count],
        CAST(SYSUTCDATETIME() AS DATETIME2(6))
    FROM [enriched];
END;
GO

/* ================================================================
   4. Publisher
   ================================================================ */

CREATE OR ALTER PROCEDURE [sharepoint].[usp_publish_it_unbudgeted_spend_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [sharepoint].[fact_kpi_result]
    WHERE [kpi_code] = 'IT-KPI-C1';

    INSERT INTO [sharepoint].[fact_kpi_result]
    (
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    FROM [sharepoint].[kpi_result_it_unbudgeted_spend_v1];
END;
GO

/* ================================================================
   5. Runner procedures
   ================================================================ */

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_it_unbudgeted_spend_v1]
    @snapshot_date DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    EXEC [sharepoint].[usp_capture_it_unbudgeted_spend_snapshot_v1]
         @snapshot_date = @snapshot_date;

    EXEC [sharepoint].[usp_build_fact_it_unbudgeted_spend_weekly_v1];
    EXEC [sharepoint].[usp_build_kpi_result_it_unbudgeted_spend_v1];
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_and_publish_it_unbudgeted_spend_v1]
    @snapshot_date DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    EXEC [sharepoint].[usp_build_it_unbudgeted_spend_v1]
         @snapshot_date = @snapshot_date;

    EXEC [sharepoint].[usp_publish_it_unbudgeted_spend_v1];
END;
GO

/* ================================================================
   6. Validation / first-use queries
   ================================================================ */

-- Review the actual physical Budgeted values before first production execution.
SELECT
    UPPER(LTRIM(RTRIM(COALESCE([budgeted], '')))) AS [budgeted_value],
    COUNT_BIG(*) AS [rows]
FROM [sharepoint_staging].[it_purchasing_2026_staging]
GROUP BY UPPER(LTRIM(RTRIM(COALESCE([budgeted], ''))))
ORDER BY [rows] DESC;

-- Check source date/value coverage.
SELECT
    COUNT_BIG(*) AS [source_rows],
    MIN(COALESCE(TRY_CONVERT(DATE, [date_ordered], 103), TRY_CONVERT(DATE, [date_ordered]))) AS [first_order_date],
    MAX(COALESCE(TRY_CONVERT(DATE, [date_ordered], 103), TRY_CONVERT(DATE, [date_ordered]))) AS [last_order_date],
    SUM(CASE WHEN TRY_CONVERT(DECIMAL(18,4), REPLACE(REPLACE(REPLACE(REPLACE(COALESCE([final_total], ''), '£', ''), ',', ''), 'GBP', ''), ' ', '')) IS NOT NULL THEN 1 ELSE 0 END) AS [rows_with_numeric_final_total]
FROM [sharepoint_staging].[it_purchasing_2026_staging];

-- Build current snapshot without publishing.
-- EXEC [sharepoint].[usp_build_it_unbudgeted_spend_v1];

-- Review history.
SELECT *
FROM [sharepoint].[fact_it_unbudgeted_spend_snapshot_v1]
ORDER BY [snapshot_date];

SELECT *
FROM [sharepoint].[kpi_result_it_unbudgeted_spend_v1]
ORDER BY [week_key];

-- Publish after validation.
-- EXEC [sharepoint].[usp_publish_it_unbudgeted_spend_v1];

SELECT *
FROM [sharepoint].[fact_kpi_result]
WHERE [kpi_code] = 'IT-KPI-C1'
ORDER BY [week_key];
