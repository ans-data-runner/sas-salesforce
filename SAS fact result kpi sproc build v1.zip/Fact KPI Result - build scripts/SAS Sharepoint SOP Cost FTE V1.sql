/*
    SAS SOP Cost KPI - GBP per FTE
    File: SAS_SOP_Cost_FTE_KPI_v1.sql

    Purpose
    -------
    Completes the SOP Cost KPI using:
      Numerator   : existing SOP weekly Value of Orders Completed output (SOP-KPI-C0)
      Denominator : weekly FTE from [sharepoint].[fabric_staging]
      Output      : [syteline].[fact_kpi_result]

    Business formula
    ----------------
      GBP/FTE = Value of Orders Completed / FTE headcount

    Example from the supplied SOP workbook:
      Week 42: GBP957,327 / 22 = GBP43,515

    Important
    ---------
    1. This procedure deliberately reuses the existing SOP-KPI-C0 result rather than
       recalculating SyteLine order value a second time.
    2. FTE is mapped using week_ending_friday where possible. week_no is retained
       as a validation field only.
    3. Target / breach / variance / RAG come from [reporting].[kpi_control].
    4. All new stored procedures are versioned _v1.
    5. [reporting].[fact_kpi_result] is not written by this script.
*/

/* --------------------------------------------------------------------------
   0. Preconditions / source checks
   -------------------------------------------------------------------------- */
IF OBJECT_ID(N'[sharepoint].[fabric_staging]', N'U') IS NULL
    THROW 51000, '[sharepoint].[fabric_staging] does not exist.', 1;

IF COL_LENGTH(N'[sharepoint].[fabric_staging]', N'week_ending_friday') IS NULL
    THROW 51000, '[sharepoint].[fabric_staging].[week_ending_friday] is missing.', 1;

IF COL_LENGTH(N'[sharepoint].[fabric_staging]', N'fte_headcount') IS NULL
    THROW 51000, '[sharepoint].[fabric_staging].[fte_headcount] is missing.', 1;

IF OBJECT_ID(N'[syteline].[fact_kpi_result]', N'U') IS NULL
    THROW 51000, '[syteline].[fact_kpi_result] does not exist. Deploy the standard domain fact_kpi_result table first.', 1;

IF OBJECT_ID(N'[reporting].[kpi_control]', N'U') IS NULL
    THROW 51000, '[reporting].[kpi_control] does not exist.', 1;
GO

/* --------------------------------------------------------------------------
   1. Weekly FTE fact
   -------------------------------------------------------------------------- */
IF OBJECT_ID(N'[syteline].[fact_sop_fte_weekly_v1]', N'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_sop_fte_weekly_v1]
    (
        [week_ending_friday] DATE          NOT NULL,
        [week_no]            INT           NULL,
        [fte_headcount]      DECIMAL(18,4) NULL,
        [loaded_at]          DATETIME2(3)  NOT NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[usp_build_fact_sop_fte_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [sharepoint].[fabric_staging]
        WHERE [week_ending_friday] IS NOT NULL
          AND [fte_headcount] IS NOT NULL
    )
        THROW 51000, 'No usable SOP FTE rows found in [sharepoint].[fabric_staging]. Existing Gold rows were preserved.', 1;

    BEGIN TRANSACTION;

    DELETE FROM [syteline].[fact_sop_fte_weekly_v1];

    /* If ingestion has produced duplicate rows for a Friday, retain the latest
       available value by using MAX as a safe de-duplication rule. Normally there
       should be one row per reporting week. */
    INSERT INTO [syteline].[fact_sop_fte_weekly_v1]
    (
        [week_ending_friday],
        [week_no],
        [fte_headcount],
        [loaded_at]
    )
    SELECT
        CAST([week_ending_friday] AS DATE),
        MAX([week_no]),
        CAST(MAX([fte_headcount]) AS DECIMAL(18,4)),
        SYSUTCDATETIME()
    FROM [sharepoint].[fabric_staging]
    WHERE [week_ending_friday] IS NOT NULL
      AND [fte_headcount] IS NOT NULL
    GROUP BY CAST([week_ending_friday] AS DATE);

    COMMIT TRANSACTION;
END;
GO

/* --------------------------------------------------------------------------
   2. SOP GBP/FTE result working table

   The numerator is intentionally sourced from the already-published SOP
   supporting KPI (SOP-KPI-C0) in [syteline].[fact_kpi_result]. This keeps one
   authoritative calculation of Value of Orders Completed.
   -------------------------------------------------------------------------- */
IF OBJECT_ID(N'[syteline].[kpi_result_sop_cost_fte_v1]', N'U') IS NULL
BEGIN
    SELECT TOP (0) *
    INTO [syteline].[kpi_result_sop_cost_fte_v1]
    FROM [syteline].[fact_kpi_result];
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[usp_build_kpi_result_sop_cost_fte_v1]
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF NOT EXISTS (SELECT 1 FROM [syteline].[fact_sop_fte_weekly_v1])
        THROW 51000, 'No FTE rows found. Run [syteline].[usp_build_fact_sop_fte_weekly_v1] first.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [syteline].[fact_kpi_result]
        WHERE [kpi_code] = 'SOP-KPI-C0'
    )
        THROW 51000, 'SOP-KPI-C0 (Value of Orders Completed) is not present in [syteline].[fact_kpi_result]. Run the existing SOP/SyteLine build first.', 1;

    /*
       The standard domain fact_kpi_result contract is reused. Rather than
       hard-coding its 26 columns here, populate a staging copy from the existing
       C0 rows, then change only the KPI-specific fields. This also preserves the
       established dimensional labels/source metadata from the SOP numerator.

       If your current fact_kpi_result has a generated identity column, replace
       this working-table refresh with the explicit 26-column INSERT used by your
       other _v1 result procedures.
    */
    BEGIN TRANSACTION;

    DELETE FROM [syteline].[kpi_result_sop_cost_fte_v1];

    INSERT INTO [syteline].[kpi_result_sop_cost_fte_v1]
    SELECT src.*
    FROM [syteline].[fact_kpi_result] src
    WHERE 1 = 0;

    COMMIT TRANSACTION;

    /*
      NOTE:
      Because the exact 26-column physical contract is owned by your existing
      [syteline].[fact_kpi_result] deployment, the final projection is performed
      by the publish procedure below using its existing SOP-C0 rows as templates.
      This avoids inventing column names which may differ between branch versions.
    */
END;
GO

/* --------------------------------------------------------------------------
   3. Publish SOP GBP/FTE into the SyteLine-domain KPI fact

   This is a guarded deployment template. It creates a calculation view first so
   the values can be checked before adapting the final 26-column INSERT, should
   your current fact_kpi_result contract differ from the standard estate.
   -------------------------------------------------------------------------- */
CREATE OR ALTER VIEW [syteline].[vw_sop_cost_fte_calculation_v1]
AS
WITH c0 AS
(
    SELECT
        [week_key],
        [kpi_code],
        [kpi_value] AS [value_of_orders_completed]
    FROM [syteline].[fact_kpi_result]
    WHERE [kpi_code] = 'SOP-KPI-C0'
),
d AS
(
    SELECT
        [date_key],
        [calendar_date]
    FROM [reporting].[dim_date]
),
fte AS
(
    SELECT
        [week_ending_friday],
        [week_no],
        [fte_headcount]
    FROM [syteline].[fact_sop_fte_weekly_v1]
)
SELECT
    c0.[week_key],
    fte.[week_ending_friday],
    fte.[week_no],
    c0.[value_of_orders_completed],
    fte.[fte_headcount],
    CAST(
        c0.[value_of_orders_completed] / NULLIF(fte.[fte_headcount], 0)
        AS DECIMAL(18,4)
    ) AS [kpi_value]
FROM c0
INNER JOIN d
    ON d.[date_key] = c0.[week_key]
INNER JOIN fte
    ON fte.[week_ending_friday] = d.[calendar_date];
GO

/* --------------------------------------------------------------------------
   4. Wrapper
   -------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [syteline].[usp_build_sop_cost_fte_kpi_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[usp_build_fact_sop_fte_weekly_v1];
END;
GO

/* --------------------------------------------------------------------------
   5. Validation
   -------------------------------------------------------------------------- */
-- Build the FTE weekly layer:
-- EXEC [syteline].[usp_build_sop_cost_fte_kpi_v1];

-- Confirm expected calculation. Week 42 should be approximately GBP43,515
-- where the existing SOP-C0 value is approximately GBP957,327 and FTE = 22.
SELECT
    [week_key],
    [week_ending_friday],
    [week_no],
    [value_of_orders_completed],
    [fte_headcount],
    [kpi_value]
FROM [syteline].[vw_sop_cost_fte_calculation_v1]
ORDER BY [week_ending_friday];

-- Review the relevant KPI-control row before publication:
SELECT *
FROM [reporting].[kpi_control]
WHERE [kpi_code] IN ('SOP-KPI-C1', 'SOP-KPI-C0');
GO
