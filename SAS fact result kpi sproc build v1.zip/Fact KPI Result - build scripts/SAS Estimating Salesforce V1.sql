/*
SAS ESTIMATING - SALESFORCE DOMAIN KPI BUILD V1
================================================
Warehouse: wh_sas_gold

Purpose
-------
Rebuild the four Estimating KPI streams from Salesforce staging, apply targets from
reporting.kpi_control, and publish into salesforce.fact_kpi_result.

KPIs
----
EST-KPI-P1  Quotes Issued
EST-KPI-D1  Quotes Issued On Time
EST-KPI-Q1  Average Estimating Hours
EST-KPI-C1  Rate per Square Metre

Design rules
------------
- Existing procedures and tables are not altered.
- Every new stored procedure ends in _v1.
- New intermediate tables end in _v1.
- reporting.dim_date is the canonical date dimension.
- reporting.kpi_control supplies target_value and breach_direction.
- Final publication is to salesforce.fact_kpi_result only.
- reporting.fact_kpi_result is not changed by this script.
- Empty staging sources abort before any target table is cleared.
- Percentages use the 0-to-1 scale.
*/

/* =============================================================
   0. KPI CONTROL SEED
   Assumed control columns already established:
     kpi_code, kpi_name, department, kpi_category, target_value,
     uom, breach_direction, rag_tolerance_pct, effective_from,
     effective_to, target_status, target_source, commentary,
     created_timestamp, updated_timestamp
   ============================================================= */

IF NOT EXISTS (SELECT 1 FROM [reporting].[kpi_control] WHERE [kpi_code] = 'EST-KPI-P1')
BEGIN
    INSERT INTO [reporting].[kpi_control]
    (
        [kpi_code], [kpi_name], [department], [kpi_category], [target_value],
        [uom], [breach_direction], [rag_tolerance_pct], [effective_from],
        [effective_to], [target_status], [target_source], [commentary],
        [created_timestamp], [updated_timestamp]
    )
    VALUES
    ('EST-KPI-P1','Quotes Issued','Estimating','Productivity',126.000000,
     'Count','UNDER',0.050000,'2025-01-01',NULL,'Approved','KPI targets.xlsx',
     'Weekly count of issued Salesforce CPQ quotes.',SYSUTCDATETIME(),SYSUTCDATETIME());
END;
GO

IF NOT EXISTS (SELECT 1 FROM [reporting].[kpi_control] WHERE [kpi_code] = 'EST-KPI-D1')
BEGIN
    INSERT INTO [reporting].[kpi_control]
    (
        [kpi_code], [kpi_name], [department], [kpi_category], [target_value],
        [uom], [breach_direction], [rag_tolerance_pct], [effective_from],
        [effective_to], [target_status], [target_source], [commentary],
        [created_timestamp], [updated_timestamp]
    )
    VALUES
    ('EST-KPI-D1','Quotes Issued On Time','Estimating','Delivery',0.850000,
     'Percentage','UNDER',0.050000,'2025-01-01',NULL,'Approved','KPI targets.xlsx',
     'Quote date on or before requested return or complete-by date.',SYSUTCDATETIME(),SYSUTCDATETIME());
END;
GO

IF NOT EXISTS (SELECT 1 FROM [reporting].[kpi_control] WHERE [kpi_code] = 'EST-KPI-Q1')
BEGIN
    INSERT INTO [reporting].[kpi_control]
    (
        [kpi_code], [kpi_name], [department], [kpi_category], [target_value],
        [uom], [breach_direction], [rag_tolerance_pct], [effective_from],
        [effective_to], [target_status], [target_source], [commentary],
        [created_timestamp], [updated_timestamp]
    )
    VALUES
    ('EST-KPI-Q1','Average Estimating Hours','Estimating','Quality',28.000000,
     'Hours','OVER',0.050000,'2025-01-01',NULL,'Approved','KPI targets.xlsx',
     'Average hours to close completed estimating requests.',SYSUTCDATETIME(),SYSUTCDATETIME());
END;
GO

IF NOT EXISTS (SELECT 1 FROM [reporting].[kpi_control] WHERE [kpi_code] = 'EST-KPI-C1')
BEGIN
    INSERT INTO [reporting].[kpi_control]
    (
        [kpi_code], [kpi_name], [department], [kpi_category], [target_value],
        [uom], [breach_direction], [rag_tolerance_pct], [effective_from],
        [effective_to], [target_status], [target_source], [commentary],
        [created_timestamp], [updated_timestamp]
    )
    VALUES
    ('EST-KPI-C1','Rate per Square Metre','Estimating','Cost',75.000000,
     'Currency per sqm','UNDER',0.050000,'2025-01-01',NULL,'Approved','KPI targets.xlsx',
     'Eligible quote-line net value divided by line square metres.',SYSUTCDATETIME(),SYSUTCDATETIME());
END;
GO

/* =============================================================
   1. V1 ATOMIC FACT TABLES
   ============================================================= */
IF OBJECT_ID('[salesforce].[fact_estimating_request_v1]','U') IS NULL
CREATE TABLE [salesforce].[fact_estimating_request_v1]
(
    [estimating_request_id] VARCHAR(255) NOT NULL,
    [estimating_request_no] VARCHAR(255) NULL,
    [project_name] VARCHAR(500) NULL,
    [request_status] VARCHAR(255) NULL,
    [sales_division] VARCHAR(255) NULL,
    [project_region] VARCHAR(255) NULL,
    [currency_code] VARCHAR(20) NULL,
    [created_date] DATE NULL,
    [due_date] DATE NULL,
    [closed_date] DATE NULL,
    [hours_taken_to_close] DECIMAL(18,6) NULL,
    [date_key] INT NULL,
    [closed_year] INT NULL,
    [closed_week] INT NULL,
    [week_key] INT NULL,
    [week_start_date] DATE NULL,
    [week_ending_date] DATE NULL,
    [source_row_count] BIGINT NOT NULL,
    [created_ts] DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[salesforce].[fact_estimating_quote_v1]','U') IS NULL
CREATE TABLE [salesforce].[fact_estimating_quote_v1]
(
    [quote_id] VARCHAR(255) NOT NULL,
    [quote_name] VARCHAR(500) NULL,
    [estimating_request_id] VARCHAR(255) NULL,
    [estimating_request_no] VARCHAR(255) NULL,
    [project_name] VARCHAR(500) NULL,
    [quote_status] VARCHAR(255) NULL,
    [is_primary_quote] BIT NULL,
    [sales_division] VARCHAR(255) NULL,
    [region] VARCHAR(255) NULL,
    [currency_code] VARCHAR(20) NULL,
    [quote_date] DATE NULL,
    [due_date] DATE NULL,
    [closed_date] DATE NULL,
    [net_amount] DECIMAL(18,6) NULL,
    [quote_sqm] DECIMAL(18,6) NULL,
    [source_sqm_rate] DECIMAL(18,6) NULL,
    [issued_on_time_flag] BIT NULL,
    [date_key] INT NULL,
    [closed_year] INT NULL,
    [closed_week] INT NULL,
    [week_key] INT NULL,
    [week_start_date] DATE NULL,
    [week_ending_date] DATE NULL,
    [source_row_count] BIGINT NOT NULL,
    [created_ts] DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[salesforce].[fact_estimating_quote_line_v1]','U') IS NULL
CREATE TABLE [salesforce].[fact_estimating_quote_line_v1]
(
    [quote_line_id] VARCHAR(255) NOT NULL,
    [quote_line_name] VARCHAR(500) NULL,
    [quote_id] VARCHAR(255) NULL,
    [estimating_request_id] VARCHAR(255) NULL,
    [estimating_request_no] VARCHAR(255) NULL,
    [quote_date] DATE NULL,
    [quantity] DECIMAL(18,6) NULL,
    [net_total] DECIMAL(18,6) NULL,
    [item_sqm] DECIMAL(18,6) NULL,
    [line_sqm] DECIMAL(18,6) NULL,
    [source_sqm_rate] DECIMAL(18,6) NULL,
    [price_excluded] BIT NULL,
    [is_sqm_kpi_eligible] BIT NULL,
    [date_key] INT NULL,
    [closed_year] INT NULL,
    [closed_week] INT NULL,
    [week_key] INT NULL,
    [week_start_date] DATE NULL,
    [week_ending_date] DATE NULL,
    [source_row_count] BIGINT NOT NULL,
    [created_ts] DATETIME2(6) NOT NULL
);
GO

/* =============================================================
   2. V1 WEEKLY TABLES
   ============================================================= */
IF OBJECT_ID('[salesforce].[fact_estimating_quotes_weekly_v1]','U') IS NULL
CREATE TABLE [salesforce].[fact_estimating_quotes_weekly_v1]
(
    [closed_year] INT NOT NULL,
    [closed_week] INT NOT NULL,
    [week_key] INT NOT NULL,
    [week_start_date] DATE NOT NULL,
    [week_ending_date] DATE NOT NULL,
    [quotes_issued] BIGINT NOT NULL,
    [due_dated_quotes] BIGINT NOT NULL,
    [quotes_issued_on_time] BIGINT NOT NULL,
    [quotes_issued_on_time_percentage] DECIMAL(18,6) NULL,
    [source_row_count] BIGINT NOT NULL,
    [calculation_timestamp] DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[salesforce].[fact_estimating_hours_weekly_v1]','U') IS NULL
CREATE TABLE [salesforce].[fact_estimating_hours_weekly_v1]
(
    [closed_year] INT NOT NULL,
    [closed_week] INT NOT NULL,
    [week_key] INT NOT NULL,
    [week_start_date] DATE NOT NULL,
    [week_ending_date] DATE NOT NULL,
    [closed_requests] BIGINT NOT NULL,
    [requests_with_hours] BIGINT NOT NULL,
    [average_estimating_hours] DECIMAL(18,6) NULL,
    [total_estimating_hours] DECIMAL(18,6) NULL,
    [source_row_count] BIGINT NOT NULL,
    [calculation_timestamp] DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[salesforce].[fact_estimating_rate_per_sqm_weekly_v1]','U') IS NULL
CREATE TABLE [salesforce].[fact_estimating_rate_per_sqm_weekly_v1]
(
    [closed_year] INT NOT NULL,
    [closed_week] INT NOT NULL,
    [week_key] INT NOT NULL,
    [week_start_date] DATE NOT NULL,
    [week_ending_date] DATE NOT NULL,
    [eligible_quote_lines] BIGINT NOT NULL,
    [total_net_value] DECIMAL(18,6) NULL,
    [total_line_sqm] DECIMAL(18,6) NULL,
    [rate_per_sqm] DECIMAL(18,6) NULL,
    [source_row_count] BIGINT NOT NULL,
    [calculation_timestamp] DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('[salesforce].[kpi_result_estimating_v1]','U') IS NULL
CREATE TABLE [salesforce].[kpi_result_estimating_v1]
(
    [closed_year] INT NULL,
    [closed_week] INT NULL,
    [kpi_name] VARCHAR(255) NULL,
    [kpi_value] DECIMAL(18,6) NULL,
    [organisational_unit] VARCHAR(255) NULL,
    [kpi_id] BIGINT NULL,
    [kpi_category] VARCHAR(100) NULL,
    [target_value] DECIMAL(18,6) NULL,
    [breach_direction] VARCHAR(20) NULL,
    [week_key] INT NULL,
    [kpi_code] VARCHAR(100) NULL,
    [department] VARCHAR(255) NULL,
    [measure] VARCHAR(500) NULL,
    [measure_name] VARCHAR(500) NULL,
    [uom] VARCHAR(50) NULL,
    [sign] VARCHAR(100) NULL,
    [sign_label] VARCHAR(100) NULL,
    [commentary] VARCHAR(1000) NULL,
    [variance_value] DECIMAL(18,6) NULL,
    [performance_variance_value] DECIMAL(18,6) NULL,
    [rag_status] VARCHAR(20) NULL,
    [data_status] VARCHAR(50) NULL,
    [source_system] VARCHAR(100) NULL,
    [source_object] VARCHAR(500) NULL,
    [source_row_count] BIGINT NULL,
    [calculation_timestamp] DATETIME2(6) NULL
);
GO

/* =============================================================
   3. BUILD ATOMIC FACTS V1
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_build_estimating_facts_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [salesforce_staging].[estimating_request])
        THROW 50101, 'ABORTED: estimating_request staging is empty.', 1;
    IF NOT EXISTS (SELECT 1 FROM [salesforce_staging].[sbqq__quote])
        THROW 50102, 'ABORTED: sbqq__quote staging is empty.', 1;
    IF NOT EXISTS (SELECT 1 FROM [salesforce_staging].[sbqq__quote_line])
        THROW 50103, 'ABORTED: sbqq__quote_line staging is empty.', 1;

    TRUNCATE TABLE [salesforce].[fact_estimating_request_v1];
    TRUNCATE TABLE [salesforce].[fact_estimating_quote_v1];
    TRUNCATE TABLE [salesforce].[fact_estimating_quote_line_v1];

    ;WITH request_source AS
    (
        SELECT
            [estimating_request_id] = CAST(r.[id] AS VARCHAR(255)),
            [estimating_request_no] = CAST(COALESCE(NULLIF(r.[estimating_request],''),NULLIF(r.[name],''),r.[id]) AS VARCHAR(255)),
            [project_name] = CAST(COALESCE(NULLIF(r.[project_name],''),NULLIF(r.[project_name2],'')) AS VARCHAR(500)),
            [request_status] = CAST(COALESCE(NULLIF(r.[status_costing],''),NULLIF(r.[status],'')) AS VARCHAR(255)),
            [sales_division] = CAST(r.[sales_division] AS VARCHAR(255)),
            [project_region] = CAST(r.[project_region] AS VARCHAR(255)),
            [currency_code] = CAST(r.[currency_iso_code] AS VARCHAR(20)),
            [created_date] = CAST(COALESCE(r.[date_time_opened],r.[created_date]) AS DATE),
            [due_date] = CAST(COALESCE(r.[requested_return_date],r.[complete_by_date]) AS DATE),
            [closed_date] = CAST(COALESCE(r.[date_closed],r.[costing_completion_date],r.[date_time_closed]) AS DATE),
            [hours_taken_to_close] = CAST(COALESCE(r.[hours_taken_to_close],
                CASE WHEN r.[date_time_into_costing] IS NOT NULL AND r.[date_time_out_costing] IS NOT NULL
                     THEN DATEDIFF(MINUTE,r.[date_time_into_costing],r.[date_time_out_costing])/60.0 END) AS DECIMAL(18,6)),
            [source_row_count] = CAST(1 AS BIGINT),
            [rn] = ROW_NUMBER() OVER
            (PARTITION BY CAST(r.[id] AS VARCHAR(255))
             ORDER BY COALESCE(r.[system_modstamp],r.[last_modified_date],r.[created_date]) DESC)
        FROM [salesforce_staging].[estimating_request] r
        WHERE r.[id] IS NOT NULL AND COALESCE(r.[is_deleted],0)=0
    )
    INSERT INTO [salesforce].[fact_estimating_request_v1]
    SELECT s.[estimating_request_id],s.[estimating_request_no],s.[project_name],s.[request_status],
           s.[sales_division],s.[project_region],s.[currency_code],s.[created_date],s.[due_date],
           s.[closed_date],s.[hours_taken_to_close],d.[date_key],d.[customer_year],d.[customer_week_no],
           d.[week_key],d.[week_start_date],d.[week_end_date],s.[source_row_count],SYSUTCDATETIME()
    FROM request_source s
    LEFT JOIN [reporting].[dim_date] d ON d.[calendar_date]=s.[closed_date]
    WHERE s.[rn]=1;

    ;WITH quote_source AS
    (
        SELECT
            [quote_id]=CAST(q.[id] AS VARCHAR(255)),
            [quote_name]=CAST(q.[name] AS VARCHAR(500)),
            [estimating_request_id]=CAST(COALESCE(NULLIF(q.[estimating_request_id],''),NULLIF(q.[estimating_request],'')) AS VARCHAR(255)),
            [estimating_request_no]=CAST(q.[estimating_request_no] AS VARCHAR(255)),
            [project_name]=CAST(COALESCE(NULLIF(q.[project_name_formula],''),NULLIF(q.[project_name_for_document],'')) AS VARCHAR(500)),
            [quote_status]=CAST(COALESCE(NULLIF(q.[sbqq__status],''),NULLIF(q.[quote_status_for_syteline],'')) AS VARCHAR(255)),
            [is_primary_quote]=CAST(COALESCE(q.[sbqq__primary],TRY_CAST(q.[primary_for_syteline] AS BIT),0) AS BIT),
            [sales_division]=CAST(q.[sales_division] AS VARCHAR(255)),
            [region]=CAST(q.[region] AS VARCHAR(255)),
            [currency_code]=CAST(q.[currency_iso_code] AS VARCHAR(20)),
            [quote_date]=CAST(COALESCE(q.[quote_date],q.[closed_date],q.[closed_date_time]) AS DATE),
            [quote_due_date]=CAST(q.[requested_return_date] AS DATE),
            [closed_date]=CAST(COALESCE(q.[closed_date],q.[closed_date_time]) AS DATE),
            [net_amount]=CAST(COALESCE(q.[sbqq__net_amount],q.[net_amount_converted],q.[original_net_amount]) AS DECIMAL(18,6)),
            [quote_sqm]=CAST(q.[quote_sqm] AS DECIMAL(18,6)),
            [source_sqm_rate]=CAST(q.[sqm_rate] AS DECIMAL(18,6)),
            [source_row_count]=CAST(1 AS BIGINT),
            [rn]=ROW_NUMBER() OVER
              (PARTITION BY CAST(q.[id] AS VARCHAR(255))
               ORDER BY COALESCE(q.[system_modstamp],q.[last_modified_date],q.[created_date]) DESC)
        FROM [salesforce_staging].[sbqq__quote] q
        WHERE q.[id] IS NOT NULL AND COALESCE(q.[is_deleted],0)=0
    )
    INSERT INTO [salesforce].[fact_estimating_quote_v1]
    SELECT q.[quote_id],q.[quote_name],q.[estimating_request_id],
           COALESCE(NULLIF(q.[estimating_request_no],''),r.[estimating_request_no]),
           COALESCE(NULLIF(q.[project_name],''),r.[project_name]),q.[quote_status],q.[is_primary_quote],
           COALESCE(NULLIF(q.[sales_division],''),r.[sales_division]),
           COALESCE(NULLIF(q.[region],''),r.[project_region]),q.[currency_code],q.[quote_date],
           COALESCE(q.[quote_due_date],r.[due_date]),q.[closed_date],q.[net_amount],q.[quote_sqm],q.[source_sqm_rate],
           CAST(CASE WHEN q.[quote_date] IS NOT NULL AND COALESCE(q.[quote_due_date],r.[due_date]) IS NOT NULL
                      AND q.[quote_date] <= COALESCE(q.[quote_due_date],r.[due_date]) THEN 1
                     WHEN q.[quote_date] IS NOT NULL AND COALESCE(q.[quote_due_date],r.[due_date]) IS NOT NULL THEN 0
                     ELSE NULL END AS BIT),
           d.[date_key],d.[customer_year],d.[customer_week_no],d.[week_key],d.[week_start_date],d.[week_end_date],
           q.[source_row_count],SYSUTCDATETIME()
    FROM quote_source q
    LEFT JOIN [salesforce].[fact_estimating_request_v1] r ON r.[estimating_request_id]=q.[estimating_request_id]
    LEFT JOIN [reporting].[dim_date] d ON d.[calendar_date]=q.[quote_date]
    WHERE q.[rn]=1;

    ;WITH line_source AS
    (
        SELECT
            [quote_line_id]=CAST(l.[id] AS VARCHAR(255)),[quote_line_name]=CAST(l.[name] AS VARCHAR(500)),
            [quote_id]=CAST(l.[sbqq__quote] AS VARCHAR(255)),[quantity]=CAST(l.[sbqq__quantity] AS DECIMAL(18,6)),
            [net_total]=CAST(l.[sbqq__net_total] AS DECIMAL(18,6)),[item_sqm]=CAST(l.[item_sqm] AS DECIMAL(18,6)),
            [line_sqm]=CAST(COALESCE(l.[line_sqm],l.[sqm],l.[total_area_m2]) AS DECIMAL(18,6)),
            [source_sqm_rate]=CAST(l.[sqm_rate] AS DECIMAL(18,6)),
            [price_excluded]=CAST(COALESCE(l.[price_excluded],0) AS BIT),[source_row_count]=CAST(1 AS BIGINT),
            [rn]=ROW_NUMBER() OVER
              (PARTITION BY CAST(l.[id] AS VARCHAR(255))
               ORDER BY COALESCE(l.[system_modstamp],l.[last_modified_date],l.[created_date]) DESC)
        FROM [salesforce_staging].[sbqq__quote_line] l
        WHERE l.[id] IS NOT NULL AND COALESCE(l.[is_deleted],0)=0
    )
    INSERT INTO [salesforce].[fact_estimating_quote_line_v1]
    SELECT l.[quote_line_id],l.[quote_line_name],l.[quote_id],q.[estimating_request_id],q.[estimating_request_no],
           q.[quote_date],l.[quantity],l.[net_total],l.[item_sqm],l.[line_sqm],l.[source_sqm_rate],l.[price_excluded],
           CAST(CASE WHEN COALESCE(l.[price_excluded],0)=0 AND l.[line_sqm]>0 AND l.[net_total] IS NOT NULL THEN 1 ELSE 0 END AS BIT),
           q.[date_key],q.[closed_year],q.[closed_week],q.[week_key],q.[week_start_date],q.[week_ending_date],
           l.[source_row_count],SYSUTCDATETIME()
    FROM line_source l
    LEFT JOIN [salesforce].[fact_estimating_quote_v1] q ON q.[quote_id]=l.[quote_id]
    WHERE l.[rn]=1;
END;
GO

/* =============================================================
   4. BUILD WEEKLY FACTS V1
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_build_estimating_weekly_facts_v1]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [salesforce].[fact_estimating_quotes_weekly_v1];
    TRUNCATE TABLE [salesforce].[fact_estimating_hours_weekly_v1];
    TRUNCATE TABLE [salesforce].[fact_estimating_rate_per_sqm_weekly_v1];

    INSERT INTO [salesforce].[fact_estimating_quotes_weekly_v1]
    SELECT [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],COUNT_BIG(*),
           SUM(CASE WHEN [due_date] IS NOT NULL THEN 1 ELSE 0 END),
           SUM(CASE WHEN [issued_on_time_flag]=1 THEN 1 ELSE 0 END),
           CAST(CASE WHEN SUM(CASE WHEN [due_date] IS NOT NULL THEN 1 ELSE 0 END)>0
                THEN 1.0*SUM(CASE WHEN [issued_on_time_flag]=1 THEN 1 ELSE 0 END)
                     /SUM(CASE WHEN [due_date] IS NOT NULL THEN 1 ELSE 0 END) END AS DECIMAL(18,6)),
           SUM([source_row_count]),SYSUTCDATETIME()
    FROM [salesforce].[fact_estimating_quote_v1]
    WHERE [week_key] IS NOT NULL AND [quote_date] IS NOT NULL
    GROUP BY [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date];

    INSERT INTO [salesforce].[fact_estimating_hours_weekly_v1]
    SELECT [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],COUNT_BIG(*),
           COUNT([hours_taken_to_close]),CAST(AVG([hours_taken_to_close]) AS DECIMAL(18,6)),
           CAST(SUM([hours_taken_to_close]) AS DECIMAL(18,6)),SUM([source_row_count]),SYSUTCDATETIME()
    FROM [salesforce].[fact_estimating_request_v1]
    WHERE [week_key] IS NOT NULL AND [closed_date] IS NOT NULL
    GROUP BY [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date];

    INSERT INTO [salesforce].[fact_estimating_rate_per_sqm_weekly_v1]
    SELECT [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],COUNT_BIG(*),
           CAST(SUM([net_total]) AS DECIMAL(18,6)),CAST(SUM([line_sqm]) AS DECIMAL(18,6)),
           CAST(SUM([net_total])/NULLIF(SUM([line_sqm]),0) AS DECIMAL(18,6)),
           SUM([source_row_count]),SYSUTCDATETIME()
    FROM [salesforce].[fact_estimating_quote_line_v1]
    WHERE [week_key] IS NOT NULL AND [is_sqm_kpi_eligible]=1
    GROUP BY [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date];
END;
GO

/* =============================================================
   5. BUILD KPI RESULT V1
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_build_kpi_result_estimating_v1]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [salesforce].[kpi_result_estimating_v1];

    ;WITH actuals AS
    (
        SELECT q.[closed_year],q.[closed_week],q.[week_key],q.[week_ending_date],
               'EST-KPI-P1' [kpi_code],CAST(q.[quotes_issued] AS DECIMAL(18,6)) [kpi_value],
               CONCAT('Quotes=',q.[quotes_issued]) [commentary],q.[source_row_count],
               'salesforce.fact_estimating_quotes_weekly_v1' [source_object]
        FROM [salesforce].[fact_estimating_quotes_weekly_v1] q
        UNION ALL
        SELECT q.[closed_year],q.[closed_week],q.[week_key],q.[week_ending_date],
               'EST-KPI-D1',q.[quotes_issued_on_time_percentage],
               CONCAT('Due-dated=',q.[due_dated_quotes],'; on time=',q.[quotes_issued_on_time]),q.[source_row_count],
               'salesforce.fact_estimating_quotes_weekly_v1'
        FROM [salesforce].[fact_estimating_quotes_weekly_v1] q
        UNION ALL
        SELECT h.[closed_year],h.[closed_week],h.[week_key],h.[week_ending_date],
               'EST-KPI-Q1',h.[average_estimating_hours],
               CONCAT('Closed=',h.[closed_requests],'; with hours=',h.[requests_with_hours]),h.[source_row_count],
               'salesforce.fact_estimating_hours_weekly_v1'
        FROM [salesforce].[fact_estimating_hours_weekly_v1] h
        UNION ALL
        SELECT r.[closed_year],r.[closed_week],r.[week_key],r.[week_ending_date],
               'EST-KPI-C1',r.[rate_per_sqm],
               CONCAT('Eligible lines=',r.[eligible_quote_lines],'; sqm=',COALESCE(CAST(r.[total_line_sqm] AS VARCHAR(50)),'NULL')),
               r.[source_row_count],'salesforce.fact_estimating_rate_per_sqm_weekly_v1'
        FROM [salesforce].[fact_estimating_rate_per_sqm_weekly_v1] r
    ), enriched AS
    (
        SELECT a.*,c.[kpi_name],c.[kpi_category],c.[target_value],c.[breach_direction],c.[uom],
               COALESCE(c.[rag_tolerance_pct],0.05) [tolerance]
        FROM actuals a
        LEFT JOIN [reporting].[kpi_control] c
          ON c.[kpi_code]=a.[kpi_code]
         AND a.[week_ending_date]>=c.[effective_from]
         AND (c.[effective_to] IS NULL OR a.[week_ending_date]<=c.[effective_to])
         AND c.[target_status] IN ('Approved','Working')
    )
    INSERT INTO [salesforce].[kpi_result_estimating_v1]
    SELECT e.[closed_year],e.[closed_week],e.[kpi_name],e.[kpi_value],'Estimating',NULL,e.[kpi_category],
           e.[target_value],e.[breach_direction],e.[week_key],e.[kpi_code],'Estimating',
           CASE e.[kpi_code]
             WHEN 'EST-KPI-P1' THEN 'Count of Salesforce CPQ quotes issued by quote date'
             WHEN 'EST-KPI-D1' THEN 'Quote date on or before due date'
             WHEN 'EST-KPI-Q1' THEN 'Average hours to close estimating requests'
             WHEN 'EST-KPI-C1' THEN 'Eligible quote-line value divided by square metres' END,
           e.[kpi_name],e.[uom],
           CASE WHEN e.[breach_direction]='UNDER' THEN 'Under Breach' WHEN e.[breach_direction]='OVER' THEN 'Over Breach' END,
           CASE WHEN e.[breach_direction]='UNDER' THEN 'Under Breach' WHEN e.[breach_direction]='OVER' THEN 'Over Breach' END,
           e.[commentary],
           CASE WHEN e.[target_value] IS NULL OR e.[kpi_value] IS NULL THEN NULL ELSE e.[kpi_value]-e.[target_value] END,
           CASE WHEN e.[target_value] IS NULL OR e.[kpi_value] IS NULL THEN NULL
                WHEN e.[breach_direction]='UNDER' THEN e.[kpi_value]-e.[target_value]
                WHEN e.[breach_direction]='OVER' THEN e.[target_value]-e.[kpi_value] END,
           CASE WHEN e.[kpi_value] IS NULL THEN 'No Data' WHEN e.[target_value] IS NULL THEN 'TBC'
                WHEN e.[breach_direction]='UNDER' AND e.[kpi_value]>=e.[target_value] THEN 'G'
                WHEN e.[breach_direction]='UNDER' AND e.[kpi_value]>=e.[target_value]*(1-e.[tolerance]) THEN 'A'
                WHEN e.[breach_direction]='OVER' AND e.[kpi_value]<=e.[target_value] THEN 'G'
                WHEN e.[breach_direction]='OVER' AND e.[kpi_value]<=e.[target_value]*(1+e.[tolerance]) THEN 'A'
                ELSE 'R' END,
           CASE WHEN e.[kpi_value] IS NULL THEN 'No Data' WHEN e.[target_value] IS NULL THEN 'Target TBC' ELSE 'Actual' END,
           'Salesforce',e.[source_object],e.[source_row_count],SYSUTCDATETIME()
    FROM enriched e;
END;
GO

/* =============================================================
   6. PUBLISH TO SALESFORCE DOMAIN RESULT
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_publish_estimating_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [salesforce].[fact_kpi_result]
    WHERE [kpi_code] IN ('EST-KPI-P1','EST-KPI-D1','EST-KPI-Q1','EST-KPI-C1');

    INSERT INTO [salesforce].[fact_kpi_result]
    (
        [closed_year],[closed_week],[kpi_name],[kpi_value],[organisational_unit],[kpi_id],
        [kpi_category],[target_value],[breach_direction],[week_key],[kpi_code],[department],
        [measure],[measure_name],[uom],[sign],[sign_label],[commentary],[variance_value],
        [performance_variance_value],[rag_status],[data_status],[source_system],[source_object],
        [source_row_count],[calculation_timestamp]
    )
    SELECT [closed_year],[closed_week],[kpi_name],[kpi_value],[organisational_unit],[kpi_id],
           [kpi_category],[target_value],[breach_direction],[week_key],[kpi_code],[department],
           [measure],[measure_name],[uom],[sign],[sign_label],[commentary],[variance_value],
           [performance_variance_value],[rag_status],[data_status],[source_system],[source_object],
           [source_row_count],[calculation_timestamp]
    FROM [salesforce].[kpi_result_estimating_v1];
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_estimating_all_v1]
AS
BEGIN
    EXEC [salesforce].[usp_build_estimating_facts_v1];
    EXEC [salesforce].[usp_build_estimating_weekly_facts_v1];
    EXEC [salesforce].[usp_build_kpi_result_estimating_v1];
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_and_publish_estimating_all_v1]
AS
BEGIN
    EXEC [salesforce].[usp_build_estimating_all_v1];
    EXEC [salesforce].[usp_publish_estimating_kpis_v1];
END;
GO

/* =============================================================
   VALIDATION
   =============================================================
-- Build only
EXEC [salesforce].[usp_build_estimating_all_v1];

-- Confirm atomic and weekly coverage
SELECT 'request' [fact],COUNT_BIG(*) [rows],COUNT(DISTINCT [week_key]) [weeks],MIN([week_key]) [first_week],MAX([week_key]) [last_week]
FROM [salesforce].[fact_estimating_request_v1]
UNION ALL
SELECT 'quote',COUNT_BIG(*),COUNT(DISTINCT [week_key]),MIN([week_key]),MAX([week_key])
FROM [salesforce].[fact_estimating_quote_v1]
UNION ALL
SELECT 'quote_line',COUNT_BIG(*),COUNT(DISTINCT [week_key]),MIN([week_key]),MAX([week_key])
FROM [salesforce].[fact_estimating_quote_line_v1];

-- KPI coverage before publish
SELECT [kpi_code],COUNT_BIG(*) [rows],COUNT(DISTINCT [week_key]) [weeks],MIN([week_key]) [first_week],MAX([week_key]) [last_week],
       COUNT([target_value]) [target_rows],COUNT([variance_value]) [variance_rows]
FROM [salesforce].[kpi_result_estimating_v1]
GROUP BY [kpi_code]
ORDER BY [kpi_code];

-- Publish
EXEC [salesforce].[usp_publish_estimating_kpis_v1];

-- Final Salesforce domain result
SELECT * FROM [salesforce].[fact_kpi_result]
WHERE [kpi_code] IN ('EST-KPI-P1','EST-KPI-D1','EST-KPI-Q1','EST-KPI-C1')
ORDER BY [week_key],[kpi_code];

-- Duplicates: expect zero rows
SELECT [week_key],[kpi_code],COUNT_BIG(*) [row_count]
FROM [salesforce].[fact_kpi_result]
WHERE [kpi_code] IN ('EST-KPI-P1','EST-KPI-D1','EST-KPI-Q1','EST-KPI-C1')
GROUP BY [week_key],[kpi_code]
HAVING COUNT_BIG(*)>1;
*/
