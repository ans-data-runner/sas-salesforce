/*
SAS SharePoint - Manufacturing Maybole EHS Reportable Incidents KPI - V1
=======================================================================
Dashboard KPI:
  Manufacturing Maybole / Quality
  KPI: EHS - 1st Aid, LTI, RIDDOR
  Measure: Count of Reportable incidents
  UOM: Count
  Target: 0
  Sign: OVER breach

Physical source:
  [sharepoint_staging].[incident_register]

Confirmed source columns used:
  date, site, location, accident_level, injury_type, riddor_date,
  investigation_number, status

Shared controls:
  [reporting].[dim_date]
  [reporting].[kpi_control]

Domain output:
  [sharepoint].[fact_kpi_result]

IMPORTANT CLASSIFICATION NOTE
-----------------------------
The physical source exposes the fields required to classify the KPI, but the exact
source values for Maybole / First Aid / LTI / RIDDOR must be validated from the data.
This V1 deliberately isolates that predicate in one source CTE. The validation query
at the bottom shows the distinct source values before UAT.
*/

/* ================================================================
   0. Ensure SharePoint domain result table exists
   ================================================================ */
IF OBJECT_ID('[sharepoint].[fact_kpi_result]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_kpi_result]
    (
        [closed_year] INT NULL,
        [closed_week] INT NULL,
        [week_key] INT NULL,
        [kpi_id] BIGINT NULL,
        [kpi_code] VARCHAR(1000) NULL,
        [kpi_name] VARCHAR(1000) NULL,
        [kpi_category] VARCHAR(1000) NULL,
        [organisational_unit] VARCHAR(1000) NULL,
        [department] VARCHAR(1000) NULL,
        [measure] VARCHAR(1000) NULL,
        [measure_name] VARCHAR(1000) NULL,
        [uom] VARCHAR(1000) NULL,
        [sign] VARCHAR(1000) NULL,
        [sign_label] VARCHAR(1000) NULL,
        [commentary] VARCHAR(1000) NULL,
        [breach_direction] VARCHAR(1000) NULL,
        [kpi_value] DECIMAL(18,4) NULL,
        [target_value] DECIMAL(18,4) NULL,
        [variance_value] DECIMAL(18,4) NULL,
        [performance_variance_value] DECIMAL(18,4) NULL,
        [rag_status] VARCHAR(1000) NULL,
        [data_status] VARCHAR(1000) NULL,
        [source_system] VARCHAR(1000) NULL,
        [source_object] VARCHAR(1000) NULL,
        [source_row_count] BIGINT NULL,
        [calculation_timestamp] DATETIME2(6) NULL
    );
END;
GO

/* ================================================================
   1. Control-table target
   ================================================================ */
DELETE FROM [reporting].[kpi_control]
WHERE [kpi_code] = 'Maybole Manuf-KPI Q2';

INSERT INTO [reporting].[kpi_control]
(
    [kpi_code], [kpi_name], [department], [kpi_category], [target_value],
    [uom], [breach_direction], [rag_tolerance_pct], [effective_from],
    [effective_to], [target_status], [target_source], [commentary],
    [created_timestamp], [updated_timestamp]
)
VALUES
(
    'Maybole Manuf-KPI Q2',
    'EHS - 1st Aid, LTI, RIDDOR',
    'Manufacturing Maybole',
    'Quality',
    CAST(0 AS DECIMAL(18,6)),
    'Count',
    'OVER',
    CAST(0.05 AS DECIMAL(18,6)),
    CAST('2026-01-01' AS DATE),
    NULL,
    'Approved',
    'Manufacturing Maybole KPI workbook',
    'Count of reportable incidents. Target zero; lower is better.',
    SYSUTCDATETIME(),
    SYSUTCDATETIME()
);
GO

/* ================================================================
   2. Atomic fact
   ================================================================ */
IF OBJECT_ID('[sharepoint].[fact_manufacturing_maybole_ehs_incident_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_manufacturing_maybole_ehs_incident_v1]
    (
        [incident_key] VARCHAR(500) NOT NULL,
        [incident_date] DATE NOT NULL,
        [site] VARCHAR(500) NULL,
        [location] VARCHAR(500) NULL,
        [accident_level] VARCHAR(500) NULL,
        [injury_type] VARCHAR(500) NULL,
        [riddor_date] DATE NULL,
        [investigation_number] VARCHAR(500) NULL,
        [status] VARCHAR(500) NULL,
        [incident_classification] VARCHAR(100) NULL,
        [date_key] INT NULL,
        [closed_year] INT NULL,
        [closed_week] INT NULL,
        [week_key] INT NULL,
        [week_start_date] DATE NULL,
        [week_ending_date] DATE NULL,
        [source_row_count] BIGINT NOT NULL,
        [created_timestamp] DATETIME2(6) NOT NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_manufacturing_maybole_ehs_incident_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [sharepoint_staging].[incident_register])
        THROW 50001, 'ABORTED: sharepoint_staging.incident_register is empty. Existing Maybole incident fact preserved.', 1;

    TRUNCATE TABLE [sharepoint].[fact_manufacturing_maybole_ehs_incident_v1];

    ;WITH src AS
    (
        SELECT
            [incident_date] = COALESCE
            (
                TRY_CONVERT(DATE, [date], 103),
                TRY_CONVERT(DATE, [date])
            ),
            [site] = LTRIM(RTRIM(CAST([site] AS VARCHAR(500)))),
            [location] = LTRIM(RTRIM(CAST([location] AS VARCHAR(500)))),
            [accident_level] = LTRIM(RTRIM(CAST([accident_level] AS VARCHAR(500)))),
            [injury_type] = LTRIM(RTRIM(CAST([injury_type] AS VARCHAR(500)))),
            [riddor_date] = COALESCE
            (
                TRY_CONVERT(DATE, [riddor_date], 103),
                TRY_CONVERT(DATE, [riddor_date])
            ),
            [investigation_number] = LTRIM(RTRIM(CAST([investigation_number] AS VARCHAR(500)))),
            [status] = LTRIM(RTRIM(CAST([status] AS VARCHAR(500))))
        FROM [sharepoint_staging].[incident_register]
    ),
    classified AS
    (
        SELECT
            *,
            [incident_classification] = CASE
                WHEN [riddor_date] IS NOT NULL THEN 'RIDDOR'
                WHEN UPPER(COALESCE([accident_level],'')) LIKE '%RIDDOR%'
                  OR UPPER(COALESCE([injury_type],'')) LIKE '%RIDDOR%' THEN 'RIDDOR'
                WHEN UPPER(COALESCE([accident_level],'')) LIKE '%LTI%'
                  OR UPPER(COALESCE([accident_level],'')) LIKE '%LOST TIME%'
                  OR UPPER(COALESCE([injury_type],'')) LIKE '%LTI%'
                  OR UPPER(COALESCE([injury_type],'')) LIKE '%LOST TIME%' THEN 'LTI'
                WHEN UPPER(COALESCE([accident_level],'')) LIKE '%FIRST AID%'
                  OR UPPER(COALESCE([accident_level],'')) LIKE '%1ST AID%'
                  OR UPPER(COALESCE([injury_type],'')) LIKE '%FIRST AID%'
                  OR UPPER(COALESCE([injury_type],'')) LIKE '%1ST AID%' THEN 'FIRST AID'
                ELSE NULL
            END
        FROM src
        WHERE [incident_date] IS NOT NULL
          AND
          (
               UPPER(COALESCE([site],'')) LIKE '%MAYBOLE%'
            OR UPPER(COALESCE([site],'')) = 'MB'
            OR UPPER(COALESCE([location],'')) LIKE '%MAYBOLE%'
          )
    ),
    qualifying AS
    (
        SELECT *,
            [incident_key] = CAST
            (
                COALESCE
                (
                    NULLIF([investigation_number],''),
                    CONCAT
                    (
                        CONVERT(VARCHAR(10),[incident_date],23),'|',
                        COALESCE([site],''),'|',COALESCE([location],''),'|',
                        COALESCE([accident_level],''),'|',COALESCE([injury_type],'')
                    )
                )
                AS VARCHAR(500)
            )
        FROM classified
        WHERE [incident_classification] IS NOT NULL
    )
    INSERT INTO [sharepoint].[fact_manufacturing_maybole_ehs_incident_v1]
    (
        [incident_key], [incident_date], [site], [location], [accident_level], [injury_type],
        [riddor_date], [investigation_number], [status], [incident_classification],
        [date_key], [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date],
        [source_row_count], [created_timestamp]
    )
    SELECT
        q.[incident_key], q.[incident_date], q.[site], q.[location], q.[accident_level], q.[injury_type],
        q.[riddor_date], q.[investigation_number], q.[status], q.[incident_classification],
        d.[date_key], d.[customer_year], d.[customer_week_no], d.[week_key],
        CAST(d.[week_start_date] AS DATE), CAST(d.[week_end_date] AS DATE),
        CAST(1 AS BIGINT), SYSUTCDATETIME()
    FROM qualifying q
    LEFT JOIN [reporting].[dim_date] d
        ON d.[calendar_date] = q.[incident_date];
END;
GO

/* ================================================================
   3. Weekly fact
   ================================================================ */
IF OBJECT_ID('[sharepoint].[fact_manufacturing_maybole_ehs_incident_weekly_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_manufacturing_maybole_ehs_incident_weekly_v1]
    (
        [closed_year] INT NOT NULL,
        [closed_week] INT NOT NULL,
        [week_key] INT NOT NULL,
        [week_start_date] DATE NOT NULL,
        [week_ending_date] DATE NOT NULL,
        [reportable_incidents] BIGINT NOT NULL,
        [first_aid_incidents] BIGINT NOT NULL,
        [lti_incidents] BIGINT NOT NULL,
        [riddor_incidents] BIGINT NOT NULL,
        [source_row_count] BIGINT NOT NULL,
        [calculation_timestamp] DATETIME2(6) NOT NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_manufacturing_maybole_ehs_incident_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [sharepoint].[fact_manufacturing_maybole_ehs_incident_weekly_v1];

    INSERT INTO [sharepoint].[fact_manufacturing_maybole_ehs_incident_weekly_v1]
    (
        [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date],
        [reportable_incidents], [first_aid_incidents], [lti_incidents], [riddor_incidents],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date],
        COUNT(DISTINCT [incident_key]),
        COUNT(DISTINCT CASE WHEN [incident_classification] = 'FIRST AID' THEN [incident_key] END),
        COUNT(DISTINCT CASE WHEN [incident_classification] = 'LTI' THEN [incident_key] END),
        COUNT(DISTINCT CASE WHEN [incident_classification] = 'RIDDOR' THEN [incident_key] END),
        COUNT_BIG(*), SYSUTCDATETIME()
    FROM [sharepoint].[fact_manufacturing_maybole_ehs_incident_v1]
    WHERE [week_key] IS NOT NULL
    GROUP BY [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date];
END;
GO

/* ================================================================
   4. KPI result
   ================================================================ */
IF OBJECT_ID('[sharepoint].[kpi_result_manufacturing_maybole_ehs_v1]', 'U') IS NULL
BEGIN
    SELECT TOP 0 *
    INTO [sharepoint].[kpi_result_manufacturing_maybole_ehs_v1]
    FROM [sharepoint].[fact_kpi_result];
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_kpi_result_manufacturing_maybole_ehs_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [sharepoint].[kpi_result_manufacturing_maybole_ehs_v1];

    ;WITH actuals AS
    (
        SELECT
            w.[closed_year], w.[closed_week], w.[week_key], w.[week_ending_date],
            CAST(w.[reportable_incidents] AS DECIMAL(18,4)) AS [kpi_value],
            w.[first_aid_incidents], w.[lti_incidents], w.[riddor_incidents],
            w.[source_row_count]
        FROM [sharepoint].[fact_manufacturing_maybole_ehs_incident_weekly_v1] w
    ), enriched AS
    (
        SELECT
            a.*,
            c.[target_value],
            COALESCE(c.[breach_direction], 'OVER') AS [breach_direction],
            COALESCE(c.[rag_tolerance_pct], 0.05) AS [rag_tolerance_pct]
        FROM actuals a
        LEFT JOIN [reporting].[kpi_control] c
          ON c.[kpi_code] = 'Maybole Manuf-KPI Q2'
         AND a.[week_ending_date] >= c.[effective_from]
         AND (c.[effective_to] IS NULL OR a.[week_ending_date] <= c.[effective_to])
    )
    INSERT INTO [sharepoint].[kpi_result_manufacturing_maybole_ehs_v1]
    (
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    )
    SELECT
        e.[closed_year], e.[closed_week], e.[week_key], NULL,
        'Maybole Manuf-KPI Q2',
        'EHS - 1st Aid, LTI, RIDDOR',
        'Quality',
        'Manufacturing Maybole',
        'Manufacturing Maybole',
        'Count of Reportable incidents',
        'EHS - 1st Aid, LTI, RIDDOR',
        'Count',
        'Over Breach',
        'Over Breach',
        CONCAT('First Aid=',e.[first_aid_incidents],'; LTI=',e.[lti_incidents],'; RIDDOR=',e.[riddor_incidents]),
        e.[breach_direction],
        e.[kpi_value],
        e.[target_value],
        CASE WHEN e.[target_value] IS NULL THEN NULL ELSE e.[kpi_value] - e.[target_value] END,
        CASE WHEN e.[target_value] IS NULL THEN NULL ELSE e.[target_value] - e.[kpi_value] END,
        CASE
            WHEN e.[target_value] IS NULL THEN 'TBC'
            WHEN e.[target_value] = 0 AND e.[kpi_value] = 0 THEN 'G'
            WHEN e.[target_value] = 0 AND e.[kpi_value] > 0 THEN 'R'
            WHEN e.[kpi_value] <= e.[target_value] THEN 'G'
            WHEN e.[kpi_value] <= e.[target_value] * (1 + e.[rag_tolerance_pct]) THEN 'A'
            ELSE 'R'
        END,
        'Working classification - review source values before UAT',
        'SharePoint',
        'sharepoint_staging.incident_register',
        e.[source_row_count],
        SYSUTCDATETIME()
    FROM enriched e;
END;
GO

/* ================================================================
   5. Publisher and runners
   ================================================================ */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_publish_manufacturing_maybole_ehs_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [sharepoint].[fact_kpi_result]
    WHERE [kpi_code] = 'Maybole Manuf-KPI Q2';

    INSERT INTO [sharepoint].[fact_kpi_result]
    (
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    FROM [sharepoint].[kpi_result_manufacturing_maybole_ehs_v1];
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_manufacturing_maybole_ehs_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [sharepoint].[usp_build_fact_manufacturing_maybole_ehs_incident_v1];
    EXEC [sharepoint].[usp_build_fact_manufacturing_maybole_ehs_incident_weekly_v1];
    EXEC [sharepoint].[usp_build_kpi_result_manufacturing_maybole_ehs_v1];
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_and_publish_manufacturing_maybole_ehs_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [sharepoint].[usp_build_manufacturing_maybole_ehs_v1];
    EXEC [sharepoint].[usp_publish_manufacturing_maybole_ehs_v1];
END;
GO

/* ================================================================
   6. Validation before UAT
   ================================================================ */

-- CRITICAL: review the physical source values and tighten the classification predicate if needed.
SELECT
    [site], [location], [accident_level], [injury_type],
    COUNT_BIG(*) AS [rows]
FROM [sharepoint_staging].[incident_register]
GROUP BY [site], [location], [accident_level], [injury_type]
ORDER BY [rows] DESC;

SELECT
    COUNT_BIG(*) AS [riddor_dated_rows]
FROM [sharepoint_staging].[incident_register]
WHERE NULLIF(LTRIM(RTRIM(COALESCE([riddor_date], ''))), '') IS NOT NULL;

-- Build only
-- EXEC [sharepoint].[usp_build_manufacturing_maybole_ehs_v1];

-- Historical weeks generated
SELECT
    COUNT_BIG(*) AS [weekly_rows],
    COUNT(DISTINCT [week_key]) AS [weeks],
    MIN([week_key]) AS [first_week],
    MAX([week_key]) AS [last_week],
    SUM([reportable_incidents]) AS [total_reportable_incidents]
FROM [sharepoint].[fact_manufacturing_maybole_ehs_incident_weekly_v1];

SELECT *
FROM [sharepoint].[kpi_result_manufacturing_maybole_ehs_v1]
ORDER BY [week_key];

-- Publish after review
-- EXEC [sharepoint].[usp_publish_manufacturing_maybole_ehs_v1];

SELECT *
FROM [sharepoint].[fact_kpi_result]
WHERE [kpi_code] = 'Maybole Manuf-KPI Q2'
ORDER BY [week_key];
