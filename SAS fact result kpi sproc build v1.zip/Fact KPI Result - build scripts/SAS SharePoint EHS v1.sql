/*
SAS SharePoint EHS KPI Pack v1
Purpose: Build the three SharePoint-backed EHS KPIs and publish them to
         [sharepoint].[fact_kpi_result].

KPIs
  EHS-KPI-P1  Lost Working Days                              Target 0.00   OVER
  EHS-KPI-C1  Gas/electricity emissions / quantities produced Target 1.00 OVER
  EHS-KPI-C2  Gas/electricity emissions / m2 produced          Target 2.75 OVER

Sources
  [sharepoint_staging].[incident_register]
  [sharepoint_staging].[tp_be]
  [sharepoint_staging].[tp_mb]

Shared controls
  [reporting].[dim_date]
  [reporting].[kpi_control]

NOTE: TP BE/MB are from the 2026 workbook, so week_no is explicitly mapped
      to customer_year = 2026.
*/

/* -------------------------------------------------------------------------
   0. Domain result table, same 26-column contract used by the other domains
   ------------------------------------------------------------------------- */
IF OBJECT_ID('[sharepoint].[fact_kpi_result]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_kpi_result]
    (
        [closed_year] INT NULL,
        [closed_week] INT NULL,
        [kpi_name] VARCHAR(255) NULL,
        [kpi_value] DECIMAL(18,6) NULL,
        [organisational_unit] VARCHAR(255) NULL,
        [kpi_id] VARCHAR(100) NULL,
        [kpi_category] VARCHAR(100) NULL,
        [target_value] DECIMAL(18,6) NULL,
        [breach_direction] VARCHAR(20) NULL,
        [week_key] INT NULL,
        [kpi_code] VARCHAR(100) NULL,
        [department] VARCHAR(255) NULL,
        [measure] VARCHAR(255) NULL,
        [measure_name] VARCHAR(255) NULL,
        [uom] VARCHAR(50) NULL,
        [sign] VARCHAR(50) NULL,
        [sign_label] VARCHAR(100) NULL,
        [commentary] VARCHAR(1000) NULL,
        [variance_value] DECIMAL(18,6) NULL,
        [performance_variance_value] DECIMAL(18,6) NULL,
        [rag_status] VARCHAR(50) NULL,
        [data_status] VARCHAR(100) NULL,
        [source_system] VARCHAR(100) NULL,
        [source_object] VARCHAR(255) NULL,
        [source_row_count] BIGINT NULL,
        [calculation_timestamp] DATETIME2(6) NULL
    );
END;
GO

/* -------------------------------------------------------------------------
   1. Target-control rows
   ------------------------------------------------------------------------- */
DELETE FROM [reporting].[kpi_control]
WHERE [kpi_code] IN ('EHS-KPI-P1','EHS-KPI-C1','EHS-KPI-C2');

INSERT INTO [reporting].[kpi_control]
(
    [kpi_code], [kpi_name], [department], [kpi_category], [target_value],
    [uom], [breach_direction], [rag_tolerance_pct], [effective_from],
    [effective_to], [target_status], [target_source], [commentary],
    [created_timestamp], [updated_timestamp]
)
VALUES
('EHS-KPI-P1','Lost Working Days','Environment, Health and Safety','Productivity',0.000000,'Days','OVER',0.050000,'2026-01-01',NULL,'APPROVED','SAS EHS KPI workbook','Lower is better.',SYSUTCDATETIME(),SYSUTCDATETIME()),
('EHS-KPI-C1','Ratio of gas and electricity emissions to quantities produced','Environment, Health and Safety','Cost',1.000000,'Ratio','OVER',0.050000,'2026-01-01',NULL,'APPROVED','SAS EHS KPI workbook','Lower is better.',SYSUTCDATETIME(),SYSUTCDATETIME()),
('EHS-KPI-C2','Ratio of gas and electricity emissions to m2 produced','Environment, Health and Safety','Cost',2.750000,'Ratio','OVER',0.050000,'2026-01-01',NULL,'APPROVED','SAS EHS KPI workbook','Lower is better.',SYSUTCDATETIME(),SYSUTCDATETIME());
GO

/* -------------------------------------------------------------------------
   2. Curated SharePoint facts
   ------------------------------------------------------------------------- */
IF OBJECT_ID('[sharepoint].[fact_ehs_lost_working_days_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_ehs_lost_working_days_v1]
    (
        [reporting_date] DATE NOT NULL,
        [closed_year] INT NULL,
        [closed_week] INT NULL,
        [week_key] INT NULL,
        [week_start_date] DATE NULL,
        [week_end_date] DATE NULL,
        [lost_working_days] DECIMAL(18,6) NULL,
        [source_row_count] BIGINT NOT NULL,
        [calculation_timestamp] DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[sharepoint].[fact_ehs_energy_weekly_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_ehs_energy_weekly_v1]
    (
        [closed_year] INT NULL,
        [closed_week] INT NULL,
        [week_key] INT NULL,
        [week_start_date] DATE NULL,
        [week_end_date] DATE NULL,
        [emissions_to_quantity_ratio] DECIMAL(18,6) NULL,
        [emissions_to_m2_ratio] DECIMAL(18,6) NULL,
        [source_row_count] BIGINT NOT NULL,
        [calculation_timestamp] DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[sharepoint].[kpi_result_ehs_v1]', 'U') IS NULL
BEGIN
    SELECT TOP (0) * INTO [sharepoint].[kpi_result_ehs_v1]
    FROM [sharepoint].[fact_kpi_result];
END;
GO

/* -------------------------------------------------------------------------
   3. Lost Working Days
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_ehs_lost_working_days_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [sharepoint_staging].[incident_register])
        THROW 50001, 'sharepoint_staging.incident_register is empty. Refresh aborted.', 1;

    TRUNCATE TABLE [sharepoint].[fact_ehs_lost_working_days_v1];

    INSERT INTO [sharepoint].[fact_ehs_lost_working_days_v1]
    (
        [reporting_date], [closed_year], [closed_week], [week_key],
        [week_start_date], [week_end_date], [lost_working_days],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        CAST(i.[date] AS DATE),
        d.[customer_year], d.[customer_week_no], d.[week_key],
        CAST(d.[week_start_date] AS DATE), CAST(d.[week_end_date] AS DATE),
        SUM(COALESCE(TRY_CAST(i.[lost_days] AS DECIMAL(18,6)),0)),
        COUNT_BIG(*), SYSUTCDATETIME()
    FROM [sharepoint_staging].[incident_register] i
    INNER JOIN [reporting].[dim_date] d
        ON d.[calendar_date] = CAST(i.[date] AS DATE)
    WHERE i.[date] IS NOT NULL
    GROUP BY CAST(i.[date] AS DATE), d.[customer_year], d.[customer_week_no],
             d.[week_key], d.[week_start_date], d.[week_end_date];
END;
GO

/* -------------------------------------------------------------------------
   4. Energy ratios
   The staged TP tabs already expose workbook-calculated intensity_total.
   C1 is calculated as the production-quantity-weighted BE/MB intensity.
   C2 uses the available m2/intensity measures from BE/MB; the source contract
   should be reconciled to the workbook before UAT if column semantics differ.
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_ehs_energy_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [sharepoint_staging].[tp_be])
        THROW 50002, 'sharepoint_staging.tp_be is empty. Refresh aborted.', 1;
    IF NOT EXISTS (SELECT 1 FROM [sharepoint_staging].[tp_mb])
        THROW 50003, 'sharepoint_staging.tp_mb is empty. Refresh aborted.', 1;

    TRUNCATE TABLE [sharepoint].[fact_ehs_energy_weekly_v1];

    ;WITH be AS
    (
        SELECT
            [week_no],
            TRY_CAST([intensity_total] AS DECIMAL(18,6)) AS [intensity_total],
            TRY_CAST([tp_actual_bridgend] AS DECIMAL(18,6)) AS [production_qty],
            TRY_CAST([m3] AS DECIMAL(18,6)) AS [production_m2]
        FROM [sharepoint_staging].[tp_be]
    ),
    mb AS
    (
        SELECT
            [week_no],
            TRY_CAST([intensity_total] AS DECIMAL(18,6)) AS [intensity_total],
            TRY_CAST([tp_actual_maybole] AS DECIMAL(18,6)) AS [production_qty],
            TRY_CAST([m3] AS DECIMAL(18,6)) AS [production_m2]
        FROM [sharepoint_staging].[tp_mb]
    ),
    weeks AS
    (
        SELECT [week_no] FROM be
        UNION
        SELECT [week_no] FROM mb
    ),
    combined AS
    (
        SELECT
            w.[week_no],
            b.[intensity_total] AS [be_intensity],
            m.[intensity_total] AS [mb_intensity],
            b.[production_qty] AS [be_qty],
            m.[production_qty] AS [mb_qty],
            b.[production_m2] AS [be_m2],
            m.[production_m2] AS [mb_m2]
        FROM weeks w
        LEFT JOIN be b ON b.[week_no] = w.[week_no]
        LEFT JOIN mb m ON m.[week_no] = w.[week_no]
    ),
    week_dim AS
    (
        SELECT
            [customer_week_no], MAX([customer_year]) AS [customer_year],
            MAX([week_key]) AS [week_key], MIN([week_start_date]) AS [week_start_date],
            MAX([week_end_date]) AS [week_end_date]
        FROM [reporting].[dim_date]
        WHERE [customer_year] = 2026
        GROUP BY [customer_week_no]
    )
    INSERT INTO [sharepoint].[fact_ehs_energy_weekly_v1]
    (
        [closed_year],[closed_week],[week_key],[week_start_date],[week_end_date],
        [emissions_to_quantity_ratio],[emissions_to_m2_ratio],[source_row_count],
        [calculation_timestamp]
    )
    SELECT
        wd.[customer_year], c.[week_no], wd.[week_key],
        CAST(wd.[week_start_date] AS DATE), CAST(wd.[week_end_date] AS DATE),
        CAST(CASE
            WHEN COALESCE(c.[be_qty],0)+COALESCE(c.[mb_qty],0) = 0 THEN NULL
            ELSE (COALESCE(c.[be_intensity],0)*COALESCE(c.[be_qty],0)
                + COALESCE(c.[mb_intensity],0)*COALESCE(c.[mb_qty],0))
                 / NULLIF(COALESCE(c.[be_qty],0)+COALESCE(c.[mb_qty],0),0)
        END AS DECIMAL(18,6)),
        CAST(CASE
            WHEN COALESCE(c.[be_m2],0)+COALESCE(c.[mb_m2],0) = 0 THEN NULL
            ELSE (COALESCE(c.[be_intensity],0)*COALESCE(c.[be_m2],0)
                + COALESCE(c.[mb_intensity],0)*COALESCE(c.[mb_m2],0))
                 / NULLIF(COALESCE(c.[be_m2],0)+COALESCE(c.[mb_m2],0),0)
        END AS DECIMAL(18,6)),
        CAST((CASE WHEN c.[be_intensity] IS NULL THEN 0 ELSE 1 END)
           + (CASE WHEN c.[mb_intensity] IS NULL THEN 0 ELSE 1 END) AS BIGINT),
        SYSUTCDATETIME()
    FROM combined c
    INNER JOIN week_dim wd ON wd.[customer_week_no] = c.[week_no];
END;
GO

/* -------------------------------------------------------------------------
   5. Build 26-column KPI results
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_kpi_result_ehs_v1]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [sharepoint].[kpi_result_ehs_v1];

    ;WITH actuals AS
    (
        SELECT [closed_year],[closed_week],[week_key],[week_end_date],
               'EHS-KPI-P1' AS [kpi_code],
               'Lost Working Days' AS [kpi_name],
               'Productivity' AS [kpi_category],
               CAST(SUM([lost_working_days]) AS DECIMAL(18,6)) AS [kpi_value],
               'Days' AS [uom], 'sharepoint_staging.incident_register' AS [source_object],
               SUM([source_row_count]) AS [source_row_count]
        FROM [sharepoint].[fact_ehs_lost_working_days_v1]
        GROUP BY [closed_year],[closed_week],[week_key],[week_end_date]

        UNION ALL

        SELECT [closed_year],[closed_week],[week_key],[week_end_date],
               'EHS-KPI-C1',
               'Ratio of gas and electricity emissions to quantities produced',
               'Cost',[emissions_to_quantity_ratio],'Ratio',
               'sharepoint_staging.tp_be + sharepoint_staging.tp_mb',[source_row_count]
        FROM [sharepoint].[fact_ehs_energy_weekly_v1]

        UNION ALL

        SELECT [closed_year],[closed_week],[week_key],[week_end_date],
               'EHS-KPI-C2',
               'Ratio of gas and electricity emissions to m2 produced',
               'Cost',[emissions_to_m2_ratio],'Ratio',
               'sharepoint_staging.tp_be + sharepoint_staging.tp_mb',[source_row_count]
        FROM [sharepoint].[fact_ehs_energy_weekly_v1]
    ),
    enriched AS
    (
        SELECT
            a.*,
            ctl.[target_value],
            COALESCE(ctl.[breach_direction],'OVER') AS [breach_direction],
            COALESCE(ctl.[rag_tolerance_pct],0.05) AS [rag_tolerance_pct]
        FROM actuals a
        LEFT JOIN [reporting].[kpi_control] ctl
          ON ctl.[kpi_code] = a.[kpi_code]
         AND a.[week_end_date] >= ctl.[effective_from]
         AND (ctl.[effective_to] IS NULL OR a.[week_end_date] <= ctl.[effective_to])
    )
    INSERT INTO [sharepoint].[kpi_result_ehs_v1]
    (
        [closed_year],[closed_week],[kpi_name],[kpi_value],[organisational_unit],
        [kpi_id],[kpi_category],[target_value],[breach_direction],[week_key],
        [kpi_code],[department],[measure],[measure_name],[uom],[sign],[sign_label],
        [commentary],[variance_value],[performance_variance_value],[rag_status],
        [data_status],[source_system],[source_object],[source_row_count],
        [calculation_timestamp]
    )
    SELECT
        [closed_year],[closed_week],[kpi_name],[kpi_value],
        'Environment, Health and Safety',NULL,[kpi_category],[target_value],
        [breach_direction],[week_key],[kpi_code],'Environment, Health and Safety',
        [kpi_name],[kpi_name],[uom],[breach_direction],
        CASE WHEN [breach_direction]='OVER' THEN 'Over Breach' ELSE 'Under Breach' END,
        NULL,
        CASE WHEN [target_value] IS NULL OR [kpi_value] IS NULL THEN NULL
             ELSE [kpi_value]-[target_value] END,
        CASE WHEN [target_value] IS NULL OR [kpi_value] IS NULL THEN NULL
             WHEN [breach_direction]='OVER' THEN [target_value]-[kpi_value]
             ELSE [kpi_value]-[target_value] END,
        CASE
            WHEN [kpi_value] IS NULL THEN 'No Data'
            WHEN [target_value] IS NULL THEN 'TBC'
            WHEN [breach_direction]='OVER' AND [kpi_value] <= [target_value] THEN 'G'
            WHEN [breach_direction]='OVER' AND [kpi_value] <= [target_value]*(1+[rag_tolerance_pct]) THEN 'A'
            WHEN [breach_direction]='UNDER' AND [kpi_value] >= [target_value] THEN 'G'
            WHEN [breach_direction]='UNDER' AND [kpi_value] >= [target_value]*(1-[rag_tolerance_pct]) THEN 'A'
            ELSE 'R'
        END,
        CASE WHEN [target_value] IS NULL THEN 'Target Missing' ELSE 'Ready for Domain Publish' END,
        'SharePoint',[source_object],[source_row_count],SYSUTCDATETIME()
    FROM enriched;
END;
GO

/* -------------------------------------------------------------------------
   6. Publish to SharePoint domain fact_kpi_result only
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_publish_ehs_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [sharepoint].[fact_kpi_result]
    WHERE [kpi_code] IN ('EHS-KPI-P1','EHS-KPI-C1','EHS-KPI-C2');

    INSERT INTO [sharepoint].[fact_kpi_result]
    (
        [closed_year],[closed_week],[kpi_name],[kpi_value],[organisational_unit],
        [kpi_id],[kpi_category],[target_value],[breach_direction],[week_key],
        [kpi_code],[department],[measure],[measure_name],[uom],[sign],[sign_label],
        [commentary],[variance_value],[performance_variance_value],[rag_status],
        [data_status],[source_system],[source_object],[source_row_count],
        [calculation_timestamp]
    )
    SELECT
        [closed_year],[closed_week],[kpi_name],[kpi_value],[organisational_unit],
        [kpi_id],[kpi_category],[target_value],[breach_direction],[week_key],
        [kpi_code],[department],[measure],[measure_name],[uom],[sign],[sign_label],
        [commentary],[variance_value],[performance_variance_value],[rag_status],
        [data_status],[source_system],[source_object],[source_row_count],
        [calculation_timestamp]
    FROM [sharepoint].[kpi_result_ehs_v1];
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_ehs_sharepoint_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [sharepoint].[usp_build_fact_ehs_lost_working_days_v1];
    EXEC [sharepoint].[usp_build_fact_ehs_energy_weekly_v1];
    EXEC [sharepoint].[usp_build_kpi_result_ehs_v1];
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_and_publish_ehs_sharepoint_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [sharepoint].[usp_build_ehs_sharepoint_kpis_v1];
    EXEC [sharepoint].[usp_publish_ehs_kpis_v1];
END;
GO

/* -------------------------------------------------------------------------
   7. Validation queries
   ------------------------------------------------------------------------- */
-- Build only first:
-- EXEC [sharepoint].[usp_build_ehs_sharepoint_kpis_v1];

-- Historical KPI coverage:
-- SELECT [kpi_code], COUNT_BIG(*) AS [rows], COUNT(DISTINCT [week_key]) AS [weeks],
--        MIN([week_key]) AS [first_week], MAX([week_key]) AS [last_week],
--        COUNT([target_value]) AS [target_rows], COUNT([variance_value]) AS [variance_rows]
-- FROM [sharepoint].[kpi_result_ehs_v1]
-- GROUP BY [kpi_code]
-- ORDER BY [kpi_code];

-- Review full KPI rows:
-- SELECT *
-- FROM [sharepoint].[kpi_result_ehs_v1]
-- ORDER BY [week_key],[kpi_code];

-- Publish after review:
-- EXEC [sharepoint].[usp_publish_ehs_kpis_v1];

-- Final SharePoint domain validation:
-- SELECT *
-- FROM [sharepoint].[fact_kpi_result]
-- WHERE [kpi_code] IN ('EHS-KPI-P1','EHS-KPI-C1','EHS-KPI-C2')
-- ORDER BY [week_key],[kpi_code];

-- Duplicate check, expected 0 rows:
-- SELECT [week_key],[kpi_code],COUNT_BIG(*) AS [rows]
-- FROM [sharepoint].[fact_kpi_result]
-- WHERE [kpi_code] IN ('EHS-KPI-P1','EHS-KPI-C1','EHS-KPI-C2')
-- GROUP BY [week_key],[kpi_code]
-- HAVING COUNT_BIG(*) > 1;
