/*
====================================================================================================
File: SAS_Salesforce_Product_Design_4_KPIs_v1.sql
Purpose:
  Builds four historical weekly Product Design KPI streams from the stable Silver/Gold staging tables:
    [salesforce_staging].[product_design]
    [salesforce_staging].[customer_service]

KPI outputs:
  Product Design-KPI P1  Drawings Completed
  Product Design-KPI D1  Product Design OTIF
  Product Design-KPI D2  Drawing Lead Time
  Product Design-KPI Q1  Customer Complaints

Architecture:
  salesforce_staging.* -> salesforce atomic facts -> weekly facts
  -> reporting.kpi_control -> salesforce.kpi_result_product_design_v1
  -> salesforce.fact_kpi_result

Important initial business rules:
  P1 actual = SUM(how_many_drawings_are_required) for records completed in the reporting week.
      The atomic/weekly facts also retain completed_record_count for UAT comparison.
  D1 actual = completed on time / completed records with a due date.
      Due date = COALESCE(sla_due_date, complete_by_date).
  D2 actual = AVG(days_in_technical), falling back to calendar DATEDIFF where required.
  Q1 actual = DISTINCT case_number count for Product Design complaints opened in the week.
      Initial scope uses department/category text containing 'product design'.

All new stored procedures are versioned with _v1.
No [dbo] objects are used.
====================================================================================================
*/

SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'salesforce')
    EXEC('CREATE SCHEMA [salesforce]');
GO

/* Atomic Product Design fact */
IF OBJECT_ID('[salesforce].[fact_product_design_task_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[fact_product_design_task_v1]
    (
        [product_design_id]             VARCHAR(50)    NOT NULL,
        [project_name]                  VARCHAR(500)   NULL,
        [status]                        VARCHAR(100)   NULL,
        [completion_date]               DATE           NULL,
        [complete_by_date]              DATE           NULL,
        [sla_due_date]                  DATE           NULL,
        [effective_due_date]            DATE           NULL,
        [sla_start_date]                DATE           NULL,
        [created_date]                  DATETIME2(6)   NULL,
        [last_modified_date]            DATETIME2(6)   NULL,
        [drawings_required]             DECIMAL(18,4)  NULL,
        [days_in_technical_source]      DECIMAL(18,4)  NULL,
        [lead_time_days_calculated]     DECIMAL(18,4)  NULL,
        [lead_time_days]                DECIMAL(18,4)  NULL,
        [sla_overdue_source]            VARCHAR(50)    NULL,
        [overdue_source]                VARCHAR(50)    NULL,
        [on_time_flag]                  TINYINT        NULL,
        [source_system]                 VARCHAR(50)    NOT NULL,
        [loaded_at]                     DATETIME2(6)   NOT NULL
    );
END;
GO

/* Atomic Product Design complaint fact */
IF OBJECT_ID('[salesforce].[fact_product_design_complaint_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[fact_product_design_complaint_v1]
    (
        [case_id]                       VARCHAR(50)    NOT NULL,
        [case_number]                   VARCHAR(100)   NULL,
        [reporting_date]                DATE           NOT NULL,
        [open_date]                     DATE           NULL,
        [date_of_complaint]             DATE           NULL,
        [created_date]                  DATETIME2(6)   NULL,
        [project_name]                  VARCHAR(500)   NULL,
        [department]                    VARCHAR(255)   NULL,
        [fault_category]                VARCHAR(255)   NULL,
        [case_category]                 VARCHAR(255)   NULL,
        [complaint_category]            VARCHAR(255)   NULL,
        [record_type_name]              VARCHAR(255)   NULL,
        [source_system]                 VARCHAR(50)    NOT NULL,
        [loaded_at]                     DATETIME2(6)   NOT NULL
    );
END;
GO

/* Weekly Product Design measures, retaining alternative UAT measures */
IF OBJECT_ID('[salesforce].[fact_product_design_weekly_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[fact_product_design_weekly_v1]
    (
        [week_key]                      INT            NOT NULL,
        [customer_year]                 INT            NOT NULL,
        [customer_week_no]              INT            NOT NULL,
        [week_start_date]               DATE           NOT NULL,
        [week_end_date]                 DATE           NOT NULL,
        [drawings_completed]            DECIMAL(18,4)  NULL,
        [completed_record_count]        BIGINT         NULL,
        [otif_eligible_count]            BIGINT         NULL,
        [on_time_count]                 BIGINT         NULL,
        [otif_rate]                     DECIMAL(18,6)  NULL,
        [drawing_lead_time_days]        DECIMAL(18,4)  NULL,
        [complaint_count]               BIGINT         NULL,
        [loaded_at]                     DATETIME2(6)   NOT NULL
    );
END;
GO

/* KPI result table for this pack */
IF OBJECT_ID('[salesforce].[kpi_result_product_design_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[kpi_result_product_design_v1]
    (
        [kpi_code]                      VARCHAR(100)   NOT NULL,
        [kpi_name]                      VARCHAR(255)   NOT NULL,
        [organisation_unit]             VARCHAR(255)   NOT NULL,
        [period_type]                   VARCHAR(20)    NOT NULL,
        [week_key]                      INT            NOT NULL,
        [customer_year]                 INT            NOT NULL,
        [customer_week_no]              INT            NOT NULL,
        [period_start_date]              DATE           NOT NULL,
        [period_end_date]                DATE           NOT NULL,
        [actual_value]                  DECIMAL(18,6)  NULL,
        [target_value]                  DECIMAL(18,6)  NULL,
        [variance_value]                DECIMAL(18,6)  NULL,
        [performance_variance_value]    DECIMAL(18,6)  NULL,
        [breach_direction]              VARCHAR(20)    NULL,
        [rag_status]                    VARCHAR(20)    NULL,
        [unit_of_measure]               VARCHAR(50)    NULL,
        [source_system]                 VARCHAR(50)    NOT NULL,
        [source_table]                  VARCHAR(255)   NOT NULL,
        [calculation_version]           VARCHAR(20)    NOT NULL,
        [loaded_at]                     DATETIME2(6)   NOT NULL
    );
END;
GO

/* Domain output table. Created if it does not yet exist. */
IF OBJECT_ID('[salesforce].[fact_kpi_result]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[fact_kpi_result]
    (
        [kpi_code]                      VARCHAR(100)   NOT NULL,
        [kpi_name]                      VARCHAR(255)   NOT NULL,
        [organisation_unit]             VARCHAR(255)   NOT NULL,
        [period_type]                   VARCHAR(20)    NOT NULL,
        [week_key]                      INT            NOT NULL,
        [customer_year]                 INT            NOT NULL,
        [customer_week_no]              INT            NOT NULL,
        [period_start_date]              DATE           NOT NULL,
        [period_end_date]                DATE           NOT NULL,
        [actual_value]                  DECIMAL(18,6)  NULL,
        [target_value]                  DECIMAL(18,6)  NULL,
        [variance_value]                DECIMAL(18,6)  NULL,
        [performance_variance_value]    DECIMAL(18,6)  NULL,
        [breach_direction]              VARCHAR(20)    NULL,
        [rag_status]                    VARCHAR(20)    NULL,
        [unit_of_measure]               VARCHAR(50)    NULL,
        [source_system]                 VARCHAR(50)    NOT NULL,
        [source_table]                  VARCHAR(255)   NOT NULL,
        [calculation_version]           VARCHAR(20)    NOT NULL,
        [loaded_at]                     DATETIME2(6)   NOT NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_fact_product_design_task_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF OBJECT_ID('[salesforce_staging].[product_design]', 'U') IS NULL
        THROW 50001, 'Missing source table [salesforce_staging].[product_design]. Existing Gold data was preserved.', 1;

    IF NOT EXISTS (SELECT 1 FROM [salesforce_staging].[product_design])
        THROW 50002, 'Source table [salesforce_staging].[product_design] is empty. Existing Gold data was preserved.', 1;

    DELETE FROM [salesforce].[fact_product_design_task_v1];

    ;WITH ranked AS
    (
        SELECT
            CAST([id] AS VARCHAR(50)) AS [product_design_id],
            CAST([project_name] AS VARCHAR(500)) AS [project_name],
            CAST([status] AS VARCHAR(100)) AS [status],
            TRY_CAST([completion_date] AS DATE) AS [completion_date],
            TRY_CAST([complete_by_date] AS DATE) AS [complete_by_date],
            TRY_CAST([sla_due_date] AS DATE) AS [sla_due_date],
            TRY_CAST([sla_start_date] AS DATE) AS [sla_start_date],
            TRY_CAST([created_date] AS DATETIME2(6)) AS [created_date],
            TRY_CAST([last_modified_date] AS DATETIME2(6)) AS [last_modified_date],
            TRY_CAST([how_many_drawings_are_required] AS DECIMAL(18,4)) AS [drawings_required],
            TRY_CAST([days_in_technical] AS DECIMAL(18,4)) AS [days_in_technical_source],
            CAST([sla_overdue] AS VARCHAR(50)) AS [sla_overdue_source],
            CAST([overdue] AS VARCHAR(50)) AS [overdue_source],
            ROW_NUMBER() OVER
            (
                PARTITION BY [id]
                ORDER BY TRY_CAST([last_modified_date] AS DATETIME2(6)) DESC
            ) AS [rn]
        FROM [salesforce_staging].[product_design]
        WHERE COALESCE(TRY_CAST([is_deleted] AS INT), 0) = 0
    )
    INSERT INTO [salesforce].[fact_product_design_task_v1]
    (
        [product_design_id], [project_name], [status], [completion_date],
        [complete_by_date], [sla_due_date], [effective_due_date], [sla_start_date],
        [created_date], [last_modified_date], [drawings_required],
        [days_in_technical_source], [lead_time_days_calculated], [lead_time_days],
        [sla_overdue_source], [overdue_source], [on_time_flag], [source_system], [loaded_at]
    )
    SELECT
        [product_design_id],
        [project_name],
        [status],
        [completion_date],
        [complete_by_date],
        [sla_due_date],
        COALESCE([sla_due_date], [complete_by_date]) AS [effective_due_date],
        [sla_start_date],
        [created_date],
        [last_modified_date],
        [drawings_required],
        [days_in_technical_source],
        CASE
            WHEN [completion_date] IS NOT NULL
             AND COALESCE([sla_start_date], TRY_CAST([created_date] AS DATE)) IS NOT NULL
            THEN CAST(DATEDIFF(DAY, COALESCE([sla_start_date], TRY_CAST([created_date] AS DATE)), [completion_date]) AS DECIMAL(18,4))
        END AS [lead_time_days_calculated],
        COALESCE
        (
            [days_in_technical_source],
            CASE
                WHEN [completion_date] IS NOT NULL
                 AND COALESCE([sla_start_date], TRY_CAST([created_date] AS DATE)) IS NOT NULL
                THEN CAST(DATEDIFF(DAY, COALESCE([sla_start_date], TRY_CAST([created_date] AS DATE)), [completion_date]) AS DECIMAL(18,4))
            END
        ) AS [lead_time_days],
        [sla_overdue_source],
        [overdue_source],
        CASE
            WHEN [completion_date] IS NULL OR COALESCE([sla_due_date], [complete_by_date]) IS NULL THEN NULL
            WHEN [completion_date] <= COALESCE([sla_due_date], [complete_by_date]) THEN 1
            ELSE 0
        END AS [on_time_flag],
        'Salesforce' AS [source_system],
        SYSUTCDATETIME() AS [loaded_at]
    FROM ranked
    WHERE [rn] = 1;
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_fact_product_design_complaint_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF OBJECT_ID('[salesforce_staging].[customer_service]', 'U') IS NULL
        THROW 50003, 'Missing source table [salesforce_staging].[customer_service]. Existing Gold data was preserved.', 1;

    IF NOT EXISTS (SELECT 1 FROM [salesforce_staging].[customer_service])
        THROW 50004, 'Source table [salesforce_staging].[customer_service] is empty. Existing Gold data was preserved.', 1;

    DELETE FROM [salesforce].[fact_product_design_complaint_v1];

    ;WITH ranked AS
    (
        SELECT
            CAST([id] AS VARCHAR(50)) AS [case_id],
            CAST([case_number] AS VARCHAR(100)) AS [case_number],
            TRY_CAST([open_date] AS DATE) AS [open_date],
            TRY_CAST([date_of_complaint] AS DATE) AS [date_of_complaint],
            TRY_CAST([created_date] AS DATETIME2(6)) AS [created_date],
            CAST([project_name] AS VARCHAR(500)) AS [project_name],
            CAST([department] AS VARCHAR(255)) AS [department],
            CAST([fault_category] AS VARCHAR(255)) AS [fault_category],
            CAST([case_category] AS VARCHAR(255)) AS [case_category],
            CAST([complaint_category] AS VARCHAR(255)) AS [complaint_category],
            CAST([record_type_name] AS VARCHAR(255)) AS [record_type_name],
            ROW_NUMBER() OVER
            (
                PARTITION BY [id]
                ORDER BY TRY_CAST([last_modified_date] AS DATETIME2(6)) DESC
            ) AS [rn]
        FROM [salesforce_staging].[customer_service]
        WHERE COALESCE(TRY_CAST([is_deleted] AS INT), 0) = 0
          AND
          (
               LOWER(COALESCE(CAST([department] AS VARCHAR(255)), '')) LIKE '%product design%'
            OR LOWER(COALESCE(CAST([fault_category] AS VARCHAR(255)), '')) LIKE '%product design%'
            OR LOWER(COALESCE(CAST([case_category] AS VARCHAR(255)), '')) LIKE '%product design%'
            OR LOWER(COALESCE(CAST([complaint_category] AS VARCHAR(255)), '')) LIKE '%product design%'
          )
    )
    INSERT INTO [salesforce].[fact_product_design_complaint_v1]
    (
        [case_id], [case_number], [reporting_date], [open_date], [date_of_complaint],
        [created_date], [project_name], [department], [fault_category], [case_category],
        [complaint_category], [record_type_name], [source_system], [loaded_at]
    )
    SELECT
        [case_id],
        [case_number],
        COALESCE([open_date], [date_of_complaint], TRY_CAST([created_date] AS DATE)) AS [reporting_date],
        [open_date],
        [date_of_complaint],
        [created_date],
        [project_name],
        [department],
        [fault_category],
        [case_category],
        [complaint_category],
        [record_type_name],
        'Salesforce' AS [source_system],
        SYSUTCDATETIME() AS [loaded_at]
    FROM ranked
    WHERE [rn] = 1
      AND COALESCE([open_date], [date_of_complaint], TRY_CAST([created_date] AS DATE)) IS NOT NULL;
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_fact_product_design_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [salesforce].[fact_product_design_weekly_v1];

    ;WITH calendar AS
    (
        SELECT
            [week_key],
            [customer_year],
            [customer_week_no],
            MIN([date]) AS [week_start_date],
            MAX([date]) AS [week_end_date]
        FROM [reporting].[dim_date]
        GROUP BY [week_key], [customer_year], [customer_week_no]
    ),
    delivery AS
    (
        SELECT
            d.[week_key],
            SUM(COALESCE(t.[drawings_required], 0)) AS [drawings_completed],
            COUNT_BIG(*) AS [completed_record_count],
            SUM(CASE WHEN t.[on_time_flag] IS NOT NULL THEN 1 ELSE 0 END) AS [otif_eligible_count],
            SUM(CASE WHEN t.[on_time_flag] = 1 THEN 1 ELSE 0 END) AS [on_time_count],
            CAST
            (
                SUM(CASE WHEN t.[on_time_flag] = 1 THEN 1.0 ELSE 0.0 END)
                / NULLIF(SUM(CASE WHEN t.[on_time_flag] IS NOT NULL THEN 1.0 ELSE 0.0 END), 0)
                AS DECIMAL(18,6)
            ) AS [otif_rate],
            CAST(AVG(t.[lead_time_days]) AS DECIMAL(18,4)) AS [drawing_lead_time_days]
        FROM [salesforce].[fact_product_design_task_v1] t
        INNER JOIN [reporting].[dim_date] d
            ON d.[date] = t.[completion_date]
        WHERE t.[completion_date] IS NOT NULL
        GROUP BY d.[week_key]
    ),
    complaints AS
    (
        SELECT
            d.[week_key],
            COUNT(DISTINCT c.[case_number]) AS [complaint_count]
        FROM [salesforce].[fact_product_design_complaint_v1] c
        INNER JOIN [reporting].[dim_date] d
            ON d.[date] = c.[reporting_date]
        GROUP BY d.[week_key]
    ),
    bounds AS
    (
        SELECT MIN([week_key]) AS [min_week_key], MAX([week_key]) AS [max_week_key]
        FROM
        (
            SELECT [week_key] FROM delivery
            UNION ALL
            SELECT [week_key] FROM complaints
        ) x
    )
    INSERT INTO [salesforce].[fact_product_design_weekly_v1]
    (
        [week_key], [customer_year], [customer_week_no], [week_start_date], [week_end_date],
        [drawings_completed], [completed_record_count], [otif_eligible_count], [on_time_count],
        [otif_rate], [drawing_lead_time_days], [complaint_count], [loaded_at]
    )
    SELECT
        cal.[week_key],
        cal.[customer_year],
        cal.[customer_week_no],
        cal.[week_start_date],
        cal.[week_end_date],
        COALESCE(del.[drawings_completed], 0),
        COALESCE(del.[completed_record_count], 0),
        COALESCE(del.[otif_eligible_count], 0),
        COALESCE(del.[on_time_count], 0),
        del.[otif_rate],
        del.[drawing_lead_time_days],
        COALESCE(comp.[complaint_count], 0),
        SYSUTCDATETIME()
    FROM calendar cal
    CROSS JOIN bounds b
    LEFT JOIN delivery del ON del.[week_key] = cal.[week_key]
    LEFT JOIN complaints comp ON comp.[week_key] = cal.[week_key]
    WHERE cal.[week_key] BETWEEN b.[min_week_key] AND b.[max_week_key];
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_kpi_result_product_design_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [salesforce].[kpi_result_product_design_v1];

    ;WITH unpivoted AS
    (
        SELECT [week_key], [customer_year], [customer_week_no], [week_start_date], [week_end_date],
               'Product Design-KPI P1' AS [kpi_code], 'Drawings Completed' AS [kpi_name],
               CAST([drawings_completed] AS DECIMAL(18,6)) AS [actual_value], 'Count' AS [unit_of_measure],
               'salesforce_staging.product_design' AS [source_table]
        FROM [salesforce].[fact_product_design_weekly_v1]
        UNION ALL
        SELECT [week_key], [customer_year], [customer_week_no], [week_start_date], [week_end_date],
               'Product Design-KPI D1', 'Product Design OTIF', CAST([otif_rate] AS DECIMAL(18,6)), 'Percentage',
               'salesforce_staging.product_design'
        FROM [salesforce].[fact_product_design_weekly_v1]
        UNION ALL
        SELECT [week_key], [customer_year], [customer_week_no], [week_start_date], [week_end_date],
               'Product Design-KPI D2', 'Drawing Lead Time', CAST([drawing_lead_time_days] AS DECIMAL(18,6)), 'Days',
               'salesforce_staging.product_design'
        FROM [salesforce].[fact_product_design_weekly_v1]
        UNION ALL
        SELECT [week_key], [customer_year], [customer_week_no], [week_start_date], [week_end_date],
               'Product Design-KPI Q1', 'Customer Complaints', CAST([complaint_count] AS DECIMAL(18,6)), 'Count',
               'salesforce_staging.customer_service'
        FROM [salesforce].[fact_product_design_weekly_v1]
    ),
    controlled AS
    (
        SELECT
            u.*,
            c.[target_value],
            UPPER(c.[breach_direction]) AS [breach_direction]
        FROM unpivoted u
        LEFT JOIN [reporting].[kpi_control] c
            ON c.[kpi_code] = u.[kpi_code]
           AND u.[week_end_date] >= COALESCE(c.[effective_from], '19000101')
           AND u.[week_end_date] <= COALESCE(c.[effective_to], '99991231')
    )
    INSERT INTO [salesforce].[kpi_result_product_design_v1]
    (
        [kpi_code], [kpi_name], [organisation_unit], [period_type], [week_key],
        [customer_year], [customer_week_no], [period_start_date], [period_end_date],
        [actual_value], [target_value], [variance_value], [performance_variance_value],
        [breach_direction], [rag_status], [unit_of_measure], [source_system], [source_table],
        [calculation_version], [loaded_at]
    )
    SELECT
        [kpi_code],
        [kpi_name],
        'Product Design',
        'Weekly',
        [week_key],
        [customer_year],
        [customer_week_no],
        [week_start_date],
        [week_end_date],
        [actual_value],
        [target_value],
        [actual_value] - [target_value] AS [variance_value],
        CASE
            WHEN [target_value] IS NULL OR [actual_value] IS NULL THEN NULL
            WHEN [breach_direction] = 'UNDER' THEN [actual_value] - [target_value]
            WHEN [breach_direction] = 'OVER' THEN [target_value] - [actual_value]
            ELSE [actual_value] - [target_value]
        END AS [performance_variance_value],
        [breach_direction],
        CASE
            WHEN [target_value] IS NULL OR [actual_value] IS NULL THEN 'TBC'
            WHEN [breach_direction] = 'UNDER' AND [actual_value] >= [target_value] THEN 'Green'
            WHEN [breach_direction] = 'UNDER' AND [actual_value] >= [target_value] * 0.95 THEN 'Amber'
            WHEN [breach_direction] = 'UNDER' THEN 'Red'
            WHEN [breach_direction] = 'OVER' AND [actual_value] <= [target_value] THEN 'Green'
            WHEN [breach_direction] = 'OVER' AND [actual_value] <= [target_value] * 1.05 THEN 'Amber'
            WHEN [breach_direction] = 'OVER' THEN 'Red'
            ELSE 'TBC'
        END AS [rag_status],
        [unit_of_measure],
        'Salesforce',
        [source_table],
        'v1',
        SYSUTCDATETIME()
    FROM controlled;
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_publish_product_design_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [salesforce].[fact_kpi_result]
    WHERE [kpi_code] IN
    (
        'Product Design-KPI P1',
        'Product Design-KPI D1',
        'Product Design-KPI D2',
        'Product Design-KPI Q1'
    );

    INSERT INTO [salesforce].[fact_kpi_result]
    (
        [kpi_code], [kpi_name], [organisation_unit], [period_type], [week_key],
        [customer_year], [customer_week_no], [period_start_date], [period_end_date],
        [actual_value], [target_value], [variance_value], [performance_variance_value],
        [breach_direction], [rag_status], [unit_of_measure], [source_system], [source_table],
        [calculation_version], [loaded_at]
    )
    SELECT
        [kpi_code], [kpi_name], [organisation_unit], [period_type], [week_key],
        [customer_year], [customer_week_no], [period_start_date], [period_end_date],
        [actual_value], [target_value], [variance_value], [performance_variance_value],
        [breach_direction], [rag_status], [unit_of_measure], [source_system], [source_table],
        [calculation_version], [loaded_at]
    FROM [salesforce].[kpi_result_product_design_v1];
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_product_design_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [salesforce].[usp_build_fact_product_design_task_v1];
    EXEC [salesforce].[usp_build_fact_product_design_complaint_v1];
    EXEC [salesforce].[usp_build_fact_product_design_weekly_v1];
    EXEC [salesforce].[usp_build_kpi_result_product_design_v1];
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_and_publish_product_design_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [salesforce].[usp_build_product_design_kpis_v1];
    EXEC [salesforce].[usp_publish_product_design_kpis_v1];
END;
GO

/*
====================================================================================================
DEPLOYMENT / UAT
====================================================================================================

1. Expected control rows (use your normal controlled deployment process; do not duplicate active rows):

   KPI code                  Target   Direction  UOM
   Product Design-KPI P1     350/450  UNDER      Count
   Product Design-KPI D1     0.90     UNDER      Percentage
   Product Design-KPI D2     7.00     OVER       Days
   Product Design-KPI Q1     1.00     OVER       Count

   P1 target changes should be represented with effective_from/effective_to dates in reporting.kpi_control.

2. Inspect Product Design complaint scope values before first publication:

SELECT
    [department], [fault_category], [case_category], [complaint_category],
    COUNT_BIG(*) AS [cases]
FROM [salesforce_staging].[customer_service]
GROUP BY [department], [fault_category], [case_category], [complaint_category]
ORDER BY [cases] DESC;

3. Build without publishing:

EXEC [salesforce].[usp_build_product_design_kpis_v1];

4. Compare P1 alternative measures. The KPI currently uses drawings_completed:

SELECT
    [customer_year], [customer_week_no], [drawings_completed], [completed_record_count]
FROM [salesforce].[fact_product_design_weekly_v1]
ORDER BY [week_key];

5. Validate OTIF and lead-time source/fallback:

SELECT TOP 100
    [product_design_id], [completion_date], [effective_due_date], [on_time_flag],
    [days_in_technical_source], [lead_time_days_calculated], [lead_time_days],
    [sla_overdue_source], [overdue_source]
FROM [salesforce].[fact_product_design_task_v1]
ORDER BY [completion_date] DESC;

6. Review KPI output:

SELECT *
FROM [salesforce].[kpi_result_product_design_v1]
ORDER BY [week_key], [kpi_code];

7. Publish after UAT:

EXEC [salesforce].[usp_publish_product_design_kpis_v1];

8. Duplicate check:

SELECT [kpi_code], [week_key], COUNT_BIG(*) AS [rows]
FROM [salesforce].[fact_kpi_result]
WHERE [kpi_code] IN
(
    'Product Design-KPI P1',
    'Product Design-KPI D1',
    'Product Design-KPI D2',
    'Product Design-KPI Q1'
)
GROUP BY [kpi_code], [week_key]
HAVING COUNT_BIG(*) > 1;
====================================================================================================
*/
