/*
SAS QUALITY MAYBOLE - CUSTOMER COMPLAINTS AND COST OF QUALITY KPI PACK V1
===================================================
Source: [salesforce_staging].[customer_service]
Calendar: [reporting].[dim_date]
Targets: [reporting].[kpi_control]
Domain output: [salesforce].[fact_kpi_result]

KPIs:
  Quality Maybole-KPI Q1 - Customer Complaints
  Quality Maybole-KPI C1 - Cost of Quality

IMPORTANT SCOPE MITIGATION
--------------------------
The exact historic PBIX Maybole predicate has not yet been recovered. The working
scope below includes a case when any available Maybole/site indicator contains
'MAYBOLE' or equals 'MB'. Review the distinct source values before UAT and amend
ONLY the predicate in usp_build_fact_quality_mb_customer_service_v1 if required.

Expected snake_case source columns:
  id, case_number, open_date, created_date, last_modified_date, is_deleted,
  department, lead_site, syteline_lead_site, project_name, total_costs
*/

/* =============================================================
   00. TABLES
   ============================================================= */
IF OBJECT_ID('[salesforce].[fact_quality_mb_customer_service_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[fact_quality_mb_customer_service_v1]
    (
        [case_id]                    VARCHAR(255)   NOT NULL,
        [case_number]                VARCHAR(255)   NULL,
        [complaint_open_date]        DATE           NULL,
        [department]                 VARCHAR(255)   NULL,
        [lead_site]                  VARCHAR(255)   NULL,
        [syteline_lead_site]         VARCHAR(255)   NULL,
        [project_name]               VARCHAR(500)   NULL,
        [total_cost]                 DECIMAL(18,6)  NULL,
        [source_created_timestamp]   DATETIME2(6)   NULL,
        [source_modified_timestamp]  DATETIME2(6)   NULL,
        [date_key]                   INT            NULL,
        [closed_year]                INT            NULL,
        [closed_week]                INT            NULL,
        [week_key]                   INT            NULL,
        [week_start_date]            DATE           NULL,
        [week_ending_date]           DATE           NULL,
        [created_timestamp]          DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[salesforce].[fact_quality_mb_customer_service_weekly_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[fact_quality_mb_customer_service_weekly_v1]
    (
        [closed_year]                INT            NOT NULL,
        [closed_week]                INT            NOT NULL,
        [week_key]                   INT            NOT NULL,
        [week_start_date]            DATE           NOT NULL,
        [week_ending_date]           DATE           NOT NULL,
        [customer_complaints]        BIGINT         NOT NULL,
        [complaints_with_cost]       BIGINT         NOT NULL,
        [cost_of_quality]            DECIMAL(18,6)  NOT NULL,
        [source_row_count]           BIGINT         NOT NULL,
        [calculation_timestamp]      DATETIME2(6)   NOT NULL
    );
END;
GO

IF OBJECT_ID('[salesforce].[kpi_result_quality_mb_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[kpi_result_quality_mb_v1]
    (
        [closed_year]                   INT            NULL,
        [closed_week]                   INT            NULL,
        [kpi_name]                      VARCHAR(255)   NULL,
        [kpi_value]                     DECIMAL(18,6)  NULL,
        [organisational_unit]           VARCHAR(255)   NULL,
        [kpi_id]                        BIGINT         NULL,
        [kpi_category]                  VARCHAR(100)   NULL,
        [target_value]                  DECIMAL(18,6)  NULL,
        [breach_direction]              VARCHAR(20)    NULL,
        [week_key]                      INT            NULL,
        [kpi_code]                      VARCHAR(100)   NULL,
        [department]                    VARCHAR(255)   NULL,
        [measure]                       VARCHAR(500)   NULL,
        [measure_name]                  VARCHAR(500)   NULL,
        [uom]                           VARCHAR(50)    NULL,
        [sign]                          VARCHAR(100)   NULL,
        [sign_label]                    VARCHAR(100)   NULL,
        [commentary]                    VARCHAR(1000) NULL,
        [variance_value]                DECIMAL(18,6)  NULL,
        [performance_variance_value]    DECIMAL(18,6)  NULL,
        [rag_status]                    VARCHAR(20)    NULL,
        [data_status]                   VARCHAR(50)    NULL,
        [source_system]                 VARCHAR(100)   NULL,
        [source_object]                 VARCHAR(500)   NULL,
        [source_row_count]              BIGINT         NULL,
        [calculation_timestamp]         DATETIME2(6)   NULL
    );
END;
GO

/* =============================================================
   01. ATOMIC FACT
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_build_fact_quality_mb_customer_service_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [salesforce_staging].[customer_service]
        WHERE COALESCE([is_deleted], 0) = 0
    )
    BEGIN
        THROW 51001,
              'ABORTED: salesforce_staging.customer_service is empty. Existing Quality MB fact data has been preserved.',
              1;
    END;

    TRUNCATE TABLE [salesforce].[fact_quality_mb_customer_service_v1];

    ;WITH [source_latest] AS
    (
        SELECT
            CAST([cs].[id] AS VARCHAR(255)) AS [case_id],
            CAST([cs].[case_number] AS VARCHAR(255)) AS [case_number],
            TRY_CAST(COALESCE([cs].[open_date], [cs].[created_date]) AS DATE) AS [complaint_open_date],
            CAST([cs].[department] AS VARCHAR(255)) AS [department],
            CAST([cs].[lead_site] AS VARCHAR(255)) AS [lead_site],
            CAST([cs].[syteline_lead_site] AS VARCHAR(255)) AS [syteline_lead_site],
            CAST([cs].[project_name] AS VARCHAR(500)) AS [project_name],
            TRY_CAST([cs].[total_costs] AS DECIMAL(18,6)) AS [total_cost],
            TRY_CAST([cs].[created_date] AS DATETIME2(6)) AS [source_created_timestamp],
            TRY_CAST([cs].[last_modified_date] AS DATETIME2(6)) AS [source_modified_timestamp],
            ROW_NUMBER() OVER
            (
                PARTITION BY CAST([cs].[id] AS VARCHAR(255))
                ORDER BY
                    TRY_CAST([cs].[last_modified_date] AS DATETIME2(6)) DESC,
                    TRY_CAST([cs].[created_date] AS DATETIME2(6)) DESC
            ) AS [rn]
        FROM [salesforce_staging].[customer_service] AS [cs]
        WHERE [cs].[id] IS NOT NULL
          AND [cs].[case_number] IS NOT NULL
          AND COALESCE([cs].[is_deleted], 0) = 0
          AND
          (
                UPPER(LTRIM(RTRIM(COALESCE(CAST([cs].[lead_site] AS VARCHAR(255)), '')))) LIKE '%MAYBOLE%'
             OR UPPER(LTRIM(RTRIM(COALESCE(CAST([cs].[lead_site] AS VARCHAR(255)), '')))) = 'MB'
             OR UPPER(LTRIM(RTRIM(COALESCE(CAST([cs].[syteline_lead_site] AS VARCHAR(255)), '')))) LIKE '%MAYBOLE%'
             OR UPPER(LTRIM(RTRIM(COALESCE(CAST([cs].[syteline_lead_site] AS VARCHAR(255)), '')))) = 'MB'
             OR UPPER(LTRIM(RTRIM(COALESCE(CAST([cs].[department] AS VARCHAR(255)), '')))) LIKE '%MAYBOLE%'
             OR UPPER(LTRIM(RTRIM(COALESCE(CAST([cs].[project_name] AS VARCHAR(500)), '')))) LIKE '%MAYBOLE%'
          )
    )
    INSERT INTO [salesforce].[fact_quality_mb_customer_service_v1]
    (
        [case_id], [case_number], [complaint_open_date], [department],
        [lead_site], [syteline_lead_site], [project_name], [total_cost],
        [source_created_timestamp], [source_modified_timestamp], [date_key],
        [closed_year], [closed_week], [week_key], [week_start_date],
        [week_ending_date], [created_timestamp]
    )
    SELECT
        [s].[case_id], [s].[case_number], [s].[complaint_open_date], [s].[department],
        [s].[lead_site], [s].[syteline_lead_site], [s].[project_name], [s].[total_cost],
        [s].[source_created_timestamp], [s].[source_modified_timestamp],
        [d].[date_key], [d].[customer_year], [d].[customer_week_no], [d].[week_key],
        [d].[week_start_date], [d].[week_end_date], SYSUTCDATETIME()
    FROM [source_latest] AS [s]
    LEFT JOIN [reporting].[dim_date] AS [d]
        ON [d].[calendar_date] = [s].[complaint_open_date]
    WHERE [s].[rn] = 1;
END;
GO

/* =============================================================
   02. WEEKLY FACT
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_build_fact_quality_mb_customer_service_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [salesforce].[fact_quality_mb_customer_service_weekly_v1];

    INSERT INTO [salesforce].[fact_quality_mb_customer_service_weekly_v1]
    (
        [closed_year], [closed_week], [week_key], [week_start_date],
        [week_ending_date], [customer_complaints], [complaints_with_cost],
        [cost_of_quality], [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date],
        COUNT(DISTINCT [case_number]),
        COUNT(DISTINCT CASE WHEN [total_cost] IS NOT NULL THEN [case_number] END),
        CAST(SUM(COALESCE([total_cost], 0)) AS DECIMAL(18,6)),
        COUNT_BIG(*), SYSUTCDATETIME()
    FROM [salesforce].[fact_quality_mb_customer_service_v1]
    WHERE [week_key] IS NOT NULL
    GROUP BY
        [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date];
END;
GO

/* =============================================================
   03. KPI RESULT - BOTH KPIs, SEPARATE ROWS
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_build_kpi_result_quality_mb_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [salesforce].[kpi_result_quality_mb_v1];

    ;WITH [actuals] AS
    (
        SELECT
            [w].[closed_year], [w].[closed_week], [w].[week_key], [w].[week_ending_date],
            CAST('Quality Maybole-KPI Q1' AS VARCHAR(100)) AS [kpi_code],
            CAST('Customer Complaints' AS VARCHAR(255)) AS [kpi_name],
            CAST('Count of Customer Service cases by open date' AS VARCHAR(500)) AS [measure],
            CAST('Customer Complaints' AS VARCHAR(500)) AS [measure_name],
            CAST('Count' AS VARCHAR(50)) AS [uom],
            CAST([w].[customer_complaints] AS DECIMAL(18,6)) AS [kpi_value],
            [w].[source_row_count],
            CONCAT('Complaints=', [w].[customer_complaints],
                   '. Working Maybole scope must be reconciled to the approved PBIX filter.') AS [commentary]
        FROM [salesforce].[fact_quality_mb_customer_service_weekly_v1] AS [w]

        UNION ALL

        SELECT
            [w].[closed_year], [w].[closed_week], [w].[week_key], [w].[week_ending_date],
            CAST('Quality Maybole-KPI C1' AS VARCHAR(100)),
            CAST('Cost of Quality' AS VARCHAR(255)),
            CAST('Sum of Customer Service total costs by open date' AS VARCHAR(500)),
            CAST('Cost of Quality' AS VARCHAR(500)),
            CAST('GBP' AS VARCHAR(50)),
            CAST([w].[cost_of_quality] AS DECIMAL(18,6)),
            [w].[source_row_count],
            CONCAT('Complaints=', [w].[customer_complaints],
                   ', complaints with cost=', [w].[complaints_with_cost],
                   '. Working Maybole scope must be reconciled to the approved PBIX filter.')
        FROM [salesforce].[fact_quality_mb_customer_service_weekly_v1] AS [w]
    ),
    [enriched] AS
    (
        SELECT
            [a].*,
            CAST([c].[target_value] AS DECIMAL(18,6)) AS [target_value],
            UPPER(NULLIF([c].[breach_direction], '')) AS [breach_direction],
            CAST(COALESCE([c].[rag_tolerance_pct], 0.05) AS DECIMAL(18,6)) AS [rag_tolerance_pct]
        FROM [actuals] AS [a]
        LEFT JOIN [reporting].[kpi_control] AS [c]
            ON [c].[kpi_code] = [a].[kpi_code]
           AND [a].[week_ending_date] >= [c].[effective_from]
           AND ([c].[effective_to] IS NULL OR [a].[week_ending_date] <= [c].[effective_to])
    )
    INSERT INTO [salesforce].[kpi_result_quality_mb_v1]
    (
        [closed_year], [closed_week], [kpi_name], [kpi_value], [organisational_unit],
        [kpi_id], [kpi_category], [target_value], [breach_direction], [week_key],
        [kpi_code], [department], [measure], [measure_name], [uom], [sign],
        [sign_label], [commentary], [variance_value], [performance_variance_value],
        [rag_status], [data_status], [source_system], [source_object],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [kpi_name], [kpi_value],
        'Quality Maybole', NULL, 'Quality', [target_value], [breach_direction], [week_key],
        [kpi_code], 'Quality Maybole', [measure], [measure_name], [uom],
        CASE WHEN [breach_direction] = 'OVER' THEN 'Over Breach' ELSE 'Under Breach' END,
        CASE WHEN [breach_direction] = 'OVER' THEN 'Over Breach' ELSE 'Under Breach' END,
        [commentary],
        CASE WHEN [target_value] IS NULL OR [kpi_value] IS NULL THEN NULL
             ELSE [kpi_value] - [target_value] END,
        CASE WHEN [target_value] IS NULL OR [kpi_value] IS NULL OR [breach_direction] IS NULL THEN NULL
             WHEN [breach_direction] = 'OVER' THEN [target_value] - [kpi_value]
             ELSE [kpi_value] - [target_value] END,
        CASE
            WHEN [kpi_value] IS NULL THEN 'No Data'
            WHEN [target_value] IS NULL OR [breach_direction] IS NULL THEN 'TBC'
            WHEN [breach_direction] = 'UNDER' AND [kpi_value] >= [target_value] THEN 'G'
            WHEN [breach_direction] = 'UNDER' AND [kpi_value] >= [target_value] * (1 - [rag_tolerance_pct]) THEN 'A'
            WHEN [breach_direction] = 'OVER' AND [kpi_value] <= [target_value] THEN 'G'
            WHEN [breach_direction] = 'OVER' AND [kpi_value] <= [target_value] * (1 + [rag_tolerance_pct]) THEN 'A'
            ELSE 'R'
        END,
        CASE WHEN [target_value] IS NULL THEN 'Working Logic - Target Missing'
             ELSE 'Working Logic - Scope Approval Required' END,
        'Salesforce', 'salesforce_staging.customer_service', [source_row_count], SYSUTCDATETIME()
    FROM [enriched];
END;
GO

/* =============================================================
   04. DOMAIN PUBLICATION
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_publish_quality_mb_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [salesforce].[fact_kpi_result]
    WHERE [kpi_code] IN ('Quality Maybole-KPI Q1', 'Quality Maybole-KPI C1');

    INSERT INTO [salesforce].[fact_kpi_result]
    (
        [closed_year], [closed_week], [kpi_name], [kpi_value], [organisational_unit],
        [kpi_id], [kpi_category], [target_value], [breach_direction], [week_key],
        [kpi_code], [department], [measure], [measure_name], [uom], [sign],
        [sign_label], [commentary], [variance_value], [performance_variance_value],
        [rag_status], [data_status], [source_system], [source_object],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [kpi_name], [kpi_value], [organisational_unit],
        [kpi_id], [kpi_category], [target_value], [breach_direction], [week_key],
        [kpi_code], [department], [measure], [measure_name], [uom], [sign],
        [sign_label], [commentary], [variance_value], [performance_variance_value],
        [rag_status], [data_status], [source_system], [source_object],
        [source_row_count], [calculation_timestamp]
    FROM [salesforce].[kpi_result_quality_mb_v1];
END;
GO

/* =============================================================
   05. ORCHESTRATORS
   ============================================================= */
CREATE OR ALTER PROCEDURE [salesforce].[usp_build_quality_mb_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [salesforce].[usp_build_fact_quality_mb_customer_service_v1];
    EXEC [salesforce].[usp_build_fact_quality_mb_customer_service_weekly_v1];
    EXEC [salesforce].[usp_build_kpi_result_quality_mb_v1];
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_and_publish_quality_mb_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [salesforce].[usp_build_quality_mb_kpis_v1];
    EXEC [salesforce].[usp_publish_quality_mb_kpis_v1];
END;
GO

/* =============================================================
   06. CONTROL TABLE SEED - REVIEW BEFORE EXECUTING
   Expected targets from the current KPI target catalogue:
     Quality Maybole-KPI Q1 = 1 complaint, OVER
     Quality Maybole-KPI C1 = 654 GBP, OVER

   Uncomment and adapt to the exact reporting.kpi_control DDL if these
   rows do not already exist.
   =============================================================
IF NOT EXISTS (SELECT 1 FROM [reporting].[kpi_control] WHERE [kpi_code] = 'Quality Maybole-KPI Q1')
BEGIN
    INSERT INTO [reporting].[kpi_control]
    (
        [kpi_code], [target_value], [breach_direction], [rag_tolerance_pct],
        [effective_from], [effective_to]
    )
    VALUES ('Quality Maybole-KPI Q1', 1.000000, 'OVER', 0.050000, '2026-01-01', NULL);
END;

IF NOT EXISTS (SELECT 1 FROM [reporting].[kpi_control] WHERE [kpi_code] = 'Quality Maybole-KPI C1')
BEGIN
    INSERT INTO [reporting].[kpi_control]
    (
        [kpi_code], [target_value], [breach_direction], [rag_tolerance_pct],
        [effective_from], [effective_to]
    )
    VALUES ('Quality Maybole-KPI C1', 654.000000, 'OVER', 0.050000, '2026-01-01', NULL);
END;
*/

/* =============================================================
   07. VALIDATION / TEST EXECUTION
   =============================================================
-- A. Source values to confirm the working Maybole scope
SELECT
    [department], [lead_site], [syteline_lead_site],
    COUNT_BIG(*) AS [cases]
FROM [salesforce_staging].[customer_service]
WHERE COALESCE([is_deleted], 0) = 0
GROUP BY [department], [lead_site], [syteline_lead_site]
ORDER BY [cases] DESC;

-- B. Build without publishing
EXEC [salesforce].[usp_build_quality_mb_kpis_v1];

-- C. Historical weekly output
SELECT
    [kpi_code], COUNT_BIG(*) AS [rows], COUNT(DISTINCT [week_key]) AS [weeks],
    MIN([week_key]) AS [first_week], MAX([week_key]) AS [last_week],
    COUNT([target_value]) AS [target_rows], COUNT([variance_value]) AS [variance_rows]
FROM [salesforce].[kpi_result_quality_mb_v1]
GROUP BY [kpi_code]
ORDER BY [kpi_code];

SELECT *
FROM [salesforce].[kpi_result_quality_mb_v1]
ORDER BY [week_key], [kpi_code];

-- D. Publish to Salesforce domain result
EXEC [salesforce].[usp_publish_quality_mb_kpis_v1];

-- E. Final domain result
SELECT *
FROM [salesforce].[fact_kpi_result]
WHERE [kpi_code] IN ('Quality Maybole-KPI Q1', 'Quality Maybole-KPI C1')
ORDER BY [week_key], [kpi_code];

-- F. Duplicate check: expected zero rows
SELECT [week_key], [kpi_code], COUNT_BIG(*) AS [row_count]
FROM [salesforce].[fact_kpi_result]
WHERE [kpi_code] IN ('Quality Maybole-KPI Q1', 'Quality Maybole-KPI C1')
GROUP BY [week_key], [kpi_code]
HAVING COUNT_BIG(*) > 1;
*/
