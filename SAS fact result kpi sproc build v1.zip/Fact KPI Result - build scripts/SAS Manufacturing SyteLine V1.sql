/*
SAS MANUFACTURING - SYTELINE END-TO-END 4 KPI V1
================================================
Purpose
  Rebuild Manufacturing Production Value and Manufacturing OTIF directly from
  syteline_staging tables, enrich weekly actuals with reporting.kpi_control,
  and publish four KPI streams into syteline.fact_kpi_result.

KPI streams
  Bridgend Manuf-KPI P1  Production Value
  Maybole Manuf-KPI P1   Production Value
  Bridgend Manuf-KPI D1  OTIF to Delivery Date
  Maybole Manuf-KPI D1   OTIF to Delivery Date

Important
  - All new procedures and intermediate tables end in _v1.
  - Existing procedures and tables are not changed.
  - reporting.fact_kpi_result is not touched.
  - Historical weeks are rebuilt from dated SyteLine staging records.
  - Empty-source guards run before destructive refreshes.
  - reporting.dim_date is the canonical customer-week calendar.
*/

/* ============================================================
   00. TARGET CONTROL RECORDS
   ============================================================ */

DELETE FROM [reporting].[kpi_control]
WHERE [kpi_code] IN
(
    'Bridgend Manuf-KPI P1',
    'Maybole Manuf-KPI P1',
    'Bridgend Manuf-KPI D1',
    'Maybole Manuf-KPI D1'
);
GO

INSERT INTO [reporting].[kpi_control]
(
    [kpi_code], [kpi_name], [department], [kpi_category],
    [target_value], [uom], [breach_direction], [rag_tolerance_pct],
    [effective_from], [effective_to], [target_status], [target_source],
    [commentary], [created_timestamp], [updated_timestamp]
)
VALUES
('Bridgend Manuf-KPI P1','Production Value','Manufacturing Bridgend','Productivity',654750.000000,'£''s','UNDER',0.050000,'2020-01-01',NULL,'Approved','KPI targets.xlsx','Current controlled target.',SYSUTCDATETIME(),SYSUTCDATETIME()),
('Maybole Manuf-KPI P1','Production Value','Manufacturing Maybole','Productivity',174500.000000,'£''s','UNDER',0.050000,'2020-01-01',NULL,'Approved','KPI targets.xlsx','Current controlled target.',SYSUTCDATETIME(),SYSUTCDATETIME()),
('Bridgend Manuf-KPI D1','OTIF to Delivery Date','Manufacturing Bridgend','Delivery',0.950000,'Percentage','UNDER',0.050000,'2020-01-01',NULL,'Approved','KPI targets.xlsx','Stored on a zero-to-one scale.',SYSUTCDATETIME(),SYSUTCDATETIME()),
('Maybole Manuf-KPI D1','OTIF to Delivery Date','Manufacturing Maybole','Delivery',0.950000,'Percentage','UNDER',0.050000,'2020-01-01',NULL,'Approved','KPI targets.xlsx','Stored on a zero-to-one scale.',SYSUTCDATETIME(),SYSUTCDATETIME());
GO

/* ============================================================
   01. V1 OUTPUT TABLES
   ============================================================ */

IF OBJECT_ID('[syteline].[fact_manufacturing_production_value_detail_v1]','U') IS NULL
CREATE TABLE [syteline].[fact_manufacturing_production_value_detail_v1]
(
    [source_stream]       VARCHAR(40)   NOT NULL,
    [source_key]          VARCHAR(500)  NOT NULL,
    [site_ref]            VARCHAR(20)   NOT NULL,
    [transaction_date]    DATE          NOT NULL,
    [warehouse_prefix]    VARCHAR(10)   NOT NULL,
    [quantity_moved]      DECIMAL(18,4) NULL,
    [transfer_price]      DECIMAL(18,6) NULL,
    [transfer_value]      DECIMAL(18,4) NULL,
    [date_key]            INT           NULL,
    [closed_year]         INT           NULL,
    [closed_week]         INT           NULL,
    [week_key]            INT           NULL,
    [week_start_date]     DATE          NULL,
    [week_ending_date]    DATE          NULL,
    [created_timestamp]   DATETIME2(6)  NOT NULL
);
GO

IF OBJECT_ID('[syteline].[fact_manufacturing_production_value_weekly_v1]','U') IS NULL
CREATE TABLE [syteline].[fact_manufacturing_production_value_weekly_v1]
(
    [closed_year]          INT            NOT NULL,
    [closed_week]          INT            NOT NULL,
    [week_key]             INT            NOT NULL,
    [week_start_date]      DATE           NOT NULL,
    [week_ending_date]     DATE           NOT NULL,
    [warehouse_prefix]     VARCHAR(10)    NOT NULL,
    [site_name]            VARCHAR(100)   NOT NULL,
    [production_value]     DECIMAL(18,4)  NULL,
    [source_row_count]     BIGINT         NOT NULL,
    [calculation_timestamp] DATETIME2(6)  NOT NULL
);
GO

IF OBJECT_ID('[syteline].[fact_manufacturing_otif_event_v1]','U') IS NULL
CREATE TABLE [syteline].[fact_manufacturing_otif_event_v1]
(
    [event_id]             VARCHAR(255)   NOT NULL,
    [rowpointer]           VARCHAR(255)   NULL,
    [co_num]               VARCHAR(100)   NULL,
    [ship_date]            DATE           NULL,
    [acknowledged_date]    DATE           NULL,
    [driving_date]         DATE           NULL,
    [warehouse_prefix]     VARCHAR(10)    NOT NULL,
    [site_name]            VARCHAR(100)   NOT NULL,
    [otif_flag]             INT            NULL,
    [included_flag]         INT            NULL,
    [otif_status]           VARCHAR(30)    NOT NULL,
    [site_ref]              VARCHAR(20)    NOT NULL,
    [record_date]           DATETIME2(6)   NULL,
    [date_key]              INT            NULL,
    [closed_year]           INT            NULL,
    [closed_week]           INT            NULL,
    [week_key]              INT            NULL,
    [week_start_date]       DATE           NULL,
    [week_ending_date]      DATE           NULL,
    [created_timestamp]     DATETIME2(6)   NOT NULL
);
GO

IF OBJECT_ID('[syteline].[fact_manufacturing_otif_weekly_v1]','U') IS NULL
CREATE TABLE [syteline].[fact_manufacturing_otif_weekly_v1]
(
    [closed_year]                INT            NOT NULL,
    [closed_week]                INT            NOT NULL,
    [week_key]                   INT            NOT NULL,
    [week_start_date]            DATE           NOT NULL,
    [week_ending_date]           DATE           NOT NULL,
    [warehouse_prefix]           VARCHAR(10)    NOT NULL,
    [site_name]                  VARCHAR(100)   NOT NULL,
    [included_events]            BIGINT         NOT NULL,
    [on_time_in_full_events]     BIGINT         NOT NULL,
    [failed_events]              BIGINT         NOT NULL,
    [outstanding_events]         BIGINT         NOT NULL,
    [otif_percentage]            DECIMAL(18,6)  NULL,
    [source_row_count]           BIGINT         NOT NULL,
    [calculation_timestamp]      DATETIME2(6)   NOT NULL
);
GO

IF OBJECT_ID('[syteline].[kpi_result_manufacturing_v1]','U') IS NULL
CREATE TABLE [syteline].[kpi_result_manufacturing_v1]
(
    [closed_year]                    INT            NULL,
    [closed_week]                    INT            NULL,
    [kpi_name]                       VARCHAR(255)   NULL,
    [kpi_value]                      DECIMAL(18,6)  NULL,
    [organisational_unit]            VARCHAR(255)   NULL,
    [kpi_id]                         BIGINT         NULL,
    [kpi_category]                   VARCHAR(100)   NULL,
    [target_value]                   DECIMAL(18,6)  NULL,
    [breach_direction]               VARCHAR(20)    NULL,
    [week_key]                       INT            NULL,
    [kpi_code]                       VARCHAR(100)   NULL,
    [department]                     VARCHAR(255)   NULL,
    [measure]                        VARCHAR(500)   NULL,
    [measure_name]                   VARCHAR(500)   NULL,
    [uom]                            VARCHAR(50)    NULL,
    [sign]                           VARCHAR(100)   NULL,
    [sign_label]                     VARCHAR(100)   NULL,
    [commentary]                     VARCHAR(1000)  NULL,
    [variance_value]                 DECIMAL(18,6)  NULL,
    [performance_variance_value]     DECIMAL(18,6)  NULL,
    [rag_status]                     VARCHAR(20)    NULL,
    [data_status]                    VARCHAR(50)    NULL,
    [source_system]                  VARCHAR(100)   NULL,
    [source_object]                  VARCHAR(500)   NULL,
    [source_row_count]               BIGINT         NULL,
    [calculation_timestamp]          DATETIME2(6)   NULL
);
GO

/* ============================================================
   02. PRODUCTION VALUE DETAIL FROM STAGING
   Customer logic: job transactions + non-inventory invoices.
   This V1 deliberately uses all available historical dates.
   ============================================================ */
CREATE OR ALTER PROCEDURE [syteline].[usp_build_fact_manufacturing_production_value_detail_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @job_rows BIGINT;
    DECLARE @invoice_rows BIGINT;

    SELECT @job_rows = COUNT_BIG(*)
    FROM [syteline_staging].[jobtran_mst]
    WHERE [site_ref] = 'RBMW'
      AND TRY_CAST([trans_date] AS DATE) IS NOT NULL;

    SELECT @invoice_rows = COUNT_BIG(*)
    FROM [syteline_staging].[inv_hdr_mst]
    WHERE [site_ref] = 'RBMW'
      AND TRY_CAST([inv_date] AS DATE) IS NOT NULL;

    IF COALESCE(@job_rows,0) + COALESCE(@invoice_rows,0) = 0
        THROW 50001, 'Manufacturing Production Value V1 aborted: both dated SyteLine source streams are empty.', 1;

    TRUNCATE TABLE [syteline].[fact_manufacturing_production_value_detail_v1];

    ;WITH job_candidates AS
    (
        SELECT
            [source_stream]    = CAST('JOB_TRANSACTION' AS VARCHAR(40)),
            [source_key]       = CAST(CONCAT(t.[job],'|',t.[suffix],'|',CONVERT(VARCHAR(10),TRY_CAST(t.[trans_date] AS DATE),23),'|',t.[whse]) AS VARCHAR(500)),
            [site_ref]         = CAST(t.[site_ref] AS VARCHAR(20)),
            [transaction_date] = TRY_CAST(t.[trans_date] AS DATE),
            [warehouse_prefix] = UPPER(LTRIM(RTRIM(CAST(t.[whse] AS VARCHAR(10))))),
            [quantity_moved]   = TRY_CAST(t.[qty_moved] AS DECIMAL(18,4)),
            [transfer_price]   = CAST(
                CASE
                    WHEN COALESCE(TRY_CAST(coi.[uf_trnprice] AS DECIMAL(18,6)),TRY_CAST(ci.[uf_trnprice] AS DECIMAL(18,6)),TRY_CAST(ip.[unit_price6] AS DECIMAL(18,6)),0)=0
                    THEN COALESCE(TRY_CAST(ip2.[unit_price6] AS DECIMAL(18,6)),0)
                    ELSE COALESCE(TRY_CAST(coi.[uf_trnprice] AS DECIMAL(18,6)),TRY_CAST(ci.[uf_trnprice] AS DECIMAL(18,6)),TRY_CAST(ip.[unit_price6] AS DECIMAL(18,6)),0)
                END AS DECIMAL(18,6)),
            [price_rank] = ROW_NUMBER() OVER
            (
                PARTITION BY t.[job],t.[suffix],t.[trans_date],t.[whse]
                ORDER BY TRY_CAST(ip.[effect_date] AS DATETIME2(6)) DESC,
                         TRY_CAST(ip2.[effect_date] AS DATETIME2(6)) DESC
            )
        FROM [syteline_staging].[jobtran_mst] t
        INNER JOIN [syteline_staging].[job_mst] j
            ON j.[job]=t.[job] AND j.[suffix]=t.[suffix] AND j.[site_ref]=t.[site_ref]
        INNER JOIN [syteline_staging].[item_mst] i
            ON i.[item]=j.[item] AND i.[site_ref]=j.[site_ref]
        LEFT JOIN [syteline_staging].[coitem_mst] ci
            ON ci.[co_num]=j.[ord_num] AND ci.[co_line]=j.[ord_line]
           AND ci.[co_release]=j.[ord_release] AND ci.[site_ref]=j.[site_ref]
        LEFT JOIN [syteline_staging].[coitem_mst] coi
            ON coi.[co_num]=j.[uf_oldrefnum] AND coi.[co_line]=j.[uf_oldreflinsuf]
           AND coi.[co_release]=j.[uf_oldrefrelease] AND coi.[site_ref]=j.[site_ref]
        LEFT JOIN [syteline_staging].[itemprice_mst] ip
            ON ip.[item]=j.[item] AND ip.[site_ref]=j.[site_ref]
           AND TRY_CAST(ip.[effect_date] AS DATE) <= TRY_CAST(t.[trans_date] AS DATE)
        LEFT JOIN [syteline_staging].[itemprice_mst] ip2
            ON ip2.[item]=j.[item] AND ip2.[site_ref]=j.[site_ref]
           AND TRY_CAST(ip2.[unit_price6] AS DECIMAL(18,6)) > 0
           AND TRY_CAST(ip2.[effect_date] AS DATE) <= CAST(GETDATE() AS DATE)
        WHERE t.[site_ref]='RBMW'
          AND TRY_CAST(t.[trans_date] AS DATE) IS NOT NULL
          AND t.[trans_type] IN ('M','F','R')
          AND TRY_CAST(t.[suffix] AS INT)=0
          AND t.[job] NOT LIKE 'JC%'
          AND t.[loc] IS NOT NULL
          AND (j.[ord_num] IS NOT NULL OR i.[product_code] LIKE 'BEFG%' OR i.[product_code] LIKE 'MBFG%')
          AND UPPER(LTRIM(RTRIM(CAST(t.[whse] AS VARCHAR(10))))) IN ('BE','MB')
    ),
    invoice_candidates AS
    (
        SELECT
            [source_stream]    = CAST('NON_INVENTORY_INVOICE' AS VARCHAR(40)),
            [source_key]       = CAST(CONCAT(ini.[inv_num],'|',ini.[co_num],'|',ini.[co_line],'|',CONVERT(VARCHAR(10),TRY_CAST(inh.[inv_date] AS DATE),23)) AS VARCHAR(500)),
            [site_ref]         = CAST(itm.[site_ref] AS VARCHAR(20)),
            [transaction_date] = TRY_CAST(inh.[inv_date] AS DATE),
            [warehouse_prefix] = UPPER(LEFT(LTRIM(RTRIM(CAST(itm.[product_code] AS VARCHAR(100)))),2)),
            [quantity_moved]   = TRY_CAST(ini.[qty_invoiced] AS DECIMAL(18,4)),
            [transfer_price]   = CAST(
                CASE
                    WHEN inh.[bill_type]='N' AND TRY_CAST(ini.[qty_invoiced] AS DECIMAL(18,4))>0 THEN 0
                    WHEN COALESCE(TRY_CAST(coi.[uf_trnprice] AS DECIMAL(18,6)),TRY_CAST(ip.[unit_price6] AS DECIMAL(18,6)),0)=0
                    THEN COALESCE(TRY_CAST(ip2.[unit_price6] AS DECIMAL(18,6)),0)
                    ELSE COALESCE(TRY_CAST(coi.[uf_trnprice] AS DECIMAL(18,6)),TRY_CAST(ip.[unit_price6] AS DECIMAL(18,6)),0)
                END AS DECIMAL(18,6)),
            [price_rank] = ROW_NUMBER() OVER
            (
                PARTITION BY ini.[inv_num],ini.[co_num],ini.[co_line],inh.[inv_date]
                ORDER BY TRY_CAST(ip.[effect_date] AS DATETIME2(6)) DESC,
                         TRY_CAST(ip2.[effect_date] AS DATETIME2(6)) DESC
            )
        FROM [syteline_staging].[non_inventory_item_mst] itm
        INNER JOIN [syteline_staging].[inv_item_mst] ini
            ON ini.[item]=itm.[item] AND ini.[site_ref]=itm.[site_ref]
        INNER JOIN [syteline_staging].[inv_hdr_mst] inh
            ON inh.[inv_num]=ini.[inv_num] AND inh.[site_ref]=ini.[site_ref]
        INNER JOIN [syteline_staging].[coitem_mst] coi
            ON coi.[co_num]=ini.[co_num] AND coi.[co_line]=ini.[co_line]
           AND coi.[co_release]=ini.[co_release] AND coi.[site_ref]=ini.[site_ref]
        LEFT JOIN [syteline_staging].[itemprice_mst] ip
            ON ip.[item]=ini.[item] AND ip.[site_ref]=ini.[site_ref]
           AND TRY_CAST(ip.[effect_date] AS DATE) <= TRY_CAST(inh.[inv_date] AS DATE)
        LEFT JOIN [syteline_staging].[itemprice_mst] ip2
            ON ip2.[item]=ini.[item] AND ip2.[site_ref]=ini.[site_ref]
           AND TRY_CAST(ip2.[unit_price6] AS DECIMAL(18,6))>0
           AND TRY_CAST(ip2.[effect_date] AS DATE)<=CAST(GETDATE() AS DATE)
        WHERE itm.[site_ref]='RBMW'
          AND TRY_CAST(inh.[inv_date] AS DATE) IS NOT NULL
          AND UPPER(LEFT(LTRIM(RTRIM(CAST(itm.[product_code] AS VARCHAR(100)))),2)) IN ('BE','MB')
          AND UPPER(CAST(itm.[product_code] AS VARCHAR(100))) NOT LIKE '%CAR%'
    ),
    source_union AS
    (
        SELECT [source_stream],[source_key],[site_ref],[transaction_date],[warehouse_prefix],[quantity_moved],[transfer_price]
        FROM job_candidates WHERE [price_rank]=1
        UNION ALL
        SELECT [source_stream],[source_key],[site_ref],[transaction_date],[warehouse_prefix],[quantity_moved],[transfer_price]
        FROM invoice_candidates WHERE [price_rank]=1
    )
    INSERT INTO [syteline].[fact_manufacturing_production_value_detail_v1]
    (
        [source_stream],[source_key],[site_ref],[transaction_date],[warehouse_prefix],
        [quantity_moved],[transfer_price],[transfer_value],[date_key],[closed_year],
        [closed_week],[week_key],[week_start_date],[week_ending_date],[created_timestamp]
    )
    SELECT
        s.[source_stream],s.[source_key],s.[site_ref],s.[transaction_date],s.[warehouse_prefix],
        s.[quantity_moved],s.[transfer_price],
        CAST(s.[quantity_moved]*s.[transfer_price] AS DECIMAL(18,4)),
        d.[date_key],d.[customer_year],d.[customer_week_no],d.[week_key],
        d.[week_start_date],d.[week_end_date],SYSUTCDATETIME()
    FROM source_union s
    LEFT JOIN [reporting].[dim_date] d
        ON d.[calendar_date]=s.[transaction_date]
    WHERE s.[warehouse_prefix] IN ('BE','MB');

    IF NOT EXISTS (SELECT 1 FROM [syteline].[fact_manufacturing_production_value_detail_v1])
        THROW 50002, 'Manufacturing Production Value V1 produced zero detail records; refresh requires investigation.', 1;
END;
GO

/* ============================================================
   03. PRODUCTION VALUE WEEKLY
   ============================================================ */
CREATE OR ALTER PROCEDURE [syteline].[usp_build_fact_manufacturing_production_value_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [syteline].[fact_manufacturing_production_value_detail_v1] WHERE [week_key] IS NOT NULL)
        THROW 50003, 'Production Value V1 detail contains no calendar-matched rows.', 1;

    TRUNCATE TABLE [syteline].[fact_manufacturing_production_value_weekly_v1];

    INSERT INTO [syteline].[fact_manufacturing_production_value_weekly_v1]
    (
        [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],
        [warehouse_prefix],[site_name],[production_value],[source_row_count],[calculation_timestamp]
    )
    SELECT
        [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],
        [warehouse_prefix],
        CASE [warehouse_prefix] WHEN 'BE' THEN 'Bridgend' ELSE 'Maybole' END,
        CAST(SUM([transfer_value]) AS DECIMAL(18,4)),
        COUNT_BIG(*),SYSUTCDATETIME()
    FROM [syteline].[fact_manufacturing_production_value_detail_v1]
    WHERE [week_key] IS NOT NULL
    GROUP BY [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],[warehouse_prefix];
END;
GO

/* ============================================================
   04. OTIF EVENT FACT FROM STAGING
   ============================================================ */
CREATE OR ALTER PROCEDURE [syteline].[usp_build_fact_manufacturing_otif_event_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [syteline_staging].[sas_otif_mst]
        WHERE UPPER(LTRIM(RTRIM(CAST([site_ref] AS VARCHAR(20)))))='RBMW'
          AND UPPER(LTRIM(RTRIM(CAST([whse] AS VARCHAR(10))))) IN ('BE','MB')
    )
        THROW 50004, 'Manufacturing OTIF V1 aborted: syteline_staging.sas_otif_mst has no RBMW BE/MB rows.', 1;

    TRUNCATE TABLE [syteline].[fact_manufacturing_otif_event_v1];

    ;WITH standardised AS
    (
        SELECT
            [rowpointer]        = CAST([rowpointer] AS VARCHAR(255)),
            [co_num]            = LTRIM(RTRIM(CAST([co_num] AS VARCHAR(100)))),
            [ship_date]         = TRY_CAST([ship_date] AS DATE),
            [acknowledged_date] = TRY_CAST([acknowledged_date] AS DATE),
            [warehouse_prefix]  = UPPER(LTRIM(RTRIM(CAST([whse] AS VARCHAR(10))))),
            [otif_flag]         = TRY_CAST([otif] AS INT),
            [included_flag]     = TRY_CAST([included] AS INT),
            [site_ref]          = UPPER(LTRIM(RTRIM(CAST([site_ref] AS VARCHAR(20))))),
            [record_date]       = TRY_CAST([record_date] AS DATETIME2(6)),
            [line_no]           = CAST([line] AS VARCHAR(100)),
            [group_name]        = CAST([group] AS VARCHAR(255))
        FROM [syteline_staging].[sas_otif_mst]
        WHERE UPPER(LTRIM(RTRIM(CAST([site_ref] AS VARCHAR(20)))))='RBMW'
          AND UPPER(LTRIM(RTRIM(CAST([whse] AS VARCHAR(10))))) IN ('BE','MB')
    ),
    shaped AS
    (
        SELECT s.*,
            [driving_date] = COALESCE(s.[ship_date],s.[acknowledged_date]),
            [otif_status] = CASE
                WHEN s.[ship_date] IS NULL THEN 'OUTSTANDING'
                WHEN s.[otif_flag]=0 THEN 'NOT ON TIME IN FULL'
                ELSE 'ON TIME IN FULL' END,
            [event_id] = COALESCE(NULLIF(s.[rowpointer],''),
                CONVERT(VARCHAR(64),HASHBYTES('SHA2_256',CONCAT(
                    COALESCE(s.[site_ref],''),'|',COALESCE(s.[warehouse_prefix],''),'|',COALESCE(s.[co_num],''),'|',
                    COALESCE(CONVERT(VARCHAR(10),s.[acknowledged_date],23),''),'|',
                    COALESCE(CONVERT(VARCHAR(10),s.[ship_date],23),''),'|',
                    COALESCE(s.[line_no],''),'|',COALESCE(s.[group_name],''))),2))
        FROM standardised s
    ),
    deduped AS
    (
        SELECT *,ROW_NUMBER() OVER
        (
            PARTITION BY [event_id]
            ORDER BY [record_date] DESC,[ship_date] DESC
        ) AS [rn]
        FROM shaped
    )
    INSERT INTO [syteline].[fact_manufacturing_otif_event_v1]
    (
        [event_id],[rowpointer],[co_num],[ship_date],[acknowledged_date],[driving_date],
        [warehouse_prefix],[site_name],[otif_flag],[included_flag],[otif_status],
        [site_ref],[record_date],[date_key],[closed_year],[closed_week],[week_key],
        [week_start_date],[week_ending_date],[created_timestamp]
    )
    SELECT
        x.[event_id],x.[rowpointer],x.[co_num],x.[ship_date],x.[acknowledged_date],x.[driving_date],
        x.[warehouse_prefix],CASE x.[warehouse_prefix] WHEN 'BE' THEN 'Bridgend' ELSE 'Maybole' END,
        x.[otif_flag],x.[included_flag],x.[otif_status],x.[site_ref],x.[record_date],
        d.[date_key],d.[customer_year],d.[customer_week_no],d.[week_key],d.[week_start_date],d.[week_end_date],SYSUTCDATETIME()
    FROM deduped x
    LEFT JOIN [reporting].[dim_date] d
        ON d.[calendar_date]=x.[driving_date]
    WHERE x.[rn]=1;
END;
GO

/* ============================================================
   05. OTIF WEEKLY
   ============================================================ */
CREATE OR ALTER PROCEDURE [syteline].[usp_build_fact_manufacturing_otif_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [syteline].[fact_manufacturing_otif_event_v1] WHERE [week_key] IS NOT NULL)
        THROW 50005, 'Manufacturing OTIF V1 event fact contains no calendar-matched rows.', 1;

    TRUNCATE TABLE [syteline].[fact_manufacturing_otif_weekly_v1];

    INSERT INTO [syteline].[fact_manufacturing_otif_weekly_v1]
    (
        [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],
        [warehouse_prefix],[site_name],[included_events],[on_time_in_full_events],
        [failed_events],[outstanding_events],[otif_percentage],[source_row_count],[calculation_timestamp]
    )
    SELECT
        [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],
        [warehouse_prefix],MAX([site_name]),
        SUM(CASE WHEN [included_flag]=1 THEN 1 ELSE 0 END),
        SUM(CASE WHEN [included_flag]=1 AND [otif_status]='ON TIME IN FULL' THEN 1 ELSE 0 END),
        SUM(CASE WHEN [included_flag]=1 AND [otif_status]='NOT ON TIME IN FULL' THEN 1 ELSE 0 END),
        SUM(CASE WHEN [included_flag]=1 AND [otif_status]='OUTSTANDING' THEN 1 ELSE 0 END),
        CAST(CASE WHEN SUM(CASE WHEN [included_flag]=1 THEN 1 ELSE 0 END)>0
             THEN 1.0*SUM(CASE WHEN [included_flag]=1 AND [otif_status]='ON TIME IN FULL' THEN 1 ELSE 0 END)
                  /SUM(CASE WHEN [included_flag]=1 THEN 1 ELSE 0 END) END AS DECIMAL(18,6)),
        COUNT_BIG(*),SYSUTCDATETIME()
    FROM [syteline].[fact_manufacturing_otif_event_v1]
    WHERE [week_key] IS NOT NULL
    GROUP BY [closed_year],[closed_week],[week_key],[week_start_date],[week_ending_date],[warehouse_prefix];
END;
GO

/* ============================================================
   06. BUILD FOUR KPI STREAMS USING reporting.kpi_control
   ============================================================ */
CREATE OR ALTER PROCEDURE [syteline].[usp_build_kpi_result_manufacturing_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [syteline].[fact_manufacturing_production_value_weekly_v1])
        THROW 50006, 'Manufacturing KPI V1 aborted: Production Value weekly fact is empty.', 1;
    IF NOT EXISTS (SELECT 1 FROM [syteline].[fact_manufacturing_otif_weekly_v1])
        THROW 50007, 'Manufacturing KPI V1 aborted: OTIF weekly fact is empty.', 1;

    TRUNCATE TABLE [syteline].[kpi_result_manufacturing_v1];

    ;WITH actuals AS
    (
        SELECT
            p.[closed_year],p.[closed_week],p.[week_key],p.[week_ending_date],p.[warehouse_prefix],
            [kpi_code]=CASE p.[warehouse_prefix] WHEN 'BE' THEN 'Bridgend Manuf-KPI P1' ELSE 'Maybole Manuf-KPI P1' END,
            [kpi_name]=CAST('Production Value' AS VARCHAR(255)),
            [kpi_category]=CAST('Productivity' AS VARCHAR(100)),
            [organisational_unit]=CASE p.[warehouse_prefix] WHEN 'BE' THEN 'Manufacturing Bridgend' ELSE 'Manufacturing Maybole' END,
            [measure]=CAST('From SyteLine - Production Value' AS VARCHAR(500)),
            [uom]=CAST('£''s' AS VARCHAR(50)),
            [kpi_value]=CAST(p.[production_value] AS DECIMAL(18,6)),
            [source_object]=CAST('syteline.fact_manufacturing_production_value_weekly_v1' AS VARCHAR(500)),
            p.[source_row_count]
        FROM [syteline].[fact_manufacturing_production_value_weekly_v1] p
        UNION ALL
        SELECT
            o.[closed_year],o.[closed_week],o.[week_key],o.[week_ending_date],o.[warehouse_prefix],
            CASE o.[warehouse_prefix] WHEN 'BE' THEN 'Bridgend Manuf-KPI D1' ELSE 'Maybole Manuf-KPI D1' END,
            'OTIF to Delivery Date','Delivery',
            CASE o.[warehouse_prefix] WHEN 'BE' THEN 'Manufacturing Bridgend' ELSE 'Manufacturing Maybole' END,
            'From SyteLine - OTIF Delivery Statistics','Percentage',
            CAST(o.[otif_percentage] AS DECIMAL(18,6)),
            'syteline.fact_manufacturing_otif_weekly_v1',o.[source_row_count]
        FROM [syteline].[fact_manufacturing_otif_weekly_v1] o
    ),
    configured AS
    (
        SELECT a.*,c.[kpi_id],c.[target_value],UPPER(c.[breach_direction]) AS [breach_direction],
               COALESCE(c.[rag_tolerance_pct],0.05) AS [rag_tolerance_pct]
        FROM actuals a
        LEFT JOIN [reporting].[kpi_control] c
          ON c.[kpi_code]=a.[kpi_code]
         AND a.[week_ending_date]>=c.[effective_from]
         AND (c.[effective_to] IS NULL OR a.[week_ending_date]<=c.[effective_to])
         AND c.[target_status]='Approved'
    )
    INSERT INTO [syteline].[kpi_result_manufacturing_v1]
    (
        [closed_year],[closed_week],[kpi_name],[kpi_value],[organisational_unit],[kpi_id],
        [kpi_category],[target_value],[breach_direction],[week_key],[kpi_code],[department],
        [measure],[measure_name],[uom],[sign],[sign_label],[commentary],[variance_value],
        [performance_variance_value],[rag_status],[data_status],[source_system],[source_object],
        [source_row_count],[calculation_timestamp]
    )
    SELECT
        x.[closed_year],x.[closed_week],x.[kpi_name],x.[kpi_value],x.[organisational_unit],x.[kpi_id],
        x.[kpi_category],x.[target_value],x.[breach_direction],x.[week_key],x.[kpi_code],x.[organisational_unit],
        x.[measure],x.[measure],x.[uom],
        CASE WHEN x.[breach_direction]='UNDER' THEN 'Under Breach' WHEN x.[breach_direction]='OVER' THEN 'Over Breach' END,
        CASE WHEN x.[breach_direction]='UNDER' THEN 'Under Breach' WHEN x.[breach_direction]='OVER' THEN 'Over Breach' END,
        CONCAT('Historical weekly ',x.[kpi_name],'. Source rows=',x.[source_row_count]),
        CASE WHEN x.[target_value] IS NULL OR x.[kpi_value] IS NULL THEN NULL ELSE x.[kpi_value]-x.[target_value] END,
        CASE WHEN x.[target_value] IS NULL OR x.[kpi_value] IS NULL THEN NULL
             WHEN x.[breach_direction]='OVER' THEN x.[target_value]-x.[kpi_value]
             ELSE x.[kpi_value]-x.[target_value] END,
        CASE WHEN x.[kpi_value] IS NULL THEN 'No Data'
             WHEN x.[target_value] IS NULL OR x.[breach_direction] IS NULL THEN 'TBC'
             WHEN x.[breach_direction]='UNDER' AND x.[kpi_value]>=x.[target_value] THEN 'G'
             WHEN x.[breach_direction]='UNDER' AND x.[kpi_value]>=x.[target_value]*(1-x.[rag_tolerance_pct]) THEN 'A'
             WHEN x.[breach_direction]='OVER' AND x.[kpi_value]<=x.[target_value] THEN 'G'
             WHEN x.[breach_direction]='OVER' AND x.[kpi_value]<=x.[target_value]*(1+x.[rag_tolerance_pct]) THEN 'A'
             ELSE 'R' END,
        CASE WHEN x.[kpi_value] IS NULL THEN 'No Data'
             WHEN x.[target_value] IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'SyteLine',x.[source_object],x.[source_row_count],SYSUTCDATETIME()
    FROM configured x;
END;
GO

/* ============================================================
   07. PUBLISH TO DOMAIN fact_kpi_result ONLY
   ============================================================ */
CREATE OR ALTER PROCEDURE [syteline].[usp_publish_manufacturing_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [syteline].[fact_kpi_result]
    WHERE [kpi_code] IN
    (
        'Bridgend Manuf-KPI P1','Maybole Manuf-KPI P1',
        'Bridgend Manuf-KPI D1','Maybole Manuf-KPI D1'
    );

    INSERT INTO [syteline].[fact_kpi_result]
    (
        [closed_year],[closed_week],[kpi_name],[kpi_value],[organisational_unit],[kpi_id],
        [kpi_category],[target_value],[breach_direction],[week_key],[kpi_code],[department],
        [measure],[measure_name],[uom],[sign],[sign_label],[commentary],[variance_value],
        [performance_variance_value],[rag_status],[data_status],[source_system],[source_object],
        [source_row_count],[calculation_timestamp]
    )
    SELECT
        [closed_year],[closed_week],[kpi_name],[kpi_value],[organisational_unit],[kpi_id],
        [kpi_category],[target_value],[breach_direction],[week_key],[kpi_code],[department],
        [measure],[measure_name],[uom],[sign],[sign_label],[commentary],[variance_value],
        [performance_variance_value],[rag_status],[data_status],[source_system],[source_object],
        [source_row_count],[calculation_timestamp]
    FROM [syteline].[kpi_result_manufacturing_v1];
END;
GO

/* ============================================================
   08. ORCHESTRATORS
   ============================================================ */
CREATE OR ALTER PROCEDURE [syteline].[usp_build_manufacturing_all_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[usp_build_fact_manufacturing_production_value_detail_v1];
    EXEC [syteline].[usp_build_fact_manufacturing_production_value_weekly_v1];
    EXEC [syteline].[usp_build_fact_manufacturing_otif_event_v1];
    EXEC [syteline].[usp_build_fact_manufacturing_otif_weekly_v1];
    EXEC [syteline].[usp_build_kpi_result_manufacturing_v1];
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[usp_build_and_publish_manufacturing_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[usp_build_manufacturing_all_v1];
    EXEC [syteline].[usp_publish_manufacturing_kpis_v1];
END;
GO

/* ============================================================
   09. VALIDATION QUERIES - RUN MANUALLY
   ============================================================

-- Confirm environment
SELECT DB_NAME() AS current_database, CURRENT_USER AS current_user;

-- Source volumes
SELECT 'jobtran_mst' AS source_name,COUNT_BIG(*) AS row_count FROM [syteline_staging].[jobtran_mst]
UNION ALL SELECT 'inv_hdr_mst',COUNT_BIG(*) FROM [syteline_staging].[inv_hdr_mst]
UNION ALL SELECT 'sas_otif_mst',COUNT_BIG(*) FROM [syteline_staging].[sas_otif_mst];

-- Build without publishing
EXEC [syteline].[usp_build_manufacturing_all_v1];

-- Historical weekly coverage
SELECT 'Production Value' AS fact_name,warehouse_prefix,COUNT_BIG(*) AS result_rows,
       COUNT(DISTINCT week_key) AS reporting_weeks,MIN(week_key) AS first_week,MAX(week_key) AS last_week
FROM [syteline].[fact_manufacturing_production_value_weekly_v1]
GROUP BY warehouse_prefix
UNION ALL
SELECT 'OTIF',warehouse_prefix,COUNT_BIG(*),COUNT(DISTINCT week_key),MIN(week_key),MAX(week_key)
FROM [syteline].[fact_manufacturing_otif_weekly_v1]
GROUP BY warehouse_prefix;

-- KPI preview: actual, target, variance and RAG
SELECT *
FROM [syteline].[kpi_result_manufacturing_v1]
ORDER BY [week_key],[kpi_code];

-- Acceptance summary
SELECT [kpi_code],COUNT_BIG(*) AS result_rows,COUNT(DISTINCT [week_key]) AS reporting_weeks,
       MIN([week_key]) AS first_week,MAX([week_key]) AS last_week,
       COUNT([target_value]) AS rows_with_target,COUNT([variance_value]) AS rows_with_variance,
       SUM(CASE WHEN [rag_status] IN ('G','A','R') THEN 1 ELSE 0 END) AS rows_with_rag
FROM [syteline].[kpi_result_manufacturing_v1]
GROUP BY [kpi_code]
ORDER BY [kpi_code];

-- Publish to the domain result only
EXEC [syteline].[usp_publish_manufacturing_kpis_v1];

-- Final domain output
SELECT *
FROM [syteline].[fact_kpi_result]
WHERE [kpi_code] IN
(
    'Bridgend Manuf-KPI P1','Maybole Manuf-KPI P1',
    'Bridgend Manuf-KPI D1','Maybole Manuf-KPI D1'
)
ORDER BY [week_key],[kpi_code];

-- Duplicate check: expected zero rows
SELECT [week_key],[kpi_code],COUNT_BIG(*) AS duplicate_count
FROM [syteline].[fact_kpi_result]
WHERE [kpi_code] IN
(
    'Bridgend Manuf-KPI P1','Maybole Manuf-KPI P1',
    'Bridgend Manuf-KPI D1','Maybole Manuf-KPI D1'
)
GROUP BY [week_key],[kpi_code]
HAVING COUNT_BIG(*)>1;

-- OTIF reconciliation: expected classification_difference = 0
SELECT *,[included_events]-([on_time_in_full_events]+[failed_events]+[outstanding_events]) AS classification_difference
FROM [syteline].[fact_manufacturing_otif_weekly_v1]
ORDER BY [week_key],[warehouse_prefix];

*/
