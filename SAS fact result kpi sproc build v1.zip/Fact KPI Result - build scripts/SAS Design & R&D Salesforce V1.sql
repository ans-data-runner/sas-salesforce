/*
SAS DESIGN & R&D KPI STORED PROCEDURES - V1
===========================================
Purpose
-------
Creates new _v1 procedures while leaving all existing procedures and tables in place.

Source:
  salesforce_staging.proposal_request

Domain facts:
  salesforce.fact_proposal
  salesforce.fact_proposal_delivery
  salesforce.fact_quality_weekly

KPI staging/result:
  salesforce.kpi_result_design_rnd

Domain publication target:
  salesforce.fact_kpi_result

Shared controls:
  reporting.dim_date
  reporting.kpi_control

KPIs:
  PROP_VOLUME      Volume Completed
  PROP_OTIF        OTIF %
  PROP_REJECTIONS  Design Rejections
  PROP_VALUE       Opportunity Value per Proposal

Notes
-----
1. Existing non-v1 procedures are not altered.
2. The v1 fact build validates the source before truncating Gold facts.
3. Targets, breach direction, tolerance and display metadata come from reporting.kpi_control.
4. This script stops at salesforce.fact_kpi_result. It does not update reporting.fact_kpi_result.
*/

/* =============================================================
   1. SEED / REFRESH DESIGN & R&D KPI CONTROL RECORDS
   =============================================================
   Confirmed working targets:
     PROP_VOLUME      28
     PROP_OTIF        0.95
     PROP_REJECTIONS  0
     PROP_VALUE       171000

   Percentage measures use a 0-1 scale.
   ============================================================= */

DELETE FROM [reporting].[kpi_control]
WHERE [kpi_code] IN
(
    'PROP_VOLUME',
    'PROP_OTIF',
    'PROP_REJECTIONS',
    'PROP_VALUE'
);

INSERT INTO [reporting].[kpi_control]
(
    [kpi_code],
    [kpi_name],
    [department],
    [kpi_category],
    [measure_name],
    [measure],
    [uom],
    [target_value],
    [breach_direction],
    [sign],
    [sign_label],
    [amber_tolerance],
    [source_system],
    [source_object],
    [is_active],
    [effective_from],
    [effective_to],
    [created_timestamp],
    [updated_timestamp]
)
VALUES
(
    'PROP_VOLUME',
    'Volume Completed',
    'Design & R&D',
    'Productivity',
    'Volume Completed',
    'Count of proposals completed in the reporting week',
    'Count',
    28.000000,
    'UNDER',
    'Under Breach',
    'Under Breach',
    0.050000,
    'Salesforce',
    'salesforce.fact_proposal',
    1,
    '2025-01-01',
    NULL,
    SYSUTCDATETIME(),
    SYSUTCDATETIME()
),
(
    'PROP_OTIF',
    'OTIF %',
    'Design & R&D',
    'Delivery',
    'OTIF %',
    'Percentage of completed proposals delivered on or before the complete-by date',
    'Percentage',
    0.950000,
    'UNDER',
    'Under Breach',
    'Under Breach',
    0.050000,
    'Salesforce',
    'salesforce.fact_proposal + salesforce.fact_proposal_delivery',
    1,
    '2025-01-01',
    NULL,
    SYSUTCDATETIME(),
    SYSUTCDATETIME()
),
(
    'PROP_REJECTIONS',
    'Design Rejections',
    'Design & R&D',
    'Quality',
    'Design Rejections',
    'Number of rejected drawings for proposals completed in the reporting week',
    'Count',
    0.000000,
    'OVER',
    'Over Breach',
    'Over Breach',
    0.050000,
    'Salesforce',
    'salesforce.fact_quality_weekly',
    1,
    '2025-01-01',
    NULL,
    SYSUTCDATETIME(),
    SYSUTCDATETIME()
),
(
    'PROP_VALUE',
    'Opportunity Value per Proposal',
    'Design & R&D',
    'Cost',
    'Opportunity Value per Proposal',
    'Average estimated opportunity value per completed proposal',
    'GBP',
    171000.000000,
    'UNDER',
    'Under Breach',
    'Under Breach',
    0.050000,
    'Salesforce',
    'salesforce.fact_proposal',
    1,
    '2025-01-01',
    NULL,
    SYSUTCDATETIME(),
    SYSUTCDATETIME()
);
GO

/* =============================================================
   2. BUILD DESIGN & R&D FACTS - V1
   ============================================================= */

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_design_rnd_facts_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @source_rows BIGINT;
    DECLARE @active_source_rows BIGINT;

    SELECT
        @source_rows = COUNT_BIG(*),
        @active_source_rows = SUM
        (
            CASE
                WHEN COALESCE([is_deleted], 0) = 0
                 AND COALESCE
                 (
                     NULLIF(LTRIM(RTRIM(TRY_CAST([proposal_number] AS VARCHAR(255)))), ''),
                     NULLIF(LTRIM(RTRIM(TRY_CAST([name] AS VARCHAR(255)))), ''),
                     TRY_CAST([id] AS VARCHAR(255))
                 ) IS NOT NULL
                THEN 1 ELSE 0
            END
        )
    FROM [salesforce_staging].[proposal_request];

    IF COALESCE(@source_rows, 0) = 0
       OR COALESCE(@active_source_rows, 0) = 0
    BEGIN
        THROW 50001,
              'ABORTED: salesforce_staging.proposal_request is empty or contains no active usable proposals. Existing Design & R&D facts were preserved.',
              1;
    END;

    TRUNCATE TABLE [salesforce].[fact_proposal];
    TRUNCATE TABLE [salesforce].[fact_proposal_delivery];
    TRUNCATE TABLE [salesforce].[fact_quality_weekly];

    /* ---------------------------------------------------------
       Proposal fact
       --------------------------------------------------------- */
    ;WITH [proposal_latest] AS
    (
        SELECT
            [proposal_request].[id],
            [proposal_request].[is_deleted],
            [proposal_request].[name],
            [proposal_request].[proposal_number],
            [proposal_request].[project_name],
            [proposal_request].[record_type_id],
            [proposal_request].[sales_division],
            [proposal_request].[sales_region],
            [proposal_request].[opened_date],
            [proposal_request].[created_date],
            [proposal_request].[closed_date],
            [proposal_request].[complete_by_date],
            [proposal_request].[currency_iso_code],
            [proposal_request].[estimated_value],
            [proposal_request].[rejected_drawings],
            [proposal_request].[last_modified_date],
            [proposal_request].[system_modstamp],
            ROW_NUMBER() OVER
            (
                PARTITION BY [proposal_request].[id]
                ORDER BY
                    [proposal_request].[system_modstamp] DESC,
                    [proposal_request].[last_modified_date] DESC,
                    [proposal_request].[created_date] DESC
            ) AS [row_number]
        FROM [salesforce_staging].[proposal_request] AS [proposal_request]
    ),
    [proposal_source] AS
    (
        SELECT
            COALESCE
            (
                NULLIF(LTRIM(RTRIM(TRY_CAST([proposal_latest].[proposal_number] AS VARCHAR(255)))), ''),
                NULLIF(LTRIM(RTRIM(TRY_CAST([proposal_latest].[name] AS VARCHAR(255)))), ''),
                TRY_CAST([proposal_latest].[id] AS VARCHAR(255))
            ) AS [proposal_request_no],
            TRY_CAST([proposal_latest].[project_name] AS VARCHAR(500)) AS [project_name],
            TRY_CAST([proposal_latest].[record_type_id] AS VARCHAR(100)) AS [record_type],
            TRY_CAST([proposal_latest].[sales_division] AS VARCHAR(255)) AS [sales_division],
            TRY_CAST([proposal_latest].[sales_region] AS VARCHAR(255)) AS [geography],
            COALESCE
            (
                TRY_CAST([proposal_latest].[opened_date] AS DATE),
                TRY_CAST([proposal_latest].[created_date] AS DATE)
            ) AS [opened_date],
            TRY_CAST([proposal_latest].[closed_date] AS DATE) AS [closed_date],
            TRY_CAST([proposal_latest].[complete_by_date] AS DATE) AS [due_date],
            TRY_CAST([proposal_latest].[currency_iso_code] AS VARCHAR(10)) AS [currency_code],
            TRY_CAST([proposal_latest].[estimated_value] AS DECIMAL(18,2)) AS [estimated_value_native],
            COALESCE(TRY_CAST([proposal_latest].[rejected_drawings] AS INT), 0) AS [rejected_drawings_count]
        FROM [proposal_latest]
        WHERE [proposal_latest].[row_number] = 1
          AND COALESCE([proposal_latest].[is_deleted], 0) = 0
    ),
    [proposal_shaped] AS
    (
        SELECT
            [proposal_source].*,
            CONVERT
            (
                BIGINT,
                SUBSTRING(HASHBYTES('SHA2_256', [proposal_source].[proposal_request_no]), 1, 8)
            ) & CONVERT(BIGINT, 9223372036854775807) AS [proposal_id]
        FROM [proposal_source]
        WHERE [proposal_source].[proposal_request_no] IS NOT NULL
    )
    INSERT INTO [salesforce].[fact_proposal]
    (
        [proposal_id],
        [proposal_request_no],
        [project_name],
        [record_type],
        [sales_division],
        [geography],
        [opened_date],
        [closed_date],
        [closed_date_key],
        [week_key],
        [currency_code],
        [estimated_value_native],
        [rejected_drawings_count],
        [exchange_rate_to_gbp],
        [estimated_value_gbp],
        [is_closed],
        [created_utc],
        [updated_utc]
    )
    SELECT
        [proposal_shaped].[proposal_id],
        [proposal_shaped].[proposal_request_no],
        [proposal_shaped].[project_name],
        [proposal_shaped].[record_type],
        [proposal_shaped].[sales_division],
        [proposal_shaped].[geography],
        [proposal_shaped].[opened_date],
        [proposal_shaped].[closed_date],
        [date_dimension].[date_key],
        [date_dimension].[week_key],
        [proposal_shaped].[currency_code],
        [proposal_shaped].[estimated_value_native],
        [proposal_shaped].[rejected_drawings_count],
        TRY_CAST(1.0 AS DECIMAL(18,8)),
        [proposal_shaped].[estimated_value_native],
        TRY_CAST
        (
            CASE WHEN [proposal_shaped].[closed_date] IS NULL THEN 0 ELSE 1 END
            AS BIT
        ),
        SYSUTCDATETIME(),
        SYSUTCDATETIME()
    FROM [proposal_shaped]
    LEFT JOIN [reporting].[dim_date] AS [date_dimension]
        ON [date_dimension].[calendar_date] = [proposal_shaped].[closed_date];

    /* ---------------------------------------------------------
       Proposal delivery fact
       --------------------------------------------------------- */
    ;WITH [proposal_latest] AS
    (
        SELECT
            [proposal_request].[id],
            [proposal_request].[is_deleted],
            [proposal_request].[name],
            [proposal_request].[proposal_number],
            [proposal_request].[complete_by_date],
            [proposal_request].[closed_date],
            [proposal_request].[created_date],
            [proposal_request].[last_modified_date],
            [proposal_request].[system_modstamp],
            ROW_NUMBER() OVER
            (
                PARTITION BY [proposal_request].[id]
                ORDER BY
                    [proposal_request].[system_modstamp] DESC,
                    [proposal_request].[last_modified_date] DESC,
                    [proposal_request].[created_date] DESC
            ) AS [row_number]
        FROM [salesforce_staging].[proposal_request] AS [proposal_request]
    ),
    [delivery_source] AS
    (
        SELECT
            COALESCE
            (
                NULLIF(LTRIM(RTRIM(TRY_CAST([proposal_latest].[proposal_number] AS VARCHAR(255)))), ''),
                NULLIF(LTRIM(RTRIM(TRY_CAST([proposal_latest].[name] AS VARCHAR(255)))), ''),
                TRY_CAST([proposal_latest].[id] AS VARCHAR(255))
            ) AS [proposal_request_no],
            TRY_CAST([proposal_latest].[complete_by_date] AS DATE) AS [due_date],
            TRY_CAST([proposal_latest].[closed_date] AS DATE) AS [completed_date]
        FROM [proposal_latest]
        WHERE [proposal_latest].[row_number] = 1
          AND COALESCE([proposal_latest].[is_deleted], 0) = 0
    ),
    [delivery_shaped] AS
    (
        SELECT
            [delivery_source].*,
            CONVERT
            (
                BIGINT,
                SUBSTRING(HASHBYTES('SHA2_256', [delivery_source].[proposal_request_no]), 1, 8)
            ) & CONVERT(BIGINT, 9223372036854775807) AS [proposal_id]
        FROM [delivery_source]
        WHERE [delivery_source].[proposal_request_no] IS NOT NULL
    )
    INSERT INTO [salesforce].[fact_proposal_delivery]
    (
        [proposal_id],
        [proposal_request_no],
        [due_date],
        [due_date_key],
        [completed_date],
        [completed_date_key],
        [on_time_flag],
        [is_on_time],
        [created_utc]
    )
    SELECT
        [delivery_shaped].[proposal_id],
        [delivery_shaped].[proposal_request_no],
        [delivery_shaped].[due_date],
        TRY_CAST(CONVERT(CHAR(8), [delivery_shaped].[due_date], 112) AS INT),
        [delivery_shaped].[completed_date],
        TRY_CAST(CONVERT(CHAR(8), [delivery_shaped].[completed_date], 112) AS INT),
        CASE
            WHEN [delivery_shaped].[completed_date] IS NOT NULL
             AND [delivery_shaped].[due_date] IS NOT NULL
             AND [delivery_shaped].[completed_date] <= [delivery_shaped].[due_date]
            THEN 1 ELSE 0
        END,
        TRY_CAST
        (
            CASE
                WHEN [delivery_shaped].[completed_date] IS NOT NULL
                 AND [delivery_shaped].[due_date] IS NOT NULL
                 AND [delivery_shaped].[completed_date] <= [delivery_shaped].[due_date]
                THEN 1 ELSE 0
            END
            AS BIT
        ),
        SYSUTCDATETIME()
    FROM [delivery_shaped];

    /* ---------------------------------------------------------
       Weekly quality fact
       --------------------------------------------------------- */
    INSERT INTO [salesforce].[fact_quality_weekly]
    (
        [customer_year],
        [customer_week_no],
        [week_key],
        [rejected_drawings_count],
        [source],
        [record_count],
        [created_utc]
    )
    SELECT
        [date_dimension].[customer_year],
        [date_dimension].[customer_week_no],
        [date_dimension].[week_key],
        SUM([proposal_fact].[rejected_drawings_count]),
        'proposal_request',
        COUNT_BIG(*),
        SYSUTCDATETIME()
    FROM [salesforce].[fact_proposal] AS [proposal_fact]
    INNER JOIN [reporting].[dim_date] AS [date_dimension]
        ON [date_dimension].[date_key] = [proposal_fact].[closed_date_key]
    WHERE [proposal_fact].[is_closed] = 1
    GROUP BY
        [date_dimension].[customer_year],
        [date_dimension].[customer_week_no],
        [date_dimension].[week_key];

    SELECT
        @source_rows AS [source_rows],
        @active_source_rows AS [active_source_rows],
        (SELECT COUNT_BIG(*) FROM [salesforce].[fact_proposal]) AS [fact_proposal_rows],
        (SELECT COUNT_BIG(*) FROM [salesforce].[fact_proposal_delivery]) AS [fact_proposal_delivery_rows],
        (SELECT COUNT_BIG(*) FROM [salesforce].[fact_quality_weekly]) AS [fact_quality_weekly_rows];
END;
GO

/* =============================================================
   3. BUILD DESIGN & R&D KPI RESULT - V1
   ============================================================= */

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_kpi_result_design_rnd_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [reporting].[kpi_control]
        WHERE [kpi_code] IN
        (
            'PROP_VOLUME',
            'PROP_OTIF',
            'PROP_REJECTIONS',
            'PROP_VALUE'
        )
        AND [is_active] = 1
    )
    BEGIN
        THROW 50002,
              'ABORTED: Active Design & R&D KPI control rows are missing from reporting.kpi_control.',
              1;
    END;

    TRUNCATE TABLE [salesforce].[kpi_result_design_rnd];

    ;WITH [week_dates] AS
    (
        SELECT
            [week_key],
            MAX([week_end_date]) AS [week_end_date]
        FROM [reporting].[dim_date]
        GROUP BY [week_key]
    ),
    [proposal_weekly] AS
    (
        SELECT
            [date_dimension].[customer_year] AS [closed_year],
            [date_dimension].[customer_week_no] AS [closed_week],
            [date_dimension].[week_key],
            COUNT_BIG(*) AS [volume_completed],
            AVG(TRY_CAST([proposal_fact].[estimated_value_gbp] AS DECIMAL(18,6)))
                AS [opportunity_value_per_proposal],
            COUNT_BIG(*) AS [source_rows]
        FROM [salesforce].[fact_proposal] AS [proposal_fact]
        INNER JOIN [reporting].[dim_date] AS [date_dimension]
            ON [date_dimension].[date_key] = [proposal_fact].[closed_date_key]
        WHERE [proposal_fact].[is_closed] = 1
        GROUP BY
            [date_dimension].[customer_year],
            [date_dimension].[customer_week_no],
            [date_dimension].[week_key]
    ),
    [otif_weekly] AS
    (
        SELECT
            [date_dimension].[customer_year] AS [closed_year],
            [date_dimension].[customer_week_no] AS [closed_week],
            [date_dimension].[week_key],
            AVG(TRY_CAST([proposal_delivery].[on_time_flag] AS DECIMAL(18,6))) AS [otif_value],
            COUNT_BIG(*) AS [source_rows]
        FROM [salesforce].[fact_proposal] AS [proposal_fact]
        INNER JOIN [salesforce].[fact_proposal_delivery] AS [proposal_delivery]
            ON [proposal_delivery].[proposal_id] = [proposal_fact].[proposal_id]
        INNER JOIN [reporting].[dim_date] AS [date_dimension]
            ON [date_dimension].[date_key] = [proposal_fact].[closed_date_key]
        WHERE [proposal_fact].[is_closed] = 1
          AND [proposal_delivery].[completed_date] IS NOT NULL
          AND [proposal_delivery].[due_date] IS NOT NULL
        GROUP BY
            [date_dimension].[customer_year],
            [date_dimension].[customer_week_no],
            [date_dimension].[week_key]
    ),
    [raw_kpi] AS
    (
        SELECT
            [proposal_weekly].[closed_year],
            [proposal_weekly].[closed_week],
            [proposal_weekly].[week_key],
            'PROP_VOLUME' AS [kpi_code],
            TRY_CAST([proposal_weekly].[volume_completed] AS DECIMAL(18,6)) AS [kpi_value],
            [proposal_weekly].[source_rows],
            'salesforce.fact_proposal' AS [source_object]
        FROM [proposal_weekly]

        UNION ALL

        SELECT
            [otif_weekly].[closed_year],
            [otif_weekly].[closed_week],
            [otif_weekly].[week_key],
            'PROP_OTIF',
            [otif_weekly].[otif_value],
            [otif_weekly].[source_rows],
            'salesforce.fact_proposal + salesforce.fact_proposal_delivery'
        FROM [otif_weekly]

        UNION ALL

        SELECT
            [quality_weekly].[customer_year],
            [quality_weekly].[customer_week_no],
            [quality_weekly].[week_key],
            'PROP_REJECTIONS',
            TRY_CAST([quality_weekly].[rejected_drawings_count] AS DECIMAL(18,6)),
            [quality_weekly].[record_count],
            'salesforce.fact_quality_weekly'
        FROM [salesforce].[fact_quality_weekly] AS [quality_weekly]

        UNION ALL

        SELECT
            [proposal_weekly].[closed_year],
            [proposal_weekly].[closed_week],
            [proposal_weekly].[week_key],
            'PROP_VALUE',
            [proposal_weekly].[opportunity_value_per_proposal],
            [proposal_weekly].[source_rows],
            'salesforce.fact_proposal'
        FROM [proposal_weekly]
    ),
    [targeted] AS
    (
        SELECT
            [raw_kpi].*,
            [control].[kpi_name],
            [control].[department],
            [control].[kpi_category],
            [control].[measure_name],
            [control].[measure],
            [control].[uom],
            [control].[target_value],
            UPPER([control].[breach_direction]) AS [breach_direction],
            [control].[sign],
            [control].[sign_label],
            COALESCE([control].[amber_tolerance], 0.05) AS [amber_tolerance],
            [control].[source_system],
            [week_dates].[week_end_date]
        FROM [raw_kpi]
        INNER JOIN [week_dates]
            ON [week_dates].[week_key] = [raw_kpi].[week_key]
        LEFT JOIN [reporting].[kpi_control] AS [control]
            ON [control].[kpi_code] = [raw_kpi].[kpi_code]
           AND [control].[is_active] = 1
           AND
           (
               [control].[effective_from] IS NULL
               OR [week_dates].[week_end_date] >= [control].[effective_from]
           )
           AND
           (
               [control].[effective_to] IS NULL
               OR [week_dates].[week_end_date] <= [control].[effective_to]
           )
    )
    INSERT INTO [salesforce].[kpi_result_design_rnd]
    (
        [closed_year],
        [closed_week],
        [kpi_name],
        [kpi_value],
        [organisational_unit],
        [kpi_id],
        [kpi_category],
        [target_value],
        [breach_direction],
        [week_key],
        [kpi_code],
        [department],
        [measure],
        [measure_name],
        [uom],
        [sign],
        [sign_label],
        [commentary],
        [variance_value],
        [performance_variance_value],
        [rag_status],
        [data_status],
        [source_system],
        [source_object],
        [source_row_count],
        [calculation_timestamp]
    )
    SELECT
        [targeted].[closed_year],
        [targeted].[closed_week],
        COALESCE([targeted].[kpi_name], [targeted].[kpi_code]),
        [targeted].[kpi_value],
        'Design & R&D',
        NULL,
        [targeted].[kpi_category],
        [targeted].[target_value],
        [targeted].[breach_direction],
        [targeted].[week_key],
        [targeted].[kpi_code],
        COALESCE([targeted].[department], 'Design & R&D'),
        [targeted].[measure],
        [targeted].[measure_name],
        [targeted].[uom],
        [targeted].[sign],
        [targeted].[sign_label],
        'Design & R&D v1: actuals calculated from Proposal Request; metadata and targets supplied by reporting.kpi_control.',
        CASE
            WHEN [targeted].[kpi_value] IS NULL OR [targeted].[target_value] IS NULL
            THEN NULL
            ELSE [targeted].[kpi_value] - [targeted].[target_value]
        END,
        CASE
            WHEN [targeted].[kpi_value] IS NULL
              OR [targeted].[target_value] IS NULL
              OR [targeted].[breach_direction] IS NULL
            THEN NULL
            WHEN [targeted].[breach_direction] = 'OVER'
            THEN [targeted].[target_value] - [targeted].[kpi_value]
            ELSE [targeted].[kpi_value] - [targeted].[target_value]
        END,
        CASE
            WHEN [targeted].[kpi_value] IS NULL THEN 'No Data'
            WHEN [targeted].[target_value] IS NULL
              OR [targeted].[breach_direction] IS NULL THEN 'TBC'
            WHEN [targeted].[breach_direction] = 'UNDER'
             AND [targeted].[kpi_value] >= [targeted].[target_value] THEN 'G'
            WHEN [targeted].[breach_direction] = 'UNDER'
             AND [targeted].[kpi_value]
                 >= [targeted].[target_value] * (1.0 - [targeted].[amber_tolerance]) THEN 'A'
            WHEN [targeted].[breach_direction] = 'OVER'
             AND [targeted].[kpi_value] <= [targeted].[target_value] THEN 'G'
            WHEN [targeted].[breach_direction] = 'OVER'
             AND [targeted].[kpi_value]
                 <= [targeted].[target_value] * (1.0 + [targeted].[amber_tolerance]) THEN 'A'
            ELSE 'R'
        END,
        CASE
            WHEN [targeted].[kpi_value] IS NULL THEN 'No Data'
            WHEN [targeted].[target_value] IS NULL THEN 'Actual - Target TBC'
            ELSE 'Actual'
        END,
        COALESCE([targeted].[source_system], 'Salesforce'),
        [targeted].[source_object],
        [targeted].[source_rows],
        SYSUTCDATETIME()
    FROM [targeted];

    SELECT
        [kpi_code],
        COUNT_BIG(*) AS [kpi_rows],
        COUNT(DISTINCT [week_key]) AS [reporting_weeks],
        MIN([week_key]) AS [first_week],
        MAX([week_key]) AS [last_week],
        COUNT([target_value]) AS [rows_with_target],
        COUNT([variance_value]) AS [rows_with_variance]
    FROM [salesforce].[kpi_result_design_rnd]
    GROUP BY [kpi_code]
    ORDER BY [kpi_code];
END;
GO

/* =============================================================
   4. PUBLISH DESIGN & R&D KPI RESULT TO SALESFORCE DOMAIN - V1
   ============================================================= */

CREATE OR ALTER PROCEDURE [salesforce].[usp_publish_design_rnd_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [salesforce].[kpi_result_design_rnd]
        WHERE [kpi_code] IN
        (
            'PROP_VOLUME',
            'PROP_OTIF',
            'PROP_REJECTIONS',
            'PROP_VALUE'
        )
    )
    BEGIN
        THROW 50003,
              'ABORTED: salesforce.kpi_result_design_rnd contains no Design & R&D KPI rows. Existing salesforce.fact_kpi_result rows were preserved.',
              1;
    END;

    DELETE FROM [salesforce].[fact_kpi_result]
    WHERE [kpi_code] IN
    (
        'PROP_VOLUME',
        'PROP_OTIF',
        'PROP_REJECTIONS',
        'PROP_VALUE'
    );

    INSERT INTO [salesforce].[fact_kpi_result]
    (
        [closed_year],
        [closed_week],
        [kpi_name],
        [kpi_value],
        [organisational_unit],
        [kpi_id],
        [kpi_category],
        [target_value],
        [breach_direction],
        [week_key],
        [kpi_code],
        [department],
        [measure],
        [measure_name],
        [uom],
        [sign],
        [sign_label],
        [commentary],
        [variance_value],
        [performance_variance_value],
        [rag_status],
        [data_status],
        [source_system],
        [source_object],
        [source_row_count],
        [calculation_timestamp]
    )
    SELECT
        [closed_year],
        [closed_week],
        [kpi_name],
        [kpi_value],
        [organisational_unit],
        [kpi_id],
        [kpi_category],
        [target_value],
        [breach_direction],
        [week_key],
        [kpi_code],
        [department],
        [measure],
        [measure_name],
        [uom],
        [sign],
        [sign_label],
        [commentary],
        [variance_value],
        [performance_variance_value],
        [rag_status],
        [data_status],
        [source_system],
        [source_object],
        [source_row_count],
        [calculation_timestamp]
    FROM [salesforce].[kpi_result_design_rnd]
    WHERE [kpi_code] IN
    (
        'PROP_VOLUME',
        'PROP_OTIF',
        'PROP_REJECTIONS',
        'PROP_VALUE'
    );

    SELECT
        [kpi_code],
        COUNT_BIG(*) AS [published_rows],
        COUNT(DISTINCT [week_key]) AS [published_weeks],
        MIN([week_key]) AS [first_week],
        MAX([week_key]) AS [last_week]
    FROM [salesforce].[fact_kpi_result]
    WHERE [kpi_code] IN
    (
        'PROP_VOLUME',
        'PROP_OTIF',
        'PROP_REJECTIONS',
        'PROP_VALUE'
    )
    GROUP BY [kpi_code]
    ORDER BY [kpi_code];
END;
GO

/* =============================================================
   5. OPTIONAL ORCHESTRATORS - V1
   ============================================================= */

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_design_rnd_all_v1]
AS
BEGIN
    SET NOCOUNT ON;

    EXEC [salesforce].[usp_build_design_rnd_facts_v1];
    EXEC [salesforce].[usp_build_kpi_result_design_rnd_v1];
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_and_publish_design_rnd_all_v1]
AS
BEGIN
    SET NOCOUNT ON;

    EXEC [salesforce].[usp_build_design_rnd_all_v1];
    EXEC [salesforce].[usp_publish_design_rnd_kpis_v1];
END;
GO

/* =============================================================
   6. TEST / VALIDATION QUERIES
   ============================================================= */

/* Environment check */
SELECT
    DB_NAME() AS [current_database],
    CURRENT_USER AS [current_user];

/* Source check */
SELECT
    COUNT_BIG(*) AS [source_rows],
    COUNT(DISTINCT [id]) AS [distinct_ids],
    COUNT(DISTINCT CASE WHEN [closed_date] IS NOT NULL THEN [id] END)
        AS [distinct_closed_ids],
    MIN(TRY_CAST([closed_date] AS DATE)) AS [first_closed_date],
    MAX(TRY_CAST([closed_date] AS DATE)) AS [last_closed_date]
FROM [salesforce_staging].[proposal_request]
WHERE COALESCE([is_deleted], 0) = 0;

/* Control check */
SELECT
    [kpi_code],
    [kpi_name],
    [target_value],
    [breach_direction],
    [amber_tolerance],
    [effective_from],
    [effective_to],
    [is_active]
FROM [reporting].[kpi_control]
WHERE [kpi_code] IN
(
    'PROP_VOLUME',
    'PROP_OTIF',
    'PROP_REJECTIONS',
    'PROP_VALUE'
)
ORDER BY [kpi_code], [effective_from];

/* Initial build without publishing */
-- EXEC [salesforce].[usp_build_design_rnd_all_v1];

/* Atomic fact validation */
SELECT
    'fact_proposal' AS [fact_name],
    COUNT_BIG(*) AS [row_count],
    COUNT(DISTINCT [week_key]) AS [reporting_weeks],
    MIN([week_key]) AS [first_week],
    MAX([week_key]) AS [last_week]
FROM [salesforce].[fact_proposal]

UNION ALL

SELECT
    'fact_proposal_delivery',
    COUNT_BIG(*),
    NULL,
    NULL,
    NULL
FROM [salesforce].[fact_proposal_delivery]

UNION ALL

SELECT
    'fact_quality_weekly',
    COUNT_BIG(*),
    COUNT(DISTINCT [week_key]),
    MIN([week_key]),
    MAX([week_key])
FROM [salesforce].[fact_quality_weekly];

/* KPI result validation */
SELECT
    [closed_year],
    [closed_week],
    [week_key],
    [kpi_code],
    [kpi_name],
    [kpi_value],
    [target_value],
    [variance_value],
    [performance_variance_value],
    [rag_status],
    [data_status],
    [source_row_count]
FROM [salesforce].[kpi_result_design_rnd]
ORDER BY [week_key], [kpi_code];

/* KPI summary */
SELECT
    [kpi_code],
    COUNT_BIG(*) AS [result_rows],
    COUNT(DISTINCT [week_key]) AS [reporting_weeks],
    MIN([week_key]) AS [first_week],
    MAX([week_key]) AS [last_week],
    COUNT([target_value]) AS [rows_with_target],
    COUNT([variance_value]) AS [rows_with_variance],
    SUM(CASE WHEN [rag_status] = 'TBC' THEN 1 ELSE 0 END) AS [tbc_rows]
FROM [salesforce].[kpi_result_design_rnd]
GROUP BY [kpi_code]
ORDER BY [kpi_code];

/* Publish after validation */
-- EXEC [salesforce].[usp_publish_design_rnd_kpis_v1];

/* Domain fact_kpi_result validation */
SELECT
    [closed_year],
    [closed_week],
    [week_key],
    [kpi_code],
    [kpi_name],
    [kpi_value],
    [target_value],
    [variance_value],
    [performance_variance_value],
    [rag_status],
    [data_status],
    [source_system],
    [source_object],
    [source_row_count]
FROM [salesforce].[fact_kpi_result]
WHERE [kpi_code] IN
(
    'PROP_VOLUME',
    'PROP_OTIF',
    'PROP_REJECTIONS',
    'PROP_VALUE'
)
ORDER BY [week_key], [kpi_code];

/* Duplicate check: expected 0 rows */
SELECT
    [week_key],
    [kpi_code],
    COUNT_BIG(*) AS [duplicate_count]
FROM [salesforce].[fact_kpi_result]
WHERE [kpi_code] IN
(
    'PROP_VOLUME',
    'PROP_OTIF',
    'PROP_REJECTIONS',
    'PROP_VALUE'
)
GROUP BY [week_key], [kpi_code]
HAVING COUNT_BIG(*) > 1;
