/* SCHEMA CORRECTION NOTE
   All domain facts, KPI result tables, publishers and stored procedures in this file use [salesforce].
   Shared calendar joins use [reporting].[dim_date].
   No [dbo] references remain. Existing non-v1 procedures are not modified.
*/
/* ACTIVE SAS GOLD V1 DEPLOYMENT
   Stored procedures versioned with _v1.
   KPI business logic and historical weekly aggregation retained from supplied script.
*/
/*
SAS SOP DELIVERY OTIF - END-TO-END GOLD KPI BUILD V1
=====================================================
Warehouse: wh_sas_gold
Confirmed source: salesforce_staging.order_tracking
Confirmed snake_case fields:
  id, is_deleted, name, created_date, last_modified_date,
  project_name, infor_order_reference,
  days_in_cleansing, days_in_customer_sign_off

KPIs:
  SOP-KPI-D1  OTIF - Order Cleansing
  SOP-KPI-D2  OTIF - Order Sign Off

Rules retained from SOP mapping:
  Cleansing on time = days_in_cleansing <= 1
  Sign Off on time  = days_in_customer_sign_off <= 5
  Weekly driver     = created_date
  KPI               = on-time eligible records / eligible records
  Target            = 95%
  Breach direction  = UNDER

Mitigation:
  A later historic flags notebook used <=2 days for Cleansing. This script uses <=1
  because the primary SOP mapping/dashboard definition uses 1 day. The threshold is
  explicitly recorded in KPI commentary for UAT.
*/

IF OBJECT_ID('salesforce.fact_sop_order_tracking','U') IS NULL
CREATE TABLE salesforce.fact_sop_order_tracking
(
 order_id VARCHAR(255) NOT NULL,
 order_tracking_no VARCHAR(255) NULL,
 project_name VARCHAR(500) NULL,
 infor_order_reference VARCHAR(500) NULL,
 created_date DATE NULL,
 days_in_cleansing DECIMAL(18,6) NULL,
 days_in_signoff DECIMAL(18,6) NULL,
 cleansing_on_time_flag BIT NULL,
 signoff_on_time_flag BIT NULL,
 date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
 week_start_date DATE NULL, week_ending_date DATE NULL,
 source_row_count BIGINT NOT NULL, created_ts DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('salesforce.fact_sop_delivery_otif_weekly','U') IS NULL
CREATE TABLE salesforce.fact_sop_delivery_otif_weekly
(
 closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
 week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
 kpi_code VARCHAR(100) NOT NULL, kpi_name VARCHAR(255) NOT NULL,
 eligible_orders BIGINT NOT NULL, on_time_orders BIGINT NOT NULL,
 otif_percentage DECIMAL(18,6) NULL,
 source_row_count BIGINT NOT NULL, calculation_timestamp DATETIME2(6) NOT NULL
);
GO

IF OBJECT_ID('salesforce.kpi_result_sop_delivery','U') IS NULL
CREATE TABLE salesforce.kpi_result_sop_delivery
(
 closed_year INT NULL, closed_week INT NULL, kpi_name VARCHAR(255) NULL,
 kpi_value DECIMAL(18,6) NULL, organisational_unit VARCHAR(255) NULL,
 kpi_id BIGINT NULL, kpi_category VARCHAR(100) NULL,
 target_value DECIMAL(18,6) NULL, breach_direction VARCHAR(20) NULL,
 week_key INT NULL, kpi_code VARCHAR(100) NULL, department VARCHAR(255) NULL,
 measure VARCHAR(500) NULL, measure_name VARCHAR(500) NULL, uom VARCHAR(50) NULL,
 sign VARCHAR(100) NULL, sign_label VARCHAR(100) NULL, commentary VARCHAR(1000) NULL,
 variance_value DECIMAL(18,6) NULL, performance_variance_value DECIMAL(18,6) NULL,
 rag_status VARCHAR(20) NULL, data_status VARCHAR(50) NULL,
 source_system VARCHAR(100) NULL, source_object VARCHAR(500) NULL,
 source_row_count BIGINT NULL, calculation_timestamp DATETIME2(6) NULL
);
GO

CREATE OR ALTER PROCEDURE salesforce.sp_build_fact_sop_order_tracking_v1
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE salesforce.fact_sop_order_tracking;

 ;WITH src AS
 (
   SELECT
     order_id=CAST(o.id AS VARCHAR(255)),
     order_tracking_no=CAST(o.name AS VARCHAR(255)),
     project_name=CAST(o.project_name AS VARCHAR(500)),
     infor_order_reference=CAST(o.infor_order_reference AS VARCHAR(500)),
     created_date=CAST(o.created_date AS DATE),
     days_in_cleansing=TRY_CAST(o.days_in_cleansing AS DECIMAL(18,6)),
     days_in_signoff=TRY_CAST(o.days_in_customer_sign_off AS DECIMAL(18,6)),
     rn=ROW_NUMBER() OVER(PARTITION BY o.id ORDER BY COALESCE(o.last_modified_date,o.created_date) DESC)
   FROM salesforce_staging.order_tracking o
   WHERE COALESCE(o.is_deleted,0)=0 AND o.id IS NOT NULL
 )
 INSERT INTO salesforce.fact_sop_order_tracking
 SELECT s.order_id,s.order_tracking_no,s.project_name,s.infor_order_reference,s.created_date,
        s.days_in_cleansing,s.days_in_signoff,
        CAST(CASE WHEN s.days_in_cleansing IS NULL THEN NULL WHEN s.days_in_cleansing<=1 THEN 1 ELSE 0 END AS BIT),
        CAST(CASE WHEN s.days_in_signoff IS NULL THEN NULL WHEN s.days_in_signoff<=5 THEN 1 ELSE 0 END AS BIT),
        d.date_key,d.customer_year,d.customer_week_no,d.week_key,d.week_start_date,d.week_end_date,
        1,SYSUTCDATETIME()
 FROM src s
 LEFT JOIN reporting.dim_date d ON d.calendar_date=s.created_date
 WHERE s.rn=1;
END;
GO

CREATE OR ALTER PROCEDURE salesforce.sp_build_fact_sop_delivery_otif_weekly_v1
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE salesforce.fact_sop_delivery_otif_weekly;

 INSERT INTO salesforce.fact_sop_delivery_otif_weekly
 SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
        'SOP-KPI-D1','OTIF - Order Cleansing',
        COUNT(cleansing_on_time_flag),SUM(CAST(cleansing_on_time_flag AS BIGINT)),
        CAST(1.0*SUM(CAST(cleansing_on_time_flag AS BIGINT))/NULLIF(COUNT(cleansing_on_time_flag),0) AS DECIMAL(18,6)),
        SUM(source_row_count),SYSUTCDATETIME()
 FROM salesforce.fact_sop_order_tracking
 WHERE week_key IS NOT NULL
 GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date
 UNION ALL
 SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
        'SOP-KPI-D2','OTIF - Order Sign Off',
        COUNT(signoff_on_time_flag),SUM(CAST(signoff_on_time_flag AS BIGINT)),
        CAST(1.0*SUM(CAST(signoff_on_time_flag AS BIGINT))/NULLIF(COUNT(signoff_on_time_flag),0) AS DECIMAL(18,6)),
        SUM(source_row_count),SYSUTCDATETIME()
 FROM salesforce.fact_sop_order_tracking
 WHERE week_key IS NOT NULL
 GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date;
END;
GO

CREATE OR ALTER PROCEDURE salesforce.sp_build_kpi_result_sop_delivery_v1
AS
BEGIN
 SET NOCOUNT ON;
 TRUNCATE TABLE salesforce.kpi_result_sop_delivery;

 INSERT INTO salesforce.kpi_result_sop_delivery
 SELECT closed_year,closed_week,kpi_name,otif_percentage,'Sales Order Processing',NULL,'Delivery',
        CAST(0.95 AS DECIMAL(18,6)),'UNDER',week_key,kpi_code,'Sales Order Processing',
        CASE WHEN kpi_code='SOP-KPI-D1' THEN 'Order Cleansing completed within 1 day'
             ELSE 'Order Sign Off completed within 5 days' END,
        kpi_name,'Percentage','Under Breach','Under Breach',
        CONCAT('Eligible=',eligible_orders,'; on time=',on_time_orders,
               CASE WHEN kpi_code='SOP-KPI-D1' THEN '; threshold <=1 day; historic <=2 day variant requires UAT.'
                    ELSE '; threshold <=5 days.' END),
        CASE WHEN otif_percentage IS NULL THEN NULL ELSE otif_percentage-0.95 END,
        CASE WHEN otif_percentage IS NULL THEN NULL ELSE otif_percentage-0.95 END,
        CASE WHEN otif_percentage IS NULL THEN 'No Data'
             WHEN otif_percentage>=0.95 THEN 'G'
             WHEN otif_percentage>=0.9025 THEN 'A' ELSE 'R' END,
        CASE WHEN otif_percentage IS NULL THEN 'No Data' ELSE 'Actual' END,
        'Salesforce','salesforce_staging.order_tracking',source_row_count,SYSUTCDATETIME()
 FROM salesforce.fact_sop_delivery_otif_weekly;
END;
GO

CREATE OR ALTER PROCEDURE salesforce.sp_build_sop_delivery_all_v1
AS
BEGIN
 EXEC salesforce.sp_build_fact_sop_order_tracking_v1;
 EXEC salesforce.sp_build_fact_sop_delivery_otif_weekly_v1;
 EXEC salesforce.sp_build_kpi_result_sop_delivery_v1;
END;
GO

CREATE OR ALTER PROCEDURE salesforce.sp_publish_sop_delivery_kpis_v1
AS
BEGIN
 DELETE FROM salesforce.fact_kpi_result WHERE kpi_code IN ('SOP-KPI-D1','SOP-KPI-D2');
 INSERT INTO salesforce.fact_kpi_result
 (
  closed_year,closed_week,kpi_name,kpi_value,organisational_unit,kpi_id,kpi_category,
  target_value,breach_direction,week_key,kpi_code,department,measure,measure_name,uom,
  sign,sign_label,commentary,variance_value,performance_variance_value,rag_status,
  data_status,source_system,source_object,source_row_count,calculation_timestamp
 )
 SELECT closed_year,closed_week,kpi_name,kpi_value,organisational_unit,kpi_id,kpi_category,
        target_value,breach_direction,week_key,kpi_code,department,measure,measure_name,uom,
        sign,sign_label,commentary,variance_value,performance_variance_value,rag_status,
        data_status,source_system,source_object,source_row_count,calculation_timestamp
 FROM salesforce.kpi_result_sop_delivery;
END;
GO

CREATE OR ALTER PROCEDURE salesforce.sp_build_and_publish_sop_delivery_all_v1
AS
BEGIN
 EXEC salesforce.sp_build_sop_delivery_all_v1;
 EXEC salesforce.sp_publish_sop_delivery_kpis_v1;
END;
GO

/* TEST
EXEC salesforce.sp_build_sop_delivery_all_v1;
SELECT * FROM salesforce.fact_sop_order_tracking ORDER BY created_date DESC;
SELECT * FROM salesforce.fact_sop_delivery_otif_weekly ORDER BY week_key,kpi_code;
SELECT * FROM salesforce.kpi_result_sop_delivery ORDER BY week_key,kpi_code;
EXEC salesforce.sp_publish_sop_delivery_kpis_v1;
SELECT * FROM salesforce.fact_kpi_result WHERE kpi_code IN ('SOP-KPI-D1','SOP-KPI-D2') ORDER BY week_key,kpi_code;
*/
