/* SCHEMA CORRECTION NOTE
   All domain facts, KPI result tables, publishers and stored procedures in this file use [syteline].
   Shared calendar joins use [reporting].[dim_date].
   No [dbo] references remain. Existing non-v1 procedures are not modified.
*/
/* VERSIONING NOTE
   All stored procedures in this deployment script use the required _v1 suffix.
   Business logic, tables, KPI codes, targets and source filters are unchanged
   from the supplied active Product Engineering result script.
*/
/*
SAS PRODUCT ENGINEERING PRODUCTIVITY - END-TO-END GOLD KPI BUILD V3
===================================================================
Warehouse: wh_sas_gold

Required sources:
    [syteline_staging].[coitem_mst]
    [syteline_staging].[item_mst]
    [reporting].[dim_date]

Gold outputs:
    syteline.fact_product_engineering_planning_load_snapshot
    syteline.fact_product_engineering_new_items_snapshot
    syteline.fact_product_engineering_items_completed_daily
    syteline.fact_product_engineering_productivity_daily
    syteline.fact_product_engineering_productivity_weekly
    syteline.kpi_result_product_engineering_productivity
    syteline.fact_kpi_result

KPI outputs:
    Product Eng - BE-KPI P1
    Product Eng - MB-KPI P1

Confirmed source population:
    site_ref = RBMW
    co_num begins C
    stat = O
    whse IN (BE, MB)
    item BOM status IN (B, D, E, P)

Planning Load:
    Count of currently eligible open order lines by warehouse.

New Items:
    Count of eligible open order lines with uf_ordereddate equal to the previous
    working day represented by the preceding available snapshot date.

Working productivity formula:
    Items Completed = Prior Planning Load + Current New Items - Current Planning Load
    Daily Productivity = Items Completed / Daily Capacity
    Weekly Productivity = average of available daily productivity values

Capacity assumptions retained from the customer workbook evidence:
    BE = 31.00 (4 resources x 7.75)
    MB = 23.25 (3 resources x 7.75)

MITIGATIONS
-----------
1. The literal Excel formula was not exposed. The formula is labelled
   ESTIMATED_FORMULA_V1 and data_status remains Working Logic - Approval Required.
2. Negative Items Completed values are retained for investigation.
3. The first snapshot for each warehouse cannot produce Items Completed because no
   prior Planning Load exists.
4. Daily snapshots are persistent. Re-running the same site/date/hour replaces only
   that capture.
5. Target = 0.80 and breach_direction = UNDER for both sites.
6. No syteline.dim_kpi dependency.
7. Explicit 26-column publication to syteline.fact_kpi_result.
8. Run the source-column validation section before compiling if physical names differ.
*/

IF SCHEMA_ID('syteline_staging') IS NULL EXEC('CREATE SCHEMA [syteline_staging]');
GO

IF OBJECT_ID('[syteline].[fact_kpi_result]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_kpi_result]
    (
        closed_year INT NULL, closed_week INT NULL, kpi_name VARCHAR(255) NULL,
        kpi_value DECIMAL(18,6) NULL, organisational_unit VARCHAR(255) NULL,
        kpi_id BIGINT NULL, kpi_category VARCHAR(100) NULL,
        target_value DECIMAL(18,6) NULL, breach_direction VARCHAR(20) NULL,
        week_key INT NULL, kpi_code VARCHAR(100) NULL, department VARCHAR(255) NULL,
        measure VARCHAR(500) NULL, measure_name VARCHAR(500) NULL, uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL, sign_label VARCHAR(100) NULL, commentary VARCHAR(1000) NULL,
        variance_value DECIMAL(18,6) NULL, performance_variance_value DECIMAL(18,6) NULL,
        rag_status VARCHAR(20) NULL, data_status VARCHAR(50) NULL,
        source_system VARCHAR(100) NULL, source_object VARCHAR(500) NULL,
        source_row_count BIGINT NULL, calculation_timestamp DATETIME2(6) NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[product_engineering_productivity_capacity]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[product_engineering_productivity_capacity]
    (
        warehouse_prefix VARCHAR(10) NOT NULL,
        daily_capacity DECIMAL(18,6) NOT NULL,
        target_value DECIMAL(18,6) NOT NULL,
        is_approved BIT NOT NULL,
        capacity_basis VARCHAR(500) NOT NULL,
        updated_ts DATETIME2(6) NOT NULL
    );

    INSERT INTO [syteline].[product_engineering_productivity_capacity]
    VALUES
        ('BE',31.000000,0.800000,0,'Working assumption: 4 resources x 7.75',SYSUTCDATETIME()),
        ('MB',23.250000,0.800000,0,'Working assumption: 3 resources x 7.75',SYSUTCDATETIME());
END;
GO

IF OBJECT_ID('[syteline].[fact_product_engineering_planning_load_snapshot]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_product_engineering_planning_load_snapshot]
    (
        snapshot_date DATE NOT NULL,
        snapshot_timestamp DATETIME2(6) NOT NULL,
        snapshot_hour TINYINT NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL,
        planning_load DECIMAL(18,6) NULL,
        source_row_count BIGINT NOT NULL,
        date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
        week_start_date DATE NULL, week_ending_date DATE NULL,
        created_ts DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[fact_product_engineering_new_items_snapshot]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_product_engineering_new_items_snapshot]
    (
        snapshot_date DATE NOT NULL,
        snapshot_timestamp DATETIME2(6) NOT NULL,
        snapshot_hour TINYINT NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL,
        new_items DECIMAL(18,6) NULL,
        source_row_count BIGINT NOT NULL,
        date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
        week_start_date DATE NULL, week_ending_date DATE NULL,
        created_ts DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[fact_product_engineering_items_completed_daily]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_product_engineering_items_completed_daily]
    (
        snapshot_date DATE NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL,
        prior_snapshot_date DATE NULL,
        snapshot_gap_days INT NULL,
        prior_planning_load DECIMAL(18,6) NULL,
        new_items DECIMAL(18,6) NULL,
        current_planning_load DECIMAL(18,6) NULL,
        items_completed DECIMAL(18,6) NULL,
        calculation_source VARCHAR(100) NOT NULL,
        data_status VARCHAR(100) NOT NULL,
        date_key INT NULL, closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
        week_start_date DATE NULL, week_ending_date DATE NULL,
        source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[fact_product_engineering_productivity_daily]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_product_engineering_productivity_daily]
    (
        snapshot_date DATE NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL,
        site_name VARCHAR(100) NOT NULL,
        items_completed DECIMAL(18,6) NULL,
        daily_capacity DECIMAL(18,6) NULL,
        productivity_percentage DECIMAL(18,6) NULL,
        capacity_approved BIT NOT NULL,
        calculation_source VARCHAR(100) NOT NULL,
        data_status VARCHAR(100) NOT NULL,
        closed_year INT NULL, closed_week INT NULL, week_key INT NULL,
        week_start_date DATE NULL, week_ending_date DATE NULL,
        source_row_count BIGINT NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[fact_product_engineering_productivity_weekly]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[fact_product_engineering_productivity_weekly]
    (
        closed_year INT NOT NULL, closed_week INT NOT NULL, week_key INT NOT NULL,
        week_start_date DATE NOT NULL, week_ending_date DATE NOT NULL,
        warehouse_prefix VARCHAR(10) NOT NULL, site_name VARCHAR(100) NOT NULL,
        snapshot_days INT NOT NULL, complete_days INT NOT NULL,
        productivity_percentage DECIMAL(18,6) NULL,
        items_completed_total DECIMAL(18,6) NULL,
        daily_capacity DECIMAL(18,6) NULL,
        capacity_approved BIT NOT NULL,
        source_row_count BIGINT NOT NULL,
        data_status VARCHAR(100) NOT NULL,
        calculation_timestamp DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[syteline].[kpi_result_product_engineering_productivity]', 'U') IS NULL
BEGIN
    CREATE TABLE [syteline].[kpi_result_product_engineering_productivity]
    (
        closed_year INT NULL, closed_week INT NULL, kpi_name VARCHAR(255) NULL,
        kpi_value DECIMAL(18,6) NULL, organisational_unit VARCHAR(255) NULL,
        kpi_id BIGINT NULL, kpi_category VARCHAR(100) NULL,
        target_value DECIMAL(18,6) NULL, breach_direction VARCHAR(20) NULL,
        week_key INT NULL, kpi_code VARCHAR(100) NULL, department VARCHAR(255) NULL,
        measure VARCHAR(500) NULL, measure_name VARCHAR(500) NULL, uom VARCHAR(50) NULL,
        sign VARCHAR(100) NULL, sign_label VARCHAR(100) NULL, commentary VARCHAR(1000) NULL,
        variance_value DECIMAL(18,6) NULL, performance_variance_value DECIMAL(18,6) NULL,
        rag_status VARCHAR(20) NULL, data_status VARCHAR(50) NULL,
        source_system VARCHAR(100) NULL, source_object VARCHAR(500) NULL,
        source_row_count BIGINT NULL, calculation_timestamp DATETIME2(6) NULL
    );
END;
GO

/* Capture Planning Load and New Items directly from SyteLine. */
CREATE OR ALTER PROCEDURE [syteline].[sp_capture_product_engineering_productivity_inputs_v1]
    @snapshot_timestamp DATETIME2(6) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @snapshot_timestamp IS NULL SET @snapshot_timestamp = SYSUTCDATETIME();

    DECLARE @snapshot_date DATE = CAST(@snapshot_timestamp AS DATE);
    DECLARE @snapshot_hour TINYINT = DATEPART(HOUR,@snapshot_timestamp);

    DELETE FROM [syteline].[fact_product_engineering_planning_load_snapshot]
    WHERE snapshot_date=@snapshot_date AND snapshot_hour=@snapshot_hour
      AND warehouse_prefix IN ('BE','MB');

    DELETE FROM [syteline].[fact_product_engineering_new_items_snapshot]
    WHERE snapshot_date=@snapshot_date AND snapshot_hour=@snapshot_hour
      AND warehouse_prefix IN ('BE','MB');

    ;WITH sites AS
    (
        SELECT 'BE' warehouse_prefix, 'Bridgend' site_name
        UNION ALL SELECT 'MB','Maybole'
    ), eligible AS
    (
        SELECT
            warehouse_prefix = UPPER(LTRIM(RTRIM(CAST(c.[whse] AS VARCHAR(10))))),
            ordered_date = CAST(c.[uf_ordereddate] AS DATE),
            source_row_count = CAST(1 AS BIGINT)
        FROM [syteline_staging].[coitem_mst] c
        INNER JOIN [syteline_staging].[item_mst] i
          ON i.[item]=c.[item] AND i.[site_ref]=c.[site_ref]
        WHERE c.[site_ref]='RBMW'
          AND c.[co_num] LIKE 'C%'
          AND c.[stat]='O'
          AND c.[whse] IN ('BE','MB')
          AND i.[uf_bomstatus] IN ('B','D','E','P')
    ), planning AS
    (
        SELECT warehouse_prefix,
               planning_load=COUNT_BIG(*),
               source_rows=SUM(source_row_count)
        FROM eligible
        GROUP BY warehouse_prefix
    ), prior_snapshot AS
    (
        SELECT s.warehouse_prefix,
               prior_snapshot_date=MAX(p.snapshot_date)
        FROM sites s
        LEFT JOIN [syteline].[fact_product_engineering_planning_load_snapshot] p
          ON p.warehouse_prefix=s.warehouse_prefix
         AND p.snapshot_hour=8
         AND p.snapshot_date<@snapshot_date
        GROUP BY s.warehouse_prefix
    ), new_items AS
    (
        SELECT e.warehouse_prefix,
               new_items=COUNT_BIG(*),
               source_rows=SUM(e.source_row_count)
        FROM eligible e
        INNER JOIN prior_snapshot p
          ON p.warehouse_prefix=e.warehouse_prefix
         AND e.ordered_date=p.prior_snapshot_date
        GROUP BY e.warehouse_prefix
    )
    INSERT INTO [syteline].[fact_product_engineering_planning_load_snapshot]
    (
        snapshot_date,snapshot_timestamp,snapshot_hour,warehouse_prefix,site_name,
        planning_load,source_row_count,date_key,closed_year,closed_week,week_key,
        week_start_date,week_ending_date,created_ts
    )
    SELECT @snapshot_date,@snapshot_timestamp,@snapshot_hour,s.warehouse_prefix,s.site_name,
           CAST(COALESCE(p.planning_load,0) AS DECIMAL(18,6)),COALESCE(p.source_rows,0),
           d.date_key,d.customer_year,d.customer_week_no,d.week_key,
           d.week_start_date,d.week_end_date,SYSUTCDATETIME()
    FROM sites s
    LEFT JOIN planning p ON p.warehouse_prefix=s.warehouse_prefix
    LEFT JOIN [reporting].[dim_date] d ON d.calendar_date=@snapshot_date;

    INSERT INTO [syteline].[fact_product_engineering_new_items_snapshot]
    (
        snapshot_date,snapshot_timestamp,snapshot_hour,warehouse_prefix,site_name,
        new_items,source_row_count,date_key,closed_year,closed_week,week_key,
        week_start_date,week_ending_date,created_ts
    )
    SELECT @snapshot_date,@snapshot_timestamp,@snapshot_hour,s.warehouse_prefix,s.site_name,
           CAST(CASE WHEN p.prior_snapshot_date IS NULL THEN NULL ELSE COALESCE(n.new_items,0) END AS DECIMAL(18,6)),
           COALESCE(n.source_rows,0),d.date_key,d.customer_year,d.customer_week_no,d.week_key,
           d.week_start_date,d.week_end_date,SYSUTCDATETIME()
    FROM sites s
    LEFT JOIN prior_snapshot p ON p.warehouse_prefix=s.warehouse_prefix
    LEFT JOIN new_items n ON n.warehouse_prefix=s.warehouse_prefix
    LEFT JOIN [reporting].[dim_date] d ON d.calendar_date=@snapshot_date;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_product_engineering_items_completed_daily_v1]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [syteline].[fact_product_engineering_items_completed_daily];

    ;WITH planning AS
    (
        SELECT snapshot_date,warehouse_prefix,MAX(site_name) site_name,
               AVG(planning_load) current_planning_load,
               SUM(source_row_count) planning_rows,
               MAX(date_key) date_key,MAX(closed_year) closed_year,
               MAX(closed_week) closed_week,MAX(week_key) week_key,
               MAX(week_start_date) week_start_date,MAX(week_ending_date) week_ending_date
        FROM [syteline].[fact_product_engineering_planning_load_snapshot]
        WHERE snapshot_hour=8
        GROUP BY snapshot_date,warehouse_prefix
    ), prior AS
    (
        SELECT p.*,
               LAG(snapshot_date) OVER(PARTITION BY warehouse_prefix ORDER BY snapshot_date) prior_snapshot_date,
               LAG(current_planning_load) OVER(PARTITION BY warehouse_prefix ORDER BY snapshot_date) prior_planning_load
        FROM planning p
    ), newitems AS
    (
        SELECT snapshot_date,warehouse_prefix,AVG(new_items) new_items,SUM(source_row_count) new_item_rows
        FROM [syteline].[fact_product_engineering_new_items_snapshot]
        WHERE snapshot_hour=8
        GROUP BY snapshot_date,warehouse_prefix
    )
    INSERT INTO [syteline].[fact_product_engineering_items_completed_daily]
    (
        snapshot_date,warehouse_prefix,site_name,prior_snapshot_date,snapshot_gap_days,
        prior_planning_load,new_items,current_planning_load,items_completed,
        calculation_source,data_status,date_key,closed_year,closed_week,week_key,
        week_start_date,week_ending_date,source_row_count,calculation_timestamp
    )
    SELECT p.snapshot_date,p.warehouse_prefix,p.site_name,p.prior_snapshot_date,
           DATEDIFF(DAY,p.prior_snapshot_date,p.snapshot_date),
           p.prior_planning_load,n.new_items,p.current_planning_load,
           CAST(CASE WHEN p.prior_planning_load IS NOT NULL AND n.new_items IS NOT NULL
                     THEN p.prior_planning_load+n.new_items-p.current_planning_load END AS DECIMAL(18,6)),
           'ESTIMATED_FORMULA_V1',
           CASE WHEN p.prior_planning_load IS NULL THEN 'No Prior Snapshot'
                WHEN n.new_items IS NULL THEN 'Missing New Items'
                WHEN DATEDIFF(DAY,p.prior_snapshot_date,p.snapshot_date)>3 THEN 'Snapshot Gap Review'
                WHEN p.prior_planning_load+n.new_items-p.current_planning_load<0 THEN 'Negative Result Review'
                ELSE 'Working Logic - Approval Required' END,
           p.date_key,p.closed_year,p.closed_week,p.week_key,p.week_start_date,p.week_ending_date,
           p.planning_rows+COALESCE(n.new_item_rows,0),SYSUTCDATETIME()
    FROM prior p
    LEFT JOIN newitems n ON n.snapshot_date=p.snapshot_date AND n.warehouse_prefix=p.warehouse_prefix;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_product_engineering_productivity_facts_v1]
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE [syteline].[fact_product_engineering_productivity_daily];
    TRUNCATE TABLE [syteline].[fact_product_engineering_productivity_weekly];

    INSERT INTO [syteline].[fact_product_engineering_productivity_daily]
    (
        snapshot_date,warehouse_prefix,site_name,items_completed,daily_capacity,
        productivity_percentage,capacity_approved,calculation_source,data_status,
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        source_row_count,calculation_timestamp
    )
    SELECT i.snapshot_date,i.warehouse_prefix,i.site_name,i.items_completed,c.daily_capacity,
           CAST(CASE WHEN i.items_completed IS NOT NULL AND c.daily_capacity>0
                     THEN i.items_completed/c.daily_capacity END AS DECIMAL(18,6)),
           c.is_approved,'ESTIMATED_FORMULA_V1',
           CASE WHEN i.items_completed IS NULL THEN i.data_status
                WHEN c.is_approved=0 THEN 'Working Logic - Approval Required'
                ELSE 'Actual' END,
           i.closed_year,i.closed_week,i.week_key,i.week_start_date,i.week_ending_date,
           i.source_row_count,SYSUTCDATETIME()
    FROM [syteline].[fact_product_engineering_items_completed_daily] i
    INNER JOIN [syteline].[product_engineering_productivity_capacity] c
      ON c.warehouse_prefix=i.warehouse_prefix;

    INSERT INTO [syteline].[fact_product_engineering_productivity_weekly]
    (
        closed_year,closed_week,week_key,week_start_date,week_ending_date,
        warehouse_prefix,site_name,snapshot_days,complete_days,productivity_percentage,
        items_completed_total,daily_capacity,capacity_approved,source_row_count,
        data_status,calculation_timestamp
    )
    SELECT closed_year,closed_week,week_key,week_start_date,week_ending_date,
           warehouse_prefix,MAX(site_name),COUNT_BIG(*),COUNT(productivity_percentage),
           CAST(AVG(productivity_percentage) AS DECIMAL(18,6)),
           CAST(SUM(items_completed) AS DECIMAL(18,6)),MAX(daily_capacity),MIN(capacity_approved),
           SUM(source_row_count),
           CASE WHEN COUNT(productivity_percentage)=0 THEN 'No Data'
                WHEN MIN(capacity_approved)=0 THEN 'Working Logic - Approval Required'
                WHEN COUNT(productivity_percentage)<5 THEN 'Partial Week'
                ELSE 'Actual' END,
           SYSUTCDATETIME()
    FROM [syteline].[fact_product_engineering_productivity_daily]
    WHERE week_key IS NOT NULL
    GROUP BY closed_year,closed_week,week_key,week_start_date,week_ending_date,warehouse_prefix;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_kpi_result_product_engineering_productivity_v1]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [syteline].[kpi_result_product_engineering_productivity]
    WHERE kpi_code IN ('Product Eng - BE-KPI P1','Product Eng - MB-KPI P1');

    INSERT INTO [syteline].[kpi_result_product_engineering_productivity]
    (
        closed_year,closed_week,kpi_name,kpi_value,organisational_unit,kpi_id,
        kpi_category,target_value,breach_direction,week_key,kpi_code,department,
        measure,measure_name,uom,sign,sign_label,commentary,variance_value,
        performance_variance_value,rag_status,data_status,source_system,
        source_object,source_row_count,calculation_timestamp
    )
    SELECT w.closed_year,w.closed_week,'Product Engineering Productivity',w.productivity_percentage,
           CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
           NULL,'Productivity',CAST(0.80 AS DECIMAL(18,6)),'UNDER',w.week_key,
           CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Eng - BE-KPI P1' ELSE 'Product Eng - MB-KPI P1' END,
           CASE w.warehouse_prefix WHEN 'BE' THEN 'Product Engineering Bridgend' ELSE 'Product Engineering Maybole' END,
           'Average daily output lines as a percentage of capacity','Output Lines vs Capacity %','Percentage',
           'Under Breach','Under Breach',
           CONCAT('Snapshot days=',w.snapshot_days,'; complete days=',w.complete_days,
                  '; items completed=',COALESCE(CAST(w.items_completed_total AS VARCHAR(50)),'NULL'),
                  '; capacity=',CAST(w.daily_capacity AS VARCHAR(50)),
                  '; formula=ESTIMATED_FORMULA_V1.'),
           CASE WHEN w.productivity_percentage IS NULL THEN NULL ELSE w.productivity_percentage-0.80 END,
           CASE WHEN w.productivity_percentage IS NULL THEN NULL ELSE w.productivity_percentage-0.80 END,
           CASE WHEN w.productivity_percentage IS NULL THEN 'No Data'
                WHEN w.capacity_approved=0 THEN 'TBC'
                WHEN w.productivity_percentage>=0.80 THEN 'G'
                WHEN w.productivity_percentage>=0.76 THEN 'A' ELSE 'R' END,
           w.data_status,'SyteLine',
           'syteline_staging.coitem_mst + syteline_staging.item_mst',
           w.source_row_count,SYSUTCDATETIME()
    FROM [syteline].[fact_product_engineering_productivity_weekly] w;
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_product_engineering_productivity_all_v1]
    @snapshot_timestamp DATETIME2(6)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[sp_capture_product_engineering_productivity_inputs_v1] @snapshot_timestamp;
    EXEC [syteline].[sp_build_product_engineering_items_completed_daily_v1];
    EXEC [syteline].[sp_build_product_engineering_productivity_facts_v1];
    EXEC [syteline].[sp_build_kpi_result_product_engineering_productivity_v1];
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_publish_product_engineering_productivity_v1]
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM [syteline].[fact_kpi_result]
    WHERE kpi_code IN ('Product Eng - BE-KPI P1','Product Eng - MB-KPI P1');

    INSERT INTO [syteline].[fact_kpi_result]
    (
        closed_year,closed_week,kpi_name,kpi_value,organisational_unit,kpi_id,
        kpi_category,target_value,breach_direction,week_key,kpi_code,department,
        measure,measure_name,uom,sign,sign_label,commentary,variance_value,
        performance_variance_value,rag_status,data_status,source_system,
        source_object,source_row_count,calculation_timestamp
    )
    SELECT closed_year,closed_week,kpi_name,kpi_value,organisational_unit,kpi_id,
           kpi_category,target_value,breach_direction,week_key,kpi_code,department,
           measure,measure_name,uom,sign,sign_label,commentary,variance_value,
           performance_variance_value,rag_status,data_status,source_system,
           source_object,source_row_count,calculation_timestamp
    FROM [syteline].[kpi_result_product_engineering_productivity];
END;
GO

CREATE OR ALTER PROCEDURE [syteline].[sp_build_and_publish_product_engineering_productivity_all_v1]
    @snapshot_timestamp DATETIME2(6)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [syteline].[sp_build_product_engineering_productivity_all_v1] @snapshot_timestamp;
    EXEC [syteline].[sp_publish_product_engineering_productivity_v1];
END;
GO

/*
VALIDATION / TEST QUERIES
=========================

-- 1. Confirm source columns.
SELECT TABLE_NAME,COLUMN_NAME,DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA='syteline_staging'
  AND TABLE_NAME IN ('coitem_mst','item_mst')
  AND COLUMN_NAME IN
      ('item','site_ref','co_num','stat','whse','uf_ordereddate','uf_bomstatus')
ORDER BY TABLE_NAME,ORDINAL_POSITION;

-- 2. Confirm source volume.
SELECT 'coitem_mst' source_table,COUNT_BIG(*) row_count FROM syteline_staging.coitem_mst
UNION ALL
SELECT 'item_mst',COUNT_BIG(*) FROM syteline_staging.item_mst;

-- 3. Capture an explicit initial 08:00 snapshot.
EXEC syteline.sp_build_product_engineering_productivity_all_v1
     @snapshot_timestamp='2026-11-04T08:00:00';

-- 4. Review snapshots.
SELECT * FROM syteline.fact_product_engineering_planning_load_snapshot
ORDER BY snapshot_date,warehouse_prefix;

SELECT * FROM syteline.fact_product_engineering_new_items_snapshot
ORDER BY snapshot_date,warehouse_prefix;

-- 5. Review Items Completed and productivity.
SELECT * FROM syteline.fact_product_engineering_items_completed_daily
ORDER BY snapshot_date,warehouse_prefix;

SELECT * FROM syteline.fact_product_engineering_productivity_weekly
ORDER BY closed_year,closed_week,warehouse_prefix;

-- 6. Review dashboard-shaped KPI results.
SELECT * FROM syteline.kpi_result_product_engineering_productivity
ORDER BY closed_year,closed_week,kpi_code;

-- 7. Publish after review.
EXEC syteline.sp_publish_product_engineering_productivity_v1;

-- 8. Review final dashboard rows.
SELECT * FROM syteline.fact_kpi_result
WHERE kpi_code IN ('Product Eng - BE-KPI P1','Product Eng - MB-KPI P1')
ORDER BY closed_year,closed_week,kpi_code;

-- 9. Reconciliation.
SELECT d.week_key,d.kpi_code,d.kpi_value domain_value,f.kpi_value final_value,
       d.kpi_value-f.kpi_value difference
FROM syteline.kpi_result_product_engineering_productivity d
LEFT JOIN syteline.fact_kpi_result f
  ON f.week_key=d.week_key AND f.kpi_code=d.kpi_code
ORDER BY d.week_key,d.kpi_code;

-- 10. Duplicate check.
SELECT week_key,kpi_code,COUNT_BIG(*) row_count
FROM syteline.fact_kpi_result
WHERE kpi_code IN ('Product Eng - BE-KPI P1','Product Eng - MB-KPI P1')
GROUP BY week_key,kpi_code
HAVING COUNT_BIG(*)>1;

-- 11. Normal scheduled call after validation.
EXEC syteline.sp_build_and_publish_product_engineering_productivity_all_v1
     @snapshot_timestamp=NULL;
*/
