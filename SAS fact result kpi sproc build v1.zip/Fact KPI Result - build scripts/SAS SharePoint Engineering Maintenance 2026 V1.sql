/*
SAS - SHAREPOINT ENGINEERING MAINTENANCE KPIs - V1
===================================================
Purpose
-------
Build two Engineering KPI streams from Gold SharePoint staging tables:
  ENGINEERING-KPI-Q1  Proactive vs Reactive Maintenance
  ENGINEERING-KPI-Q2  Mean Time Between Failure

Source workbook: 2026 Maintenance KPI.xlsx

Current physical sources:
  sharepoint_staging.proactive_reactive_maintenance
  sharepoint_staging.mean_time_between_failure

Shared objects:
  reporting.dim_date
  reporting.kpi_control

Domain output:
  sharepoint.fact_kpi_result

Notes
-----
- Existing procedures/tables are left untouched; all procedures created here end _v1.
- Expected source columns from current warehouse/source mapping are isolated in the
  two source CTEs. Inspect the schema validation query before first execution.
- Proactive maintenance target = 0.80 and MTBF target = 4 from KPI target catalogue.
- Source values are normalised so proactive values stored as 80 or 0.80 both become 0.80.
- Historical weekly rows are mapped explicitly to reporting customer year 2026.
*/

/* -------------------------------------------------------------------------
   0. SharePoint domain fact_kpi_result
   Standard 26-column domain contract. Cross-domain merge to
   reporting.fact_kpi_result remains a separate later step.
   ------------------------------------------------------------------------- */
IF OBJECT_ID('[sharepoint].[fact_kpi_result]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_kpi_result]
    (
        [closed_year] INT NULL,
        [closed_week] INT NULL,
        [kpi_name] VARCHAR(1000) NULL,
        [kpi_value] DECIMAL(18,4) NULL,
        [organisational_unit] VARCHAR(1000) NULL,
        [kpi_id] BIGINT NULL,
        [kpi_category] VARCHAR(1000) NULL,
        [target_value] DECIMAL(18,4) NULL,
        [breach_direction] VARCHAR(1000) NULL,
        [week_key] INT NULL,
        [kpi_code] VARCHAR(1000) NULL,
        [department] VARCHAR(1000) NULL,
        [measure] VARCHAR(1000) NULL,
        [measure_name] VARCHAR(1000) NULL,
        [uom] VARCHAR(1000) NULL,
        [sign] VARCHAR(1000) NULL,
        [sign_label] VARCHAR(1000) NULL,
        [commentary] VARCHAR(1000) NULL,
        [variance_value] DECIMAL(18,4) NULL,
        [performance_variance_value] DECIMAL(18,4) NULL,
        [rag_status] VARCHAR(1000) NULL,
        [data_status] VARCHAR(1000) NULL,
        [source_system] VARCHAR(1000) NULL,
        [source_object] VARCHAR(1000) NULL,
        [source_row_count] BIGINT NULL,
        [calculation_timestamp] DATETIME2(6) NULL
    );
END;
GO

/* -------------------------------------------------------------------------
   1. Domain tables
   ------------------------------------------------------------------------- */

IF OBJECT_ID('[sharepoint].[fact_engineering_proactive_reactive_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_engineering_proactive_reactive_v1]
    (
        [reporting_date] DATE NULL,
        [source_week_no] INT NULL,
        [proactive_value] DECIMAL(18,6) NULL,
        [source_target] DECIMAL(18,6) NULL,
        [closed_year] INT NULL,
        [closed_week] INT NULL,
        [week_key] INT NULL,
        [week_start_date] DATE NULL,
        [week_ending_date] DATE NULL,
        [source_row_count] BIGINT NOT NULL,
        [calculation_timestamp] DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[sharepoint].[fact_engineering_mtbf_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_engineering_mtbf_v1]
    (
        [reporting_date] DATE NULL,
        [source_week_no] INT NULL,
        [mtbf_value] DECIMAL(18,6) NULL,
        [source_target] DECIMAL(18,6) NULL,
        [closed_year] INT NULL,
        [closed_week] INT NULL,
        [week_key] INT NULL,
        [week_start_date] DATE NULL,
        [week_ending_date] DATE NULL,
        [source_row_count] BIGINT NOT NULL,
        [calculation_timestamp] DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[sharepoint].[kpi_result_engineering_maintenance_v1]', 'U') IS NULL
BEGIN
    SELECT TOP 0 *
    INTO [sharepoint].[kpi_result_engineering_maintenance_v1]
    FROM [sharepoint].[fact_kpi_result];
END;
GO

/* -------------------------------------------------------------------------
   1. Proactive vs Reactive Maintenance

   EXPECTED LANDED COLUMNS:
     week_no
     proactive
     target

   If a physical reporting-date column exists, replace the reporting_date
   expression below. Until then, source week number is resolved against the
   customer week in reporting.dim_date using customer year 2026 because the source is 2026 Maintenance KPI.xlsx.
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_engineering_proactive_reactive_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [sharepoint_staging].[proactive_reactive_maintenance])
        THROW 50001, 'ABORTED: sharepoint_staging.proactive_reactive_maintenance is empty.', 1;

    TRUNCATE TABLE [sharepoint].[fact_engineering_proactive_reactive_v1];

    ;WITH src AS
    (
        SELECT
            TRY_CAST([week_no] AS INT) AS [source_week_no],
            TRY_CAST([proactive] AS DECIMAL(18,6)) AS [proactive_raw],
            TRY_CAST([target] AS DECIMAL(18,6)) AS [target_raw]
        FROM [sharepoint_staging].[proactive_reactive_maintenance]
        WHERE TRY_CAST([week_no] AS INT) IS NOT NULL
    ), week_map AS
    (
        SELECT
            d.[customer_year],
            d.[customer_week_no],
            MIN(d.[calendar_date]) AS [reporting_date],
            MIN(d.[week_key]) AS [week_key],
            MIN(d.[week_start_date]) AS [week_start_date],
            MIN(d.[week_end_date]) AS [week_end_date]
        FROM [reporting].[dim_date] d
        WHERE d.[customer_year] = 2026
        GROUP BY d.[customer_year], d.[customer_week_no]
    )
    INSERT INTO [sharepoint].[fact_engineering_proactive_reactive_v1]
    (
        [reporting_date], [source_week_no], [proactive_value], [source_target],
        [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        w.[reporting_date],
        s.[source_week_no],
        CAST(CASE WHEN s.[proactive_raw] > 1 THEN s.[proactive_raw] / 100.0 ELSE s.[proactive_raw] END AS DECIMAL(18,6)),
        CAST(CASE WHEN s.[target_raw] > 1 THEN s.[target_raw] / 100.0 ELSE s.[target_raw] END AS DECIMAL(18,6)),
        w.[customer_year],
        w.[customer_week_no],
        w.[week_key],
        w.[week_start_date],
        w.[week_end_date],
        CAST(1 AS BIGINT),
        CAST(SYSUTCDATETIME() AS DATETIME2(6))
    FROM src s
    INNER JOIN week_map w
        ON w.[customer_week_no] = s.[source_week_no];
END;
GO

/* -------------------------------------------------------------------------
   2. Mean Time Between Failure

   EXPECTED LANDED COLUMNS:
     week_no
     mtbf
     target
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_engineering_mtbf_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [sharepoint_staging].[mean_time_between_failure])
        THROW 50002, 'ABORTED: sharepoint_staging.mean_time_between_failure is empty.', 1;

    TRUNCATE TABLE [sharepoint].[fact_engineering_mtbf_v1];

    ;WITH src AS
    (
        SELECT
            TRY_CAST([week_no] AS INT) AS [source_week_no],
            TRY_CAST([mtbf] AS DECIMAL(18,6)) AS [mtbf_value],
            TRY_CAST([target] AS DECIMAL(18,6)) AS [source_target]
        FROM [sharepoint_staging].[mean_time_between_failure]
        WHERE TRY_CAST([week_no] AS INT) IS NOT NULL
    ), week_map AS
    (
        SELECT
            d.[customer_year],
            d.[customer_week_no],
            MIN(d.[calendar_date]) AS [reporting_date],
            MIN(d.[week_key]) AS [week_key],
            MIN(d.[week_start_date]) AS [week_start_date],
            MIN(d.[week_end_date]) AS [week_end_date]
        FROM [reporting].[dim_date] d
        WHERE d.[customer_year] = 2026
        GROUP BY d.[customer_year], d.[customer_week_no]
    )
    INSERT INTO [sharepoint].[fact_engineering_mtbf_v1]
    (
        [reporting_date], [source_week_no], [mtbf_value], [source_target],
        [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        w.[reporting_date],
        s.[source_week_no],
        s.[mtbf_value],
        s.[source_target],
        w.[customer_year],
        w.[customer_week_no],
        w.[week_key],
        w.[week_start_date],
        w.[week_end_date],
        CAST(1 AS BIGINT),
        CAST(SYSUTCDATETIME() AS DATETIME2(6))
    FROM src s
    INNER JOIN week_map w
        ON w.[customer_week_no] = s.[source_week_no];
END;
GO

/* -------------------------------------------------------------------------
   3. KPI result using reporting.kpi_control
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_kpi_result_engineering_maintenance_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [sharepoint].[kpi_result_engineering_maintenance_v1];

    ;WITH actuals AS
    (
        SELECT
            p.[closed_year], p.[closed_week], p.[week_key], p.[week_ending_date],
            CAST('ENG-KPI-Q1' AS VARCHAR(100)) AS [kpi_code],
            CAST('Proactive vs Reactive Maintenance' AS VARCHAR(255)) AS [kpi_name],
            CAST('Quality' AS VARCHAR(100)) AS [kpi_category],
            CAST(p.[proactive_value] AS DECIMAL(18,6)) AS [kpi_value],
            p.[source_row_count],
            CAST('sharepoint.proactive_reactive_maintenance' AS VARCHAR(500)) AS [source_object]
        FROM [sharepoint].[fact_engineering_proactive_reactive_v1] p

        UNION ALL

        SELECT
            m.[closed_year], m.[closed_week], m.[week_key], m.[week_ending_date],
            CAST('ENG-KPI-Q2' AS VARCHAR(100)),
            CAST('Mean Time Between Failure' AS VARCHAR(255)),
            CAST('Quality' AS VARCHAR(100)),
            CAST(m.[mtbf_value] AS DECIMAL(18,6)),
            m.[source_row_count],
            CAST('sharepoint.mean_time_between_failure' AS VARCHAR(500))
        FROM [sharepoint].[fact_engineering_mtbf_v1] m
    ), enriched AS
    (
        SELECT
            a.*,
            TRY_CAST(c.[target_value] AS DECIMAL(18,6)) AS [target_value],
            UPPER(COALESCE(NULLIF(c.[breach_direction], ''), 'UNDER')) AS [breach_direction],
            TRY_CAST(COALESCE(c.[rag_tolerance_pct], 0.05) AS DECIMAL(18,6)) AS [rag_tolerance_pct],
            c.[kpi_id]
        FROM actuals a
        LEFT JOIN [reporting].[kpi_control] c
            ON c.[kpi_code] = a.[kpi_code]
           AND (c.[effective_from] IS NULL OR a.[week_ending_date] >= c.[effective_from])
           AND (c.[effective_to] IS NULL OR a.[week_ending_date] <= c.[effective_to])
    )
    INSERT INTO [sharepoint].[kpi_result_engineering_maintenance_v1]
    (
        [closed_year], [closed_week], [kpi_name], [kpi_value], [organisational_unit],
        [kpi_id], [kpi_category], [target_value], [breach_direction], [week_key],
        [kpi_code], [department], [measure], [measure_name], [uom], [sign], [sign_label],
        [commentary], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    )
    SELECT
        e.[closed_year], e.[closed_week], e.[kpi_name], e.[kpi_value],
        'Engineering', e.[kpi_id], e.[kpi_category], e.[target_value], e.[breach_direction], e.[week_key],
        e.[kpi_code], 'Engineering',
        CASE WHEN e.[kpi_code] = 'ENG-KPI-Q1' THEN 'Proactive maintenance percentage' ELSE 'Mean Time Between Failure' END,
        e.[kpi_name],
        CASE WHEN e.[kpi_code] = 'ENG-KPI-Q1' THEN 'Percentage' ELSE 'Days' END,
        CASE WHEN e.[breach_direction] = 'OVER' THEN 'Over Breach' ELSE 'Under Breach' END,
        CASE WHEN e.[breach_direction] = 'OVER' THEN 'Over Breach' ELSE 'Under Breach' END,
        CASE WHEN e.[target_value] IS NULL THEN 'Actual - Target TBC' ELSE NULL END,
        CASE WHEN e.[target_value] IS NULL THEN NULL ELSE e.[kpi_value] - e.[target_value] END,
        CASE
            WHEN e.[target_value] IS NULL THEN NULL
            WHEN e.[breach_direction] = 'OVER' THEN e.[target_value] - e.[kpi_value]
            ELSE e.[kpi_value] - e.[target_value]
        END,
        CASE
            WHEN e.[kpi_value] IS NULL THEN 'No Data'
            WHEN e.[target_value] IS NULL THEN 'TBC'
            WHEN e.[breach_direction] = 'OVER' AND e.[kpi_value] <= e.[target_value] THEN 'G'
            WHEN e.[breach_direction] = 'OVER' AND e.[kpi_value] <= e.[target_value] * (1 + e.[rag_tolerance_pct]) THEN 'A'
            WHEN e.[breach_direction] = 'UNDER' AND e.[kpi_value] >= e.[target_value] THEN 'G'
            WHEN e.[breach_direction] = 'UNDER' AND e.[kpi_value] >= e.[target_value] * (1 - e.[rag_tolerance_pct]) THEN 'A'
            ELSE 'R'
        END,
        CASE WHEN e.[target_value] IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'SharePoint', e.[source_object], e.[source_row_count], CAST(SYSUTCDATETIME() AS DATETIME2(6))
    FROM enriched e;
END;
GO

/* -------------------------------------------------------------------------
   4. Publisher to SharePoint domain result
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_publish_engineering_maintenance_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [sharepoint].[fact_kpi_result]
    WHERE [kpi_code] IN ('ENG-KPI-Q1', 'ENG-KPI-Q2');

    INSERT INTO [sharepoint].[fact_kpi_result]
    (
        [closed_year], [closed_week], [kpi_name], [kpi_value], [organisational_unit],
        [kpi_id], [kpi_category], [target_value], [breach_direction], [week_key],
        [kpi_code], [department], [measure], [measure_name], [uom], [sign], [sign_label],
        [commentary], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [kpi_name], [kpi_value], [organisational_unit],
        [kpi_id], [kpi_category], [target_value], [breach_direction], [week_key],
        [kpi_code], [department], [measure], [measure_name], [uom], [sign], [sign_label],
        [commentary], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count], [calculation_timestamp]
    FROM [sharepoint].[kpi_result_engineering_maintenance_v1];
END;
GO

/* -------------------------------------------------------------------------
   5. Orchestrators
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_engineering_maintenance_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [sharepoint].[usp_build_fact_engineering_proactive_reactive_v1];
    EXEC [sharepoint].[usp_build_fact_engineering_mtbf_v1];
    EXEC [sharepoint].[usp_build_kpi_result_engineering_maintenance_v1];
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_and_publish_engineering_maintenance_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [sharepoint].[usp_build_engineering_maintenance_kpis_v1];
    EXEC [sharepoint].[usp_publish_engineering_maintenance_kpis_v1];
END;
GO

/* -------------------------------------------------------------------------
   6. Expected control records

   Ensure reporting.kpi_control contains:

   ENG-KPI-Q1 | Engineering | Quality | Proactive vs Reactive Maintenance
              | target_value = 0.80 | breach_direction = UNDER

   ENG-KPI-Q2 | Engineering | Quality | Mean Time Between Failure
              | target_value = 4.00 | breach_direction = UNDER
   ------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------
   7. Validation queries - run manually
   -------------------------------------------------------------------------

-- A. Confirm physical source columns before first execution
SELECT TABLE_NAME, ORDINAL_POSITION, COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'sharepoint_staging'
  AND TABLE_NAME IN ('proactive_reactive_maintenance', 'mean_time_between_failure')
ORDER BY TABLE_NAME, ORDINAL_POSITION;

-- B. Confirm SharePoint domain result table exists
SELECT OBJECT_ID('[sharepoint].[fact_kpi_result]', 'U') AS [sharepoint_fact_kpi_result_object_id];

-- C. Confirm 2026 customer-week coverage
SELECT COUNT(DISTINCT [customer_week_no]) AS [customer_weeks_2026],
       MIN([week_key]) AS [first_week_key], MAX([week_key]) AS [last_week_key]
FROM [reporting].[dim_date]
WHERE [customer_year] = 2026;

-- D. Source volumes
SELECT 'proactive_reactive_maintenance' AS source_table, COUNT_BIG(*) AS rows
FROM [sharepoint_staging].[proactive_reactive_maintenance]
UNION ALL
SELECT 'mean_time_between_failure', COUNT_BIG(*)
FROM [sharepoint_staging].[mean_time_between_failure];

-- C. Build only
EXEC [sharepoint].[usp_build_engineering_maintenance_kpis_v1];

-- D. KPI result coverage
SELECT
    [kpi_code],
    COUNT_BIG(*) AS [rows],
    COUNT(DISTINCT [week_key]) AS [weeks],
    MIN([week_key]) AS [first_week],
    MAX([week_key]) AS [last_week],
    COUNT([target_value]) AS [target_rows],
    COUNT([variance_value]) AS [variance_rows]
FROM [sharepoint].[kpi_result_engineering_maintenance_v1]
GROUP BY [kpi_code]
ORDER BY [kpi_code];

-- E. Inspect historical results
SELECT *
FROM [sharepoint].[kpi_result_engineering_maintenance_v1]
ORDER BY [week_key], [kpi_code];

-- F. Publish
EXEC [sharepoint].[usp_publish_engineering_maintenance_kpis_v1];

-- G. Domain result
SELECT *
FROM [sharepoint].[fact_kpi_result]
WHERE [kpi_code] IN ('ENG-KPI-Q1', 'ENG-KPI-Q2')
ORDER BY [week_key], [kpi_code];

-- H. Duplicate check
SELECT [week_key], [kpi_code], COUNT_BIG(*) AS [rows]
FROM [sharepoint].[fact_kpi_result]
WHERE [kpi_code] IN ('ENG-KPI-Q1', 'ENG-KPI-Q2')
GROUP BY [week_key], [kpi_code]
HAVING COUNT_BIG(*) > 1;
*/
