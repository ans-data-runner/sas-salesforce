/*
    SAS Customer Service KPI Pack v1
    =================================
    Purpose
      Prepare seven complaint/cost KPI streams from the future Silver/Gold table:
          [salesforce_staging].[customer_service]

    Bronze source may be Salesforce [Case] or [Customer Service]. This pack intentionally
    depends only on the stable Silver/Gold name [salesforce_staging].[customer_service].

    KPI outputs
      1. SOP-KPI-Q1                         SOP Customer Complaints
      2. Quality Maybole-KPI Q1             Customer Complaints - MB all
      3. Quality Maybole-KPI C1             Cost of Quality - MB
      4. Product Design-KPI Q1              Product Design Customer Complaints
      5. Engineering-KPI Q1                 Engineering Customer Complaints
      6. Maybole Manuf-KPI Q1               Manufacturing Maybole Customer Complaints
      7. Bridgend Manuf-KPI Q1              Manufacturing Bridgend Customer Complaints

    Notes
      - All procedures end in _v1.
      - Existing procedures and tables are not removed.
      - The pack stops at [salesforce].[fact_kpi_result].
      - [reporting].[fact_kpi_result] is not modified.
      - Weekly zero rows are generated between the first and last complaint dates so that
        zero-complaint weeks are visible in reporting.
      - Initial scope predicates are configuration-driven and must be validated against the
        actual landed department/site/category values.
      - Cost of Quality initially uses Total_Costs__c -> total_costs, matching the historic
        report definition. Other cost components are retained in the atomic fact.
*/

/* ============================================================
   0. Required schemas
   ============================================================ */
IF SCHEMA_ID('salesforce') IS NULL
    EXEC ('CREATE SCHEMA [salesforce]');
GO

/* ============================================================
   1. Configurable scope table
   ============================================================ */
IF OBJECT_ID('[salesforce].[customer_service_kpi_scope_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[customer_service_kpi_scope_v1]
    (
        [kpi_code]                 VARCHAR(100)  NOT NULL,
        [kpi_name]                 VARCHAR(255)  NOT NULL,
        [kpi_category]             VARCHAR(100)  NOT NULL,
        [organisational_unit]      VARCHAR(255)  NOT NULL,
        [department_pattern]       VARCHAR(255)  NULL,
        [lead_site_pattern]        VARCHAR(255)  NULL,
        [syteline_site_pattern]    VARCHAR(255)  NULL,
        [project_pattern]          VARCHAR(255)  NULL,
        [record_type_pattern]      VARCHAR(255)  NULL,
        [case_category_pattern]    VARCHAR(255)  NULL,
        [complaint_category_pattern] VARCHAR(255) NULL,
        [metric_type]              VARCHAR(20)   NOT NULL,
        [is_active]                BIT           NOT NULL,
        [scope_status]             VARCHAR(100)  NOT NULL,
        [scope_commentary]         VARCHAR(1000) NULL
    );
END;
GO

DELETE FROM [salesforce].[customer_service_kpi_scope_v1]
WHERE [kpi_code] IN
(
    'SOP-KPI-Q1',
    'Quality Maybole-KPI Q1',
    'Quality Maybole-KPI C1',
    'Product Design-KPI Q1',
    'Engineering-KPI Q1',
    'Maybole Manuf-KPI Q1',
    'Bridgend Manuf-KPI Q1'
);

INSERT INTO [salesforce].[customer_service_kpi_scope_v1]
(
    [kpi_code], [kpi_name], [kpi_category], [organisational_unit],
    [department_pattern], [lead_site_pattern], [syteline_site_pattern],
    [project_pattern], [record_type_pattern], [case_category_pattern],
    [complaint_category_pattern], [metric_type], [is_active],
    [scope_status], [scope_commentary]
)
VALUES
('SOP-KPI-Q1', 'Customer Complaints', 'Quality', 'Sales Order Processing',
 '01 SOP', NULL, NULL, NULL, NULL, NULL, NULL, 'COUNT', 1,
 'Working Logic - Approval Required', 'Initial scope is Department = 01 SOP. Open date is used first for reporting.'),

('Quality Maybole-KPI Q1', 'Customer complaints - MB all', 'Quality', 'Quality Maybole',
 NULL, 'Maybole', 'Maybole', 'Maybole', NULL, NULL, NULL, 'COUNT', 1,
 'Working Logic - Approval Required', 'Initial Maybole scope uses lead site, SyteLine lead site, project or department values.'),

('Quality Maybole-KPI C1', 'Cost of Quality - MB', 'Cost', 'Quality Maybole',
 NULL, 'Maybole', 'Maybole', 'Maybole', NULL, NULL, NULL, 'COST', 1,
 'Working Logic - Approval Required', 'Initial measure is SUM(total_costs), matching the historic dashboard definition.'),

('Product Design-KPI Q1', 'Customer Complaints', 'Quality', 'Product Design',
 'Product Design', NULL, NULL, 'Product Design', NULL, NULL, NULL, 'COUNT', 1,
 'Working Logic - Approval Required', 'Validate the landed Product Design department/project values.'),

('Engineering-KPI Q1', 'Planning Engineering Complaints', 'Quality', 'Engineering',
 'Engineering', NULL, NULL, 'Engineering', NULL, NULL, NULL, 'COUNT', 1,
 'Working Logic - Approval Required', 'Validate whether Planning Engineering has a more specific physical value.'),

('Maybole Manuf-KPI Q1', 'Customer Complaints - MB Production', 'Quality', 'Manufacturing Maybole',
 'Manufacturing', 'Maybole', 'Maybole', 'Maybole', NULL, NULL, NULL, 'COUNT', 1,
 'Working Logic - Approval Required', 'Validate production/manufacturing and Maybole filter values.'),

('Bridgend Manuf-KPI Q1', 'Customer Complaints - BE Production', 'Quality', 'Manufacturing Bridgend',
 'Manufacturing', 'Bridgend', 'Bridgend', 'Bridgend', NULL, NULL, NULL, 'COUNT', 1,
 'Working Logic - Approval Required', 'Validate production/manufacturing and Bridgend filter values.');
GO

/* ============================================================
   2. Atomic Customer Service fact
   ============================================================ */
IF OBJECT_ID('[salesforce].[fact_customer_service_complaint_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[fact_customer_service_complaint_v1]
    (
        [case_id]                    VARCHAR(255)   NOT NULL,
        [case_number]                VARCHAR(255)   NULL,
        [status]                     VARCHAR(255)   NULL,
        [is_closed]                  BIT            NULL,
        [open_date]                  DATE           NULL,
        [date_of_complaint]          DATE           NULL,
        [created_date]               DATE           NULL,
        [closed_date]                DATE           NULL,
        [reporting_date]             DATE           NULL,
        [reporting_date_source]      VARCHAR(50)    NULL,
        [department]                 VARCHAR(500)   NULL,
        [project_name]               VARCHAR(500)   NULL,
        [lead_site]                  VARCHAR(500)   NULL,
        [syteline_lead_site]         VARCHAR(500)   NULL,
        [record_type_name]           VARCHAR(500)   NULL,
        [case_category]              VARCHAR(500)   NULL,
        [complaint_category]         VARCHAR(500)   NULL,
        [complaint_reason]           VARCHAR(1000)  NULL,
        [nature_of_complaint]        VARCHAR(1000)  NULL,
        [total_costs]                DECIMAL(18,6)  NULL,
        [quality_cost]               DECIMAL(18,6)  NULL,
        [customer_service_cost]      DECIMAL(18,6)  NULL,
        [design_technical_cost]      DECIMAL(18,6)  NULL,
        [estimating_cost]            DECIMAL(18,6)  NULL,
        [slt_cost]                   DECIMAL(18,6)  NULL,
        [date_key]                   INT            NULL,
        [closed_year]                INT            NULL,
        [closed_week]                INT            NULL,
        [week_key]                   INT            NULL,
        [week_start_date]            DATE           NULL,
        [week_ending_date]           DATE           NULL,
        [source_row_count]           BIGINT         NOT NULL,
        [source_modified_timestamp]  DATETIME2(6)   NULL,
        [created_timestamp]          DATETIME2(6)   NOT NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_fact_customer_service_complaint_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF OBJECT_ID('[salesforce_staging].[customer_service]', 'U') IS NULL
        THROW 51001, 'ABORTED: salesforce_staging.customer_service does not yet exist.', 1;

    DECLARE @source_rows BIGINT;
    DECLARE @sql NVARCHAR(MAX);

    SET @sql = N'SELECT @count_out = COUNT_BIG(*) FROM [salesforce_staging].[customer_service];';
    EXEC sys.sp_executesql @sql, N'@count_out BIGINT OUTPUT', @count_out = @source_rows OUTPUT;

    IF COALESCE(@source_rows, 0) = 0
        THROW 51002, 'ABORTED: salesforce_staging.customer_service contains zero rows. Existing Gold fact is preserved.', 1;

    TRUNCATE TABLE [salesforce].[fact_customer_service_complaint_v1];

    SET @sql = N'
    ;WITH source_latest AS
    (
        SELECT
            CAST([id] AS VARCHAR(255)) AS [case_id],
            CAST([case_number] AS VARCHAR(255)) AS [case_number],
            CAST([status] AS VARCHAR(255)) AS [status],
            TRY_CAST([is_closed] AS BIT) AS [is_closed],
            TRY_CAST([open_date] AS DATE) AS [open_date],
            TRY_CAST([date_of_complaint] AS DATE) AS [date_of_complaint],
            TRY_CAST([created_date] AS DATE) AS [created_date],
            TRY_CAST([closed_date] AS DATE) AS [closed_date],
            CAST([department] AS VARCHAR(500)) AS [department],
            CAST([project_name] AS VARCHAR(500)) AS [project_name],
            CAST([lead_site] AS VARCHAR(500)) AS [lead_site],
            CAST([syteline_lead_site] AS VARCHAR(500)) AS [syteline_lead_site],
            CAST([record_type_name] AS VARCHAR(500)) AS [record_type_name],
            CAST([case_category] AS VARCHAR(500)) AS [case_category],
            CAST([complaint_category] AS VARCHAR(500)) AS [complaint_category],
            CAST([complaint_reason] AS VARCHAR(1000)) AS [complaint_reason],
            CAST([nature_of_complaint] AS VARCHAR(1000)) AS [nature_of_complaint],
            TRY_CAST([total_costs] AS DECIMAL(18,6)) AS [total_costs],
            TRY_CAST([quality_cost] AS DECIMAL(18,6)) AS [quality_cost],
            TRY_CAST([customer_service_cost] AS DECIMAL(18,6)) AS [customer_service_cost],
            TRY_CAST([design_technical_cost] AS DECIMAL(18,6)) AS [design_technical_cost],
            TRY_CAST([estimating_cost] AS DECIMAL(18,6)) AS [estimating_cost],
            TRY_CAST([slt_cost] AS DECIMAL(18,6)) AS [slt_cost],
            TRY_CAST([last_modified_date] AS DATETIME2(6)) AS [last_modified_date],
            ROW_NUMBER() OVER
            (
                PARTITION BY CAST([id] AS VARCHAR(255))
                ORDER BY
                    TRY_CAST([last_modified_date] AS DATETIME2(6)) DESC,
                    TRY_CAST([system_modstamp] AS DATETIME2(6)) DESC,
                    TRY_CAST([created_date] AS DATETIME2(6)) DESC
            ) AS [rn]
        FROM [salesforce_staging].[customer_service]
        WHERE [id] IS NOT NULL
          AND COALESCE(TRY_CAST([is_deleted] AS BIT), 0) = 0
    ), shaped AS
    (
        SELECT
            *,
            COALESCE([open_date], [date_of_complaint], [created_date]) AS [reporting_date],
            CASE
                WHEN [open_date] IS NOT NULL THEN ''OPEN_DATE''
                WHEN [date_of_complaint] IS NOT NULL THEN ''DATE_OF_COMPLAINT''
                WHEN [created_date] IS NOT NULL THEN ''CREATED_DATE''
                ELSE ''NO_DATE''
            END AS [reporting_date_source]
        FROM source_latest
        WHERE [rn] = 1
    )
    INSERT INTO [salesforce].[fact_customer_service_complaint_v1]
    (
        [case_id], [case_number], [status], [is_closed],
        [open_date], [date_of_complaint], [created_date], [closed_date],
        [reporting_date], [reporting_date_source], [department], [project_name],
        [lead_site], [syteline_lead_site], [record_type_name], [case_category],
        [complaint_category], [complaint_reason], [nature_of_complaint],
        [total_costs], [quality_cost], [customer_service_cost],
        [design_technical_cost], [estimating_cost], [slt_cost],
        [date_key], [closed_year], [closed_week], [week_key],
        [week_start_date], [week_ending_date], [source_row_count],
        [source_modified_timestamp], [created_timestamp]
    )
    SELECT
        s.[case_id], s.[case_number], s.[status], s.[is_closed],
        s.[open_date], s.[date_of_complaint], s.[created_date], s.[closed_date],
        s.[reporting_date], s.[reporting_date_source], s.[department], s.[project_name],
        s.[lead_site], s.[syteline_lead_site], s.[record_type_name], s.[case_category],
        s.[complaint_category], s.[complaint_reason], s.[nature_of_complaint],
        s.[total_costs], s.[quality_cost], s.[customer_service_cost],
        s.[design_technical_cost], s.[estimating_cost], s.[slt_cost],
        d.[date_key], d.[customer_year], d.[customer_week_no], d.[week_key],
        TRY_CAST(d.[week_start_date] AS DATE), TRY_CAST(d.[week_end_date] AS DATE),
        CAST(1 AS BIGINT), s.[last_modified_date], SYSUTCDATETIME()
    FROM shaped s
    LEFT JOIN [reporting].[dim_date] d
      ON d.[calendar_date] = s.[reporting_date];';

    EXEC sys.sp_executesql @sql;

    IF NOT EXISTS (SELECT 1 FROM [salesforce].[fact_customer_service_complaint_v1])
        THROW 51003, 'Customer Service transformation returned zero rows after source validation.', 1;
END;
GO

/* ============================================================
   3. Weekly KPI fact, including zero-complaint weeks
   ============================================================ */
IF OBJECT_ID('[salesforce].[fact_customer_service_kpi_weekly_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[fact_customer_service_kpi_weekly_v1]
    (
        [closed_year]             INT            NOT NULL,
        [closed_week]             INT            NOT NULL,
        [week_key]                INT            NOT NULL,
        [week_start_date]         DATE           NULL,
        [week_ending_date]        DATE           NULL,
        [kpi_code]                VARCHAR(100)   NOT NULL,
        [kpi_name]                VARCHAR(255)   NOT NULL,
        [kpi_category]            VARCHAR(100)   NOT NULL,
        [organisational_unit]     VARCHAR(255)   NOT NULL,
        [metric_type]             VARCHAR(20)    NOT NULL,
        [complaint_count]         BIGINT         NOT NULL,
        [complaint_value]         DECIMAL(18,6)  NOT NULL,
        [kpi_value]               DECIMAL(18,6)  NOT NULL,
        [source_row_count]        BIGINT         NOT NULL,
        [created_timestamp]       DATETIME2(6)   NOT NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_fact_customer_service_kpi_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM [salesforce].[fact_customer_service_complaint_v1])
        THROW 51004, 'ABORTED: customer service atomic fact is empty.', 1;

    TRUNCATE TABLE [salesforce].[fact_customer_service_kpi_weekly_v1];

    DECLARE @min_date DATE = (SELECT MIN([reporting_date]) FROM [salesforce].[fact_customer_service_complaint_v1] WHERE [reporting_date] IS NOT NULL);
    DECLARE @max_date DATE = (SELECT MAX([reporting_date]) FROM [salesforce].[fact_customer_service_complaint_v1] WHERE [reporting_date] IS NOT NULL);

    ;WITH weeks AS
    (
        SELECT DISTINCT
            [customer_year] AS [closed_year],
            [customer_week_no] AS [closed_week],
            [week_key],
            TRY_CAST([week_start_date] AS DATE) AS [week_start_date],
            TRY_CAST([week_end_date] AS DATE) AS [week_ending_date]
        FROM [reporting].[dim_date]
        WHERE [calendar_date] BETWEEN @min_date AND @max_date
          AND [week_key] IS NOT NULL
    ), scoped_cases AS
    (
        SELECT
            s.[kpi_code], s.[kpi_name], s.[kpi_category], s.[organisational_unit], s.[metric_type],
            c.[case_id], c.[week_key], COALESCE(c.[total_costs], 0) AS [total_costs]
        FROM [salesforce].[customer_service_kpi_scope_v1] s
        INNER JOIN [salesforce].[fact_customer_service_complaint_v1] c
            ON c.[week_key] IS NOT NULL
        WHERE s.[is_active] = 1
          AND
          (
              (s.[kpi_code] = 'SOP-KPI-Q1'
               AND UPPER(LTRIM(RTRIM(COALESCE(c.[department], '')))) = UPPER(s.[department_pattern]))

              OR
              (s.[kpi_code] IN ('Quality Maybole-KPI Q1', 'Quality Maybole-KPI C1')
               AND
               (
                   UPPER(COALESCE(c.[lead_site], '')) LIKE '%MAYBOLE%'
                   OR UPPER(COALESCE(c.[syteline_lead_site], '')) LIKE '%MAYBOLE%'
                   OR UPPER(COALESCE(c.[project_name], '')) LIKE '%MAYBOLE%'
                   OR UPPER(COALESCE(c.[department], '')) LIKE '%MAYBOLE%'
                   OR UPPER(LTRIM(RTRIM(COALESCE(c.[lead_site], '')))) = 'MB'
                   OR UPPER(LTRIM(RTRIM(COALESCE(c.[syteline_lead_site], '')))) = 'MB'
               ))

              OR
              (s.[kpi_code] = 'Product Design-KPI Q1'
               AND
               (
                   UPPER(COALESCE(c.[department], '')) LIKE '%PRODUCT DESIGN%'
                   OR UPPER(COALESCE(c.[project_name], '')) LIKE '%PRODUCT DESIGN%'
               ))

              OR
              (s.[kpi_code] = 'Engineering-KPI Q1'
               AND UPPER(COALESCE(c.[department], '')) LIKE '%ENGINEERING%')

              OR
              (s.[kpi_code] = 'Maybole Manuf-KPI Q1'
               AND
               (
                   UPPER(COALESCE(c.[department], '')) LIKE '%MANUFACTUR%'
                   AND
                   (
                       UPPER(COALESCE(c.[lead_site], '')) LIKE '%MAYBOLE%'
                       OR UPPER(COALESCE(c.[syteline_lead_site], '')) LIKE '%MAYBOLE%'
                       OR UPPER(COALESCE(c.[project_name], '')) LIKE '%MAYBOLE%'
                       OR UPPER(LTRIM(RTRIM(COALESCE(c.[lead_site], '')))) = 'MB'
                       OR UPPER(LTRIM(RTRIM(COALESCE(c.[syteline_lead_site], '')))) = 'MB'
                   )
               ))

              OR
              (s.[kpi_code] = 'Bridgend Manuf-KPI Q1'
               AND
               (
                   UPPER(COALESCE(c.[department], '')) LIKE '%MANUFACTUR%'
                   AND
                   (
                       UPPER(COALESCE(c.[lead_site], '')) LIKE '%BRIDGEND%'
                       OR UPPER(COALESCE(c.[syteline_lead_site], '')) LIKE '%BRIDGEND%'
                       OR UPPER(COALESCE(c.[project_name], '')) LIKE '%BRIDGEND%'
                       OR UPPER(LTRIM(RTRIM(COALESCE(c.[lead_site], '')))) = 'BE'
                       OR UPPER(LTRIM(RTRIM(COALESCE(c.[syteline_lead_site], '')))) = 'BE'
                   )
               ))
          )
    ), aggregated AS
    (
        SELECT
            [kpi_code], [week_key],
            COUNT(DISTINCT [case_id]) AS [complaint_count],
            SUM([total_costs]) AS [complaint_value],
            COUNT_BIG(*) AS [source_row_count]
        FROM scoped_cases
        GROUP BY [kpi_code], [week_key]
    )
    INSERT INTO [salesforce].[fact_customer_service_kpi_weekly_v1]
    (
        [closed_year], [closed_week], [week_key], [week_start_date], [week_ending_date],
        [kpi_code], [kpi_name], [kpi_category], [organisational_unit], [metric_type],
        [complaint_count], [complaint_value], [kpi_value], [source_row_count], [created_timestamp]
    )
    SELECT
        w.[closed_year], w.[closed_week], w.[week_key], w.[week_start_date], w.[week_ending_date],
        s.[kpi_code], s.[kpi_name], s.[kpi_category], s.[organisational_unit], s.[metric_type],
        COALESCE(a.[complaint_count], 0),
        COALESCE(a.[complaint_value], 0),
        CASE WHEN s.[metric_type] = 'COST'
             THEN CAST(COALESCE(a.[complaint_value], 0) AS DECIMAL(18,6))
             ELSE CAST(COALESCE(a.[complaint_count], 0) AS DECIMAL(18,6)) END,
        COALESCE(a.[source_row_count], 0),
        SYSUTCDATETIME()
    FROM weeks w
    CROSS JOIN [salesforce].[customer_service_kpi_scope_v1] s
    LEFT JOIN aggregated a
      ON a.[week_key] = w.[week_key]
     AND a.[kpi_code] = s.[kpi_code]
    WHERE s.[is_active] = 1;
END;
GO

/* ============================================================
   4. KPI result with target, variance and direction-aware RAG
   Expects reporting.kpi_control columns:
       kpi_code, target_value, breach_direction
   ============================================================ */
IF OBJECT_ID('[salesforce].[kpi_result_customer_service_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [salesforce].[kpi_result_customer_service_v1]
    (
        [closed_year]                 INT            NOT NULL,
        [closed_week]                 INT            NOT NULL,
        [week_key]                    INT            NOT NULL,
        [kpi_id]                      VARCHAR(100)   NULL,
        [kpi_code]                    VARCHAR(100)   NOT NULL,
        [kpi_name]                    VARCHAR(255)   NOT NULL,
        [kpi_category]                VARCHAR(100)   NOT NULL,
        [organisational_unit]         VARCHAR(255)   NULL,
        [department]                  VARCHAR(255)   NULL,
        [measure]                     VARCHAR(255)   NULL,
        [measure_name]                VARCHAR(255)   NULL,
        [uom]                         VARCHAR(50)    NULL,
        [sign]                        VARCHAR(20)    NULL,
        [sign_label]                  VARCHAR(100)   NULL,
        [commentary]                  VARCHAR(1000) NULL,
        [breach_direction]            VARCHAR(20)    NULL,
        [kpi_value]                   DECIMAL(18,6)  NULL,
        [target_value]                DECIMAL(18,6)  NULL,
        [variance_value]              DECIMAL(18,6)  NULL,
        [performance_variance_value]  DECIMAL(18,6)  NULL,
        [rag_status]                  VARCHAR(20)    NULL,
        [data_status]                 VARCHAR(100)   NULL,
        [source_system]               VARCHAR(100)   NULL,
        [source_object]               VARCHAR(500)   NULL,
        [source_row_count]            BIGINT         NULL,
        [calculation_timestamp]       DATETIME2(6)   NULL
    );
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_kpi_result_customer_service_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [salesforce].[kpi_result_customer_service_v1];

    INSERT INTO [salesforce].[kpi_result_customer_service_v1]
    (
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count],
        [calculation_timestamp]
    )
    SELECT
        w.[closed_year], w.[closed_week], w.[week_key],
        w.[kpi_code], w.[kpi_code], w.[kpi_name], w.[kpi_category],
        w.[organisational_unit], w.[organisational_unit], w.[kpi_name], w.[kpi_name],
        CASE WHEN w.[metric_type] = 'COST' THEN 'GBP' ELSE 'Count' END,
        'Over Breach', 'Lower is better',
        CONCAT('Customer Service working scope. Count=', CAST(w.[complaint_count] AS VARCHAR(30)),
               '; Value=', CAST(w.[complaint_value] AS VARCHAR(50)),
               '. Validate department/site/category filters after ingestion.'),
        COALESCE(c.[breach_direction], 'OVER'),
        w.[kpi_value], c.[target_value],
        CASE WHEN c.[target_value] IS NULL THEN NULL
             ELSE w.[kpi_value] - c.[target_value] END,
        CASE
            WHEN c.[target_value] IS NULL THEN NULL
            WHEN COALESCE(c.[breach_direction], 'OVER') = 'OVER'
                THEN c.[target_value] - w.[kpi_value]
            ELSE w.[kpi_value] - c.[target_value]
        END,
        CASE
            WHEN c.[target_value] IS NULL THEN 'TBC'
            WHEN COALESCE(c.[breach_direction], 'OVER') = 'OVER'
                 AND w.[kpi_value] <= c.[target_value] THEN 'G'
            WHEN COALESCE(c.[breach_direction], 'OVER') = 'OVER'
                 AND c.[target_value] > 0
                 AND w.[kpi_value] <= c.[target_value] * 1.05 THEN 'A'
            WHEN COALESCE(c.[breach_direction], 'OVER') = 'UNDER'
                 AND w.[kpi_value] >= c.[target_value] THEN 'G'
            WHEN COALESCE(c.[breach_direction], 'OVER') = 'UNDER'
                 AND w.[kpi_value] >= c.[target_value] * 0.95 THEN 'A'
            ELSE 'R'
        END,
        CASE WHEN c.[target_value] IS NULL
             THEN 'Target Missing / Scope Approval Required'
             ELSE 'Working Logic - Scope Approval Required' END,
        'Salesforce', 'salesforce_staging.customer_service',
        w.[source_row_count], SYSUTCDATETIME()
    FROM [salesforce].[fact_customer_service_kpi_weekly_v1] w
    LEFT JOIN [reporting].[kpi_control] c
      ON c.[kpi_code] = w.[kpi_code];
END;
GO

/* ============================================================
   5. Domain publication only
   ============================================================ */
CREATE OR ALTER PROCEDURE [salesforce].[usp_publish_customer_service_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [salesforce].[fact_kpi_result]
    WHERE [kpi_code] IN
    (
        'SOP-KPI-Q1',
        'Quality Maybole-KPI Q1',
        'Quality Maybole-KPI C1',
        'Product Design-KPI Q1',
        'Engineering-KPI Q1',
        'Maybole Manuf-KPI Q1',
        'Bridgend Manuf-KPI Q1'
    );

    INSERT INTO [salesforce].[fact_kpi_result]
    (
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count],
        [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [week_key], [kpi_id], [kpi_code], [kpi_name],
        [kpi_category], [organisational_unit], [department], [measure], [measure_name],
        [uom], [sign], [sign_label], [commentary], [breach_direction], [kpi_value],
        [target_value], [variance_value], [performance_variance_value], [rag_status],
        [data_status], [source_system], [source_object], [source_row_count],
        [calculation_timestamp]
    FROM [salesforce].[kpi_result_customer_service_v1];
END;
GO

/* ============================================================
   6. Orchestration
   ============================================================ */
CREATE OR ALTER PROCEDURE [salesforce].[usp_build_customer_service_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [salesforce].[usp_build_fact_customer_service_complaint_v1];
    EXEC [salesforce].[usp_build_fact_customer_service_kpi_weekly_v1];
    EXEC [salesforce].[usp_build_kpi_result_customer_service_v1];
END;
GO

CREATE OR ALTER PROCEDURE [salesforce].[usp_build_and_publish_customer_service_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;
    EXEC [salesforce].[usp_build_customer_service_kpis_v1];
    EXEC [salesforce].[usp_publish_customer_service_kpis_v1];
END;
GO

/* ============================================================
   7. Post-ingestion diagnostics and test sequence
   ============================================================ */

/* A. Verify the landed schema */
SELECT
    [TABLE_NAME], [ORDINAL_POSITION], [COLUMN_NAME], [DATA_TYPE]
FROM [INFORMATION_SCHEMA].[COLUMNS]
WHERE [TABLE_SCHEMA] = 'salesforce_staging'
  AND [TABLE_NAME] = 'customer_service'
ORDER BY [ORDINAL_POSITION];

/* B. Inspect physical scope values after the table lands */
/*
SELECT [department], COUNT_BIG(*) AS [cases]
FROM [salesforce_staging].[customer_service]
GROUP BY [department]
ORDER BY [cases] DESC;

SELECT [lead_site], [syteline_lead_site], COUNT_BIG(*) AS [cases]
FROM [salesforce_staging].[customer_service]
GROUP BY [lead_site], [syteline_lead_site]
ORDER BY [cases] DESC;
*/

/* C. Build without publication */
/*
EXEC [salesforce].[usp_build_customer_service_kpis_v1];

SELECT
    [kpi_code], COUNT_BIG(*) AS [rows], COUNT(DISTINCT [week_key]) AS [weeks],
    MIN([week_key]) AS [first_week], MAX([week_key]) AS [last_week],
    COUNT([target_value]) AS [target_rows], COUNT([variance_value]) AS [variance_rows]
FROM [salesforce].[kpi_result_customer_service_v1]
GROUP BY [kpi_code]
ORDER BY [kpi_code];

SELECT *
FROM [salesforce].[kpi_result_customer_service_v1]
ORDER BY [week_key], [kpi_code];
*/

/* D. Publish after filter validation */
/*
EXEC [salesforce].[usp_publish_customer_service_kpis_v1];

SELECT *
FROM [salesforce].[fact_kpi_result]
WHERE [kpi_code] IN
(
    'SOP-KPI-Q1',
    'Quality Maybole-KPI Q1',
    'Quality Maybole-KPI C1',
    'Product Design-KPI Q1',
    'Engineering-KPI Q1',
    'Maybole Manuf-KPI Q1',
    'Bridgend Manuf-KPI Q1'
)
ORDER BY [week_key], [kpi_code];
*/
