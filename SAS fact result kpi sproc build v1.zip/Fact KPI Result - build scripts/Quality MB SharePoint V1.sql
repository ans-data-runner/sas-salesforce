/*
SAS QUALITY MAYBOLE - SHAREPOINT KPI PROCEDURES V1
===================================================
Purpose
-------
Build the two SharePoint-backed Quality Maybole KPI streams:
  1. Quality Maybole-KPI P1 - Internal Audit Plan
  2. Quality Maybole-KPI D1 - Reraise - Internal Rework Costs

Architecture
------------
sharepoint_staging.quality_mb_internal_audits
sharepoint_staging.quality_mb_reraise_log
        -> sharepoint atomic facts
        -> sharepoint weekly facts
        -> reporting.kpi_control
        -> sharepoint KPI result
        -> sharepoint.fact_kpi_result

Important
---------
- All new stored procedures end in _v1.
- reporting.fact_kpi_result is NOT updated by this script.
- Existing procedures and tables are not altered.
- Expected landing columns are listed in the validation section.
- Percentage values are not used by these two KPIs.
*/

IF SCHEMA_ID('sharepoint') IS NULL
    EXEC('CREATE SCHEMA [sharepoint]');
GO

/* =============================================================
   1. KPI CONTROL RECORDS
   =============================================================
   Current working targets from the supplied Quality workbook:
     P1 Internal Audit Plan: 40, UNDER breach
     D1 Internal Rework Costs: 1025 GBP, OVER breach

   The DELETE/INSERT pattern makes deployment repeatable.
   If reporting.kpi_control uses effective-dated targets, amend the
   effective dates below rather than hard-coding targets in procedures.
*/

DELETE FROM [reporting].[kpi_control]
WHERE [kpi_code] IN
(
    'Quality Maybole-KPI P1',
    'Quality Maybole-KPI D1'
);
GO

INSERT INTO [reporting].[kpi_control]
(
    [kpi_code],
    [kpi_name],
    [department],
    [kpi_category],
    [target_value],
    [uom],
    [breach_direction],
    [rag_tolerance_pct],
    [effective_from],
    [effective_to],
    [target_status],
    [target_source],
    [commentary],
    [created_timestamp],
    [updated_timestamp]
)
VALUES
(
    'Quality Maybole-KPI P1',
    'Internal Audit Plan',
    'Quality Maybole',
    'Productivity',
    CAST(40 AS DECIMAL(18,6)),
    'Count',
    'UNDER',
    CAST(0.05 AS DECIMAL(18,6)),
    CAST('2024-01-01' AS DATE),
    NULL,
    'Working - validate effective dates',
    'Quality KPI workbook',
    'Count of completed internal audit plans by completion week.',
    SYSUTCDATETIME(),
    SYSUTCDATETIME()
),
(
    'Quality Maybole-KPI D1',
    'Reraise - Internal Rework Costs',
    'Quality Maybole',
    'Delivery',
    CAST(1025 AS DECIMAL(18,6)),
    'GBP',
    'OVER',
    CAST(0.05 AS DECIMAL(18,6)),
    CAST('2024-01-01' AS DATE),
    NULL,
    'Working - validate effective dates',
    'Quality KPI workbook',
    'Weekly sum of Costs Total from the Re-Raise Log.',
    SYSUTCDATETIME(),
    SYSUTCDATETIME()
);
GO

/* =============================================================
   2. ATOMIC FACT TABLES
   ============================================================= */

IF OBJECT_ID('[sharepoint].[fact_quality_mb_internal_audit_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_quality_mb_internal_audit_v1]
    (
        [audit_id]              VARCHAR(255)  NOT NULL,
        [start_timestamp]       DATETIME2(6)  NULL,
        [completion_timestamp]  DATETIME2(6)  NULL,
        [completion_date]       DATE          NULL,
        [conducted_by]          VARCHAR(500)  NULL,
        [area_conducted]        VARCHAR(500)  NULL,
        [question_date]         DATE          NULL,
        [date_key]              INT           NULL,
        [closed_year]           INT           NULL,
        [closed_week]           INT           NULL,
        [week_key]              INT           NULL,
        [week_start_date]       DATE          NULL,
        [week_ending_date]      DATE          NULL,
        [source_row_count]      BIGINT        NOT NULL,
        [created_timestamp]     DATETIME2(6)  NOT NULL
    );
END;
GO

IF OBJECT_ID('[sharepoint].[fact_quality_mb_reraise_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_quality_mb_reraise_v1]
    (
        [reraise_id]            VARCHAR(255)   NOT NULL,
        [event_date]            DATE           NULL,
        [start_timestamp]       DATETIME2(6)   NULL,
        [completion_timestamp]  DATETIME2(6)   NULL,
        [job_number]            VARCHAR(500)   NULL,
        [item_number]           VARCHAR(500)   NULL,
        [reason_for_scrap]      VARCHAR(1000)  NULL,
        [cost_per]              DECIMAL(18,6)  NULL,
        [cost_total]            DECIMAL(18,6)  NULL,
        [date_key]              INT            NULL,
        [closed_year]           INT            NULL,
        [closed_week]           INT            NULL,
        [week_key]              INT            NULL,
        [week_start_date]       DATE           NULL,
        [week_ending_date]      DATE           NULL,
        [source_row_count]      BIGINT         NOT NULL,
        [created_timestamp]     DATETIME2(6)   NOT NULL
    );
END;
GO

/* =============================================================
   3. WEEKLY FACT TABLES
   ============================================================= */

IF OBJECT_ID('[sharepoint].[fact_quality_mb_internal_audit_weekly_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_quality_mb_internal_audit_weekly_v1]
    (
        [closed_year]          INT           NOT NULL,
        [closed_week]          INT           NOT NULL,
        [week_key]             INT           NOT NULL,
        [week_start_date]      DATE          NOT NULL,
        [week_ending_date]     DATE          NOT NULL,
        [completed_audits]     BIGINT        NOT NULL,
        [source_row_count]     BIGINT        NOT NULL,
        [calculation_timestamp] DATETIME2(6) NOT NULL
    );
END;
GO

IF OBJECT_ID('[sharepoint].[fact_quality_mb_reraise_weekly_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[fact_quality_mb_reraise_weekly_v1]
    (
        [closed_year]           INT           NOT NULL,
        [closed_week]           INT           NOT NULL,
        [week_key]              INT           NOT NULL,
        [week_start_date]       DATE          NOT NULL,
        [week_ending_date]      DATE          NOT NULL,
        [reraise_count]          BIGINT        NOT NULL,
        [internal_rework_cost]  DECIMAL(18,6) NULL,
        [source_row_count]      BIGINT        NOT NULL,
        [calculation_timestamp] DATETIME2(6) NOT NULL
    );
END;
GO

/* =============================================================
   4. DOMAIN KPI RESULT TABLE
   ============================================================= */

IF OBJECT_ID('[sharepoint].[kpi_result_quality_mb_v1]', 'U') IS NULL
BEGIN
    CREATE TABLE [sharepoint].[kpi_result_quality_mb_v1]
    (
        [closed_year]                  INT             NULL,
        [closed_week]                  INT             NULL,
        [kpi_name]                     VARCHAR(255)    NULL,
        [kpi_value]                    DECIMAL(18,6)   NULL,
        [organisational_unit]          VARCHAR(255)    NULL,
        [kpi_id]                       BIGINT          NULL,
        [kpi_category]                 VARCHAR(100)    NULL,
        [target_value]                 DECIMAL(18,6)   NULL,
        [breach_direction]             VARCHAR(20)     NULL,
        [week_key]                     INT             NULL,
        [kpi_code]                     VARCHAR(100)    NULL,
        [department]                   VARCHAR(255)    NULL,
        [measure]                      VARCHAR(500)    NULL,
        [measure_name]                 VARCHAR(500)    NULL,
        [uom]                          VARCHAR(50)     NULL,
        [sign]                         VARCHAR(100)    NULL,
        [sign_label]                   VARCHAR(100)    NULL,
        [commentary]                   VARCHAR(1000)   NULL,
        [variance_value]               DECIMAL(18,6)   NULL,
        [performance_variance_value]   DECIMAL(18,6)   NULL,
        [rag_status]                   VARCHAR(20)     NULL,
        [data_status]                  VARCHAR(100)    NULL,
        [source_system]                VARCHAR(100)    NULL,
        [source_object]                VARCHAR(500)    NULL,
        [source_row_count]             BIGINT          NULL,
        [calculation_timestamp]        DATETIME2(6)    NULL
    );
END;
GO

/* =============================================================
   5. SOURCE -> ATOMIC FACT: INTERNAL AUDITS
   Expected staging columns:
     id, start_time, completion_time, conducted_by,
     area_conducted, question
   ============================================================= */

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_quality_mb_internal_audit_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [sharepoint_staging].[quality_mb_internal_audits]
    )
    BEGIN
        THROW 51001,
              'ABORTED: sharepoint_staging.quality_mb_internal_audits contains zero rows. Existing Gold fact preserved.',
              1;
    END;

    TRUNCATE TABLE [sharepoint].[fact_quality_mb_internal_audit_v1];

    ;WITH src AS
    (
        SELECT
            [audit_id] = CAST([id] AS VARCHAR(255)),
            [start_timestamp] = TRY_CAST([start_time] AS DATETIME2(6)),
            [completion_timestamp] = TRY_CAST([completion_time] AS DATETIME2(6)),
            [completion_date] = TRY_CAST([completion_time] AS DATE),
            [conducted_by] = CAST([conducted_by] AS VARCHAR(500)),
            [area_conducted] = CAST([area_conducted] AS VARCHAR(500)),
            [question_date] = TRY_CAST([question] AS DATE),
            [rn] = ROW_NUMBER() OVER
            (
                PARTITION BY CAST([id] AS VARCHAR(255))
                ORDER BY
                    TRY_CAST([completion_time] AS DATETIME2(6)) DESC,
                    TRY_CAST([start_time] AS DATETIME2(6)) DESC
            )
        FROM [sharepoint_staging].[quality_mb_internal_audits]
        WHERE [id] IS NOT NULL
    )
    INSERT INTO [sharepoint].[fact_quality_mb_internal_audit_v1]
    (
        [audit_id], [start_timestamp], [completion_timestamp],
        [completion_date], [conducted_by], [area_conducted],
        [question_date], [date_key], [closed_year], [closed_week],
        [week_key], [week_start_date], [week_ending_date],
        [source_row_count], [created_timestamp]
    )
    SELECT
        s.[audit_id],
        s.[start_timestamp],
        s.[completion_timestamp],
        s.[completion_date],
        s.[conducted_by],
        s.[area_conducted],
        s.[question_date],
        d.[date_key],
        d.[customer_year],
        d.[customer_week_no],
        d.[week_key],
        d.[week_start_date],
        d.[week_end_date],
        CAST(1 AS BIGINT),
        SYSUTCDATETIME()
    FROM src s
    LEFT JOIN [reporting].[dim_date] d
        ON d.[calendar_date] = s.[completion_date]
    WHERE s.[rn] = 1
      AND s.[completion_date] IS NOT NULL;
END;
GO

/* =============================================================
   6. SOURCE -> ATOMIC FACT: RERAISE COSTS
   Expected staging columns:
     id, start_time, completion_time, date, job_number,
     item_number, reason_for_scrap, costs_per, costs_total
   ============================================================= */

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_quality_mb_reraise_v1]
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [sharepoint_staging].[quality_mb_reraise_log]
    )
    BEGIN
        THROW 51002,
              'ABORTED: sharepoint_staging.quality_mb_reraise_log contains zero rows. Existing Gold fact preserved.',
              1;
    END;

    TRUNCATE TABLE [sharepoint].[fact_quality_mb_reraise_v1];

    ;WITH src AS
    (
        SELECT
            [reraise_id] = CAST([id] AS VARCHAR(255)),
            [start_timestamp] = TRY_CAST([start_time] AS DATETIME2(6)),
            [completion_timestamp] = TRY_CAST([completion_time] AS DATETIME2(6)),
            [event_date] = COALESCE
            (
                TRY_CAST([date] AS DATE),
                TRY_CAST([completion_time] AS DATE),
                TRY_CAST([start_time] AS DATE)
            ),
            [job_number] = CAST([job_number] AS VARCHAR(500)),
            [item_number] = CAST([item_number] AS VARCHAR(500)),
            [reason_for_scrap] = CAST([reason_for_scrap] AS VARCHAR(1000)),
            [cost_per] = TRY_CAST
            (
                REPLACE(REPLACE(CAST([costs_per] AS VARCHAR(100)), '£', ''), ',', '')
                AS DECIMAL(18,6)
            ),
            [cost_total] = TRY_CAST
            (
                REPLACE(REPLACE(CAST([costs_total] AS VARCHAR(100)), '£', ''), ',', '')
                AS DECIMAL(18,6)
            ),
            [rn] = ROW_NUMBER() OVER
            (
                PARTITION BY CAST([id] AS VARCHAR(255))
                ORDER BY
                    TRY_CAST([completion_time] AS DATETIME2(6)) DESC,
                    TRY_CAST([start_time] AS DATETIME2(6)) DESC
            )
        FROM [sharepoint_staging].[quality_mb_reraise_log]
        WHERE [id] IS NOT NULL
    )
    INSERT INTO [sharepoint].[fact_quality_mb_reraise_v1]
    (
        [reraise_id], [event_date], [start_timestamp],
        [completion_timestamp], [job_number], [item_number],
        [reason_for_scrap], [cost_per], [cost_total], [date_key],
        [closed_year], [closed_week], [week_key], [week_start_date],
        [week_ending_date], [source_row_count], [created_timestamp]
    )
    SELECT
        s.[reraise_id],
        s.[event_date],
        s.[start_timestamp],
        s.[completion_timestamp],
        s.[job_number],
        s.[item_number],
        s.[reason_for_scrap],
        s.[cost_per],
        s.[cost_total],
        d.[date_key],
        d.[customer_year],
        d.[customer_week_no],
        d.[week_key],
        d.[week_start_date],
        d.[week_end_date],
        CAST(1 AS BIGINT),
        SYSUTCDATETIME()
    FROM src s
    LEFT JOIN [reporting].[dim_date] d
        ON d.[calendar_date] = s.[event_date]
    WHERE s.[rn] = 1
      AND s.[event_date] IS NOT NULL;
END;
GO

/* =============================================================
   7. WEEKLY FACTS
   ============================================================= */

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_fact_quality_mb_weekly_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [sharepoint].[fact_quality_mb_internal_audit_weekly_v1];
    TRUNCATE TABLE [sharepoint].[fact_quality_mb_reraise_weekly_v1];

    INSERT INTO [sharepoint].[fact_quality_mb_internal_audit_weekly_v1]
    (
        [closed_year], [closed_week], [week_key], [week_start_date],
        [week_ending_date], [completed_audits], [source_row_count],
        [calculation_timestamp]
    )
    SELECT
        [closed_year],
        [closed_week],
        [week_key],
        [week_start_date],
        [week_ending_date],
        COUNT(DISTINCT [audit_id]),
        SUM([source_row_count]),
        SYSUTCDATETIME()
    FROM [sharepoint].[fact_quality_mb_internal_audit_v1]
    WHERE [week_key] IS NOT NULL
    GROUP BY
        [closed_year], [closed_week], [week_key],
        [week_start_date], [week_ending_date];

    INSERT INTO [sharepoint].[fact_quality_mb_reraise_weekly_v1]
    (
        [closed_year], [closed_week], [week_key], [week_start_date],
        [week_ending_date], [reraise_count], [internal_rework_cost],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year],
        [closed_week],
        [week_key],
        [week_start_date],
        [week_ending_date],
        COUNT(DISTINCT [reraise_id]),
        SUM(COALESCE([cost_total], 0)),
        SUM([source_row_count]),
        SYSUTCDATETIME()
    FROM [sharepoint].[fact_quality_mb_reraise_v1]
    WHERE [week_key] IS NOT NULL
    GROUP BY
        [closed_year], [closed_week], [week_key],
        [week_start_date], [week_ending_date];
END;
GO

/* =============================================================
   8. KPI RESULT
   ============================================================= */

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_kpi_result_quality_mb_v1]
AS
BEGIN
    SET NOCOUNT ON;

    TRUNCATE TABLE [sharepoint].[kpi_result_quality_mb_v1];

    ;WITH actuals AS
    (
        SELECT
            w.[closed_year], w.[closed_week], w.[week_key],
            w.[week_ending_date],
            [kpi_code] = CAST('Quality Maybole-KPI P1' AS VARCHAR(100)),
            [kpi_name] = CAST('Internal Audit Plan' AS VARCHAR(255)),
            [kpi_category] = CAST('Productivity' AS VARCHAR(100)),
            [kpi_value] = CAST(w.[completed_audits] AS DECIMAL(18,6)),
            [measure] = CAST('Count of internal audit plans completed' AS VARCHAR(500)),
            [measure_name] = CAST('Internal Audit Plan' AS VARCHAR(500)),
            [source_object] = CAST('sharepoint_staging.quality_mb_internal_audits' AS VARCHAR(500)),
            w.[source_row_count]
        FROM [sharepoint].[fact_quality_mb_internal_audit_weekly_v1] w

        UNION ALL

        SELECT
            w.[closed_year], w.[closed_week], w.[week_key],
            w.[week_ending_date],
            CAST('Quality Maybole-KPI D1' AS VARCHAR(100)),
            CAST('Reraise - Internal Rework Costs' AS VARCHAR(255)),
            CAST('Delivery' AS VARCHAR(100)),
            CAST(w.[internal_rework_cost] AS DECIMAL(18,6)),
            CAST('Cost of the Internal Rework' AS VARCHAR(500)),
            CAST('Internal Rework Costs' AS VARCHAR(500)),
            CAST('sharepoint_staging.quality_mb_reraise_log' AS VARCHAR(500)),
            w.[source_row_count]
        FROM [sharepoint].[fact_quality_mb_reraise_weekly_v1] w
    ), enriched AS
    (
        SELECT
            a.*,
            c.[target_value],
            c.[uom],
            UPPER(c.[breach_direction]) AS [breach_direction],
            COALESCE(c.[rag_tolerance_pct], CAST(0.05 AS DECIMAL(18,6))) AS [rag_tolerance_pct]
        FROM actuals a
        LEFT JOIN [reporting].[kpi_control] c
          ON c.[kpi_code] = a.[kpi_code]
         AND a.[week_ending_date] >= c.[effective_from]
         AND (c.[effective_to] IS NULL OR a.[week_ending_date] <= c.[effective_to])
    )
    INSERT INTO [sharepoint].[kpi_result_quality_mb_v1]
    (
        [closed_year], [closed_week], [kpi_name], [kpi_value],
        [organisational_unit], [kpi_id], [kpi_category], [target_value],
        [breach_direction], [week_key], [kpi_code], [department],
        [measure], [measure_name], [uom], [sign], [sign_label],
        [commentary], [variance_value], [performance_variance_value],
        [rag_status], [data_status], [source_system], [source_object],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        e.[closed_year],
        e.[closed_week],
        e.[kpi_name],
        e.[kpi_value],
        'Quality Maybole',
        NULL,
        e.[kpi_category],
        e.[target_value],
        e.[breach_direction],
        e.[week_key],
        e.[kpi_code],
        'Quality',
        e.[measure],
        e.[measure_name],
        e.[uom],
        CASE WHEN e.[breach_direction] = 'OVER' THEN 'Over Breach' ELSE 'Under Breach' END,
        CASE WHEN e.[breach_direction] = 'OVER' THEN 'Over Breach' ELSE 'Under Breach' END,
        CASE
            WHEN e.[target_value] IS NULL THEN 'Target not configured in reporting.kpi_control.'
            WHEN e.[kpi_code] = 'Quality Maybole-KPI P1' THEN 'Completed audit submissions by completion week.'
            ELSE 'Weekly sum of Costs Total from Re-Raise Log.'
        END,
        CASE WHEN e.[target_value] IS NULL THEN NULL
             ELSE e.[kpi_value] - e.[target_value] END,
        CASE
            WHEN e.[target_value] IS NULL THEN NULL
            WHEN e.[breach_direction] = 'UNDER' THEN e.[kpi_value] - e.[target_value]
            WHEN e.[breach_direction] = 'OVER' THEN e.[target_value] - e.[kpi_value]
            ELSE NULL
        END,
        CASE
            WHEN e.[kpi_value] IS NULL THEN 'No Data'
            WHEN e.[target_value] IS NULL THEN 'TBC'
            WHEN e.[breach_direction] = 'UNDER' AND e.[kpi_value] >= e.[target_value] THEN 'G'
            WHEN e.[breach_direction] = 'UNDER' AND e.[kpi_value] >= e.[target_value] * (1 - e.[rag_tolerance_pct]) THEN 'A'
            WHEN e.[breach_direction] = 'OVER' AND e.[kpi_value] <= e.[target_value] THEN 'G'
            WHEN e.[breach_direction] = 'OVER' AND e.[kpi_value] <= e.[target_value] * (1 + e.[rag_tolerance_pct]) THEN 'A'
            ELSE 'R'
        END,
        CASE WHEN e.[target_value] IS NULL THEN 'Actual - Target TBC' ELSE 'Actual' END,
        'SharePoint',
        e.[source_object],
        e.[source_row_count],
        SYSUTCDATETIME()
    FROM enriched e;
END;
GO

/* =============================================================
   9. PUBLISH TO SHAREPOINT DOMAIN RESULT
   ============================================================= */

CREATE OR ALTER PROCEDURE [sharepoint].[usp_publish_quality_mb_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM [sharepoint].[fact_kpi_result]
    WHERE [kpi_code] IN
    (
        'Quality Maybole-KPI P1',
        'Quality Maybole-KPI D1'
    );

    INSERT INTO [sharepoint].[fact_kpi_result]
    (
        [closed_year], [closed_week], [kpi_name], [kpi_value],
        [organisational_unit], [kpi_id], [kpi_category], [target_value],
        [breach_direction], [week_key], [kpi_code], [department],
        [measure], [measure_name], [uom], [sign], [sign_label],
        [commentary], [variance_value], [performance_variance_value],
        [rag_status], [data_status], [source_system], [source_object],
        [source_row_count], [calculation_timestamp]
    )
    SELECT
        [closed_year], [closed_week], [kpi_name], [kpi_value],
        [organisational_unit], [kpi_id], [kpi_category], [target_value],
        [breach_direction], [week_key], [kpi_code], [department],
        [measure], [measure_name], [uom], [sign], [sign_label],
        [commentary], [variance_value], [performance_variance_value],
        [rag_status], [data_status], [source_system], [source_object],
        [source_row_count], [calculation_timestamp]
    FROM [sharepoint].[kpi_result_quality_mb_v1];
END;
GO

/* =============================================================
   10. RUNNERS
   ============================================================= */

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_quality_mb_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    EXEC [sharepoint].[usp_build_fact_quality_mb_internal_audit_v1];
    EXEC [sharepoint].[usp_build_fact_quality_mb_reraise_v1];
    EXEC [sharepoint].[usp_build_fact_quality_mb_weekly_v1];
    EXEC [sharepoint].[usp_build_kpi_result_quality_mb_v1];
END;
GO

CREATE OR ALTER PROCEDURE [sharepoint].[usp_build_and_publish_quality_mb_kpis_v1]
AS
BEGIN
    SET NOCOUNT ON;

    EXEC [sharepoint].[usp_build_quality_mb_kpis_v1];
    EXEC [sharepoint].[usp_publish_quality_mb_kpis_v1];
END;
GO

/* =============================================================
   11. VALIDATION / TEST QUERIES
   =============================================================

-- A. Confirm source column names before first execution.
SELECT
    TABLE_NAME,
    ORDINAL_POSITION,
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'sharepoint_staging'
  AND TABLE_NAME IN
  (
      'quality_mb_internal_audits',
      'quality_mb_reraise_log'
  )
ORDER BY TABLE_NAME, ORDINAL_POSITION;

-- B. Build without publication.
EXEC [sharepoint].[usp_build_quality_mb_kpis_v1];

-- C. Atomic fact coverage.
SELECT
    'internal_audits' AS [fact_name],
    COUNT_BIG(*) AS [rows],
    COUNT(DISTINCT [week_key]) AS [weeks],
    MIN([week_key]) AS [first_week],
    MAX([week_key]) AS [last_week]
FROM [sharepoint].[fact_quality_mb_internal_audit_v1]
UNION ALL
SELECT
    'reraise',
    COUNT_BIG(*),
    COUNT(DISTINCT [week_key]),
    MIN([week_key]),
    MAX([week_key])
FROM [sharepoint].[fact_quality_mb_reraise_v1];

-- D. KPI result coverage.
SELECT
    [kpi_code],
    COUNT_BIG(*) AS [rows],
    COUNT(DISTINCT [week_key]) AS [weeks],
    MIN([week_key]) AS [first_week],
    MAX([week_key]) AS [last_week],
    COUNT([target_value]) AS [target_rows],
    COUNT([variance_value]) AS [variance_rows]
FROM [sharepoint].[kpi_result_quality_mb_v1]
GROUP BY [kpi_code]
ORDER BY [kpi_code];

-- E. Detailed result review.
SELECT *
FROM [sharepoint].[kpi_result_quality_mb_v1]
ORDER BY [week_key], [kpi_code];

-- F. Publish after review.
EXEC [sharepoint].[usp_publish_quality_mb_kpis_v1];

-- G. Domain final check.
SELECT *
FROM [sharepoint].[fact_kpi_result]
WHERE [kpi_code] IN
(
    'Quality Maybole-KPI P1',
    'Quality Maybole-KPI D1'
)
ORDER BY [week_key], [kpi_code];

-- H. Duplicate check. Expected: zero rows.
SELECT
    [week_key],
    [kpi_code],
    COUNT_BIG(*) AS [row_count]
FROM [sharepoint].[fact_kpi_result]
WHERE [kpi_code] IN
(
    'Quality Maybole-KPI P1',
    'Quality Maybole-KPI D1'
)
GROUP BY [week_key], [kpi_code]
HAVING COUNT_BIG(*) > 1;

*/
