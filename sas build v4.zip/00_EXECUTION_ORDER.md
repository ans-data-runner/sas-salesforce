# EXECUTION ORDER — SAS KPI Reporting Build
Follow top to bottom. Tick each box. Anything marked ⚠ is a decision/path to set before running that step.

---

## STEP 0 — Pre-flight (5 min)

- [ ] ⚠ EHS energy CSVs uploaded to bronze: `Files/ehs/energy/EHS_nenergy_gas_data_Bridgend.csv` and `..._Maybole.csv` (or edit `SOURCE_FILES` in nb_010 to wherever you drop them)
- [ ] ⚠ Accident tracker uploaded to bronze: `Files/ehs/accidents/accident_tracker.csv` (or edit `BRONZE_SOURCE` in nb_030)
- [ ] ⚠ SafetyCulture bronze table name confirmed (`SafetyCultureTest` per the bronze PDF) — edit `BRONZE_SOURCE` in nb_020 if different
- [ ] Bronze Salesforce tables loaded as normal (`Estimating Request`, `Quote Line`, `Order Tracking`, `Customer Service`, proposal tables)
- [ ] Silver `dim_date` populated (your existing calendar notebook) — nb_005 reads it

## STEP 1 — Gold SQL (run in wh_sas_gold, in this order)

- [ ] `step1_gold_sql/01_ddl_kpi_model.sql`          — schemas `kpi` + `stg`, all tables
- [ ] `step1_gold_sql/02_sp_load_dim_week.sql`       — proc
- [ ] `step1_gold_sql/03_sp_load_fact_kpi_result.sql`— proc (RAG + TBC logic)
- [ ] `step1_gold_sql/04_vw_kpi_report.sql`          — the two reporting views
- [ ] `step1_gold_sql/05_seed_kpi_reference.sql`     — departments, all ~70 KPIs, targets, commentary
- Verify: `SELECT COUNT(*) FROM kpi.dim_kpi;` → ~64 rows, 18 active.
- ⏸ `06_migrate_fact_kpi_result_v2.sql` — do NOT run yet. Run after Step 5 verification, when you want v2 Design history carried over.

## STEP 2 — Import notebooks (one-time)

Import each `.py` in `step2_notebooks/` as a Fabric notebook (same names). Then in EVERY notebook except nb_000:
- [ ] Replace the commented line `# %run nb_000_env_config` with a real cell: `%run nb_000_env_config`

In `nb_000_env_config`:
- [ ] Confirm the parameters cell: `BRONZE_LAKEHOUSE = "bronze_lakehouse"`, `SILVER_LAKEHOUSE = "lh_sas_silver"`, `GOLD_WAREHOUSE = "wh_sas_gold"` (mark it as a parameters cell)
- [ ] Run the notebook once, then run `seed_emission_factors()` (uncomment the call) → creates silver `ref_emission_factor`

## STEP 3 — Calendar into gold

- [ ] Run notebook `nb_005_gold_stage_dim_week`
- [ ] In wh_sas_gold: `EXEC kpi.sp_load_dim_week;`
- Verify: `SELECT * FROM kpi.dim_week WHERE is_current_week = 1;` → exactly 1 row, this week's Friday.

## STEP 4 — Silver builds (can run in any order / parallel)

- [ ] `nb_010_silver_ehs_energy`        (⚠ check `CALENDAR_YEAR = 2026` matches the CSVs' Week No)
- [ ] `nb_020_silver_ehs_inspections`
- [ ] `nb_030_silver_ehs_accidents`
- [ ] `nb_040_silver_estimating_kpis`
- [ ] `nb_050_silver_sop_kpis`          (⚠ thresholds default to workbook rules: cleansing ≤1 day, sign-off ≤5; `FTE_HEADCOUNT = None` until SAS supply it)
- Verify: each notebook's final `display()` shows weekly rows with sensible values.

## STEP 5 — Stage + load facts

- [ ] Run `nb_100_gold_stage_ehs_kpis`
- [ ] Run `nb_110_gold_stage_salesforce_kpis`
- [ ] In wh_sas_gold: `EXEC kpi.sp_load_fact_kpi_result;`
  (If it throws error 50001, a staged kpi_code/week didn't resolve — the message tells you; nothing is part-loaded.)
- Verify:
```sql
SELECT department_code, rag_status, COUNT(*) rows_
FROM   kpi.vw_kpi_report GROUP BY department_code, rag_status ORDER BY 1,2;

SELECT * FROM kpi.vw_kpi_report_header;

-- spot-check EHS wk 48 FY25 vs the 2026 template:
-- P1 lost days 0/G, D1 124/G (target 100), Q1 94/G (target 90)
SELECT kpi_code, week_label, target_value, actual_value, display_value, rag_status
FROM   kpi.vw_kpi_report
WHERE  department_code = 'EHS' AND week_end_date = '2025-11-28' ORDER BY sort_order;
```

## STEP 6 — Optional: migrate v2 history

- [ ] `step1_gold_sql/06_migrate_fact_kpi_result_v2.sql` (Design history from `[salesforce].[fact_kpi_result_v2]`; old table untouched)

## STEP 7 — Schedule pipeline `pl_kpi_weekly` (Mon am)

nb_005 → **SP** `kpi.sp_load_dim_week` → [nb_010 ∥ nb_020 ∥ nb_030 ∥ nb_040 ∥ nb_050] → nb_100 → nb_110 → **SP** `kpi.sp_load_fact_kpi_result`

## STEP 8 — Point Power BI

Matrix → `kpi.vw_kpi_report` · header → `kpi.vw_kpi_report_header` · detail pages → silver `slv_ehs_inspection` / `slv_ehs_accident`. Field mapping: `docs/DOC_02`.

---
**If something fails:** every notebook fails fast with a named assertion (unmapped CSV column, week not in calendar); the fact proc refuses unresolved codes rather than dropping rows; re-running any step is safe (silver = overwrite, fact = delete+insert per KPI-week, staging cleared on consume).
